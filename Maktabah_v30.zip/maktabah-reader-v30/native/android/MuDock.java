package com.kr.urdulibrary;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewConfiguration;
import java.util.ArrayList;
import java.util.List;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * The annotate toolbar at the bottom of the reader: tool, colour, thickness, opacity, shape, snap, undo / redo.
 * It only edits the MuInk settings; the activity reacts through Cb. Add new tools (sticker, note pin) as new chips here.
 */
final class MuDock extends LinearLayout {
    interface Cb {
        void onTool(int tool);
        void onChanged();
        void onUndo();
        void onRedo();
        void onDone();
        void onAction(int id);
        /** The settings / appearance card opened or closed (the activity shows or hides the tap-outside catcher). */
        void onOverlay(boolean shown);
    }

    static final int SEARCH = 1, CONTENTS = 3, THEME = 4, LOOK = 5, GOTO = 6;

    interface Str { String s(String key); }

    private final MuInk ink;
    private final Cb cb;
    private final Str str;
    private final float d;
    private int bg = 0xFFFFFFFF, fg = 0xFF1C2420, sub = 0xFF6B7770, chip = 0xFFEDEDE8, accent = 0xFF176B4D;

    private final LinearLayout toolRow, optBox, panelBox, cards, items;
    private final ScrollView cardScroll;      // floating card layer; the activity places it next to the tray
    private boolean overlayWas = false;
    private final HorizontalScrollView hTray;
    private final ScrollView vTray;
    private final List<View> dividers = new ArrayList<>();
    private int side = 0;                  // tray position: 0 bottom, 1 left, 2 right
    private final LinearLayout[] toolItem = new LinearLayout[4];       // read, marker, pen, eraser
    private final MuReaderActivity.IconView[] toolIcon = new MuReaderActivity.IconView[4];
    private final TextView[] toolText = new TextView[4];
    private final LineBadge[] lineBadge = new LineBadge[4];            // "straight line on" mark on marker / pen
    private long lastTapAt = 0;
    private int lastTapTool = -1;
    private final Runnable pendingOpts = new Runnable() {     // settings open only after the double-tap window has passed
        @Override public void run() { hidePanelQuiet(); optsShown = !optsShown; refresh(); }
    };
    private View colorScroll, thickRow, opacRow, eraseRow;
    private final TextView[] eraseChip = new TextView[2];
    private LinearLayout undoItem, redoItem, themeItem;
    private TextView themeText;
    private int themeIdx = 0;
    private final LinearLayout colorRow;
    private final MuReaderActivity.Swatch[] sw = new MuReaderActivity.Swatch[MuAnnot.FILL.length];
    private final SeekBar thick, opac;
    private final Preview preview;
    private final TextView thickLbl, opacLbl;
    private final TextView[] shapeChip = new TextView[3];
    private final TextView snapChip, tipChip;
    private final View shapeRow, snapRow;
    private boolean optsShown = false;     // settings open only when the active tool is tapped again
    private boolean quiet = false;

    MuDock(Context c, MuInk ink, Cb cb, Str str) {
        super(c);
        this.ink = ink; this.cb = cb; this.str = str;
        d = c.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        setClickable(true);
        setPadding(dp(12), 0, dp(12), dp(10));

        // ---- tray: one scrollable row with every reader option
        toolRow = new LinearLayout(c);
        toolRow.setOrientation(HORIZONTAL);
        toolRow.setGravity(Gravity.CENTER_VERTICAL);
        hTray = new HorizontalScrollView(c);
        hTray.setHorizontalScrollBarEnabled(false);
        hTray.setOverScrollMode(OVER_SCROLL_NEVER);
        vTray = new ScrollView(c);
        vTray.setVerticalScrollBarEnabled(false);
        vTray.setOverScrollMode(OVER_SCROLL_NEVER);
        items = new LinearLayout(c);
        items.setOrientation(HORIZONTAL);
        items.setGravity(Gravity.CENTER_VERTICAL);
        final int[] tIcons = {MuReaderActivity.IconView.POINTER, MuReaderActivity.IconView.MARKER, MuReaderActivity.IconView.PEN, MuReaderActivity.IconView.ERASER};
        final String[] tKeys = {"read", "tool_marker", "tool_pen", "tool_eraser"};
        for (int i = 0; i < 4; i++) {
            final int tool = i;                      // 0 = read (no tool), 1..3 = marker, pen, eraser
            toolIcon[i] = trayIcon(c, tIcons[i]);
            toolText[i] = trayText(c, str.s(tKeys[i]));
            View iconView = toolIcon[i];
            if (tool != 0) {
                FrameLayout box = new FrameLayout(c);
                box.addView(toolIcon[i], new FrameLayout.LayoutParams(-1, -1));
                lineBadge[i] = new LineBadge(c, tool == MuInk.ERASER);
                FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(dp(15), dp(15), Gravity.TOP | Gravity.END);
                blp.topMargin = dp(-2);
                blp.setMarginEnd(dp(1));
                box.addView(lineBadge[i], blp);
                iconView = box;
            }
            toolItem[i] = trayItem(c, iconView, toolText[i], v -> onToolTap(tool));
            items.addView(toolItem[i], trayLp());
        }
        items.addView(divider(c));
        MuReaderActivity.IconView ui = trayIcon(c, MuReaderActivity.IconView.UNDO);
        undoItem = trayItem(c, ui, trayText(c, str.s("undo")), v -> cb.onUndo());
        MuReaderActivity.IconView ri = trayIcon(c, MuReaderActivity.IconView.REDO);
        redoItem = trayItem(c, ri, trayText(c, str.s("redo")), v -> cb.onRedo());
        items.addView(undoItem, trayLp());
        items.addView(redoItem, trayLp());
        items.addView(divider(c));
        items.addView(action(c, GOTO, MuReaderActivity.IconView.GOTO, str.s("page")), trayLp());
        themeText = trayText(c, str.s("paper"));
        themeItem = trayItem(c, trayIcon(c, MuReaderActivity.IconView.THEME), themeText, v -> cb.onAction(THEME));
        items.addView(themeItem, trayLp());
        items.addView(action(c, LOOK, MuReaderActivity.IconView.SLIDERS, str.s("look")), trayLp());
        toolRow.setPadding(dp(6), dp(4), dp(6), dp(4));
        toolRow.setElevation(dp(6));
        toolRow.setClickable(true);

        cards = new LinearLayout(c);
        cards.setOrientation(VERTICAL);
        cardScroll = new ScrollView(c);
        cardScroll.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        cardScroll.setVerticalScrollBarEnabled(false);
        cardScroll.setOverScrollMode(OVER_SCROLL_NEVER);
        cardScroll.setClipToPadding(false);               // leave room for the card shadow
        cardScroll.setClipChildren(false);
        cardScroll.setPadding(dp(12), dp(8), dp(12), dp(8));
        cardScroll.addView(cards, new ViewGroup.LayoutParams(-1, -2));
        cardScroll.setVisibility(GONE);

        // ---- options (hidden for the eraser, or when collapsed)
        optBox = new LinearLayout(c);
        optBox.setOrientation(VERTICAL);
        optBox.setPadding(dp(14), dp(6), dp(14), dp(8));
        optBox.setElevation(dp(6));
        optBox.setClickable(true);
        cards.addView(optBox, new LayoutParams(-1, -2));

        // ---- floating panel (appearance), same slot as the options card
        panelBox = new LinearLayout(c);
        panelBox.setOrientation(VERTICAL);
        panelBox.setPadding(dp(16), dp(12), dp(16), dp(12));
        panelBox.setElevation(dp(6));
        panelBox.setClickable(true);
        panelBox.setVisibility(GONE);
        cards.addView(panelBox, 0, new LayoutParams(-1, -2));

        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        colorRow = new LinearLayout(c);
        colorRow.setOrientation(HORIZONTAL);
        colorRow.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < sw.length; i++) {
            final int ci = i;
            sw[i] = new MuReaderActivity.Swatch(c, MuAnnot.INK[i], false);
            sw[i].setOnClickListener(v -> { ink.color = ci; syncSwatches(); cb.onChanged(); invalidatePreview(); });
            LayoutParams lp = new LayoutParams(dp(38), dp(38));
            colorRow.addView(sw[i], lp);
        }
        colorScroll = hs;
        hs.addView(colorRow, new ViewGroup.LayoutParams(-2, -2));
        LayoutParams hlp = new LayoutParams(-1, dp(42));
        hlp.topMargin = dp(8);
        optBox.addView(hs, hlp);

        thickLbl = label(c, str.s("thick"));
        thick = seek(c);
        thick.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (quiet || !user) return;
                float t = p / 100f;
                ink.setWidth(MuInk.MIN_W + t * t * (ink.maxW() - MuInk.MIN_W));
                invalidatePreview(); cb.onChanged();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        preview = new Preview(c);
        LinearLayout r1 = new LinearLayout(c);
        r1.setOrientation(HORIZONTAL);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        r1.addView(thickLbl, new LayoutParams(dp(74), -2));
        r1.addView(thick, new LayoutParams(0, dp(34), 1f));
        LayoutParams plp = new LayoutParams(dp(52), dp(30));
        plp.setMarginStart(dp(10));
        r1.addView(preview, plp);
        thickRow = r1;
        optBox.addView(r1, new LayoutParams(-1, dp(38)));

        opacLbl = label(c, str.s("opacity"));
        opac = seek(c);
        opac.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (quiet || !user) return;
                ink.setAlpha(15 + Math.round(p * 0.85f));
                invalidatePreview(); cb.onChanged();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        LinearLayout r2 = new LinearLayout(c);
        r2.setOrientation(HORIZONTAL);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        r2.addView(opacLbl, new LayoutParams(dp(74), -2));
        r2.addView(opac, new LayoutParams(0, dp(34), 1f));
        opacRow = r2;
        optBox.addView(r2, new LayoutParams(-1, dp(38)));

        LinearLayout sr = new LinearLayout(c);
        sr.setOrientation(HORIZONTAL);
        sr.setGravity(Gravity.CENTER_VERTICAL);
        final String[] sk = {"shape_free", "shape_line", "shape_box"};
        for (int i = 0; i < 3; i++) {
            final int shape = i;
            TextView t = pill(c, str.s(sk[i]));
            t.setOnClickListener(v -> { ink.setShape(shape); refresh(); cb.onChanged(); });
            shapeChip[i] = t;
            LayoutParams lp = new LayoutParams(-2, dp(34));
            lp.setMarginEnd(dp(6));
            sr.addView(t, lp);
        }
        shapeRow = sr;
        LayoutParams srl = new LayoutParams(-1, dp(38));
        srl.topMargin = dp(4);
        optBox.addView(sr, srl);

        LinearLayout nr = new LinearLayout(c);
        nr.setOrientation(HORIZONTAL);
        nr.setGravity(Gravity.CENTER_VERTICAL);
        snapChip = pill(c, str.s("snap"));
        snapChip.setOnClickListener(v -> { ink.snap = !ink.snap; refresh(); cb.onChanged(); });
        tipChip = pill(c, str.s("tip_flat"));
        tipChip.setOnClickListener(v -> { ink.flat = !ink.flat; refresh(); cb.onChanged(); });
        LayoutParams l1 = new LayoutParams(-2, dp(34));
        l1.setMarginEnd(dp(6));
        nr.addView(snapChip, l1);
        nr.addView(tipChip, new LayoutParams(-2, dp(34)));
        snapRow = nr;
        LayoutParams nrl = new LayoutParams(-1, dp(38));
        nrl.topMargin = dp(2);
        optBox.addView(nr, nrl);

        LinearLayout er = new LinearLayout(c);
        er.setOrientation(HORIZONTAL);
        er.setGravity(Gravity.CENTER_VERTICAL);
        final String[] ek = {"erase_whole", "erase_free"};
        for (int i = 0; i < 2; i++) {
            final int mode = i;
            TextView t = pill(c, str.s(ek[i]));
            t.setOnClickListener(v -> { ink.eraseMode = mode; refresh(); cb.onChanged(); });
            eraseChip[i] = t;
            LayoutParams lp = new LayoutParams(-2, dp(34));
            lp.setMarginEnd(dp(6));
            er.addView(t, lp);
        }
        eraseRow = er;
        LayoutParams erl = new LayoutParams(-1, dp(42));
        erl.topMargin = dp(4);
        optBox.addView(er, 0, erl);

        setSide(0);
        refresh();
    }

    /** Tap: select / open settings. Quick second tap on marker, pen or eraser: straight line / erasing way on-off. */
    private void onToolTap(int tool) {
        removeCallbacks(pendingOpts);
        long now = SystemClock.uptimeMillis();
        if (tool != 0 && tool == lastTapTool && now - lastTapAt <= ViewConfiguration.getDoubleTapTimeout()) {
            lastTapAt = 0; lastTapTool = -1;
            if (ink.tool != tool) { hidePanelQuiet(); optsShown = false; ink.tool = tool; cb.onTool(tool); }
            if (tool == MuInk.ERASER) ink.eraseMode = ink.eraseMode == MuInk.FREEHAND ? MuInk.WHOLE : MuInk.FREEHAND;
            else ink.setShape(ink.shape() == MuInk.LINE ? MuInk.FREE : MuInk.LINE);
            toolItem[tool].performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            refresh(); cb.onChanged();
            return;
        }
        lastTapAt = now; lastTapTool = tool;
        if (ink.tool == tool && tool != 0) postDelayed(pendingOpts, ViewConfiguration.getDoubleTapTimeout());
        else { hidePanelQuiet(); optsShown = false; ink.tool = tool; cb.onTool(tool); refresh(); }
    }

    private LayoutParams trayLp() { return new LayoutParams(dp(66), dp(56)); }

    private View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(0x33888888);
        LayoutParams lp = new LayoutParams(dp(1), dp(28));
        lp.setMargins(dp(4), 0, dp(4), 0);
        v.setLayoutParams(lp);
        dividers.add(v);
        return v;
    }

    /** Where the tray sits: 0 = bottom, 1 = left edge, 2 = right edge. The settings card is a separate layer (overlayView). */
    void setSide(int s) {
        side = s;
        boolean sd = s != 0;
        setClickable(!sd);
        removeAllViews();
        toolRow.removeAllViews();
        hTray.removeAllViews();
        vTray.removeAllViews();
        setOrientation(sd ? HORIZONTAL : VERTICAL);
        toolRow.setOrientation(sd ? VERTICAL : HORIZONTAL);
        toolRow.setGravity(sd ? Gravity.CENTER_HORIZONTAL : Gravity.CENTER_VERTICAL);
        items.setOrientation(sd ? VERTICAL : HORIZONTAL);
        items.setGravity(sd ? Gravity.CENTER_HORIZONTAL : Gravity.CENTER_VERTICAL);
        for (View dv : dividers) {
            LayoutParams lp = sd ? new LayoutParams(dp(28), dp(1)) : new LayoutParams(dp(1), dp(28));
            if (sd) lp.setMargins(0, dp(4), 0, dp(4)); else lp.setMargins(dp(4), 0, dp(4), 0);
            dv.setLayoutParams(lp);
        }
        if (sd) {
            vTray.addView(items, new ViewGroup.LayoutParams(-2, -2));
            toolRow.addView(vTray, new LayoutParams(-2, -2));
            LayoutParams rowLp = new LayoutParams(-2, -2);
            rowLp.gravity = Gravity.CENTER_VERTICAL;
            addView(toolRow, rowLp);
        } else {
            hTray.addView(items, new ViewGroup.LayoutParams(-2, -2));
            toolRow.addView(hTray, new LayoutParams(0, -2, 1f));
            addView(toolRow, new LayoutParams(-1, -2));
        }
        refresh();
    }

    /** The floating settings / appearance card. The activity adds it to the reader and positions it beside the tray. */
    View overlayView() { return cardScroll; }

    /** Closes the settings / appearance card. Returns true when something was open. */
    boolean dismissOverlays() {
        removeCallbacks(pendingOpts);
        boolean was = optsShown || isPanelShown();
        optsShown = false;
        hidePanelQuiet();
        refresh();
        return was;
    }

    int side() { return side; }

    /** Width the tray strip takes at the left / right edge, including its margin. */
    int stripWidth() { return dp(90); }

    private MuReaderActivity.IconView trayIcon(Context c, int kind) {
        MuReaderActivity.IconView v = new MuReaderActivity.IconView(c, kind);
        v.setScale(0.8f);
        v.setBackground(null);
        v.setClickable(false);
        return v;
    }

    private TextView trayText(Context c, String t) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(10.5f);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        v.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return v;
    }

    private LinearLayout trayItem(Context c, View icon, TextView label, OnClickListener l) {
        LinearLayout b = new LinearLayout(c);
        b.setOrientation(VERTICAL);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(3), dp(2), dp(3), dp(2));
        b.addView(icon, new LayoutParams(dp(40), dp(28)));
        b.addView(label, new LayoutParams(-1, -2));
        b.setContentDescription(label.getText());
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout action(Context c, final int id, int kind, String label) {
        return trayItem(c, trayIcon(c, kind), trayText(c, label), v -> cb.onAction(id));
    }

    void showPanel(View content) {
        panelBox.removeAllViews();
        panelBox.addView(content, new LayoutParams(-1, -2));
        panelBox.setVisibility(VISIBLE);
        refresh();
    }

    void hidePanel() {
        if (panelBox.getVisibility() == VISIBLE) { panelBox.setVisibility(GONE); panelBox.removeAllViews(); refresh(); }
    }

    private void hidePanelQuiet() { panelBox.setVisibility(GONE); panelBox.removeAllViews(); }

    boolean isPanelShown() { return panelBox.getVisibility() == VISIBLE; }

    void setThemeIdx(int idx) {
        themeIdx = idx;
        themeText.setText(str.s(idx == 2 ? "night" : idx == 1 ? "sepia" : "paper"));
    }

    private int dp(float v) { return Math.round(v * d); }

    private void invalidatePreview() { if (preview != null) preview.invalidate(); }

    private MuReaderActivity.IconView icon(Context c, int kind, String desc) {
        MuReaderActivity.IconView v = new MuReaderActivity.IconView(c, kind);
        v.setScale(0.58f);
        v.setBackground(null);
        v.setContentDescription(desc);
        return v;
    }

    private TextView label(Context c, String t) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(12f);
        v.setSingleLine(true);
        return v;
    }

    private TextView pill(Context c, String t) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(12.5f);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        v.setPadding(dp(13), 0, dp(13), 0);
        return v;
    }

    private SeekBar seek(Context c) {
        SeekBar s = new SeekBar(c);
        s.setMax(100);
        s.setPadding(dp(14), 0, dp(14), 0);
        return s;
    }

    private GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    // ------------------------------------------------------------------ public
    void restyle(int bg, int fg, int sub, int chip, int accent) {
        this.bg = bg; this.fg = fg; this.sub = sub; this.chip = chip; this.accent = accent;
        toolRow.setBackground(round(bg, 20));
        optBox.setBackground(round(bg, 18));
        panelBox.setBackground(round(bg, 18));
        refresh();
    }

    void setUndoState(boolean canUndo, boolean canRedo) {
        undoItem.setAlpha(canUndo ? 1f : 0.3f);
        redoItem.setAlpha(canRedo ? 1f : 0.3f);
        undoItem.setEnabled(canUndo);
        redoItem.setEnabled(canRedo);
    }

    /** Re-reads everything from the MuInk settings. */
    void refresh() {
        quiet = true;
        boolean eraser = ink.tool == MuInk.ERASER;
        for (int i = 0; i < 4; i++) {
            boolean on = ink.tool == i;
            toolItem[i].setBackground(round(on ? accent : 0x00000000, 16));
            toolIcon[i].setColor(on ? 0xFFFFFFFF : fg);
            toolText[i].setTextColor(on ? 0xFFFFFFFF : sub);
            if (lineBadge[i] != null) {
                boolean badge = i == MuInk.ERASER ? ink.eraseMode == MuInk.FREEHAND : (i == MuInk.PEN ? ink.penShape : ink.markerShape) == MuInk.LINE;
                lineBadge[i].setOn(badge, on ? 0xFFFFFFFF : accent, on ? accent : 0xFFFFFFFF);
            }
        }
        for (LinearLayout it : new LinearLayout[]{undoItem, redoItem, themeItem}) {
            ((MuReaderActivity.IconView) it.getChildAt(0)).setColor(fg);
            ((TextView) it.getChildAt(1)).setTextColor(sub);
        }
        applyTrayRest();
        optBox.setVisibility(ink.tool == MuInk.OFF || !optsShown || isPanelShown() ? GONE : VISIBLE);
        boolean overlay = optBox.getVisibility() == VISIBLE || isPanelShown();
        cards.setVisibility(overlay ? VISIBLE : GONE);
        cardScroll.setVisibility(overlay ? VISIBLE : GONE);
        if (overlay != overlayWas) { overlayWas = overlay; if (cb != null) cb.onOverlay(overlay); }
        boolean freeErase = eraser && ink.eraseMode == MuInk.FREEHAND;
        eraseRow.setVisibility(eraser ? VISIBLE : GONE);
        colorScroll.setVisibility(eraser ? GONE : VISIBLE);
        opacRow.setVisibility(eraser ? GONE : VISIBLE);
        thickRow.setVisibility(!eraser || freeErase ? VISIBLE : GONE);
        for (int i = 0; i < 2; i++) {
            boolean on = ink.eraseMode == i;
            eraseChip[i].setBackground(round(on ? accent : chip, 17));
            eraseChip[i].setTextColor(on ? 0xFFFFFFFF : fg);
        }
        boolean marker = ink.tool == MuInk.MARKER;
        int colors = marker ? MuAnnot.TEXT_COLORS : MuAnnot.FILL.length;
        if (ink.color >= colors) ink.color = 0;
        for (int i = 0; i < sw.length; i++) sw[i].setVisibility(i < colors ? VISIBLE : GONE);
        syncSwatches();
        thickLbl.setTextColor(sub); opacLbl.setTextColor(sub);
        tint(thick); tint(opac);
        float t = (ink.width() - MuInk.MIN_W) / (ink.maxW() - MuInk.MIN_W);
        thick.setProgress(Math.round((float) Math.sqrt(Math.max(0f, Math.min(1f, t))) * 100f));
        opac.setProgress(Math.round((ink.alpha() - 15) / 0.85f));
        for (int i = 0; i < 3; i++) {
            shapeChip[i].setVisibility(eraser ? GONE : VISIBLE);
            boolean on = ink.shape() == i;
            shapeChip[i].setBackground(round(on ? accent : chip, 17));
            shapeChip[i].setTextColor(on ? 0xFFFFFFFF : fg);
        }
        snapChip.setVisibility(marker && ink.shape() != MuInk.BOX ? VISIBLE : GONE);
        tipChip.setVisibility(marker ? VISIBLE : GONE);
        snapChip.setBackground(round(ink.snap ? accent : chip, 17));
        snapChip.setTextColor(ink.snap ? 0xFFFFFFFF : fg);
        tipChip.setText(str.s(ink.flat ? "tip_flat" : "tip_round"));
        tipChip.setBackground(round(chip, 17));
        tipChip.setTextColor(fg);
        snapRow.setVisibility(marker ? VISIBLE : GONE);
        shapeRow.setVisibility(eraser ? GONE : VISIBLE);
        preview.invalidate();
        quiet = false;
    }

    /** Items that are plain actions keep the theme colours. */
    private void applyTrayRest() {
        for (int i = 0; i < items.getChildCount(); i++) {
            View v = items.getChildAt(i);
            if (!(v instanceof LinearLayout) || ((LinearLayout) v).getChildCount() != 2) continue;
            View ic = ((LinearLayout) v).getChildAt(0), tx = ((LinearLayout) v).getChildAt(1);
            boolean tool = v == toolItem[0] || v == toolItem[1] || v == toolItem[2] || v == toolItem[3];
            if (!tool && ic instanceof MuReaderActivity.IconView) {
                ((MuReaderActivity.IconView) ic).setColor(fg);
                ((TextView) tx).setTextColor(sub);
            }
        }
    }

    private void tint(SeekBar s) {
        try {
            s.getProgressDrawable().setColorFilter(accent, android.graphics.PorterDuff.Mode.SRC_IN);
            s.getThumb().setColorFilter(accent, android.graphics.PorterDuff.Mode.SRC_IN);
        } catch (Throwable ignored) { }
    }

    private void syncSwatches() {
        for (int i = 0; i < sw.length; i++) sw[i].setOn(i == ink.color);
    }

    /** Small round mark with a diagonal line; pops in when straight-line mode is on. */
    private final class LineBadge extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int fill = 0xFFFFFFFF, stroke = 0xFF176B4D;
        private boolean shown = false;

        private final boolean curve;

        LineBadge(Context c, boolean curve) {
            super(c);
            this.curve = curve;
            setClickable(false);
            setAlpha(0f); setScaleX(0.3f); setScaleY(0.3f);
            setVisibility(INVISIBLE);
        }

        void setOn(boolean on, int fill, int stroke) {
            boolean colorChanged = this.fill != fill || this.stroke != stroke;
            this.fill = fill; this.stroke = stroke;
            if (colorChanged) invalidate();
            if (on == shown) return;
            shown = on;
            if (on) {
                setVisibility(VISIBLE);
                animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start();
            } else {
                animate().alpha(0f).scaleX(0.3f).scaleY(0.3f).setDuration(140)
                        .withEndAction(() -> { if (!shown) setVisibility(INVISIBLE); }).start();
            }
        }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), r = Math.min(w, h) / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(fill);
            cv.drawCircle(w / 2f, h / 2f, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(dp(1.8f));
            p.setColor(stroke);
            float k = r * 0.46f;
            if (!curve) { cv.drawLine(w / 2f - k, h / 2f + k, w / 2f + k, h / 2f - k, p); return; }
            android.graphics.Path sp = new android.graphics.Path();
            sp.moveTo(w / 2f - k, h / 2f + k * 0.5f);
            sp.cubicTo(w / 2f - k * 0.2f, h / 2f - k * 1.5f, w / 2f + k * 0.2f, h / 2f + k * 1.5f, w / 2f + k, h / 2f - k * 0.5f);
            p.setStrokeWidth(dp(1.5f));
            cv.drawPath(sp, p);
        }
    }

    /** Live sample of the current stroke: real thickness relative to the page width. */
    private final class Preview extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        Preview(Context c) { super(c); }

        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            r.set(0, 0, w, h);
            p.setStyle(Paint.Style.FILL);
            p.setColor(chip);
            cv.drawRoundRect(r, dp(10), dp(10), p);
            if (ink.tool == MuInk.ERASER) {
                float rad = Math.max(dp(3), (ink.eraserW / MuInk.ERASER_MAX_W) * (h - dp(6)) / 2f);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1.6f));
                p.setColor(fg);
                cv.drawCircle(w / 2f, h / 2f, rad, p);
                return;
            }
            float screen = getResources().getDisplayMetrics().widthPixels;
            float th = Math.max(dp(1.5f), Math.min(h - dp(4), ink.width() * screen));
            int base = ink.tool == MuInk.MARKER ? MuAnnot.FILL[Math.min(ink.color, MuAnnot.FILL.length - 1)] : MuAnnot.INK[Math.min(ink.color, MuAnnot.INK.length - 1)];
            p.setColor(MuAnnot.alphaOf(base, ink.alpha()));
            float x0 = dp(9), x1 = w - dp(9), cy = h / 2f;
            if (ink.tool == MuInk.MARKER && ink.flat) {
                r.set(x0, cy - th / 2f, x1, cy + th / 2f);
                cv.drawRect(r, p);
            } else {
                r.set(x0, cy - th / 2f, x1, cy + th / 2f);
                cv.drawRoundRect(r, th / 2f, th / 2f, p);
            }
        }
    }
}
