// Supabase is used ONLY for the book catalogue. The rest of the app (shell, navigation,
// classes/categories fallback, settings, favourites, reader) must keep working when the
// server is slow, blocked or unreachable. So this file guarantees three things:
//   1. importing it can never hang the app (bounded library load, offline stub if it fails),
//   2. every request has a hard timeout (no more "skeleton forever"),
//   3. after a failure we fail fast for a short cool-down instead of stacking up new hangs.
//
// Inside the Android app the library is bundled (/vendor/supabase.js) so the app
// starts offline; in a normal browser it falls back to the CDN.

export const SUPABASE_URL = 'https://nyjtwqhcwxnxzerimsch.supabase.co';
export const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_J_J6MS17c6DYSOrJDgOfRg_KbX5bNV6';

const REQUEST_TIMEOUT_MS = 10000;   // hard limit for any single Supabase request
const FAST_FAIL_COOLDOWN_MS = 6000; // after an immediate network error
const TIMEOUT_COOLDOWN_MS = 20000;  // after a request that timed out

function withTimeout(promise, ms, label) {
  let timer;
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`${label} timed out`)), ms); });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

async function loadCreateClient() {
  try {
    return (await withTimeout(import('/vendor/supabase.js'), 4000, 'bundled supabase')).createClient;
  } catch {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      console.warn('Offline: skipping the Supabase CDN, running with local data only.');
      return null;
    }
    try {
      return (await withTimeout(import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm'), 3500, 'supabase CDN')).createClient;
    } catch (error) {
      console.warn('Supabase library unavailable; running with local data only.', error);
      return null;
    }
  }
}

let downUntil = 0;
/** Forget earlier failures (used before a user-requested retry, and when the network comes back). */
export function resetServerHealth() { downUntil = 0; }
if (typeof window !== 'undefined') window.addEventListener('online', resetServerHealth);

function networkError(message, code) {
  const error = new Error(message);
  error.code = code;
  error.retryable = true;
  return error;
}

async function guardedFetch(input, init = {}) {
  if (Date.now() < downUntil) throw networkError('Server unreachable (waiting before retry)', 'COOLDOWN');
  const controller = new AbortController();
  const outer = init.signal;
  if (outer) {
    if (outer.aborted) controller.abort();
    else outer.addEventListener('abort', () => controller.abort(), { once: true });
  }
  let timedOut = false;
  const timer = setTimeout(() => { timedOut = true; controller.abort(); }, REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(input, { ...init, signal: controller.signal });
    downUntil = 0;
    return response;
  } catch (error) {
    if (timedOut) {
      downUntil = Date.now() + TIMEOUT_COOLDOWN_MS;
      throw networkError('Request timed out', 'TIMEOUT');
    }
    if (!(outer && outer.aborted)) downUntil = Date.now() + FAST_FAIL_COOLDOWN_MS;
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

// Same chainable shape as the real client, but every query resolves with an error.
// The data layer already knows how to fall back to cached / bundled data on errors.
function createOfflineClient() {
  const failure = { data: null, count: null, error: { message: 'Supabase library unavailable', code: 'UNAVAILABLE' } };
  const make = () => new Proxy(function () {}, {
    get(_, prop) {
      if (prop === 'then') return (resolve) => resolve(failure);
      if (prop === 'getPublicUrl') return () => ({ data: { publicUrl: '' } });
      return make();
    },
    apply() { return make(); }
  });
  return make();
}

const createClient = await loadCreateClient();

export const supabase = createClient
  ? createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, storageKey: 'kr-urdu-library-public' },
      global: { fetch: guardedFetch }
    })
  : createOfflineClient();
