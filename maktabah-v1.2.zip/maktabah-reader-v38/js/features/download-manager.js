import { addDownloadRecord, addPendingDownload, removePendingDownload, getPendingDownloads } from "./downloads-store.js";
/*
 * Maktabah — Download Manager
 *
 * Download orchestration: native Android DownloadManager (progress, cancel, retry) or a direct browser download.
 * The manager is intentionally framework-free and SPCK-compatible.
 * Cancellation has an explicit intermediate state so the UI can confirm the abort.
 */

const ACTIVE = new Map();
const RETRYABLE = new Map();
const SUBSCRIBERS = new Set();

export const DOWNLOAD_STATES = Object.freeze({
  IDLE: "idle",
  PREPARING: "preparing",
  DOWNLOADING: "downloading",
  COMPLETING: "completing",
  CANCELLING: "cancelling",
  HANDING_OFF: "handing-off",
  HANDED_OFF: "handed-off",
  COMPLETED: "completed",
  FAILED: "failed",
  CANCELLED: "cancelled"
});

function safeFilename(value){
  return (value || "Maktabah Book")
    .replace(/[\\/:*?"<>|]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 180)
    .replace(/[. ]+$/, "") || "Maktabah Book";
}

function buildFilename(book){
  const title = safeFilename(book?.titleEn || book?.title || "Maktabah Book");
  return `${title}.pdf`;
}

function emit(callbacks, state, detail = {}){
  const payload = { state, ...detail };
  try { callbacks?.onStateChange?.(payload); } catch (err) { console.error("Download state callback failed", err); }
  try { callbacks?.[state]?.(payload); } catch (err) { console.error("Download callback failed", err); }
  for(const listener of SUBSCRIBERS){
    try { listener(payload); } catch (err) { console.error("Download subscriber failed", err); }
  }
  return payload;
}

function triggerDirectDownload(url, filename){
  if(!url) throw new Error("Download URL is required");
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  a.remove();
}


function bytesToMegabytes(bytes){
  if(!Number.isFinite(bytes) || bytes < 0) return null;
  return bytes / (1024 * 1024);
}

function createDownloadError(message, code, retryable = true){
  const error = new Error(message);
  error.code = code;
  error.retryable = retryable;
  return error;
}

// ---------------------------------------------------------------------------
// Native Android downloads (Capacitor APK)
// Uses the KRDownloader plugin (Android DownloadManager) so the file is saved
// straight into the public Downloads folder with a system notification, and the
// user never leaves the app. Plain browsers/SPCK never have window.Capacitor, so
// they keep using the original fetch/blob flow untouched.
// ---------------------------------------------------------------------------
export const BUILD_TAG = "v1.2";

// A plain-JS app (no bundler) does NOT get Capacitor.registerPlugin, because that
// lives in @capacitor/core. The native bridge that Android injects always provides
// Capacitor.nativePromise, so we talk to the Java plugin through that directly.
let nativePlugin;
let nativePluginVia = "";
export function getNativePlugin(){
  if(nativePlugin !== undefined) return nativePlugin;
  nativePlugin = null;
  try{
    const cap = window.Capacitor;
    const isNative = Boolean(cap?.isNativePlatform?.() || cap?.getPlatform?.() === "android");
    if(isNative){
      if(typeof cap.registerPlugin === "function"){
        nativePlugin = cap.registerPlugin("KRDownloader");
        nativePluginVia = "reg";
      }else if(cap.Plugins?.KRDownloader){
        nativePlugin = cap.Plugins.KRDownloader;
        nativePluginVia = "plugins";
      }else if(typeof cap.nativePromise === "function"){
        nativePlugin = new Proxy({}, {
          get: (_, method) => method === "then" ? undefined : (options = {}) => cap.nativePromise("KRDownloader", String(method), options)
        });
        nativePluginVia = "np";
      }
    }
  }catch{}
  return nativePlugin;
}

// Short text shown on the download card so it is obvious which build is running
// and whether the native (Capacitor) downloader was detected.
export function nativeDiagnostics(){
  let cap = 0, native = 0, reg = 0, np = 0;
  try{
    const c = window.Capacitor;
    cap = c ? 1 : 0;
    native = (c?.isNativePlatform?.() || c?.getPlatform?.() === "android") ? 1 : 0;
    reg = typeof c?.registerPlugin === "function" ? 1 : 0;
    np = typeof c?.nativePromise === "function" ? 1 : 0;
  }catch{}
  return `${BUILD_TAG} cap:${cap} native:${native} reg:${reg} np:${np} plugin:${getNativePlugin() ? nativePluginVia : 0}`;
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function nativeFailureMessage(reason){
  const code = Number(reason);
  if(code === 1006) return "Not enough storage space on this device.";
  if(code === 1007) return "Storage is not available.";
  if(code === 1001) return "Could not write the file to Downloads.";
  if(code >= 400 && code < 600) return `Download failed: ${code}`;
  return "The download failed. Please try again.";
}

/** Saves the library record of a finished native download. Returns true when it was stored. */
function saveNativeRecord(meta, id, s, size){
  try{
    let savedName = meta.filename;
    if(s?.uri){
      try{
        const last = decodeURIComponent(String(s.uri).split("/").pop() || "");
        if(last) savedName = last;
      }catch{}
    }
    return addDownloadRecord({
      bookId: meta.bookId,
      downloadId: id,
      filename: savedName,
      title: meta.title || "",
      titleEn: meta.titleEn || "",
      author: meta.author || "",
      authorEn: meta.authorEn || "",
      cover: meta.cover || "",
      size
    });
  }catch(err){
    console.warn("Could not save the download record", err);
    return false;
  }
}

let recoverRuns = 0;
/**
 * Called once at start-up: a download that finished while the app was closed (or reloaded) gets its library record now.
 * Still-running downloads are checked again a little later.
 */
export async function recoverPendingDownloads(){
  const plugin = getNativePlugin();
  if(!plugin) return;
  const list = getPendingDownloads();
  if(!list.length) return;
  let stillRunning = false;
  for(const p of list){
    if(ACTIVE.has(p.bookId)) continue;           // this session is already following it
    try{
      const s = await plugin.status({ id: p.downloadId });
      if(!s || s.found === false || s.status === 16){ removePendingDownload(p.bookId); continue; }
      if(s.status === 8){
        if(/text\/html/i.test(String(s.mime || ""))){
          try{ await plugin.cancel({ id: p.downloadId }); }catch{}
        }else{
          const total = Number(s.total) > 0 ? Number(s.total) : (Number(s.downloaded) || 0);
          saveNativeRecord(p, p.downloadId, s, total);
        }
        removePendingDownload(p.bookId);
        continue;
      }
      stillRunning = true;
    }catch{ stillRunning = true; }
  }
  if(stillRunning && ++recoverRuns <= 30) setTimeout(() => { recoverPendingDownloads(); }, 10000);
}

class DownloadJob {
  constructor(book, url, options = {}){
    this.book = book;
    this.url = url;
    this.filename = buildFilename(book);
    this.callbacks = options;
    this.controller = new AbortController();
    this.nativeDownload = options.nativeDownload === true;
    this.options = { ...options };
    this.allowLargeFileHandoff = options.allowLargeFileHandoff !== false;
    this.largeFileThresholdBytes = Number.isFinite(options.largeFileThresholdBytes) ? options.largeFileThresholdBytes : (100 * 1024 * 1024);
    this.state = DOWNLOAD_STATES.IDLE;
    this.startedAt = 0;
    this.promise = null;
    this.lastProgress = {};
  }

  setState(state, detail = {}){
    this.state = state;
    this.lastProgress = { ...this.lastProgress, ...detail };
    return emit(this.callbacks, state, {
      bookId: this.book?.id ?? null,
      filename: this.filename,
      ...detail
    });
  }

  async run(){
    this.startedAt = Date.now();
    this.setState(DOWNLOAD_STATES.PREPARING);

    let nativeFallbackReason = "";
    if(!getNativePlugin()){
      nativeFallbackReason = window.Capacitor ? "native downloader not detected" : "not running inside Capacitor";
    }
    if(getNativePlugin() && this.options.disableNative !== true){
      try{
        return await this.runNative();
      }catch(err){
        if(err?.code !== "NATIVE_UNAVAILABLE" && err?.code !== "NATIVE_START_FAILED"){
          const result = {
            ok: false,
            state: DOWNLOAD_STATES.FAILED,
            mode: "native",
            bookId: this.book?.id ?? null,
            filename: this.filename,
            error: err,
            errorMessage: err?.message || ""
          };
          this.setState(DOWNLOAD_STATES.FAILED, result);
          if(err?.retryable !== false) {
            RETRYABLE.set(this.book?.id, { book: this.book, url: this.url, options: { ...this.options } });
          }
          throw err;
        }
        nativeFallbackReason = `start failed: ${err?.message || err?.code || "unknown"}`;
        console.warn("Native download could not start; falling back to browser flow.", err);
      }
    }

    // Not inside the Android app (or the native downloader could not start): open the file link directly,
    // the browser then saves it. Archive.org / Google Drive do not allow reading the file from JavaScript.
    return this.handOffToBrowser("direct", nativeFallbackReason ? { nativeFallbackReason } : {});
  }

  finishNativeCancel(){
    const result = {
      ok: false,
      state: DOWNLOAD_STATES.CANCELLED,
      mode: "native",
      bookId: this.book?.id ?? null,
      filename: this.filename,
      ...this.lastProgress
    };
    this.setState(DOWNLOAD_STATES.CANCELLED, result);
    RETRYABLE.set(this.book?.id, { book: this.book, url: this.url, options: { ...this.options } });
    return result;
  }

  async runNative(){
    try{
      return await this.runNativeInner();
    }finally{
      removePendingDownload(this.book?.id);     // finished, failed or cancelled in this session; only a killed app leaves it behind
    }
  }

  async runNativeInner(){
    const plugin = getNativePlugin();
    if(!plugin) throw createDownloadError("Native downloader is unavailable.", "NATIVE_UNAVAILABLE", false);

    let started;
    try{
      started = await plugin.start({ url: this.url, filename: this.filename, title: this.filename });
    }catch(err){
      throw createDownloadError(err?.message || "Could not start the download.", "NATIVE_START_FAILED", true);
    }
    const id = started?.id;
    if(id === undefined || id === null){
      throw createDownloadError("Could not start the download.", "NATIVE_START_FAILED", true);
    }
    this.nativeId = id;
    addPendingDownload({
      bookId: this.book?.id, downloadId: id, filename: this.filename,
      title: this.book?.title || "", titleEn: this.book?.titleEn || "",
      author: this.book?.author || "", authorEn: this.book?.authorEn || "", cover: this.book?.cover || ""
    });

    if(this.controller.signal.aborted){
      try{ await plugin.cancel({ id }); }catch{}
      return this.finishNativeCancel();
    }

    let lastAt = Date.now();
    let lastBytes = 0;
    let smoothedSpeed = 0;
    // Safety limits so this loop can never run forever: repeated status errors, or no new bytes for a long time.
    const maxStatusErrors = Number.isFinite(this.options.maxStatusErrors) ? this.options.maxStatusErrors : 20;
    const stallMs = Number.isFinite(this.options.stallMs) ? this.options.stallMs : 5 * 60 * 1000;
    let statusErrors = 0;
    let lastSeenBytes = -1;
    let lastProgressAt = Date.now();
    const abortNative = async (message, code) => {
      try{ await plugin.cancel({ id }); }catch{}
      throw createDownloadError(message, code, true);
    };

    this.setState(DOWNLOAD_STATES.DOWNLOADING, {
      mode: "native",
      progressSupported: true,
      sizeKnown: false,
      totalBytes: null,
      downloadedBytes: 0,
      downloadedMegabytes: 0,
      percentage: null
    });

    while(true){
      await sleep(500);
      if(this.controller.signal.aborted) return this.finishNativeCancel();

      let s;
      try{
        s = await plugin.status({ id });
        statusErrors = 0;
      }catch{
        if(++statusErrors >= maxStatusErrors) await abortNative("Could not read the download status. Please try again.", "NATIVE_STATUS_FAILED");
        continue;
      }
      if(this.controller.signal.aborted) return this.finishNativeCancel();
      // The user removed the download from the system Downloads UI/notification.
      if(!s || s.found === false) return this.finishNativeCancel();

      const downloaded = Number(s.downloaded) > 0 ? Number(s.downloaded) : 0;
      const total = Number(s.total) > 0 ? Number(s.total) : null;

      if(s.status === 8){
        // Google Drive can answer "200 OK" with a web page instead of the file. Never keep that as a book.
        if(/text\/html/i.test(String(s.mime || ""))){
          await abortNative("The server sent a web page instead of the PDF. Use “Open source” from the reader menu.", "NATIVE_NOT_PDF");
        }
        const finalTotal = total || downloaded;
        // The library record is written first: whoever reacts to "completed" must already find the book.
        const recordSaved = saveNativeRecord({
          bookId: this.book?.id, filename: this.filename, title: this.book?.title,
          titleEn: this.book?.titleEn, author: this.book?.author, authorEn: this.book?.authorEn, cover: this.book?.cover
        }, id, s, finalTotal);
        const result = {
          ok: true,
          state: DOWNLOAD_STATES.COMPLETED,
          mode: "native",
          bookId: this.book?.id ?? null,
          filename: this.filename,
          bytes: finalTotal,
          totalBytes: finalTotal,
          uri: s.uri || null,
          recordSaved,
          elapsedMs: Date.now() - this.startedAt
        };
        this.setState(DOWNLOAD_STATES.COMPLETED, result);
        RETRYABLE.delete(this.book?.id);
        return result;
      }

      if(s.status === 16){
        throw createDownloadError(nativeFailureMessage(s.reason), `NATIVE_FAILED_${s.reason}`, true);
      }

      const now = Date.now();
      if(downloaded !== lastSeenBytes){ lastSeenBytes = downloaded; lastProgressAt = now; }
      else if(now - lastProgressAt > stallMs) await abortNative("The download stalled. Check your connection and retry.", "NATIVE_STALLED");
      const elapsed = Math.max(1, now - lastAt);
      const delta = downloaded - lastBytes;
      if(delta > 0){
        const instant = delta / (elapsed / 1000);
        smoothedSpeed = smoothedSpeed ? (smoothedSpeed * 0.7) + (instant * 0.3) : instant;
      }
      lastAt = now;
      lastBytes = downloaded;

      const remaining = total ? Math.max(0, total - downloaded) : null;
      this.setState(DOWNLOAD_STATES.DOWNLOADING, {
        mode: "native",
        progressSupported: true,
        sizeKnown: Number.isFinite(total),
        totalBytes: total,
        downloadedBytes: downloaded,
        downloadedMegabytes: bytesToMegabytes(downloaded),
        totalMegabytes: bytesToMegabytes(total),
        percentage: total ? Math.min(100, (downloaded / total) * 100) : null,
        speedBytesPerSecond: smoothedSpeed || null,
        etaSeconds: smoothedSpeed > 0 && remaining != null ? remaining / smoothedSpeed : null
      });
    }
  }

  handOffToBrowser(reason, metadata = {}){
    if(this.state === DOWNLOAD_STATES.CANCELLING || this.controller.signal.aborted){
      const result = { ok:false, state:DOWNLOAD_STATES.CANCELLED, mode:"handoff", reason, bookId:this.book?.id ?? null, filename:this.filename, ...this.lastProgress };
      this.setState(DOWNLOAD_STATES.CANCELLED, result);
      RETRYABLE.set(this.book?.id, { book: this.book, url: this.url, options: { ...this.options } });
      return Promise.resolve(result);
    }

    this.setState(DOWNLOAD_STATES.HANDING_OFF, {
      ...metadata,
      mode:"handoff",
      handoffReason:reason,
      sizeKnown:Number.isFinite(metadata.totalBytes),
      totalBytes:metadata.totalBytes ?? null,
      totalMegabytes:bytesToMegabytes(metadata.totalBytes),
      downloadedBytes:0,
      downloadedMegabytes:0,
      percentage:null
    });

    try {
      triggerDirectDownload(this.url, this.filename);
      const result = {
        ok:true,
        state:DOWNLOAD_STATES.HANDED_OFF,
        mode:"handoff",
        reason,
        bookId:this.book?.id ?? null,
        filename:this.filename,
        nativeFallbackReason:metadata.nativeFallbackReason || "",
        totalBytes:metadata.totalBytes ?? null,
        sizeKnown:Number.isFinite(metadata.totalBytes),
        elapsedMs:Date.now()-this.startedAt
      };
      this.setState(DOWNLOAD_STATES.HANDED_OFF, result);
      RETRYABLE.delete(this.book?.id);
      return Promise.resolve(result);
    } catch(err){
      const result={ok:false,state:DOWNLOAD_STATES.FAILED,mode:"handoff",reason,bookId:this.book?.id ?? null,filename:this.filename,error:err};
      this.setState(DOWNLOAD_STATES.FAILED,result);
      RETRYABLE.set(this.book?.id, { book: this.book, url: this.url, options: { ...this.options } });
      return Promise.reject(err);
    }
  }

  cancel(){
    if([
      DOWNLOAD_STATES.COMPLETED,
      DOWNLOAD_STATES.FAILED,
      DOWNLOAD_STATES.CANCELLED,
      DOWNLOAD_STATES.CANCELLING,
      DOWNLOAD_STATES.HANDING_OFF,
      DOWNLOAD_STATES.HANDED_OFF
    ].includes(this.state)) return false;

    // Give the UI a visible cancellation state before aborting the stream.
    // This is intentionally synchronous so the user immediately sees
    // "Cancelling…" instead of the status card disappearing.
    this.setState(DOWNLOAD_STATES.CANCELLING, {
      ...this.lastProgress,
      cancelRequestedAt: Date.now()
    });
    if(this.nativeId !== undefined && this.nativeId !== null){
      try{ Promise.resolve(getNativePlugin()?.cancel({ id: this.nativeId })).catch(() => {}); }catch{}
    }
    this.controller.abort();
    return true;
  }
}

export const downloadManager = {
  download(book, url, options = {}){
    if(!book?.id) return Promise.reject(new Error("Book id is required for download"));

    const existing = ACTIVE.get(book.id);
    if(existing) return existing.promise;

    const job = new DownloadJob(book, url, options);
    job.promise = job.run().finally(() => {
      if(ACTIVE.get(book.id) === job) ACTIVE.delete(book.id);
    });
    ACTIVE.set(book.id, job);
    return job.promise;
  },

  cancel(bookId){
    return ACTIVE.get(bookId)?.cancel() || false;
  },

  isDownloading(bookId){
    return ACTIVE.has(bookId);
  },

  getState(bookId){
    return ACTIVE.get(bookId)?.state || DOWNLOAD_STATES.IDLE;
  },

  getActiveJobs(){
    return Array.from(ACTIVE.values()).map(job => ({
      bookId: job.book?.id ?? null,
      filename: job.filename,
      state: job.state,
      progress: { ...job.lastProgress }
    }));
  },

  canRetry(bookId){
    return RETRYABLE.has(bookId) && !ACTIVE.has(bookId);
  },

  retry(bookId){
    if(ACTIVE.has(bookId)) return ACTIVE.get(bookId).promise;
    const request = RETRYABLE.get(bookId);
    if(!request) return Promise.reject(new Error("No retryable download"));
    if(typeof navigator !== "undefined" && navigator.onLine === false){
      const error=new Error("You appear to be offline.");
      error.code="OFFLINE";
      return Promise.reject(error);
    }
    RETRYABLE.delete(bookId);
    return this.download(request.book, request.url, request.options);
  },

  clearRetry(bookId){
    RETRYABLE.delete(bookId);
  },

  subscribe(listener){
    if(typeof listener !== "function") return () => {};
    SUBSCRIBERS.add(listener);
    return () => SUBSCRIBERS.delete(listener);
  }
};
