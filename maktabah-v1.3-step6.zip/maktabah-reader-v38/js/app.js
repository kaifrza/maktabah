import { loadLibraryData, libraryNeedsSync, loadEmergencyLibrary, ensureAllBooksLoaded, searchBooksPage, resetSearchState, mergeBooksIntoLibrary, getLibraryCacheInfo, loadClassStats, loadCategoryStats, fetchBooksByIds } from "./data/data-loader.js";
import { state } from "./state.js";
import { readRoute, navigate, replaceRoute, ensureAppHistory, isAppHistoryEntry, syncHashNavigation, lockScrollSave } from "./router.js";
import { showBottomNav, hideBottomNav, BOTTOM_NAV_TABS } from "./components/bottom-nav.js";
import { bookCard, typesetCover, paletteIndex, HEART, ARCHIVE_ICON } from "./components/book-card.js";
import { coverPalette } from "./utils/palette.js";
import { icon } from "./utils/icons.js";
import { identityFor } from "./utils/identity.js";
import { watchInsets } from "./features/insets.js";
import { ensureUrduFont } from "./features/fonts.js";
import { getPerfMode, setPerfMode, effectivePerf, perfSource, initPerf } from "./features/perf.js";
import { getScanMode, setScanMode, scanInfo, onScanChange, scanSupported, runScan, requestAccess, checkAccess } from "./features/device-scan.js";
import { watchNativePtr, syncNativePtr } from "./features/native-ptr.js";
import { searchBooks } from "./features/search.js";
import { searchArchive, getArchiveBook, hydrateArchiveBook, resolveArchivePdf, isArchiveId } from "./features/archive-search.js";
import { applyTheme, changeTheme, watchSystemTheme } from "./features/theme.js";
import { getFavorites, toggleFavorite, addHistory, getHistory, clearHistory, getBookProgress, setProgress, clearProgress, setLanguage } from "./utils/storage.js";
import { escapeHTML } from "./utils/helpers.js";
import { coverMarkup, wireCover, prefetchCovers, getCoverCacheInfo, clearCoverCache } from "./utils/cover.js";
import { downloadManager, DOWNLOAD_STATES, nativeDiagnostics, getNativePlugin, BUILD_TAG, recoverPendingDownloads } from "./features/download-manager.js";
import { openInNativeReader, nativeReaderWanted } from "./features/native-reader.js";
import { saveBackup, openRestoreDialog } from "./features/backup.js";
import { trapFocus } from "./utils/focus-trap.js";
import { getDownloadRecord, getDownloads } from "./features/downloads-store.js";
import { renderLibrary, cleanupLibrary } from "./features/library-screen.js";
import { initHeaderBehavior } from "./features/header-behavior.js";

const app = document.querySelector("#app");
let data;
const t = {
  ur: {
    brand:"مکتبہ", tagline:"اردو و اسلامی کتب کا ڈیجیٹل کتب خانہ", search:"کتاب، مصنف یا لفظ تلاش کریں",
    classes:"جماعت کے لحاظ سے", featured:"منتخب کتب", recent:"حال ہی میں شامل کتب", continue:"جہاں چھوڑا تھا",
    available:"دستیاب", back:"واپس", read:"پڑھیں", download:"ڈاؤنلوڈ", fav:"پسندیدہ کتب", source:"اصل ماخذ",
    openSource:"اصل ویب سائٹ دیکھیں", report:"مسئلہ رپورٹ کریں", more:"مزید", empty:"ابھی کوئی کتاب موجود نہیں۔",
    clearHistory:"مطالعہ کی تاریخ صاف کریں", clearData:"مقامی ڈیٹا صاف کریں", clearOffline:"محفوظ شدہ کتب صاف کریں", confirmClear:"پسندیدہ، مطالعہ کی تاریخ اور پیش رفت صاف کر دیں؟",
    cleared:"مقامی ڈیٹا صاف کر دیا گیا۔", theme:"ظاہری انداز", language:"زبان", rights:"ذرائع اور حقوق",
    browse:"سب جماعتیں دیکھیں", allBooks:"تمام کتب", catalogue:"تمام کتب", searchResults:"تلاش کے نتائج", noSearch:"کوئی کتاب نہیں ملی",
    noSearchHint:"عنوان، مصنف یا کوئی دوسرا لفظ آزما کر دیکھیں۔", noClassBooks:"اس جماعت میں ابھی کوئی کتاب دستیاب نہیں۔", noCategoryBooks:"اس زمرے میں ابھی کوئی کتاب دستیاب نہیں۔", noFavorites:"ابھی کوئی پسندیدہ کتاب نہیں۔", filterAll:"تمام کتب", filterMatn:"متون", filterSharah:"شروحات", continueAction:"مطالعہ جاری رکھیں", pageOf:"صفحہ",
    reportSoon:"رپورٹ فیچر ابھی دستیاب نہیں ہے۔", related:"ملتی جلتی کتب", relatedHint:"اسی جماعت یا زمرے کی مزید کتب", sourceMissing:"اس کتاب کا PDF ماخذ ابھی دستیاب نہیں ہے۔", favoriteAdded:"کتاب پسندیدہ میں شامل ہوگئی۔", favoriteRemoved:"کتاب پسندیدہ سے ہٹا دی گئی۔",
    historyCleared:"مطالعہ کی تاریخ صاف کر دی گئی۔", dataCleared:"مقامی ڈیٹا صاف کر دیا گیا۔", quickClasses:"جماعتیں", quickCategories:"زمرے",
    quickFavorites:"پسندیدہ", quickHistory:"حالیہ مطالعہ", about:"مختصر تعارف", unavailable:"فی الحال دستیاب نہیں", quickSettings:"فوری ترتیبات", librarySection:"لائبریری", offlineSection:"آف لائن کتب", dataSection:"ڈیٹا اور اسٹوریج", appearanceShort:"ظاہری انداز", languageShort:"زبان", savedBooks:"محفوظ شدہ کتب", storageUsed:"استعمال شدہ جگہ", clearHistoryShort:"مطالعہ کی تاریخ صاف کریں", clearDataShort:"تمام مقامی ڈیٹا صاف کریں", clearOfflineShort:"صاف کریں", sourceRightsShort:"ذرائع اور حقوق", aboutApp:"Maktabah کے بارے میں", systemTheme:"سسٹم", lightTheme:"لائٹ", darkTheme:"ڈارک",
    syncLoading:"کتابوں کی فہرست لوڈ ہو رہی ہے…", syncFailed:"انٹرنیٹ سے کتابیں نہیں مل سکیں۔ کنکشن چیک کریں۔", syncStale:"محفوظ شدہ پرانی فہرست دکھائی جا رہی ہے۔",
    offline:"آپ آف لائن ہیں؛ محفوظ شدہ کتب دکھائی جا رہی ہیں۔", online:"انٹرنیٹ بحال ہوگیا۔", cached:"محفوظ شدہ ڈیٹا استعمال ہو رہا ہے۔", readerLoading:"کتاب لوڈ ہو رہی ہے…", readerPageError:"صفحہ دکھایا نہیں جا سکا", readerLoadError:"PDF لوڈ نہیں ہو سکی",
    openPdf:"PDF کھولیں", readerSource:"اصل ماخذ کھولیں", previous:"پچھلا صفحہ", next:"اگلا صفحہ", zoomOut:"زوم کم کریں",
    zoomIn:"زوم بڑھائیں", fullscreen:"مکمل اسکرین", hideControls:"کنٹرول چھپائیں", showControls:"کنٹرول دکھائیں", retry:"دوبارہ کوشش کریں", alternateReader:"متبادل ریڈر استعمال کریں", readerViewerHint:"اگر PDF یہاں نظر نہ آئے تو متبادل ریڈر استعمال کریں۔", readerClosed:"مطالعہ بند کر دیا گیا۔", refresh:"تازہ کریں", refreshing:"کتب تازہ کی جا رہی ہیں…", refreshed:"کتب تازہ ہوگئیں۔", refreshFailed:"تازہ کاری ناکام ہوگئی۔"
  },
  en: {
    brand:"Maktabah", tagline:"A Digital Home for Urdu & Islamic Books", search:"Search books, authors or keywords",
    classes:"Browse by Class", featured:"Featured Books", recent:"Recently Added", continue:"Continue Reading",
    available:"Available", back:"Back", read:"Read", download:"Download", fav:"Favorites", source:"Original Source",
    openSource:"View Original Source", report:"Report a Problem", more:"More", empty:"No books found.",
    clearHistory:"Clear reading history", clearData:"Clear local data", clearOffline:"Clear saved offline books", confirmClear:"Clear favorites, reading history and reading progress?",
    cleared:"Local data cleared.", theme:"Appearance", language:"Language", rights:"Sources & Rights",
    browse:"View all classes", allBooks:"All books", catalogue:"All books", searchResults:"Search results", noSearch:"No books found",
    noSearchHint:"Try a different title, author, or keyword.", noClassBooks:"No books are available in this class yet.", noCategoryBooks:"No books are available in this category yet.", noFavorites:"No favorite books yet.", filterAll:"All books", filterMatn:"Matn", filterSharah:"Commentary", continueAction:"Continue reading", pageOf:"Page",
    reportSoon:"Reporting is not available yet.", related:"Related books", relatedHint:"More books from the same class or category", sourceMissing:"A PDF source is not currently available for this book.", favoriteAdded:"Book added to favorites.", favoriteRemoved:"Book removed from favorites.",
    historyCleared:"Reading history cleared.", dataCleared:"Local data cleared.", quickClasses:"Classes", quickCategories:"Categories",
    quickFavorites:"Favorites", quickHistory:"Recent", about:"About this book", unavailable:"Currently unavailable", quickSettings:"Quick settings", librarySection:"Library", offlineSection:"Offline books", dataSection:"Data & storage", appearanceShort:"Appearance", languageShort:"Language", savedBooks:"Saved books", storageUsed:"Storage used", clearHistoryShort:"Clear reading history", clearDataShort:"Clear all local data", clearOfflineShort:"Clear", sourceRightsShort:"Sources & Rights", aboutApp:"About Maktabah", systemTheme:"System", lightTheme:"Light", darkTheme:"Dark",
    syncLoading:"Loading the book list…", syncFailed:"Couldn't reach the library. Check your connection.", syncStale:"Showing your saved book list (may be out of date).",
    offline:"You are offline; showing cached library data.", online:"Internet connection restored.", cached:"Using cached library data.", readerLoading:"Loading book…", readerPageError:"Page could not be rendered", readerLoadError:"Unable to load PDF",
    openPdf:"Open PDF", readerSource:"Open Source", previous:"Previous page", next:"Next page", zoomOut:"Zoom out",
    zoomIn:"Zoom in", fullscreen:"Fullscreen", hideControls:"Hide controls", showControls:"Show controls", retry:"Retry", alternateReader:"Use alternate reader", readerViewerHint:"If the PDF does not appear here, use the alternate reader.", readerClosed:"Reading closed.", refresh:"Refresh", refreshing:"Refreshing library…", refreshed:"Library refreshed.", refreshFailed:"Refresh failed."
  }
};

const langName = (c, lang) => lang === "ur" ? c.name : (c.nameEn || c.name);
function currentLang(){ return state.language; }
function setDirection(){
  const rtl = currentLang() === "ur";
  document.documentElement.lang = rtl ? "ur" : "en";
  document.documentElement.dir = rtl ? "rtl" : "ltr";
}
function httpsUrl(url){
  if(typeof url!=="string" || !url.trim()) return null;
  try{
    const u=new URL(url.trim());
    if(u.protocol==="http:") u.protocol="https:";
    return u.protocol==="https:" && !u.username && !u.password ? u.href : null;
  }catch{ return null; }
}
function validExternalUrl(url){ return httpsUrl(url)!==null; }
function openExternal(url){ const safe=httpsUrl(url); if(safe) window.open(safe, "_blank", "noopener,noreferrer"); }
function archiveIdentifierFromUrl(url){
  try{
    const u=new URL(url,location.href);
    if(!/(^|\.)archive\.org$/i.test(u.hostname))return null;
    const parts=u.pathname.split('/').filter(Boolean);
    for(const marker of ['download','details','embed']){
      const i=parts.indexOf(marker);
      if(i>=0&&parts[i+1])return decodeURIComponent(parts[i+1]);
    }
  }catch{}
  return null;
}

function readerSourceForBook(book){
  const type=String(book?.pdfSourceType||'').toLowerCase();
  const driveId=String(book?.driveFileId||'').trim();
  if(type==='drive' || driveId){
    if(driveId)return {kind:'drive',url:`https://drive.google.com/file/d/${encodeURIComponent(driveId)}/preview`};
  }
  // Be resilient to older records where a Drive /file/{id}/view URL was
  // stored in pdfUrl without a separate drive_file_id. The canonical reader
  // still remains Drive preview; this does not create a second source.
  for(const candidate of [book?.source?.pageUrl,book?.pdfUrl]){
    try{
      const u=new URL(candidate,location.href);
      const m=u.pathname.match(/^\/file\/d\/([A-Za-z0-9_-]+)/i);
      if(/(^|\.)drive\.google\.com$/i.test(u.hostname) && m?.[1]){
        return {kind:'drive',url:`https://drive.google.com/file/d/${encodeURIComponent(m[1])}/preview`};
      }
    }catch{}

    const identifier=archiveIdentifierFromUrl(candidate);
    if(identifier)return {kind:'archive',url:`https://archive.org/embed/${encodeURIComponent(identifier)}`};
  }
  const safePdf=httpsUrl(book?.pdfUrl);
  if(safePdf)return {kind:'external',url:safePdf};
  return null;
}
// Direct download link for a book: Google Drive uses the public export link, everything else
// (Archive.org etc.) uses the stored PDF address. Returns null when the book has no usable source.
function downloadUrlForBook(book){
  const driveId=String(book?.driveFileId||'').trim();
  // confirm=t skips Google's "can't scan this file for viruses" page that would otherwise be saved as the PDF.
  if(driveId) return `https://drive.google.com/uc?export=download&confirm=t&id=${encodeURIComponent(driveId)}`;
  for(const candidate of [book?.pdfUrl,book?.source?.pageUrl]){
    try{
      const u=new URL(candidate,location.href);
      const m=u.pathname.match(/^\/file\/d\/([A-Za-z0-9_-]+)/i);
      if(/(^|\.)drive\.google\.com$/i.test(u.hostname) && m?.[1]) return `https://drive.google.com/uc?export=download&confirm=t&id=${encodeURIComponent(m[1])}`;
    }catch{}
  }
  return httpsUrl(book?.pdfUrl);
}

function formatDownloadBytes(bytes){
  if(!Number.isFinite(bytes) || bytes < 0) return "—";
  const units=["B","KB","MB","GB"];
  let n=bytes, i=0;
  while(n>=1024 && i<units.length-1){ n/=1024; i++; }
  const digits=i===0?0:(n>=100?0:n>=10?1:2);
  return `${n.toFixed(digits)} ${units[i]}`;
}

function formatDownloadSpeed(bytesPerSecond){
  return Number.isFinite(bytesPerSecond) && bytesPerSecond > 0 ? `${formatDownloadBytes(bytesPerSecond)}/s` : "";
}

function formatDownloadEta(seconds){
  if(!Number.isFinite(seconds) || seconds < 0) return "";
  const total=Math.ceil(seconds);
  if(total < 60) return `${total}s`;
  const minutes=Math.floor(total/60);
  const secs=total%60;
  if(minutes < 60) return `${minutes}m ${secs}s`;
  const hours=Math.floor(minutes/60);
  return `${hours}h ${minutes%60}m`;
}

function ensureDownloadStatus(){
  let region=document.querySelector(".download-status-region");
  if(!region){
    region=document.createElement("div");
    region.className="download-status-region";
    region.setAttribute("aria-live","polite");
    region.setAttribute("aria-atomic","false");
    document.body.appendChild(region);
  }
  return region;
}

function updateDownloadStatus(payload){
  const region=ensureDownloadStatus();
  if(payload.state===DOWNLOAD_STATES.IDLE || !payload.bookId) return;

  const key=String(payload.bookId).replace(/[^A-Za-z0-9_-]/g,"_");
  // A new update (e.g. Retry) must cancel the pending "remove card" timer of the previous finished attempt.
  clearTimeout(updateDownloadStatus["timer_"+key]);
  let card=region.querySelector('[data-download-id="'+CSS.escape(String(payload.bookId))+'"]');
  if(!card){
    card=document.createElement("section");
    card.className="download-status is-entering";
    card.dataset.downloadId=String(payload.bookId);
    region.appendChild(card);
    setTimeout(()=>card.classList.remove("is-entering"),400);
  }

  const title=payload.filename ? payload.filename.replace(/\.pdf$/i,"") : (currentLang()==="ur" ? "کتاب" : "Book");
  const ur=currentLang()==="ur";
  let statusText=ur ? "ڈاؤن لوڈ ہو رہی ہے…" : "Downloading…";
  if(payload.state===DOWNLOAD_STATES.PREPARING) statusText=ur ? "ڈاؤن لوڈ تیار ہو رہا ہے…" : "Preparing download…";
  if(payload.state===DOWNLOAD_STATES.COMPLETING) statusText=ur ? "فائل تیار ہو رہی ہے…" : "Finishing…";
  if(payload.state===DOWNLOAD_STATES.CANCELLING) statusText=ur ? "ڈاؤن لوڈ منسوخ ہو رہا ہے…" : "Cancelling download…";
  if(payload.state===DOWNLOAD_STATES.HANDING_OFF) statusText=ur ? "فائل براؤزر کے حوالے کی جا رہی ہے…" : "Handing download to browser…";
  if(payload.state===DOWNLOAD_STATES.HANDED_OFF) statusText=ur ? "ڈاؤن لوڈ براؤزر کے حوالے ہوگیا" : "Download handed to browser";
  if(payload.state===DOWNLOAD_STATES.COMPLETED) statusText=ur ? "ڈاؤن لوڈ مکمل ہوگیا" : "Download complete";
  if(payload.state===DOWNLOAD_STATES.FAILED) statusText=ur ? "ڈاؤن لوڈ ناکام ہوگیا" : "Download failed";
  if(payload.state===DOWNLOAD_STATES.CANCELLED) statusText=ur ? "ڈاؤن لوڈ منسوخ ہوگیا" : "Download cancelled";

  const percent=Number.isFinite(payload.percentage) ? Math.max(0,Math.min(100,payload.percentage)) : null;
  const hasTotal=Number.isFinite(payload.totalBytes) && payload.totalBytes>0;
  let bytesLine;
  if(hasTotal) bytesLine=formatDownloadBytes(payload.downloadedBytes||0)+" / "+formatDownloadBytes(payload.totalBytes);
  else if(Number.isFinite(payload.downloadedBytes)) bytesLine=formatDownloadBytes(payload.downloadedBytes)+" · "+(ur ? "کل سائز معلوم نہیں" : "size unknown");
  else bytesLine=ur ? "سائز معلوم کیا جا رہا ہے" : "Checking file size…";

  const progressLabel=percent===null ? "" : percent.toFixed(percent>=10 ? 0 : 1)+"%";
  const speed=formatDownloadSpeed(payload.speedBytesPerSecond);
  const eta=formatDownloadEta(payload.etaSeconds);
  let details=speed;
  if(eta) details+=(details ? " · " : "")+(ur ? "باقی " : "left ")+eta;
  if(payload.state===DOWNLOAD_STATES.FAILED && payload.errorMessage) details=payload.errorMessage;
  if(payload.state===DOWNLOAD_STATES.CANCELLED) details=ur ? "آپ دوبارہ کوشش کر سکتے ہیں۔" : "You can retry this download.";
  if(payload.state===DOWNLOAD_STATES.HANDED_OFF){
    details=ur ? "براؤزر اب فائل محفوظ کرے گا۔" : "Your browser is handling the file save.";
    console.info("Maktabah handoff", payload.nativeFallbackReason||"", nativeDiagnostics());
  }
  if(payload.state===DOWNLOAD_STATES.COMPLETED && payload.mode==="native") details=ur ? "فائل ڈاؤن لوڈز فولڈر میں محفوظ ہوگئی۔" : "Saved to your Downloads folder.";

  const canCancel=[DOWNLOAD_STATES.PREPARING,DOWNLOAD_STATES.DOWNLOADING,DOWNLOAD_STATES.COMPLETING].includes(payload.state);
  const cancelLabel=ur ? "ڈاؤن لوڈ منسوخ کریں" : "Cancel download";
  const cancelMarkup=canCancel ? '<button type="button" class="download-status-cancel" aria-label="'+escapeHTML(cancelLabel)+'"><i class="fa-solid fa-xmark"></i></button>' : "";
  const canRetry=[DOWNLOAD_STATES.FAILED,DOWNLOAD_STATES.CANCELLED].includes(payload.state) && downloadManager.canRetry(payload.bookId);
  const retryMarkup=canRetry ? '<button type="button" class="download-status-retry">'+escapeHTML(ur ? "دوبارہ کوشش کریں" : "Retry")+'</button>' : "";
  let progressMarkup;
  if(percent!==null) progressMarkup='<div class="download-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'+percent.toFixed(1)+'"><span style="width:'+percent+'%"></span></div>';
  else progressMarkup='<div class="download-progress-track indeterminate"><span></span></div>';
  const detailsMarkup=details ? '<div class="download-status-sub">'+escapeHTML(details)+'</div>' : "";
  const doneStates=[DOWNLOAD_STATES.COMPLETED,DOWNLOAD_STATES.HANDED_OFF];
  const badStates=[DOWNLOAD_STATES.FAILED,DOWNLOAD_STATES.CANCELLED];
  const cancellingClass=(payload.state===DOWNLOAD_STATES.CANCELLING ? " is-cancelling" : "")+(doneStates.includes(payload.state) ? " is-done" : "")+(badStates.includes(payload.state) ? " is-failed" : "");
  const iconName=doneStates.includes(payload.state) ? "fa-circle-check" : (badStates.includes(payload.state) ? "fa-triangle-exclamation" : "fa-download");
  const busyAttr=[DOWNLOAD_STATES.PREPARING,DOWNLOAD_STATES.DOWNLOADING,DOWNLOAD_STATES.COMPLETING,DOWNLOAD_STATES.CANCELLING,DOWNLOAD_STATES.HANDING_OFF].includes(payload.state) ? ' aria-busy="true"' : "";
  card.className="download-status"+cancellingClass+(card.classList.contains("is-entering") ? " is-entering" : "");
  card.setAttribute("role","status");
  if(busyAttr) card.setAttribute("aria-busy","true"); else card.removeAttribute("aria-busy");
  card.innerHTML='<div class="download-status-head"><div class="download-status-title"><span class="ds-ico"><i class="fa-solid '+iconName+'"></i></span><span class="ds-text">'+escapeHTML(statusText)+'</span></div>'+cancelMarkup+'</div>'
    +'<div class="download-status-book" title="'+escapeHTML(title)+'">'+escapeHTML(title)+'</div>'
    +progressMarkup
    +'<div class="download-status-meta"><span>'+escapeHTML(bytesLine)+'</span><strong>'+escapeHTML(progressLabel)+'</strong></div>'
    +detailsMarkup+retryMarkup;

  const cancel=card.querySelector(".download-status-cancel");
  if(cancel) cancel.onclick=()=>downloadManager.cancel(payload.bookId);
  const retry=card.querySelector(".download-status-retry");
  if(retry){ retry.onclick=async()=>{ retry.disabled=true; try{ await downloadManager.retry(payload.bookId); }catch(err){ console.error("Maktabah PDF retry failed",err); } }; }

  if([DOWNLOAD_STATES.COMPLETED,DOWNLOAD_STATES.HANDED_OFF,DOWNLOAD_STATES.FAILED,DOWNLOAD_STATES.CANCELLED].includes(payload.state)){
    const timerKey="timer_"+key;
    clearTimeout(updateDownloadStatus[timerKey]);
    updateDownloadStatus[timerKey]=setTimeout(()=>{
      const target=region.querySelector('[data-download-id="'+CSS.escape(String(payload.bookId))+'"]');
      const done=()=>{ if(target&&target.classList.contains("is-leaving")) target.remove(); if(!region.children.length) region.remove(); };
      if(target){ target.classList.add("is-leaving"); setTimeout(done,240); } else done();
    }, payload.state===DOWNLOAD_STATES.COMPLETED ? 3200 : (payload.state===DOWNLOAD_STATES.HANDED_OFF ? 20000 : 4500));
  }
}
downloadManager.subscribe(updateDownloadStatus);

function showToast(message){
  let region=document.querySelector(".toast-region");
  if(!region){ region=document.createElement("div"); region.className="toast-region"; region.setAttribute("aria-live","polite"); region.setAttribute("aria-atomic","true"); document.body.appendChild(region); }
  region.innerHTML=`<div class="toast" role="status">${escapeHTML(message)}</div>`;
  clearTimeout(showToast.timer);
  showToast.timer=setTimeout(()=>region.remove(),2600);
}

function confirmDialog(title, message, confirmLabel, danger=false){
  return new Promise(resolve=>{
    const backdrop=document.createElement("div"); backdrop.className="modal-backdrop";
    backdrop.innerHTML=`<section class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle"><h2 id="modalTitle">${escapeHTML(title)}</h2><p>${escapeHTML(message)}</p><div class="modal-actions"><button class="btn" id="modalCancel">${currentLang()==="ur"?"منسوخ":"Cancel"}</button><button class="btn ${danger?"danger":"primary"}" id="modalConfirm">${escapeHTML(confirmLabel)}</button></div></section>`;
    document.body.appendChild(backdrop);
    const release=trapFocus(backdrop);
    const onKey=e=>{if(e.key==="Escape")finish(false);};
    const finish=value=>{document.removeEventListener("keydown",onKey);backdrop.remove();release();resolve(value);};
    backdrop.querySelector("#modalCancel").onclick=()=>finish(false);
    backdrop.querySelector("#modalConfirm").onclick=()=>finish(true);
    backdrop.addEventListener("click",e=>{if(e.target===backdrop)finish(false);});
    document.addEventListener("keydown",onKey);
    backdrop.querySelector("#modalConfirm").focus();
  });
}

function goBackInApp() {
  // Always keep Back inside the library when possible. A direct/deep link is
  // seeded with Home by ensureAppHistory(), so history.back() is safe here.
  if (isAppHistoryEntry() && history.length > 1) history.back();
  else navigate("home", {}, { replace: true });
}

// ---- Android hardware Back ------------------------------------------------
// MainActivity asks the web layer what to do on every Back press by calling
// window.__krBack(). Order: close the topmost overlay -> go to the previous
// screen -> (tab screens) go Home -> on Home, press twice to exit.
// Returns "handled" (stay in app) or "exit" (native may close the app).
const TAB_ROOTS = new Set(["classes","categories","downloads","more","catalogue","favorites","search"]);
let lastExitTap = 0;
window.__krBack = function(){
  try{
    const modal = document.querySelector(".modal-backdrop");
    if(modal){ modal.click(); if(modal.isConnected) modal.remove(); return "handled"; }
    const info = document.querySelector(".more-info-dialog");
    if(info){ const x=info.querySelector("[data-close]"); if(x) x.click(); if(info.isConnected) info.remove(); return "handled"; }
    const menu = document.querySelector("#readerMoreMenu:not([hidden])");
    if(menu){ document.querySelector("#more")?.click(); if(!menu.hidden) menu.hidden = true; return "handled"; }
    if(document.querySelector(".class-search-panel.is-open")){ history.back(); return "handled"; }
    const { route } = readRoute();
    if(route !== "home"){
      if(TAB_ROOTS.has(route)) navigate("home", {}, { replace: true });
      else goBackInApp();
      return "handled";
    }
    const now = Date.now();
    if(now - lastExitTap < 2000) return "exit";
    lastExitTap = now;
    showToast(currentLang()==="ur" ? "باہر نکلنے کے لیے دوبارہ بیک دبائیں" : "Press back again to exit");
    return "handled";
  }catch(err){ console.error("back handler", err); return "exit"; }
};

let networkStatusTimer = null;
function updateNetworkStatus(mode = null) {
  const offline = mode === "offline" || (mode === null && typeof navigator !== "undefined" && navigator.onLine === false);
  const nodes = document.querySelectorAll(".network-status");
  nodes.forEach(node => {
    node.dataset.state = offline ? "offline" : "online";
    node.hidden = !offline;
    node.textContent = offline ? t[currentLang()].offline : "";
  });
}

function announceNetworkStatus(mode) {
  if (mode === "offline") {
    showToast(t[currentLang()].offline);
    updateNetworkStatus("offline");
    return;
  }
  updateNetworkStatus("online");
  if (networkStatusTimer) clearTimeout(networkStatusTimer);
  const message = t[currentLang()].online;
  showToast(message);
  networkStatusTimer = window.setTimeout(() => updateNetworkStatus(null), 2600);
}

function shell(title, content, active){
  const lang=currentLang();
  title = escapeHTML(title);
  app.innerHTML = "";
  const top = document.createElement("header"); top.className = `topbar ${state.route === "home" ? "topbar-home" : ""} ${(state.route === "reader" || state.route === "local") ? "topbar-reader" : ""}`;
  top.innerHTML = `<a class="brand" href="#home" aria-label="${escapeHTML(t[lang].brand)}"><span class="brand-mark"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M11.5 6.4C10.2 5.5 8.2 5.2 4.8 5.5V17.7C8.2 17.4 10.2 17.7 11.5 18.6Z"/><path fill="currentColor" d="M12.5 6.4C13.8 5.5 15.8 5.2 19.2 5.5V17.7C15.8 17.4 13.8 17.7 12.5 18.6Z"/></svg></span><span class="brand-copy"><span class="brand-name">${escapeHTML(t[lang].brand)}</span><span class="brand-context">${title}</span></span></a>
    <div class="topbar-actions"><span class="network-status" data-state="online" hidden role="status" aria-live="polite"></span>${state.route !== "reader" && state.route !== "search" && state.route !== "home" ? `<button class="icon-btn" id="searchBtn" type="button" aria-label="${escapeHTML(lang==="ur"?"تلاش":"Search")}" title="${escapeHTML(lang==="ur"?"تلاش":"Search")}"><i class="fa-solid fa-magnifying-glass"></i></button>` : ""}<button class="icon-btn" id="favoritesBtn" type="button" aria-label="${escapeHTML(lang==="ur"?"پسندیدہ":"Favorites")}" title="${escapeHTML(lang==="ur"?"پسندیدہ":"Favorites")}"><i class="fa-solid fa-heart"></i></button></div>`;
  app.appendChild(top);
  updateNetworkStatus(null);
  const page = document.createElement("main"); page.className = "page"; page.innerHTML = content; app.appendChild(page);
  mountSyncBanner(page);
  if(state.route !== "reader") showBottomNav(active, lang); else hideBottomNav();   // one persistent dock (js/components/bottom-nav.js): only its highlight changes
  const searchBtn = top.querySelector("#searchBtn");
  if(searchBtn) searchBtn.onclick = () => navigate("search",{q:""});
  const favoritesBtn = top.querySelector("#favoritesBtn");
  if(favoritesBtn) favoritesBtn.onclick = () => navigate("favorites");
  const refreshBtn = top.querySelector("#refreshBtn");
  if(refreshBtn) refreshBtn.onclick = () => refreshLibrary({ source: "button" });
  return page;
}

function detailShell(title, content){
  const lang=currentLang();
  app.innerHTML="";
  const top=document.createElement("header"); top.className="detail-top";
  top.innerHTML=`<button class="icon-btn detail-back" id="bookBack" type="button" aria-label="${escapeHTML(t[lang].back)}"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M15 5l-7 7 7 7"/></svg></button><span class="detail-top-title" aria-hidden="true">${escapeHTML(title)}</span><span class="detail-top-end"><span class="network-status" data-state="online" hidden role="status" aria-live="polite"></span></span>`;
  app.appendChild(top);
  updateNetworkStatus(null);
  const page=document.createElement("main"); page.className="page"; page.innerHTML=content; app.appendChild(page);
  return page;
}

let refreshInFlight = null;

function showRefreshIndicator(stateName){
  let indicator = document.querySelector(".pull-refresh-indicator");
  if(!indicator){
    indicator = document.createElement("div");
    indicator.className = "pull-refresh-indicator";
    indicator.setAttribute("role", "status");
    indicator.setAttribute("aria-live", "polite");
    document.body.appendChild(indicator);
  }
  const lang=currentLang(), L=t[lang];
  const labels={pull:lang==="ur"?"تازہ کرنے کے لیے نیچے کھینچیں":"Pull to refresh",release:lang==="ur"?"تازہ کرنے کے لیے چھوڑ دیں":"Release to refresh",refreshing:L.refreshing,done:L.refreshed,error:L.refreshFailed};
  indicator.dataset.state=stateName;
  if(stateName!=="pull"&&stateName!=="release"){ indicator.style.transition=""; indicator.style.transform=""; indicator.style.opacity=""; }
  indicator.innerHTML = `<span class="pull-refresh-icon" aria-hidden="true"><i class="fa-solid fa-arrows-rotate"></i></span><span>${escapeHTML(labels[stateName] || labels.pull)}</span>`;
  if(stateName === "done" || stateName === "error"){
    window.setTimeout(()=>{ if(indicator.dataset.state===stateName) indicator.remove(); }, 1300);
  }
  return indicator;
}

/** True while the search screen shows results for a query (the start screen with recent searches has nothing to refresh). */
function searchHasResults(){ return Boolean(document.querySelector(".sr-screen #libPanel")); }

/** Pull-to-refresh on the search screen: forget the finished search, draw the screen again and wait until the results are back. */
async function refreshSearchScreen(){
  resetSearchState();                                                                   // data layer: paging of the old query is dropped
  searchSession={ ...searchSession, books:[], done:false };                            // same query, no saved results
  archiveSession={ ...archiveSession, books:[], page:0, done:false, started:false, meta:{} };   // keeps the open tab + language filter
  lastRenderedRoute="";
  await renderRouteOnce();                                                              // starts both loads (skeletons show meanwhile)
  const pending=[searchLoadInFlight,searchIaInFlight].filter(Boolean).map(p=>Promise.resolve(p).catch(()=>{}));
  if(pending.length) await Promise.race([Promise.all(pending), new Promise(r=>setTimeout(r,15000))]);
}

async function refreshLibrary({source="pull"}={}){
  if(refreshInFlight) return refreshInFlight;
  if((state.route === "reader" || state.route === "local")) return;
  const startedAt=Date.now();
  if(state.route==="downloads") runScan();   // pull-to-refresh on Library = quick manual scan of the phone
  const button=document.querySelector("#refreshBtn");
  refreshInFlight=(async()=>{
    if(button){ button.disabled=true; button.classList.add("is-spinning"); button.setAttribute("aria-busy","true"); }
    const quiet = source === "native";
    if(!quiet) showRefreshIndicator("refreshing");
    try{
      if(state.route==="search"){
        // Search screen: run the same search again from scratch (library + Archive.org tab).
        await refreshSearchScreen();
      }else{
        const next=await loadLibraryData({force:true});
        data=next;
        state.dataReady=true;
        syncAttempts=0; setSyncState("ok");
        updateNetworkStatus(null);
        lastRenderedRoute="";
        await renderRouteOnce();
      }
      const elapsed=Date.now()-startedAt;
      if(elapsed<500) await new Promise(r=>setTimeout(r,500-elapsed));
      if(!quiet) showRefreshIndicator("done");
      return {ok:true};
    }catch(error){
      console.error("Maktabah refresh failed",error);
      if(!quiet) showRefreshIndicator("error");
      showToast(t[currentLang()].refreshFailed);
      return {ok:false,error};
    }finally{
      const currentButton=document.querySelector("#refreshBtn");
      if(currentButton){ currentButton.disabled=false; currentButton.classList.remove("is-spinning"); currentButton.removeAttribute("aria-busy"); }
      refreshInFlight=null;
    }
  })();
  return refreshInFlight;
}


/* ---------- Catalogue sync (Supabase is only for the books) ----------
   The app starts from what it already has (saved catalogue or bundled data) and never waits for
   the network. This block fetches the real catalogue in the background with retry + back-off. */
const SYNC_ROUTES = ["home","classes","categories","catalogue","class","category"];
let syncState = "idle";            // idle | loading | failed | ok
let syncInFlight = null, syncTimer = 0, syncAttempts = 0;

function syncBannerKind(){
  const info = getLibraryCacheInfo();
  const placeholder = info.source === "local-fallback" || info.source === "empty";
  if(syncState === "loading" && (placeholder || info.stale)) return "loading";
  if(syncState === "failed" && placeholder) return "failed";
  if(syncState === "failed" && info.stale) return "stale";
  return "";
}
function buildSyncBanner(){
  const kind = syncBannerKind();
  if(!kind) return null;
  const L = t[currentLang()];
  const el = document.createElement("div");
  el.className = "sync-banner"; el.dataset.state = kind;
  el.setAttribute("role","status"); el.setAttribute("aria-live","polite");
  const msg = kind === "loading" ? L.syncLoading : kind === "stale" ? L.syncStale : L.syncFailed;
  el.innerHTML = `<i class="fa-solid ${kind === "loading" ? "fa-arrows-rotate sync-spin" : "fa-triangle-exclamation"}" aria-hidden="true"></i><span>${escapeHTML(msg)}</span>${kind === "loading" ? "" : `<button type="button" class="sync-retry">${escapeHTML(L.retry)}</button>`}`;
  const btn = el.querySelector(".sync-retry");
  if(btn) btn.onclick = () => backgroundSync();
  return el;
}
function mountSyncBanner(page){
  page = page || document.querySelector("main.page");
  if(!page) return;
  page.querySelector(":scope > .sync-banner")?.remove();
  if(!SYNC_ROUTES.includes(state.route)) return;
  const banner = buildSyncBanner();
  if(banner) page.prepend(banner);
}
function setSyncState(next){ syncState = next; mountSyncBanner(); }
function scheduleSyncRetry(){
  clearTimeout(syncTimer);
  const delays = [15000, 45000, 120000, 300000];
  const wait = delays[Math.min(Math.max(syncAttempts - 1, 0), delays.length - 1)];
  syncTimer = setTimeout(() => {
    if(syncState !== "failed") return;
    if(document.hidden || navigator.onLine === false) scheduleSyncRetry(); else backgroundSync();
  }, wait);
}
function rerenderAfterSync(){
  const route = readRoute().route;
  if(!SYNC_ROUTES.includes(route)) return;                       // never disturb reader / book / search
  if(document.querySelector(".class-search-panel.is-open")) return; // user is typing
  lastRenderedRoute = "";
  renderRouteOnce();
}
function backgroundSync(){
  if(syncInFlight) return syncInFlight;
  clearTimeout(syncTimer);
  setSyncState("loading");
  syncInFlight = (async () => {
    try{
      const next = await loadLibraryData({ force:true });
      data = next; state.dataReady = true; syncAttempts = 0;
      setSyncState("ok");
      rerenderAfterSync();
    }catch(error){
      syncAttempts += 1;
      console.warn("Maktabah catalogue sync failed", error);
      setSyncState("failed");
      scheduleSyncRetry();
    }finally{ syncInFlight = null; }
  })();
  return syncInFlight;
}
window.addEventListener("online", () => { if(syncState === "failed") backgroundSync(); });
document.addEventListener("visibilitychange", () => { if(!document.hidden && syncState === "failed" && !syncInFlight) backgroundSync(); });

/* If the first screen has not appeared after 6s for ANY reason, render with whatever we have. */
function startBootWatchdog(){
  setTimeout(() => {
    if(!document.querySelector(".boot")) return;
    console.warn("Maktabah boot watchdog: forcing first render");
    try{ data = loadEmergencyLibrary(); state.dataReady = true; lastRenderedRoute = ""; renderRouteOnce(); }
    catch(error){ renderBootError(error); }
  }, 6000);
}

window.__krNativeRefresh = () => { Promise.resolve(refreshLibrary({source:"native"})).finally(()=>{ try{ getNativePlugin()?.refreshDone?.(); }catch{} }); };

function installPullToRefresh(){
  if(window.__krPullRefreshInstalled) return;
  window.__krPullRefreshInstalled=true;
  // Deliberate-pull rules: the gesture only counts if it starts with the page exactly at the
  // top, is a clearly vertical drag, is pulled well past a threshold AND is still held there
  // when the finger lifts. Quick flicks, scrolls inside lists/carousels, taps and drags that
  // begin while a fling is still settling never refresh.
  const PTR_ROUTES = new Set(["home","catalogue","classes","class","categories","category","favorites","search","more","downloads"]);
  const SLOP = 14;            // px of finger travel before the gesture is "a pull"
  const RESIST = 0.5;         // finger px -> indicator px
  const TRIGGER = 80;         // indicator px needed (= ~160px of finger travel)
  const MAX = 120;
  const COOLDOWN_MS = 4000;
  let t0 = 0, startY = 0, startX = 0, pull = 0, active = false, pulling = false, lastScrollAt = 0, lastRefreshAt = 0;
  window.addEventListener("scroll",()=>{ lastScrollAt = Date.now(); },{passive:true});

  const insideScroller = el => {
    for(let n = el; n && n !== document.body && n !== document.documentElement; n = n.parentElement){
      if(!(n instanceof HTMLElement)) continue;
      const cs = getComputedStyle(n);
      if((/(auto|scroll)/.test(cs.overflowY) && n.scrollHeight > n.clientHeight + 1) ||
         (/(auto|scroll)/.test(cs.overflowX) && n.scrollWidth > n.clientWidth + 1)) return true;
    }
    return false;
  };
  const blocked = () => !PTR_ROUTES.has(state.route) || (state.route === "search" && !searchHasResults()) || refreshInFlight || Date.now() - lastRefreshAt < COOLDOWN_MS ||
    document.querySelector(".modal-backdrop, .more-info-dialog, .class-search-panel.is-open, .lr-sheet-wrap.open");
  const reset = (keepIndicator=false) => {
    active = false; pulling = false; pull = 0;
    const ind = document.querySelector(".pull-refresh-indicator");
    if(ind && !keepIndicator && ind.dataset.state !== "refreshing") ind.remove();
  };

  document.addEventListener("touchstart",e=>{
    active = false; pulling = false; pull = 0;
    if(window.__krNativePtr || e.touches.length !== 1 || blocked()) return;
    if(window.scrollY > 0 || Date.now() - lastScrollAt < 160) return;   // must be settled at the very top
    if(insideScroller(e.target)) return;
    startY = e.touches[0].clientY; startX = e.touches[0].clientX; t0 = Date.now(); active = true;
  },{passive:true});

  document.addEventListener("touchmove",e=>{
    if(!active) return;
    if(e.touches.length !== 1 || window.scrollY > 0){ reset(); return; }
    const dy = e.touches[0].clientY - startY, dx = e.touches[0].clientX - startX;
    if(!pulling){
      if(dy < 0 || Math.abs(dx) > Math.abs(dy)){ if(Math.abs(dx) > SLOP || dy < -SLOP) reset(); return; }  // scrolling down the page or sideways
      if(dy < SLOP || Math.abs(dx) > dy * 0.6) return;                                                      // not clearly vertical yet
      pulling = true;
    }
    if(dy <= 0){ reset(); return; }
    pull = Math.min(MAX, (dy - SLOP) * RESIST);
    const ind = showRefreshIndicator(pull >= TRIGGER ? "release" : "pull");
    ind.style.transition = "none";
    ind.style.transform = `translate(-50%, ${Math.min(58, pull * 0.75)}px)`;
    ind.style.opacity = String(Math.min(1, pull / 28));
    const icon = ind.querySelector(".pull-refresh-icon i");
    if(icon) icon.style.transform = `rotate(${Math.round(pull / TRIGGER * 270)}deg)`;
    if(e.cancelable) e.preventDefault();
  },{passive:false});

  const finish = () => {
    if(!active) return;
    const go = pulling && pull >= TRIGGER && Date.now() - t0 >= 280;   // a fast flick is not a pull
    reset(go);
    if(go){ lastRefreshAt = Date.now(); refreshLibrary({source:"pull"}); }
  };
  document.addEventListener("touchend",finish,{passive:true});
  document.addEventListener("touchcancel",()=>reset(),{passive:true});
}

// State for the search-results screen (infinite loading of further result pages).
let searchObserver = null;
let searchLoadInFlight = null;
let searchIaInFlight = null;   // Archive.org load of the search screen (pull-to-refresh waits for it)
// Results of the last search, so coming back from a book shows the same list again.
// (The data layer remembers a finished query and would otherwise return nothing the second time.)
let searchSession = { q: "", books: [], done: false };
let searchRequestToken = 0;
// Archive.org part of the same search screen (kept so Back from a book shows the same list).
let archiveSession = { q: "", books: [], page: 0, done: false, started: false, tab: "lib", filter: "all", meta: {} };
let iaObserver = null;

function leadCard(book, lang){
  const ur=lang==="ur", L=t[lang];
  const title=ur?book.title:(book.titleEn||book.title);
  const progress=getBookProgress(book.id);
  const percent=Math.max(0,Math.min(100,Math.round(Number(progress?.percent)||0)));
  const pageNo=Number(progress?.page)||0, total=Number(progress?.totalPages)||Number(book.pages)||0;
  const label=(pageNo&&total)?(ur?`صفحہ ${pageNo} از ${total}`:`Page ${pageNo} of ${total}`)
    :(percent?(ur?`${percent}% مکمل`:`${percent}% complete`):(ur?"مطالعہ شروع کریں":"Ready to start"));
  const el=document.createElement("article");
  el.className=`home-lead tc-${paletteIndex(book.id)}`; el.id="homeLead"; el.tabIndex=0; el.setAttribute("role","link");
  el.setAttribute("aria-label",(ur?"مطالعہ جاری رکھیں: ":"Continue reading: ")+title);
  el.innerHTML=`<div class="cover is-mini lead-cover">${typesetCover(title,book.author,book.id)}${book.cover?coverMarkup(escapeHTML(book.cover),escapeHTML(title)):""}</div>
    <div class="lead-copy"><span class="lead-kicker">${escapeHTML(L.continue)}</span><h2 class="lead-title">${escapeHTML(title)}</h2><p class="lead-author">${escapeHTML(book.author||"")}</p>
    <div class="lead-progress"><div class="lead-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent}"><span style="width:${percent}%"></span></div><small>${escapeHTML(label)}</small></div>
    <button class="cta-btn" type="button">${escapeHTML(L.continueAction)}<i class="fa-solid fa-arrow-${ur?"left":"right"}"></i></button></div>`;
  const coverBox=el.querySelector(".lead-cover");
  wireCover(coverBox);
  const img=coverBox.querySelector("img");
  if(img) img.addEventListener("load",()=>{
    const pal=coverPalette(img);
    if(pal) for(const [k,v] of Object.entries(pal)) el.style.setProperty(k,v);
  },{once:true});
  const open=()=>openReader(book.id);
  el.addEventListener("click",open);
  el.addEventListener("keydown",e=>{ if((e.key==="Enter"||e.key===" ")&&e.target===el){ e.preventDefault(); open(); } });
  return el;
}

function welcomeCard(lang){
  const ur=lang==="ur", L=t[lang];
  const el=document.createElement("section"); el.className="home-welcome"; el.id="homeLead";
  el.innerHTML=`<div class="welcome-copy"><span class="lead-kicker">${ur?"کتب کا مطالعہ":"Your library"}</span><h2 class="welcome-title">${escapeHTML(L.tagline)}</h2>
    <button class="cta-btn" id="welcomeBrowse" type="button">${ur?"جماعتیں دیکھیں":"Browse classes"}<i class="fa-solid fa-arrow-${ur?"left":"right"}"></i></button></div>
    <svg class="welcome-art" viewBox="0 0 120 120" aria-hidden="true" focusable="false"><g fill="none" stroke="currentColor" stroke-width="1.4"><rect x="22" y="22" width="76" height="76" rx="6"/><rect x="22" y="22" width="76" height="76" rx="6" transform="rotate(45 60 60)"/><circle cx="60" cy="60" r="25"/><circle cx="60" cy="60" r="10"/></g></svg>`;
  el.querySelector("#welcomeBrowse").onclick=()=>navigate("classes");
  return el;
}

function renderHome(){
  const lang=currentLang(), L=t[lang], ur=lang==="ur";
  const recent=(data.recentBooks || data.books);
  const findBook=id=>data.byId?.get(id) || data.books.find(b=>b.id===id) || getArchiveBook(id);
  const historyBooks=getHistory().map(findBook).filter(Boolean).slice(0,6);
  const favoriteBooks=getFavorites().map(findBook).filter(Boolean).slice(0,12);
  const earlier=historyBooks.slice(1);
  const seeAll=ur?"سب دیکھیں":"See all";
  const head=(id,title,sub,href)=>`<div class="section-head"><div><h2 class="section-title">${title}</h2>${sub?`<p class="section-subtitle">${sub}</p>`:""}</div>${href?`<a class="section-link" href="${href}">${seeAll}</a>`:""}</div>`;
  const chip=(id,icon,text)=>`<button class="home-chip" id="${id}" type="button"><i class="fa-solid ${icon}"></i><span>${text}</span></button>`;
  const page=shell(ur?"السلام علیکم":"Assalamu alaikum", `
    <form class="search-pill" id="searchForm" role="search"><span class="search-pill-icon" aria-hidden="true">${icon("search")}</span><input id="searchInput" type="search" autocomplete="off" enterkeyhint="search" aria-label="${L.search}" placeholder="${L.search}"><button class="search-pill-clear" id="searchClear" type="button" hidden aria-label="${ur?"صاف کریں":"Clear"}"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6 6 18"/></svg></button></form>
    <div class="home-chips" aria-label="${ur?"فوری رسائی":"Quick access"}">${chip("quickClasses","fa-book-open",L.quickClasses)}${chip("quickCategories","fa-layer-group",L.quickCategories)}${chip("quickFavorites","fa-heart",L.quickFavorites)}${chip("quickHistory","fa-clock-rotate-left",L.quickHistory)}</div>
    <div id="homeLeadSlot"></div>
    ${earlier.length?`<section class="section home-shelf-section" id="earlierSection">${head("earlier",ur?"حال ہی میں کھولی گئی":"Recently opened","",null)}<div class="shelf" id="earlierShelf"></div></section>`:""}
    ${recent.length?`<section class="section home-shelf-section" id="recentSection">${head("recent",L.recent,"","#catalogue")}<div class="shelf" id="recentShelf"></div></section>`:`<section class="section home-shelf-section" id="recentSection">${head("recent",L.recent,"",null)}<div class="hp-empty">${icon("book")}<strong>${ur?"کتابوں کی فہرست ابھی دستیاب نہیں":"The book list isn't available yet"}</strong><p>${ur?"انٹرنیٹ چیک کر کے فہرست دوبارہ لوڈ کریں۔":"Check your connection and load the list again."}</p><button class="cta-btn" id="homeRetry" type="button">${icon("refresh")}${ur?"دوبارہ لوڈ کریں":"Reload list"}</button></div></section>`}
    ${favoriteBooks.length?`<section class="section home-shelf-section" id="favSection">${head("fav",ur?"پسندیدہ کتب":"Your favorites","","#favorites")}<div class="shelf" id="favShelf"></div></section>`:""}`,"home");
  page.classList.add("home-page");
  if(state.prevRoute!=="home") page.classList.add("hp-animate");

  page.querySelector("#homeLeadSlot").appendChild(historyBooks.length?leadCard(historyBooks[0],lang):welcomeCard(lang));

  const fillShelf=(selector,books,href)=>{
    const target=page.querySelector(selector); if(!target) return;
    books.forEach(b=>target.appendChild(bookCard(b,lang,(a,id)=>a==="book"?navigate("book",{id}):null)));
    if(href){
      const more=document.createElement("a"); more.className="shelf-more"; more.href=href;
      more.innerHTML=`<span class="shelf-more-ring"><i class="fa-solid fa-arrow-${ur?"left":"right"}"></i></span><span>${seeAll}</span>`;
      target.appendChild(more);
    }
  };
  fillShelf("#earlierShelf",earlier,null);
  fillShelf("#recentShelf",recent.slice(0,10),"#catalogue");
  fillShelf("#favShelf",favoriteBooks,"#favorites");
  hydrateMissingBooks([...getHistory().slice(0,10),...getFavorites().slice(0,24)],()=>{
    if(state.route==="home"){ lastRenderedRoute=""; renderRouteOnce(); }
  });

  // Keeps class statistics warm for the Classes screen (Home no longer shows the class grid).
  loadClassStats().catch(error=>console.warn('Maktabah class stats unavailable.', error));

  const searchInput=page.querySelector("#searchInput"), searchClear=page.querySelector("#searchClear");
  // Tapping the search bar opens the search screen (recent searches + shortcuts); typing happens there.
  searchInput.addEventListener("focus",()=>{ searchInput.blur(); navigate("search",{q:""}); });
  searchInput.addEventListener("input",()=>{searchClear.hidden=!searchInput.value;});
  searchClear.onclick=()=>{searchInput.value="";searchClear.hidden=true;searchInput.focus();};
  page.querySelector("#homeRetry")?.addEventListener("click",()=>refreshLibrary({source:"button"}));
  page.querySelector("#searchForm").onsubmit=e=>{e.preventDefault();const q=page.querySelector("#searchInput").value.trim();if(q)navigate("search",{q});};
  page.querySelector("#quickClasses").onclick=()=>navigate("classes");
  page.querySelector("#quickCategories").onclick=()=>navigate("categories");
  page.querySelector("#quickFavorites").onclick=()=>navigate("favorites");
  page.querySelector("#quickHistory").onclick=()=>{
    const target=page.querySelector("#earlierSection")||(historyBooks.length?page.querySelector("#homeLead"):null);
    if(target) target.scrollIntoView({behavior:"smooth",block:"center"});
    else showToast(ur?"ابھی مطالعہ کی تاریخ خالی ہے۔":"No recent reading yet.");
  };
}

/* Updates the address bar of the screen being shown WITHOUT announcing a navigation. Calling navigate() here
   fired a fake popstate that closed the open search panel and rebuilt the whole screen. */
function syncUrl(route, params, flag){
  const keep = flag && history.state?.[flag];
  replaceRoute(route, params);
  if(keep) history.replaceState({...history.state,[flag]:true},"");
  lastRenderedRoute = location.hash || "#home";
}

/* Books the screen needs (favourites, history) may not be in the partly loaded catalogue yet: ask the server
   for exactly those, then let the caller redraw. Ids the server does not have are never asked again. */
const missingBookIds = new Set();
function hydrateMissingBooks(ids, onFound){
  const all=[...new Set(ids)].filter(Boolean);
  // Archive.org books come from their own small store; if one is missing (cleared storage), fetch it back.
  const missingIa=all.filter(id=>isArchiveId(id) && !getArchiveBook(id) && !missingBookIds.has(id)).slice(0,12);
  if(missingIa.length){
    Promise.all(missingIa.map(id=>hydrateArchiveBook(id).then(b=>{ if(!b) missingBookIds.add(id); return b; }).catch(()=>null)))
      .then(found=>{ if(found.some(Boolean)) onFound?.(); });
  }
  const missing=all.filter(id=>!isArchiveId(id) && !data.byId?.get(id) && !missingBookIds.has(id));
  if(!missing.length) return;
  fetchBooksByIds(missing).then(found=>{
    const got=new Set(found.map(b=>b.id));
    missing.forEach(id=>{ if(!got.has(id)) missingBookIds.add(id); });
    if(found.length) onFound?.();
  }).catch(()=>{});   // offline / server problem: keep what is on screen
}

function classShell(title, content){
  const lang=currentLang();
  title = escapeHTML(title);
  app.innerHTML = "";
  const header = document.createElement("header");
  header.className = "class-topbar";
  header.innerHTML = `<div class="class-topbar-main">
    <button class="class-header-action class-back-btn" id="classBack" type="button" aria-label="${escapeHTML(t[lang].back)}" title="${escapeHTML(t[lang].back)}"><i class="fa-solid ${lang==="ur"?"fa-arrow-right":"fa-arrow-left"}"></i></button>
    <div class="class-header-title" title="${title}">${title}</div>
    <button class="class-header-action class-search-toggle" id="classSearchToggle" type="button" aria-label="${escapeHTML(t[lang].search)}" aria-expanded="false" aria-controls="classSearchPanel" title="${escapeHTML(t[lang].search)}"><i class="fa-solid fa-magnifying-glass"></i></button>
  </div>
  <div class="class-search-panel" id="classSearchPanel" aria-hidden="true">
    <form class="search-box class-search-form" id="classSearchForm">
      <span aria-hidden="true"><i class="fa-solid fa-magnifying-glass"></i></span>
      <input id="classSearchInput" autocomplete="off" enterkeyhint="search" aria-label="${escapeHTML(t[lang].search)}" placeholder="${escapeHTML(t[lang].search)}" disabled>
      <button class="class-search-clear" id="classSearchClear" type="button" aria-label="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}" title="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}"><i class="fa-solid fa-xmark"></i></button>
    </form>
  </div>`;
  app.appendChild(header);
  const page=document.createElement("main");
  page.className="page class-screen-page";
  page.innerHTML=content;
  app.appendChild(page);
  return {page,header};
}

function categoryShell(title, content){
  const lang=currentLang();
  title = escapeHTML(title);
  app.innerHTML = "";
  const header = document.createElement("header");
  header.className = "class-topbar category-topbar";
  header.innerHTML = `<div class="class-topbar-main">
    <button class="class-header-action class-back-btn" id="categoryBack" type="button" aria-label="${escapeHTML(t[lang].back)}" title="${escapeHTML(t[lang].back)}"><i class="fa-solid ${lang==="ur"?"fa-arrow-right":"fa-arrow-left"}"></i></button>
    <div class="class-header-title" title="${title}">${title}</div>
    <button class="class-header-action class-search-toggle" id="categorySearchToggle" type="button" aria-label="${escapeHTML(t[lang].search)}" aria-expanded="false" aria-controls="categorySearchPanel" title="${escapeHTML(t[lang].search)}"><i class="fa-solid fa-magnifying-glass"></i></button>
  </div>
  <div class="class-search-panel" id="categorySearchPanel" aria-hidden="true">
    <form class="search-box class-search-form" id="categorySearchForm">
      <span aria-hidden="true"><i class="fa-solid fa-magnifying-glass"></i></span>
      <input id="categorySearchInput" autocomplete="off" enterkeyhint="search" aria-label="${escapeHTML(t[lang].search)}" placeholder="${escapeHTML(t[lang].search)}" disabled>
      <button class="class-search-clear" id="categorySearchClear" type="button" aria-label="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}" title="${escapeHTML(lang==="ur"?"تلاش بند کریں":"Close search")}"><i class="fa-solid fa-xmark"></i></button>
    </form>
  </div>`;
  app.appendChild(header);
  const page=document.createElement("main");
  page.className="page class-screen-page category-screen-page";
  page.innerHTML=content;
  app.appendChild(page);
  return {page,header};
}

// One screen for a single class and for "All books" (all=true), so both look and behave exactly the same.
function renderClass(id, all=false){
  const lang=currentLang(), L=t[lang], c=all?null:data.classes.find(x=>x.id===id); if(!all && !c)return navigate("classes");
  const title=all?L.catalogue:langName(c,lang), routeName=all?"catalogue":"class";
  const baseParams=()=>all?{}:{id};
  const classBooks=all?(data.books||[]):(data.byClass?.get(id) || data.books.filter(b=>(b.classIds||[b.classId]).includes(id)));
  const routeParams=readRoute().params;
  const initialType=routeParams.type==="matn" || routeParams.type==="sharah" ? routeParams.type : null;
  const initialQuery=String(routeParams.q||"");
  const {page,header}=classShell(title, `<div class="class-intro"><div><h1 class="section-title">${escapeHTML(title)}</h1><div class="muted" id="classBookCount"></div></div><div class="class-intro-icon" aria-hidden="true"><i class="fa-solid fa-book-open"></i></div></div><div class="actions discovery-filters" role="group" aria-label="${lang==="ur"?"کتب کی قسم":"Book type"}"><button class="btn active" id="all" aria-pressed="true"><i class="fa-solid fa-layer-group"></i> ${L.filterAll}</button><button class="btn" id="matn" aria-pressed="false"><i class="fa-solid fa-book-open"></i> ${L.filterMatn}</button><button class="btn" id="sharah" aria-pressed="false"><i class="fa-solid fa-book"></i> ${L.filterSharah}</button></div><section class="section class-books-section"><div class="section-head"><h2 class="section-title" id="bookHeading">${L.filterAll}</h2></div><div class="grid book-grid" id="books"></div></section>`);
  const filters=[...page.querySelectorAll(".discovery-filters .btn")];
  const searchInput=header.querySelector("#classSearchInput");
  const searchPanel=header.querySelector("#classSearchPanel");
  const searchToggle=header.querySelector("#classSearchToggle");
  const searchClear=header.querySelector("#classSearchClear");
  let searchTimer=0;
  const closeSearchPanel=({clear=false}={})=>{
    searchPanel.classList.remove("is-open");
    searchPanel.setAttribute("aria-hidden","true");
    searchToggle.setAttribute("aria-expanded","false");
    searchToggle.setAttribute("aria-label",L.search);
    searchToggle.title=L.search;
    searchToggle.innerHTML='<i class="fa-solid fa-magnifying-glass"></i>';
    searchInput.disabled=true;
    if(clear){
      searchInput.value="";
      const type=readRoute().params.type||initialType;
      const nextParams=baseParams(); if(type)nextParams.type=type;
      replaceRoute(routeName,nextParams);
    }
  };
  const openSearchPanel=()=>{
    if(searchPanel.classList.contains("is-open")) return;
    if(!history.state?.classSearchOpen){
      history.pushState({...history.state,classSearchOpen:true},"",location.href);
    }
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
    requestAnimationFrame(()=>{searchInput.focus({preventScroll:true}); searchInput.select();});
  };
  const closeSearchViaBack=({clear=true}={})=>{
    const hadSearchHistory=Boolean(history.state?.classSearchOpen);
    if(clear){
      searchInput.value="";
      const type=readRoute().params.type||initialType;
      const nextParams=baseParams(); if(type)nextParams.type=type;
      replaceRoute(routeName,nextParams);
    }
    if(hadSearchHistory && history.length>1) history.back();
    else closeSearchPanel();
  };
  window.__krClassSearchClose = closeSearchPanel;
  const filtersType=()=>readRoute().params.type||initialType;
  const render=(type=initialType,{updateUrl=true,query=searchInput.value.trim()}={})=>{
    const normalizedQuery=query.trim();
    const scopedBooks=classBooks.filter(b=>!type||b.bookType===type);
    const books=searchBooks(scopedBooks,normalizedQuery);
    const target=page.querySelector("#books"); target.innerHTML="";
    filters.forEach(btn=>{const active=btn.id===(type||"all");btn.classList.toggle("active",active);btn.setAttribute("aria-pressed",String(active));});
    page.querySelector("#bookHeading").textContent=type==="matn"?L.filterMatn:type==="sharah"?L.filterSharah:L.filterAll;
    page.querySelector("#classBookCount").textContent=`${books.length} ${lang==="ur"?"کتب":"books"}`;
    if(updateUrl){
      const nextParams=baseParams(); if(type)nextParams.type=type; if(normalizedQuery)nextParams.q=normalizedQuery;
      syncUrl(routeName,nextParams,"classSearchOpen");
    }
    if(!books.length){target.innerHTML=`<div class="empty contextual-empty"><i class="fa-solid fa-book-open"></i><strong>${escapeHTML(normalizedQuery?L.noSearch:L.noClassBooks)}</strong><p>${escapeHTML(normalizedQuery?(lang==="ur"?`“${normalizedQuery}” کے لیے کوئی کتاب نہیں ملی۔`:`No books found for “${normalizedQuery}”.`):(lang==="ur"?"دوسرا فلٹر منتخب کر کے دیکھیں۔":"Try another filter or browse another class."))}</p>${normalizedQuery?"":`<a class="cta-btn" href="#catalogue">${escapeHTML(L.allBooks)}</a>`}</div>`;return;}
    books.forEach(b=>target.appendChild(bookCard(b,lang,(a,x)=>a==="book"?navigate("book",{id:x,...(all?{fromCatalogue:"1"}:{fromClass:id}),type:type||"",q:normalizedQuery}):null)));
  };
  header.querySelector("#classBack").onclick=()=>{ if(searchPanel.classList.contains("is-open")){ closeSearchViaBack(); return; } goBackInApp(); };
  searchToggle.onclick=()=>{ if(searchPanel.classList.contains("is-open")) closeSearchViaBack(); else openSearchPanel(); };
  searchClear.onclick=()=>closeSearchViaBack();
  page.querySelector("#all").onclick=()=>render(null);
  page.querySelector("#matn").onclick=()=>render("matn");
  page.querySelector("#sharah").onclick=()=>render("sharah");
  header.querySelector("#classSearchForm").onsubmit=e=>{e.preventDefault();render(filtersType(),{query:searchInput.value});};
  searchInput.addEventListener("input",()=>{
    clearTimeout(searchTimer);
    searchTimer=setTimeout(()=>{
      const type=filtersType();
      const normalizedQuery=searchInput.value.trim();
      render(type,{updateUrl:false,query:searchInput.value});
      const nextParams=baseParams(); if(type) nextParams.type=type; if(normalizedQuery) nextParams.q=normalizedQuery;
      replaceRoute(routeName,nextParams);
      if(searchPanel.classList.contains("is-open")) history.replaceState({...history.state,classSearchOpen:true},"",location.href);
    },180);
  });
  if(initialQuery){
    searchInput.value=initialQuery;
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
  }
  render(initialType,{updateUrl:false,query:initialQuery});
}

/* One card design for both the Classes and Categories tabs. */
function renderCardList({title,sub,route,pageClass,kind,items,allCard,getLocalTotal,loadStats,statsLabel,onOpen}){
  const lang=currentLang(), L=t[lang], ur=lang==="ur";
  const page=shell(title,`<header class="tab-head"><div><h1 class="tab-title">${title}</h1><p class="tab-sub">${sub}</p></div></header><div class="class-list" id="cardList"></div>`,route);
  page.classList.add("classes-page",pageClass);
  const list=page.querySelector("#cardList");
  const bookWord=ur?"کتب":"books", noBooks=ur?"ابھی کوئی کتاب نہیں":"No books yet";
  const fill=(row,stat)=>{
    const count=row.querySelector(".class-count");
    if(!stat){ count.textContent=`— ${bookWord}`; row.classList.remove("is-empty"); return; }
    count.textContent=stat.total?`${stat.total} ${bookWord}`:noBooks;
    row.classList.toggle("is-empty",!stat.total);
  };
  // Counts are only trustworthy once the whole catalogue is loaded; otherwise show a placeholder
  // and fill in the authoritative numbers from the stats loader.
  const complete=getLibraryCacheInfo().complete;
  if(allCard){
    const allRow=document.createElement("a");
    allRow.className="class-row is-all"; allRow.href=allCard.href; allRow.style.setProperty("--i",0);
    allRow.innerHTML=`<span class="class-ico">${icon("library")}</span><span class="class-text"><span class="class-name">${escapeHTML(allCard.name)}</span><span class="class-count">${escapeHTML(allCard.sub)}</span></span><i class="fa-solid fa-chevron-${ur?"left":"right"} class-go" aria-hidden="true"></i>`;
    list.appendChild(allRow);
  }
  items.forEach((c,i)=>{
    const row=document.createElement("button");
    const idn=identityFor(kind,c);
    row.type="button"; row.className=`class-row tc-${idn.tone}`; row.dataset.itemId=c.id; row.style.setProperty("--i",Math.min(i+(allCard?1:0),10));
    row.innerHTML=`<span class="class-ico" aria-hidden="true">${idn.glyph}</span><span class="class-name">${escapeHTML(langName(c,lang))}</span><span class="class-count"></span>`;
    row.onclick=()=>onOpen(c);
    fill(row, complete?{total:getLocalTotal(c)}:null);
    list.appendChild(row);
  });
  loadStats().then(stats=>{
    if(!stats || !page.isConnected) return;
    list.querySelectorAll(".class-row[data-item-id]").forEach(row=>{ const stat=stats[row.dataset.itemId]; if(stat) fill(row,stat); });
  }).catch(error=>console.warn(`Maktabah ${statsLabel} stats unavailable.`, error));
}

function renderClasses(){
  const lang=currentLang(), L=t[lang], ur=lang==="ur";
  renderCardList({
    title:L.classes,
    sub:ur?"اپنی جماعت منتخب کریں اور متعلقہ کتب دیکھیں":"Choose a class to browse its books",
    route:"classes", pageClass:"classes-screen", kind:"class",
    items:data.classes,
    allCard:{href:"#catalogue",name:L.allBooks,sub:ur?"پوری لائبریری ایک جگہ":"The whole library in one place"},
    getLocalTotal:c=>(data.byClass?.get(c.id)||[]).length,
    loadStats:loadClassStats, statsLabel:"class",
    onOpen:c=>navigate("class",{id:c.id})
  });
}

function renderCategories(){
  const lang=currentLang(), ur=lang==="ur";
  renderCardList({
    title:ur?"زمرے":"Categories",
    sub:ur?"موضوع کے لحاظ سے کتب دیکھیں":"Browse books by topic",
    route:"categories", pageClass:"categories-page", kind:"category",
    items:data.categories,
    getLocalTotal:c=>(data.byCategory?.get(c.id)||[]).length,
    loadStats:loadCategoryStats, statsLabel:"category",
    onOpen:c=>navigate("category",{id:c.id})
  });
}

function renderCategory(id){
  const lang=currentLang(),L=t[lang],c=data.categories.find(x=>x.id===id);
  if(!c)return navigate("categories");
  const books=data.byCategory?.get(id) || data.books.filter(b=>(b.categoryIds||[]).includes(id));
  const routeParams=readRoute().params,initialQuery=String(routeParams.q||"");
  const {page,header}=categoryShell(langName(c,lang),`<div class="class-intro category-intro"><div><h1 class="section-title">${escapeHTML(langName(c,lang))}</h1><div class="muted" id="categoryBookCount"></div></div><div class="class-intro-icon" aria-hidden="true"><i class="fa-solid fa-layer-group"></i></div></div><section class="section category-books-section"><div class="section-head"><h2 class="section-title">${L.catalogue}</h2></div><div class="grid book-grid" id="books"></div></section>`);
  const searchInput=header.querySelector("#categorySearchInput");
  const searchPanel=header.querySelector("#categorySearchPanel");
  const searchToggle=header.querySelector("#categorySearchToggle");
  const searchClear=header.querySelector("#categorySearchClear");
  let timer=0;

  const baseParams=()=>({id});
  const closeSearchPanel=({clear=false}={})=>{
    searchPanel.classList.remove("is-open");
    searchPanel.setAttribute("aria-hidden","true");
    searchToggle.setAttribute("aria-expanded","false");
    searchToggle.setAttribute("aria-label",L.search);
    searchToggle.title=L.search;
    searchToggle.innerHTML='<i class="fa-solid fa-magnifying-glass"></i>';
    searchInput.disabled=true;
    if(clear){
      searchInput.value="";
      replaceRoute("category",baseParams());
    }
  };
  const openSearchPanel=()=>{
    if(searchPanel.classList.contains("is-open"))return;
    if(!history.state?.categorySearchOpen){
      history.pushState({...history.state,categorySearchOpen:true},"",location.href);
    }
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
    requestAnimationFrame(()=>{searchInput.focus({preventScroll:true});searchInput.select();});
  };
  const closeSearchViaBack=({clear=true}={})=>{
    const hadSearchHistory=Boolean(history.state?.categorySearchOpen);
    if(clear){
      searchInput.value="";
      replaceRoute("category",baseParams());
    }
    if(hadSearchHistory && history.length>1)history.back();
    else closeSearchPanel();
  };
  window.__krCategorySearchClose=closeSearchPanel;

  const render=(query=searchInput.value.trim(),updateUrl=true)=>{
    const normalizedQuery=query.trim(),filtered=searchBooks(books,normalizedQuery),target=page.querySelector("#books");
    target.innerHTML="";
    page.querySelector("#categoryBookCount").textContent=`${filtered.length} ${lang==="ur"?"کتب":"books"}`;
    if(updateUrl){
      const nextParams={id};
      if(normalizedQuery)nextParams.q=normalizedQuery;
      syncUrl("category",nextParams,"categorySearchOpen");
    }
    if(!filtered.length){
      target.innerHTML=`<div class="empty contextual-empty"><i class="fa-solid fa-layer-group"></i><strong>${escapeHTML(normalizedQuery?L.noSearch:L.noCategoryBooks)}</strong><p>${escapeHTML(normalizedQuery?(lang==="ur"?`“${normalizedQuery}” کے لیے کوئی کتاب نہیں ملی۔`:`No books found for “${normalizedQuery}”.`):(lang==="ur"?"دوسرا زمرہ منتخب کر کے دیکھیں۔":"Browse another category to find more books."))}</p>${normalizedQuery?"":`<a class="cta-btn" href="#catalogue">${escapeHTML(L.allBooks)}</a>`}</div>`;
      return;
    }
    filtered.forEach(b=>target.appendChild(bookCard(b,lang,(a,x)=>a==="book"?navigate("book",{id:x,fromCategory:id,q:normalizedQuery}):null)));
  };

  header.querySelector("#categoryBack").onclick=()=>{
    if(searchPanel.classList.contains("is-open")){closeSearchViaBack();return;}
    goBackInApp();
  };
  searchToggle.onclick=()=>{
    if(searchPanel.classList.contains("is-open"))closeSearchViaBack();
    else openSearchPanel();
  };
  searchClear.onclick=()=>closeSearchViaBack();
  header.querySelector("#categorySearchForm").onsubmit=e=>{e.preventDefault();render(searchInput.value);};
  searchInput.addEventListener("input",()=>{
    clearTimeout(timer);
    timer=setTimeout(()=>{
      const normalizedQuery=searchInput.value.trim();
      render(searchInput.value,false);
      const nextParams={id};
      if(normalizedQuery)nextParams.q=normalizedQuery;
      replaceRoute("category",nextParams);
      if(searchPanel.classList.contains("is-open"))history.replaceState({...history.state,categorySearchOpen:true},"",location.href);
    },180);
  });

  if(initialQuery){
    searchInput.value=initialQuery;
    searchInput.disabled=false;
    searchPanel.classList.add("is-open");
    searchPanel.setAttribute("aria-hidden","false");
    searchToggle.setAttribute("aria-expanded","true");
    searchToggle.setAttribute("aria-label",lang==="ur"?"تلاش بند کریں":"Close search");
    searchToggle.title=lang==="ur"?"تلاش بند کریں":"Close search";
    searchToggle.innerHTML='<i class="fa-solid fa-xmark"></i>';
  }
  render(initialQuery,false);
}
const RECENT_SEARCH_KEY="krl_recent_searches_v1";
function getRecentSearches(){
  try{const v=JSON.parse(localStorage.getItem(RECENT_SEARCH_KEY)||"[]");return Array.isArray(v)?v.filter(x=>typeof x==="string"&&x.trim()).slice(0,8):[];}catch{return [];}
}
function addRecentSearch(q){
  q=String(q||"").trim(); if(!q) return;
  try{const list=[q,...getRecentSearches().filter(x=>x.toLowerCase()!==q.toLowerCase())].slice(0,8);localStorage.setItem(RECENT_SEARCH_KEY,JSON.stringify(list));}catch{}
}
function clearRecentSearches(){ try{localStorage.removeItem(RECENT_SEARCH_KEY);}catch{} }

function renderSearch(q){
  const lang=currentLang(),L=t[lang],ur=lang==="ur";
  q=String(q||"").trim();
  const S=ur
    ?{label:"تلاش کے نتائج",searching:"نتائج تلاش کی جا رہی ہیں…",clear:"صاف کریں",clearInput:"تلاش صاف کریں",recent:"حالیہ تلاشیں",hint:"کتاب کا نام، مصنف یا کوئی لفظ لکھ کر تلاش کریں۔",browse:"تمام کتب دیکھیں",classes:"جماعتیں",categories:"زمرے",retry:"دوبارہ کوشش کریں",failed:"نتائج لوڈ نہیں ہو سکے۔",failedHint:"انٹرنیٹ چیک کر کے دوبارہ کوشش کریں۔",loading:"مزید نتائج لوڈ ہو رہے ہیں…",done:"تمام نتائج دکھا دیے گئے ہیں۔",moreErr:"نتائج لوڈ نہیں ہو سکے۔ دوبارہ کوشش کریں۔",none:"کوئی نتیجہ نہیں ملا"}
    :{label:"Search results",searching:"Searching…",clear:"Clear",clearInput:"Clear search",recent:"Recent searches",hint:"Type a title, author or any word to search.",browse:"Browse all books",classes:"Classes",categories:"Categories",retry:"Try again",failed:"Could not load results.",failedHint:"Check your connection and try again.",loading:"Loading more results…",done:"All matching results loaded.",moreErr:"Could not load more results.",none:"No results found"};
  const back=ur?"fa-arrow-right":"fa-arrow-left";
  const recents=q?[]:getRecentSearches();
  const chip=(txt,attr)=>`<button type="button" class="sr-chip" ${attr}>${escapeHTML(txt)}</button>`;
  const emptyQuery=`<section class="sr-start" id="srStart">
      ${recents.length?`<div class="sr-sec-head"><h2>${S.recent}</h2><button type="button" class="sr-link" id="srClearRecents">${S.clear}</button></div><div class="sr-chips">${recents.map(r=>chip(r,`data-q="${escapeHTML(r)}"`)).join("")}</div>`
        :`<div class="sr-hint"><span class="sr-hint-ico" aria-hidden="true">${icon("search")}</span><p>${S.hint}</p></div>`}
      <div class="sr-chips sr-browse"><button type="button" class="sr-chip is-soft" id="srClasses">${S.classes}</button><button type="button" class="sr-chip is-soft" id="srCategories">${S.categories}</button><button type="button" class="sr-chip is-soft" id="srAll">${S.browse}</button></div>
    </section>`;
  const skeletons=Array.from({length:6},()=>`<div class="sr-skel" aria-hidden="true"><div class="sr-skel-cover"></div><div class="sr-skel-line"></div><div class="sr-skel-line short"></div></div>`).join("");
  const A=ur
    ?{tabLib:"لائبریری",label:"Archive.org کے نتائج",intro:"یہ کتب Archive.org سے ہیں۔ آپ انہیں یہیں پڑھ اور ڈاؤنلوڈ کر سکتے ہیں۔",searching:"Archive.org سے تلاش ہو رہی ہے…",loading:"مزید نتائج لوڈ ہو رہے ہیں…",more:"مزید نتائج",done:"Archive.org کے تمام نتائج دکھا دیے گئے ہیں۔",none:"Archive.org پر بھی کوئی نتیجہ نہیں ملا",noneHint:"کوئی دوسرا لفظ، یا کتاب کا نام انگریزی/رومن میں آزما کر دیکھیں۔",fail:"Archive.org سے رابطہ نہیں ہو سکا۔",failHint:"انٹرنیٹ چیک کر کے دوبارہ کوشش کریں۔",retry:"دوبارہ کوشش کریں",nudgeText:"مطلوبہ کتاب نہیں ملی؟",nudgeBtn:"Archive.org میں تلاش کریں",emptyCta:"Archive.org میں تلاش کریں",tabs:"تلاش کے ذرائع",fLabel:"زبان",fAll:"سب",fUr:"اردو",fOther:"دیگر زبانیں",urduNote:"اردو لفظوں میں بھی تلاش کیا گیا:",noFilter:"اس فلٹر میں ابھی کوئی کتاب نہیں ملی۔",showAll:"سب کتب دکھائیں"}
    :{tabLib:"Library",label:"Archive.org results",intro:"These books come from Archive.org. You can read and download them right here.",searching:"Searching Archive.org…",loading:"Loading more results…",more:"Load more results",done:"All Archive.org results are shown.",none:"No results on Archive.org either",noneHint:"Try another word, or the title in English / Roman letters.",fail:"Could not reach Archive.org.",failHint:"Check your connection and try again.",retry:"Try again",nudgeText:"Can't find your book?",nudgeBtn:"Search Archive.org",emptyCta:"Search Archive.org",tabs:"Search sources",fLabel:"Language",fAll:"All",fUr:"Urdu",fOther:"Other languages",urduNote:"Also searched in Urdu script:",noFilter:"No books match this filter yet.",showAll:"Show all books"};
  const tabsMarkup=`<div class="sr-tabs" role="tablist" aria-label="${escapeHTML(A.tabs)}">
      <button type="button" role="tab" class="sr-tab is-active" id="tabLib" aria-selected="true" aria-controls="libPanel"><span>${A.tabLib}</span><em class="sr-tab-n" id="tabLibN"></em></button>
      <button type="button" role="tab" class="sr-tab" id="tabIa" aria-selected="false" aria-controls="iaPanel" tabindex="-1">${ARCHIVE_ICON}<span>Archive.org</span><em class="sr-tab-n" id="tabIaN"></em></button>
    </div>`;
  const iaPanelMarkup=`<div class="sr-panel" id="iaPanel" role="tabpanel" aria-labelledby="tabIa" hidden>
      <header class="sr-head"><p class="sr-label">${A.label}</p><h1 class="sr-query">“<bdi>${escapeHTML(q)}</bdi>”</h1><p class="sr-sub" id="iaSummary" aria-live="polite"></p></header>
      <p class="ia-intro">${ARCHIVE_ICON}<span>${A.intro}</span></p>
      <p class="ia-urdu-note" id="iaNote" hidden></p>
      <div class="ia-tools" id="iaTools" role="group" aria-label="${escapeHTML(A.fLabel)}" hidden>
        <button type="button" class="ia-chip" data-f="all" aria-pressed="true">${A.fAll}</button>
        <button type="button" class="ia-chip" data-f="ur" aria-pressed="false">${A.fUr}</button>
        <button type="button" class="ia-chip" data-f="other" aria-pressed="false">${A.fOther}</button>
      </div>
      <div class="grid book-grid" id="iaGrid"></div>
      <div class="ia-foot" id="iaFoot" aria-live="polite"></div>
    </div>`;
  const page=document.createElement("main");
  page.className="sr-screen sr-page"; page.setAttribute("aria-label",ur?"تلاش":"Search");
  page.innerHTML=`<header class="sr-top">
      <button class="icon-btn sr-back" id="searchBack" type="button" aria-label="${escapeHTML(L.back)}"><i class="fa-solid ${back}"></i></button>
      <form class="search-pill sr-pill" id="searchForm" role="search"><span class="search-pill-icon" aria-hidden="true">${icon("search")}</span><input id="searchInput" type="search" value="${escapeHTML(q)}" autocomplete="off" enterkeyhint="search" aria-label="${escapeHTML(L.search)}" placeholder="${escapeHTML(L.search)}"><button class="search-pill-clear" id="searchClear" type="button" aria-label="${S.clearInput}" ${q?"":"hidden"}><i class="fa-solid fa-xmark"></i></button></form>${q?tabsMarkup:""}
    </header>
    <section class="page sr-body">${q?`<div class="sr-panel" id="libPanel" role="tabpanel" aria-labelledby="tabLib"><header class="sr-head"><p class="sr-label">${S.label}</p><h1 class="sr-query">“<bdi>${escapeHTML(q)}</bdi>”</h1><p class="sr-sub" id="searchSummary" aria-live="polite">${S.searching}</p></header>
    <div class="grid book-grid" id="books">${skeletons}</div>
    <div class="catalogue-loader" id="searchLoader" data-state="idle" aria-live="polite"><span class="catalogue-loader-spinner" aria-hidden="true"><i class="fa-solid fa-arrows-rotate"></i></span><span id="searchLoaderText"></span><button type="button" class="sr-link sr-loader-retry" id="searchLoaderRetry" hidden>${S.retry}</button></div></div>${iaPanelMarkup}`:emptyQuery}</section>`;
  app.innerHTML=""; app.appendChild(page);
  searchObserver?.disconnect(); searchObserver=null;
  iaObserver?.disconnect(); iaObserver=null;
  const $=s=>page.querySelector(s);
  const input=$("#searchInput"),clearBtn=$("#searchClear");
  const tabLib=$("#tabLib"),tabIa=$("#tabIa"),tabLibN=$("#tabLibN"),tabIaN=$("#tabIaN"),libPanel=$("#libPanel"),iaPanel=$("#iaPanel"),iaGrid=$("#iaGrid"),iaFoot=$("#iaFoot"),iaSummary=$("#iaSummary");

  $("#searchBack").onclick=()=>goBackInApp();
  // Scrolling the results hides the keyboard so the whole list is visible.
  let lastY=window.scrollY;
  const onScroll=()=>{
    if(!page.isConnected){window.removeEventListener("scroll",onScroll);return;}
    if(Math.abs(window.scrollY-lastY)>12 && document.activeElement===input) input.blur();
    lastY=window.scrollY;
  };
  window.addEventListener("scroll",onScroll,{passive:true});
  input.addEventListener("input",()=>{clearBtn.hidden=!input.value;});
  clearBtn.onclick=()=>{input.value="";clearBtn.hidden=true;input.focus();};
  const run=(text)=>{
    const next=String(text||"").trim();
    if(!next){input.focus();return;}
    if(next===q) return;
    navigate("search",{q:next},{replace:state.route==="search"});
  };
  $("#searchForm").onsubmit=e=>{e.preventDefault();input.blur();run(input.value);};

  if(!q){
    page.querySelectorAll(".sr-chip[data-q]").forEach(b=>b.onclick=()=>run(b.dataset.q));
    $("#srClearRecents")?.addEventListener("click",()=>{clearRecentSearches();renderSearch("");});
    $("#srClasses").onclick=()=>navigate("classes");
    $("#srCategories").onclick=()=>navigate("categories");
    $("#srAll").onclick=()=>navigate("catalogue");
    setTimeout(()=>{try{input.focus();}catch{}},60);
    return;
  }

  const token=++searchRequestToken;
  searchLoadInFlight=null; // a slow request from the previous query must not block this one
  if(searchSession.q!==q) searchSession={q,books:[],done:false};
  const target=$("#books"),loader=$("#searchLoader"),loaderText=$("#searchLoaderText"),retryBtn=$("#searchLoaderRetry");
  const setLoader=(mode)=>{
    loader.dataset.state=mode;
    retryBtn.hidden=mode!=="error";
    loaderText.textContent=mode==="loading"?S.loading:mode==="done"?S.done:mode==="error"?S.moreErr:"";
  };
  const clearSkeleton=()=>target.querySelectorAll(".sr-skel").forEach(n=>n.remove());
  const updateSummary=(count,done)=>{
    tabLibN.textContent=`${count}${done?"":"+"}`;
    $("#searchSummary").textContent=ur?(count===1&&done?"1 کتاب":`${count}${done?"":"+"} کتب`):`${count}${done?"":"+"} ${count===1&&done?"book":"books"}`;
  };
  const showEmpty=()=>{
    target.innerHTML=`<div class="sr-empty"><span class="sr-empty-ico" aria-hidden="true">${icon("search")}</span><strong>${escapeHTML(L.noSearch)}</strong><p>${escapeHTML(ur?`“${q}” کے لیے کوئی نتیجہ نہیں ملا۔ ${L.noSearchHint}`:`No results for “${q}”. ${L.noSearchHint}`)}</p><div class="sr-empty-actions"><button type="button" class="sr-cta ia-cta" id="srEmptyIa">${ARCHIVE_ICON}<span>${A.emptyCta}</span></button><button type="button" class="sr-chip is-soft" id="srEmptyClear">${S.clearInput}</button><button type="button" class="sr-chip is-soft" id="srEmptyAll">${S.browse}</button></div></div>`;
    target.classList.add("is-empty");
    $("#srEmptyClear").onclick=()=>{input.value="";clearBtn.hidden=true;input.focus();};
    $("#srEmptyAll").onclick=()=>navigate("catalogue");
    $("#srEmptyIa").onclick=()=>setTab("ia");
    $("#searchSummary").textContent=S.none;
    tabLibN.textContent="0";
  };
  const showFailed=()=>{
    target.innerHTML=`<div class="sr-empty"><span class="sr-empty-ico is-warn" aria-hidden="true">${icon("alert")}</span><strong>${S.failed}</strong><p>${S.failedHint}</p><div class="sr-empty-actions"><button type="button" class="sr-cta" id="srRetry">${S.retry}</button><button type="button" class="sr-chip is-soft ia-chip-btn" id="srFailedIa">${ARCHIVE_ICON}<span>${A.emptyCta}</span></button></div></div>`;
    target.classList.add("is-empty");
    $("#searchSummary").textContent="";
    $("#srRetry").onclick=()=>{target.classList.remove("is-empty");target.innerHTML=skeletons;$("#searchSummary").textContent=S.searching;loadMore();};
    $("#srFailedIa").onclick=()=>setTab("ia");
    tabLibN.textContent="";
  };
  let savedRecent=false;
  const openBook=(a,id)=>a==="book"?navigate("book",{id}):null;

  // ---- Archive.org tab: its own results list inside this same screen ----
  let iaBusy=false,iaFailed=false;
  const iaState=()=>{ if(archiveSession.q!==q) archiveSession={q,books:[],page:0,done:false,started:false,tab:"lib",filter:"all",meta:{}}; return archiveSession; };
  const iaTools=$("#iaTools"),iaNote=$("#iaNote");
  const iaChips=[...iaPanel.querySelectorAll(".ia-chip")];
  // Language filter: "ur" = Urdu books (language says Urdu, or the title is in Urdu script).
  const iaVisible=b=>{ const f=iaState().filter; return f==="all"||(f==="ur"?Boolean(b.isUrdu):!b.isUrdu); };
  const iaShown=()=>iaState().books.filter(iaVisible);
  const iaCount=()=>{
    const st=iaState(), n=st.books.length, shown=iaShown().length, plus=st.done?"":"+";
    tabIaN.textContent=n?`${n}${plus}`:"";
    iaSummary.textContent=st.filter!=="all"
      ?(ur?`${shown} کتب (کل ${n}${plus})`:`${shown} of ${n}${plus}`)
      :(ur?(n===1&&st.done?"1 کتاب":`${n}${plus} کتب`):`${n}${plus} ${n===1&&st.done?"book":"books"}`);
  };
  const iaChrome=()=>{                      // chips + the "also searched in Urdu script" line
    const st=iaState();
    iaTools.hidden=!st.books.length;
    iaChips.forEach(c=>c.setAttribute("aria-pressed",String(c.dataset.f===st.filter)));
    const uq=st.meta?.urduQuery;
    iaNote.hidden=!uq;
    if(uq) iaNote.innerHTML=`${escapeHTML(A.urduNote)} <bdi dir="rtl" lang="ur">${escapeHTML(uq)}</bdi>`;
  };
  const iaFooter=mode=>{
    if(mode==="loading") iaFoot.innerHTML=`<p class="ia-note"><i class="fa-solid fa-arrows-rotate ia-spin" aria-hidden="true"></i> ${escapeHTML(A.loading)}</p>`;
    else if(mode==="more") iaFoot.innerHTML=`<button type="button" class="sr-chip is-soft ia-more">${escapeHTML(A.more)}</button>`;
    else if(mode==="done") iaFoot.innerHTML=`<p class="ia-note">${escapeHTML(A.done)}</p>`;
    else if(mode==="error") iaFoot.innerHTML=`<p class="ia-note is-warn">${escapeHTML(A.fail)}</p><button type="button" class="sr-chip is-soft ia-more">${escapeHTML(A.retry)}</button>`;
    else iaFoot.innerHTML="";
    iaFoot.querySelector(".ia-more")?.addEventListener("click",()=>{ iaFailed=false; iaLoad(); });
  };
  const iaEmptyState=(failed)=>{
    iaGrid.innerHTML=`<div class="sr-empty"><span class="sr-empty-ico${failed?" is-warn":""}" aria-hidden="true">${icon(failed?"alert":"search")}</span><strong>${escapeHTML(failed?A.fail:A.none)}</strong><p>${escapeHTML(failed?A.failHint:A.noneHint)}</p>${failed?`<div class="sr-empty-actions"><button type="button" class="sr-cta" id="iaRetry">${escapeHTML(A.retry)}</button></div>`:""}</div>`;
    iaGrid.classList.add("is-empty");
    iaGrid.querySelector("#iaRetry")?.addEventListener("click",()=>{ iaFailed=false; iaLoad(); });
    iaSummary.textContent=failed?"":(ur?"کوئی نتیجہ نہیں":"No results");
    tabIaN.textContent=failed?"":"0";
    iaTools.hidden=true;
    iaFoot.innerHTML="";
  };
  // Draw the grid from scratch for the current filter (used on filter change and when coming back).
  const iaRender=()=>{
    const st=iaState(), list=iaShown();
    iaGrid.querySelectorAll(".sr-skel,.sr-empty").forEach(n=>n.remove());
    iaGrid.classList.remove("is-empty");
    iaGrid.replaceChildren(...list.map(b=>bookCard(b,lang,openBook)));
    if(!list.length&&st.books.length){
      iaGrid.classList.add("is-empty");
      iaGrid.innerHTML=`<div class="sr-empty"><span class="sr-empty-ico" aria-hidden="true">${icon("search")}</span><strong>${escapeHTML(A.noFilter)}</strong><div class="sr-empty-actions"><button type="button" class="sr-cta" id="iaShowAll">${escapeHTML(A.showAll)}</button></div></div>`;
      iaGrid.querySelector("#iaShowAll").onclick=()=>iaSetFilter("all");
    }
    iaChrome(); iaCount();
  };
  const iaSetFilter=f=>{
    const st=iaState(); if(st.filter===f) return;
    st.filter=f; iaRender();
    if(!st.done&&iaShown().length<6) iaLoad();      // few matches so far: look further
  };
  iaChips.forEach(c=>c.onclick=()=>iaSetFilter(c.dataset.f));
  const iaAddCards=books=>books.filter(iaVisible).forEach(b=>iaGrid.appendChild(bookCard(b,lang,openBook)));
  const iaLoadRun=async()=>{
    const st=iaState();
    if(iaBusy||st.done)return;
    iaBusy=true; st.started=true;
    let again=false;
    if(!st.books.length){ iaGrid.classList.remove("is-empty"); iaGrid.innerHTML=skeletons; iaSummary.textContent=A.searching; iaFoot.innerHTML=""; }
    else iaFooter("loading");
    try{
      const res=await searchArchive(q,{page:st.page+1});
      if(!page.isConnected||token!==searchRequestToken)return;
      iaGrid.querySelectorAll(".sr-skel").forEach(n=>n.remove());
      st.page+=1; st.done=Boolean(res.done); st.meta=res.meta||st.meta;
      const have=new Set(st.books.map(b=>b.id));
      const fresh=res.books.filter(b=>!have.has(b.id));
      fresh.forEach(b=>st.books.push(b));
      if(!st.books.length){ iaEmptyState(false); return; }
      if(iaGrid.classList.contains("is-empty")||iaGrid.querySelector(".sr-empty")) iaRender(); else { iaAddCards(fresh); iaChrome(); iaCount(); }
      iaFooter(st.done?"done":"more");
      // A filter is on and almost nothing matches yet: keep fetching pages (a few) instead of showing an empty screen.
      if(!st.done&&st.filter!=="all"&&iaShown().length<6&&st.page<6) again=true;
    }catch(error){
      console.warn("Archive.org search failed",error);
      if(!page.isConnected||token!==searchRequestToken)return;
      iaFailed=true;
      iaGrid.querySelectorAll(".sr-skel").forEach(n=>n.remove());
      if(!st.books.length) iaEmptyState(true); else iaFooter("error");
    }finally{ iaBusy=false; }
    if(again) iaLoad();
  };
  const iaLoad=()=>{
    const p=iaLoadRun();
    searchIaInFlight=p;
    const clear=()=>{ if(searchIaInFlight===p) searchIaInFlight=null; };
    p.then(clear,clear);
    return p;
  };
  const setTab=(name,{scroll=true}={})=>{
    const ia=name==="ia", st=iaState();
    st.tab=name;
    libPanel.hidden=ia; iaPanel.hidden=!ia;
    [[tabLib,!ia],[tabIa,ia]].forEach(([btn,on])=>{ btn.classList.toggle("is-active",on); btn.setAttribute("aria-selected",String(on)); btn.tabIndex=on?0:-1; });
    if(ia&&!st.started) iaLoad();
    if(scroll){ try{ window.scrollTo({top:0,left:0,behavior:"auto"}); }catch{} }
  };
  tabLib.onclick=()=>setTab("lib");
  tabIa.onclick=()=>setTab("ia");
  // Small hint under the library results (when there are some): the book may still be on Archive.org.
  const offerArchive=()=>{
    if(target.classList.contains("is-empty")||libPanel.querySelector(".ia-nudge"))return;
    const el=document.createElement("div");
    el.className="ia-nudge";
    el.innerHTML=`<span class="ia-nudge-ico" aria-hidden="true">${ARCHIVE_ICON}</span><p>${escapeHTML(A.nudgeText)}</p><button type="button" class="sr-chip is-soft">${escapeHTML(A.nudgeBtn)}</button>`;
    el.querySelector("button").onclick=()=>setTab("ia");
    libPanel.appendChild(el);
  };
  // More Archive.org results load by themselves while scrolling.
  iaObserver=new IntersectionObserver(entries=>{
    const st=iaState();
    if(entries.some(e=>e.isIntersecting)&&st.started&&st.books.length&&!iaFailed&&!iaPanel.hidden) iaLoad();
  },{root:null,rootMargin:"0px 0px 500px 0px",threshold:0.01});
  iaObserver.observe(iaFoot);
  // Coming back to this search: show the Archive.org list (and tab) we already had.
  {
    const st=iaState();
    if(st.started&&st.books.length){
      iaRender(); iaFooter(st.done?"done":"more");
    }else if(st.started&&st.done){ iaEmptyState(false); }
    if(st.tab==="ia") setTab("ia",{scroll:false});
  }
  const loadMore=async()=>{
    if(token!==searchRequestToken || searchLoadInFlight || state.route!=="search" || !page.isConnected)return;
    searchLoadInFlight=(async()=>{
      setLoader("loading");
      try{
        let result,remoteFailed=false;
        try{
          result=await searchBooksPage(q,{pageSize:20});
        }catch(remoteError){
          remoteFailed=true;
          console.warn("Maktabah server search unavailable; using cached catalogue.",remoteError);
          result={results:searchBooks(data.books,q).slice(0,20),done:true};
        }
        if(token!==searchRequestToken || !page.isConnected)return;
        clearSkeleton();
        if(result.results?.length){
          mergeBooksIntoLibrary(result.results);
          const have=new Set([...target.querySelectorAll(".book-card")].map(c=>c.dataset.bookId));
          searchBooks(result.results,q).forEach(b=>{
            if(have.has(b.id))return; have.add(b.id);
            searchSession.books.push(b);
            target.appendChild(bookCard(b,lang,openBook));
          });
        }
        // A fallback answer from the saved catalogue is not a finished search: keep it retryable.
        if(token===searchRequestToken) searchSession.done=remoteFailed?false:Boolean(result.done);
        const count=target.querySelectorAll(".book-card").length;
        if(count&&!savedRecent){savedRecent=true;addRecentSearch(q);}
        // If the server could not be reached and the saved catalogue is only partial/placeholder,
        // "no results" would be misleading: say the search could not run, and offer a retry.
        const info=getLibraryCacheInfo();
        const unreliable=remoteFailed&&(!info.complete||info.source==="local-fallback"||info.source==="empty");
        if(!count&&result.done){ if(unreliable){showFailed();setLoader("idle");} else showEmpty(); }
        else updateSummary(count,Boolean(result.done));
        if(result.done){ setLoader(count?"done":"idle"); searchObserver?.disconnect(); searchObserver=null; offerArchive(); }
        else setLoader("idle");
      }catch(error){
        console.error("Maktabah search failed",error);
        if(token!==searchRequestToken || !page.isConnected)return;
        clearSkeleton();
        if(!target.querySelector(".book-card")){ showFailed(); setLoader("idle"); }
        else setLoader("error");
      }finally{ if(token===searchRequestToken) searchLoadInFlight=null; }
    })();
    return searchLoadInFlight;
  };
  retryBtn.onclick=()=>loadMore();
  if(searchSession.books.length){
    // Coming back to a search we already ran: show the saved list at once, keep loading only if more can come.
    clearSkeleton();
    searchSession.books.forEach(b=>target.appendChild(bookCard(b,lang,openBook)));
    savedRecent=true;
    updateSummary(searchSession.books.length,searchSession.done);
    if(searchSession.done){ setLoader("done"); offerArchive(); return; }
  }else if(searchSession.done){
    clearSkeleton(); showEmpty(); offerArchive(); return;
  }
  searchObserver=new IntersectionObserver(entries=>{if(entries.some(entry=>entry.isIntersecting))loadMore();},{root:null,rootMargin:"0px 0px 500px 0px",threshold:0.01});
  searchObserver.observe(loader);
  loadMore();
}

function renderFavorites(){
  const lang=currentLang(),L=t[lang],ur=lang==="ur";
  const byId=id=>data.byId?.get(id)||data.books.find(b=>b.id===id)||getArchiveBook(id);
  // Newest saved first (storage keeps insertion order).
  const books=getFavorites().slice().reverse().map(byId).filter(Boolean);
  hydrateMissingBooks(getFavorites(),()=>{
    if(state.route==="favorites"){ lastRenderedRoute=""; renderRouteOnce(); }
  });
  const titleOf=b=>ur?b.title:(b.titleEn||b.title);
  const subText=n=>ur?(n===1?"1 کتاب محفوظ":`${n} کتب محفوظ`):`${n} ${n===1?"book":"books"} saved`;
  const S=ur
    ?{recent:"تازہ ترین",title:"عنوان",sort:"ترتیب",find:"پسندیدہ میں تلاش کریں",none:"کوئی کتاب نہیں ملی",hint:"کسی بھی کتاب پر دل کے آئیکن کو دبائیں، وہ یہاں محفوظ ہو جائے گی۔",browse:"کتب دیکھیں",removed:"پسندیدہ سے ہٹا دی گئی",undo:"واپس لائیں",source:"ماخذ",srcAll:"سب",srcLib:"لائبریری"}
    :{recent:"Recently saved",title:"Title A–Z",sort:"Sort",find:"Search favorites",none:"No matching books",hint:"Tap the heart on any book to keep it here.",browse:"Browse books",removed:"Removed from favorites",undo:"Undo",source:"Source",srcAll:"All",srcLib:"Library"};
  const page=document.createElement("main");
  page.className="fav-screen fv-page"; page.setAttribute("aria-label",L.fav);
  page.innerHTML=`<header class="fav-top">
      <button class="icon-btn" id="favBack" type="button" aria-label="${escapeHTML(L.back)}"><i class="fa-solid ${ur?"fa-arrow-right":"fa-arrow-left"}"></i></button>
      <div class="fv-heading"><strong class="fav-title">${escapeHTML(L.fav)}</strong><small class="fv-sub" id="favSub">${subText(books.length)}</small></div>
    </header>
    <section class="page"><div class="fv-wrap">
      <div class="fv-tools" id="favTools" hidden>
        <div class="fv-sort" role="group" aria-label="${S.sort}">
          <button type="button" class="fv-chip" data-sort="recent" aria-pressed="true">${S.recent}</button>
          <button type="button" class="fv-chip" data-sort="title" aria-pressed="false">${S.title}</button>
        </div>
        <div class="fv-sort fv-src" id="favSrc" role="group" aria-label="${S.source}" hidden>
          <button type="button" class="fv-chip" data-src="all" aria-pressed="true">${S.srcAll}</button>
          <button type="button" class="fv-chip" data-src="lib" aria-pressed="false">${S.srcLib}</button>
          <button type="button" class="fv-chip" data-src="ia" aria-pressed="false">Archive.org</button>
        </div>
        <label class="fv-find" id="favFind" hidden><span aria-hidden="true">${icon("search")}</span><input id="favFilter" type="search" autocomplete="off" enterkeyhint="search" placeholder="${S.find}" aria-label="${S.find}"></label>
      </div>
      <div class="grid book-grid" id="books"></div>
      <p class="fv-nomatch" id="favNoMatch" hidden>${S.none}</p>
      <div class="fv-empty" id="favEmpty" hidden>
        <span class="fv-empty-ico" aria-hidden="true">${icon("heart")}</span>
        <strong>${escapeHTML(L.noFavorites)}</strong>
        <p>${S.hint}</p>
        <button type="button" class="fv-cta" id="favBrowse">${S.browse}</button>
      </div>
    </div></section>`;
  app.innerHTML=""; app.appendChild(page);
  page.querySelector("#favBack").onclick=()=>{ if(history.length>1) history.back(); else navigate("home"); };

  const $=s=>page.querySelector(s);
  const target=$("#books"),sub=$("#favSub"),tools=$("#favTools"),find=$("#favFind"),filter=$("#favFilter"),noMatch=$("#favNoMatch"),empty=$("#favEmpty");
  const cards=new Map(),removed=new Set();
  let sort="recent",query="",src="all",undoTimer=null;
  const srcRow=$("#favSrc");

  const openBook=(a,id)=>a==="book"?navigate("book",{id}):null;
  const showUndo=(book)=>{
    document.querySelector(".fv-undo")?.remove(); clearTimeout(undoTimer);
    const bar=document.createElement("div"); bar.className="fv-undo"; bar.setAttribute("role","status");
    bar.innerHTML=`<span>${S.removed}</span><button type="button">${S.undo}</button>`;
    bar.querySelector("button").onclick=()=>{
      clearTimeout(undoTimer); bar.remove();
      toggleFavorite(book.id); removed.delete(book.id);
      const card=cards.get(book.id),hb=card?.querySelector(".favorite-btn");
      if(hb){hb.classList.add("active");hb.setAttribute("aria-pressed","true");}
      card?.classList.remove("is-leaving");
      paint();
    };
    document.body.appendChild(bar);
    undoTimer=setTimeout(()=>bar.remove(),5000);
  };

  books.forEach(b=>{
    const card=bookCard(b,lang,openBook);
    card.addEventListener("favoritechange",e=>{
      if(e.detail?.favorite) return;
      removed.add(b.id); card.classList.add("is-leaving");
      showUndo(b);
      setTimeout(()=>{ if(removed.has(b.id)) paint(); },200);
    });
    cards.set(b.id,card);
  });

  function paint(){
    const live=books.filter(b=>!removed.has(b.id));
    sub.textContent=subText(live.length);
    const none=live.length===0;
    empty.hidden=!none; target.hidden=none;
    tools.hidden=live.length<2;
    find.hidden=live.length<8 && !query;
    if(none){ noMatch.hidden=true; return; }
    // The Library / Archive.org filter only appears when favourites contain both kinds.
    const mixed=live.some(b=>b.isArchive)&&live.some(b=>!b.isArchive);
    srcRow.hidden=!mixed;
    const effSrc=mixed?src:"all";
    const q=query.trim().toLowerCase();
    let list=q?live.filter(b=>`${b.title||""} ${b.titleEn||""} ${b.author||""}`.toLowerCase().includes(q)):live.slice();
    if(effSrc!=="all") list=list.filter(b=>Boolean(b.isArchive)===(effSrc==="ia"));
    if(sort==="title") list.sort((a,b)=>String(titleOf(a)).localeCompare(String(titleOf(b)),ur?"ur":"en"));
    target.replaceChildren(...list.map(b=>cards.get(b.id)));
    noMatch.hidden=list.length>0;
  }

  page.querySelectorAll("#favSrc .fv-chip").forEach(btn=>btn.onclick=()=>{
    if(src===btn.dataset.src) return;
    src=btn.dataset.src;
    page.querySelectorAll("#favSrc .fv-chip").forEach(x=>x.setAttribute("aria-pressed",String(x===btn)));
    paint();
  });
  page.querySelectorAll(".fv-sort:not(#favSrc) .fv-chip").forEach(btn=>btn.onclick=()=>{
    if(sort===btn.dataset.sort) return;
    sort=btn.dataset.sort;
    page.querySelectorAll(".fv-sort:not(#favSrc) .fv-chip").forEach(x=>x.setAttribute("aria-pressed",String(x===btn)));
    try{navigator.vibrate?.(8);}catch{}
    paint();
  });
  filter.addEventListener("input",()=>{query=filter.value;paint();});
  $("#favBrowse").onclick=()=>navigate("catalogue");
  paint();
}
function getRelatedBooks(book, limit = 4){
  const classIds = new Set(Array.isArray(book.classIds) ? book.classIds : (book.classId ? [book.classId] : []));
  const categoryIds = new Set(Array.isArray(book.categoryIds) ? book.categoryIds : []);
  return data.books
    .filter(candidate => candidate.id !== book.id && candidate.status === "available")
    .map(candidate => {
      const candidateClasses = Array.isArray(candidate.classIds) ? candidate.classIds : (candidate.classId ? [candidate.classId] : []);
      const candidateCategories = Array.isArray(candidate.categoryIds) ? candidate.categoryIds : [];
      let score = 0;
      if (candidateClasses.some(id => classIds.has(id))) score += 4;
      if (candidateCategories.some(id => categoryIds.has(id))) score += 3;
      if (candidate.bookType === book.bookType) score += 1;
      return { candidate, score };
    })
    .filter(item => item.score > 0)
    .sort((a,b) => b.score - a.score || String(b.candidate.addedAt || "").localeCompare(String(a.candidate.addedAt || "")))
    .slice(0, limit)
    .map(item => item.candidate);
}

function renderBook(id){
  const lang=currentLang(),L=t[lang],b=data.byId?.get(id) || data.books.find(x=>x.id===id) || getArchiveBook(id);if(!b)return navigate("home");
  const title=lang==="ur"?b.title:(b.titleEn||b.title), fav=getFavorites().includes(b.id), progress=getBookProgress(b.id);
  const percent=Math.max(0,Math.min(100,Number(progress?.percent)||0));
  const hasPdf=b.status==="available" && (validExternalUrl(b.pdfUrl) || Boolean(b.driveFileId) || Boolean(b.isArchive)), hasSource=validExternalUrl(b.source?.pageUrl);
  const ok=b.status==="available";
  const statTypeLabel=b.bookType==="matn"?(lang==="ur"?"متون":"Matn"):(lang==="ur"?"شروحات":"Commentary");
  const stat=(v,c,cls="")=>`<div class="stat ${cls}"><strong>${escapeHTML(String(v))}</strong><span>${escapeHTML(c)}</span></div>`;
  const meta=[
    stat(statTypeLabel, lang==="ur"?"قسم":"Type"),
    b.pages?stat(b.pages, lang==="ur"?"صفحات":"Pages"):"",
    stat("PDF", lang==="ur"?"فارمیٹ":"Format"),
    stat(ok?L.available:(lang==="ur"?"دستیاب نہیں":"Unavailable"), lang==="ur"?"حالت":"Status", ok?"stat-ok":"stat-bad")
  ].filter(Boolean).join("");
  const resume=progress?.openedAt?`<div class="book-progress" aria-label="${lang==="ur"?`${percent}% مطالعہ مکمل`:`${percent}% read`}"><div class="book-progress-head"><span><i class="fa-solid fa-clock-rotate-left"></i> ${lang==="ur"?"مطالعہ کی پیش رفت":"Reading progress"}</span><strong>${percent}%</strong></div><div class="book-progress-track"><span style="width:${percent}%"></span></div><button class="progress-action" id="resume">${L.continueAction} <i class="fa-solid ${lang==="ur"?"fa-arrow-left":"fa-arrow-right"}"></i></button></div>`:"";
  const related=getRelatedBooks(b,4);
  const relatedMarkup=related.length ? `<section class="detail-section related-books-section"><div class="section-head"><div><h2 class="section-title">${L.related}</h2><p class="section-subtitle">${L.relatedHint}</p></div></div><div class="grid book-grid related-books-grid" id="relatedBooks"></div></section>` : "";
  const downloadNote=!hasPdf ? `<p class="action-note" role="status"><i class="fa-solid fa-circle-info"></i> ${escapeHTML(L.sourceMissing)}</p>` : "";
  const page=detailShell(title,`<article class="book-detail"><div class="book-detail-main"><div class="detail-ambient tc-${paletteIndex(b.id)}" aria-hidden="true"></div><div class="detail-cover-wrap"><div class="cover detail-cover">${typesetCover(title,b.author,b.id)}${b.cover?coverMarkup(escapeHTML(b.cover),`${escapeHTML(title)} cover`):""}</div></div><div class="book-detail-info"><h1 class="detail-title">${escapeHTML(title)}</h1><p class="detail-author">${escapeHTML(b.author||"")}</p><div class="chips" aria-label="${lang==="ur"?"کتاب کی معلومات":"Book information"}">${meta}</div>${resume}<div class="detail-buttons"><button class="btn primary" id="read" ${b.status!=="available"?"disabled":""}><i class="fa-solid fa-book-open"></i> ${L.read}</button><button class="btn" id="download" ${!hasPdf?"disabled":""}><i class="fa-solid fa-download"></i> ${L.download}</button><button class="btn detail-favorite ${fav?"active":""}" id="fav" aria-pressed="${fav}">${HEART}<span>${L.fav}</span></button></div>${downloadNote}</div></div><div class="book-detail-sections"><section class="detail-section"><h2 class="section-title">${L.about}</h2><p class="muted detail-desc" id="desc">${escapeHTML(b.description||"")}</p><button class="desc-toggle" id="descToggle" type="button" hidden>${lang==="ur"?"مزید پڑھیں":"Read more"}</button></section>${relatedMarkup}<section class="detail-section"><h2 class="section-title">${L.source}</h2>${b.source?.name?`<p class="source-name">${escapeHTML(b.source.name)}</p>`:""}${hasSource?`<button class="btn" id="source"><i class="fa-solid fa-arrow-up-right-from-square"></i> ${L.openSource}</button>`:`<p class="muted source-unavailable">${lang==="ur"?"اصل ماخذ دستیاب نہیں ہے۔":"Original source is not available."}</p>`}</section><section class="detail-section detail-report"><button class="btn danger" id="report"><i class="fa-solid fa-triangle-exclamation"></i> ${L.report}</button></section></div></article>`,"");
  page.classList.add("book-detail-page");
  app.querySelector("#bookBack")?.addEventListener("click",()=>goBackInApp());
  const topBar=app.querySelector(".detail-top"), heroTitle=page.querySelector(".detail-title");
  if(topBar && heroTitle && "IntersectionObserver" in window){
    new IntersectionObserver(([en])=>topBar.classList.toggle("is-scrolled",!en.isIntersecting && en.boundingClientRect.top<200),{rootMargin:"-64px 0px 0px 0px",threshold:0}).observe(heroTitle);
  }
  wireCover(page.querySelector(".detail-cover"));
  const coverImg=page.querySelector(".detail-cover img"), ambient=page.querySelector(".detail-ambient");
  const showAmbient=()=>ambient?.classList.add("is-ready");
  if(coverImg){
    coverImg.addEventListener("load",()=>{
      const pal=ambient?coverPalette(coverImg):null;
      if(pal) for(const [k,v] of Object.entries(pal)) ambient.style.setProperty(k,v);
      showAmbient();
    },{once:true});
    setTimeout(showAmbient,2500);
  } else requestAnimationFrame(showAmbient);
  const desc=page.querySelector("#desc"), descToggle=page.querySelector("#descToggle");
  requestAnimationFrame(()=>{
    if(desc && descToggle && desc.scrollHeight>desc.clientHeight+2) descToggle.hidden=false; else desc?.classList.add("open");
  });
  descToggle?.addEventListener("click",()=>{
    const open=desc.classList.toggle("open");
    descToggle.textContent=open?(lang==="ur"?"کم دکھائیں":"Show less"):(lang==="ur"?"مزید پڑھیں":"Read more");
  });
  // Book details are a fresh view: never inherit a previous document scroll position.
  requestAnimationFrame(() => window.scrollTo({ top: 0, left: 0, behavior: "auto" }));
  page.querySelector("#read").onclick=()=>{setProgress(id,{openedAt:new Date().toISOString(),source:"reader"});openReader(id);};
  page.querySelector("#resume")?.addEventListener("click",()=>{setProgress(id,{openedAt:new Date().toISOString(),source:"reader"});openReader(id);});
  page.querySelector("#download")?.addEventListener("click",async()=>{
    await downloadBookPdf(b);
  });
  page.querySelector("#fav").onclick=()=>{
    const was=fav;
    const result=toggleFavorite(id);
    const nowFavorite=Array.isArray(result) ? result.includes(id) : Boolean(result);
    const button=page.querySelector("#fav");
    button.classList.toggle("active",nowFavorite);
    button.setAttribute("aria-pressed",String(nowFavorite));
    if(nowFavorite){ button.classList.remove("pop"); void button.offsetWidth; button.classList.add("pop"); setTimeout(()=>button.classList.remove("pop"),650); try{navigator.vibrate?.(10);}catch{} }
    const icon=button.querySelector("i");
    if(icon){icon.classList.toggle("fa-solid",nowFavorite);icon.classList.toggle("fa-regular",!nowFavorite);}
    showToast(was?L.favoriteRemoved:L.favoriteAdded);
  };
  page.querySelector("#source")?.addEventListener("click",()=>openExternal(b.source.pageUrl));
  page.querySelector("#report").onclick=()=>showToast(L.reportSoon);
  if(related.length){
    const target=page.querySelector("#relatedBooks");
    related.forEach(book=>target.appendChild(bookCard(book,lang,(action,id)=>action==="book"?navigate("book",{id}):null)));
  }
}

function renderMore(){
  const lang=currentLang(),L=t[lang],theme=state.theme;
  const ur=lang==="ur";
  const themeIdx={system:0,light:1,dark:2}[theme]??0;
  const perfIdx={auto:0,full:1,lite:2}[getPerfMode()];
  const perfName=v=>ur?({auto:"خودکار",full:"مکمل",lite:"ہلکا"}[v]):({auto:"Auto",full:"Full",lite:"Lite"}[v]);
  const perfDesc=v=>ur
    ?({auto:`خودکار: اس فون کے لیے ${effectivePerf()==="lite"?"ہلکا":"مکمل"} موڈ منتخب${perfSource()==="measured"?" (رفتار ناپ کر)":""}`,full:"مکمل: تمام اثرات اور بلر (نئے فونز کے لیے)",lite:"ہلکا: بلر اور بھاری اثرات بند، زیادہ رواں (کمزور فونز کے لیے)"}[v])
    :({auto:`Auto: ${effectivePerf()==="lite"?"Lite":"Full"} chosen for this phone${perfSource()==="measured"?" after measuring its smoothness":" (recommended)"}`,full:"Full: all effects and blur (best on newer phones)",lite:"Lite: no blur or heavy effects, smoothest (best on older phones)"}[v]);
  const scanOn=scanSupported();
  const scanModeName=v=>v==="auto"?(ur?"خودکار":"Auto"):(ur?"دستی":"Manual");
  const scanModeDesc=v=>ur
    ?(v==="auto"?"لائبریری کھولنے پر، اگر فہرست پرانی ہو، نئی PDF فائلیں خود تلاش ہو جاتی ہیں":"فائلیں صرف تب تلاش ہوں گی جب آپ «ابھی تلاش کریں» دبائیں")
    :(v==="auto"?"Looks for new PDFs by itself when you open Library and the list is old":"Only scans when you tap Scan now");
  const scanAgo=at=>{
    if(!at) return ur?"ابھی تک تلاش نہیں ہوئی":"Not scanned yet";
    const m=Math.floor((Date.now()-at)/60000);
    const w=m<1?(ur?"ابھی ابھی":"just now"):m<60?(ur?`${m} منٹ پہلے`:`${m} min ago`):m<1440?(ur?`${Math.floor(m/60)} گھنٹے پہلے`:`${Math.floor(m/60)} h ago`):(ur?`${Math.floor(m/1440)} دن پہلے`:`${Math.floor(m/1440)} d ago`);
    return ur?`آخری تلاش: ${w}`:`Last scan: ${w}`;
  };
  const themeLabel=v=>v==="system"?L.systemTheme:v==="dark"?L.darkTheme:L.lightTheme;
  const row=(id,ico,tone,title,sub)=>`<button class="mo-row" id="${id}" type="button"><span class="mo-ico ${tone}">${icon(ico)}</span><span class="mo-copy"><strong>${escapeHTML(title)}</strong>${sub?`<small>${escapeHTML(sub)}</small>`:""}</span>${icon("chevron","mo-chev")}</button>`;
  const themeBtn=(v,ico)=>`<button type="button" class="mo-seg-btn" data-theme-choice="${v}" aria-pressed="${theme===v}">${icon(ico)}<span>${escapeHTML(themeLabel(v))}</span></button>`;
  const page=shell(L.more,`<div class="mo-wrap">
    <header class="tab-head mo-in" style="--k:0"><div><h1 class="tab-title" id="moreTitle">${escapeHTML(L.more)}</h1><p class="tab-sub">${ur?"ظاہری انداز، زبان اور آف لائن کتب":"Appearance, language and offline books"}</p></div></header>

    <section class="mo-section mo-in" style="--k:1" aria-labelledby="quickSettingsTitle">
      <h2 class="mo-label" id="quickSettingsTitle">${escapeHTML(L.quickSettings)}</h2>
      <div class="mo-group">
        <div class="mo-setting">
          <div class="mo-setting-head"><span class="mo-ico is-amber">${icon("sun")}</span><span class="mo-copy"><strong>${escapeHTML(L.appearanceShort)}</strong><small id="themeValue">${escapeHTML(themeLabel(theme))}</small></span></div>
          <div class="mo-seg" id="themeSeg" style="--n:3;--i:${themeIdx}" role="group" aria-label="${escapeHTML(L.appearanceShort)}"><span class="mo-seg-thumb" aria-hidden="true"></span>${themeBtn("system","auto")}${themeBtn("light","sun")}${themeBtn("dark","moon")}</div>
        </div>
        <div class="mo-setting">
          <div class="mo-setting-head"><span class="mo-ico is-blue">${icon("globe")}</span><span class="mo-copy"><strong>${escapeHTML(L.languageShort)}</strong><small>${ur?"اردو":"English"}</small></span></div>
          <div class="mo-seg" id="langSeg" style="--n:2;--i:${ur?0:1}" role="group" aria-label="${escapeHTML(L.languageShort)}"><span class="mo-seg-thumb" aria-hidden="true"></span>
            <button type="button" class="mo-seg-btn" id="ur" aria-pressed="${ur}"><span>اردو</span></button>
            <button type="button" class="mo-seg-btn" id="en" aria-pressed="${!ur}"><span>English</span></button>
          </div>
        </div>
        <div class="mo-setting">
          <div class="mo-setting-head"><span class="mo-ico is-green">${icon("bolt")}</span><span class="mo-copy"><strong>${ur?"کارکردگی":"Performance"}</strong><small id="perfValue">${escapeHTML(perfDesc(getPerfMode()))}</small></span></div>
          <div class="mo-seg" id="perfSeg" style="--n:3;--i:${perfIdx}" role="group" aria-label="${ur?"کارکردگی":"Performance"}"><span class="mo-seg-thumb" aria-hidden="true"></span>
            ${["auto","full","lite"].map(v=>`<button type="button" class="mo-seg-btn" data-perf="${v}" aria-pressed="${getPerfMode()===v}"><span>${escapeHTML(perfName(v))}</span></button>`).join("")}
          </div>
        </div>
      </div>
    </section>

    ${scanOn?`<section class="mo-section mo-in" style="--k:3" aria-labelledby="scanSectionTitle">
      <h2 class="mo-label" id="scanSectionTitle">${ur?"فون کی PDF فائلیں":"Device PDFs"}</h2>
      <div class="mo-group">
        <div class="mo-setting">
          <div class="mo-setting-head"><span class="mo-ico is-blue">${icon("folder")}</span><span class="mo-copy"><strong>${ur?"تلاش کا طریقہ":"Scan mode"}</strong><small id="scanModeHint">${escapeHTML(scanModeDesc(getScanMode()))}</small></span></div>
          <div class="mo-seg" id="scanSeg" style="--n:2;--i:${getScanMode()==="auto"?0:1}" role="group" aria-label="${ur?"تلاش کا طریقہ":"Scan mode"}"><span class="mo-seg-thumb" aria-hidden="true"></span>
            ${["auto","manual"].map(v=>`<button type="button" class="mo-seg-btn" data-scan="${v}" aria-pressed="${getScanMode()===v}"><span>${escapeHTML(scanModeName(v))}</span></button>`).join("")}
          </div>
        </div>
        <div class="mo-scanrow">
          <div class="mo-setting-head"><span class="mo-ico">${icon("pdf")}</span><span class="mo-copy"><strong id="scanCount"></strong><small id="scanWhen"></small></span></div>
          <button class="mo-scanbtn" id="scanNow" type="button"></button>
        </div>
      </div>
    </section>

    `:""}<section class="mo-section mo-in" style="--k:3" aria-labelledby="dataSectionTitle">
      <div class="mo-group">
        <button class="mo-row mo-toggle" id="dataSectionToggle" type="button" aria-expanded="false" aria-controls="dataSectionPanel"><span class="mo-ico is-blue">${icon("database")}</span><span class="mo-copy"><strong id="dataSectionTitle">${escapeHTML(L.dataSection)}</strong></span>${icon("chevron","mo-chev")}</button>
        <div class="mo-collapse" id="dataSectionPanel"><div><div class="mo-panel">
          <p>${escapeHTML(ur?"پسندیدہ، مطالعہ کی تاریخ، پیش رفت، بک مارک اور ہائی لائٹ اسی ڈیوائس پر محفوظ ہوتے ہیں۔ فون بدلنے یا ایپ کا ڈیٹا صاف کرنے سے پہلے بیک اپ بنا لیں۔":"Favorites, history, progress, bookmarks and highlights are stored only on this device. Make a backup before changing phones or clearing app data.")}</p>
          <p id="coverCacheInfo" class="mo-cover-info"></p>
          <div class="mo-actions">
            <button class="mo-ghost" id="backupData" type="button">${icon("download")}<span>${escapeHTML(ur?"بیک اپ بنائیں":"Back up my data")}</span></button>
            <button class="mo-ghost" id="restoreData" type="button">${icon("upload")}<span>${escapeHTML(ur?"بیک اپ سے بحال کریں":"Restore from backup")}</span></button>
            <button class="mo-ghost" id="clearCovers" type="button">${icon("trash")}<span>${escapeHTML(ur?"کورز کی کیش صاف کریں":"Clear cover cache")}</span></button>
            <button class="mo-ghost" id="clearHistory" type="button">${icon("clock")}<span>${escapeHTML(L.clearHistoryShort)}</span></button>
            <button class="mo-danger is-solid" id="clearData" type="button">${icon("trash")}<span>${escapeHTML(L.clearDataShort)}</span></button>
          </div>
        </div></div></div>
      </div>
    </section>

    <section class="mo-section mo-in" style="--k:4" aria-label="${escapeHTML(L.more)}">
      <div class="mo-group">
        ${row("openRights","scale","is-amber",L.sourceRightsShort,"")}
        ${row("openAbout","info","is-blue",L.aboutApp,"")}
      </div>
    </section>

    <footer class="mo-footer mo-in" style="--k:5"><span class="mo-footer-mark" aria-hidden="true"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M11.5 6.4C10.2 5.5 8.2 5.2 4.8 5.5V17.7C8.2 17.4 10.2 17.7 11.5 18.6Z"/><path fill="currentColor" d="M12.5 6.4C13.8 5.5 15.8 5.2 19.2 5.5V17.7C15.8 17.4 13.8 17.7 12.5 18.6Z"/></svg></span><strong>${escapeHTML(L.brand)}</strong><span>${escapeHTML(L.tagline)}</span><small>${escapeHTML(BUILD_TAG)}</small></footer>
  </div>`,"more");
  page.classList.add("mo-page");

  const pressSeg=(seg,btn,idx)=>{
    seg.style.setProperty("--i",String(idx));
    seg.querySelectorAll(".mo-seg-btn").forEach(x=>x.setAttribute("aria-pressed",String(x===btn)));
    try{navigator.vibrate?.(8);}catch{}
  };
  page.querySelectorAll("[data-theme-choice]").forEach(b=>b.onclick=()=>{
    const v=b.dataset.themeChoice; if(v===state.theme) return;
    state.theme=v; changeTheme(v);
    pressSeg(page.querySelector("#themeSeg"),b,{system:0,light:1,dark:2}[v]);
    const val=page.querySelector("#themeValue"); if(val) val.textContent=themeLabel(v);
  });
  page.querySelectorAll("[data-perf]").forEach(b=>b.onclick=()=>{
    const v=b.dataset.perf; if(v===getPerfMode()) return;
    setPerfMode(v);
    pressSeg(page.querySelector("#perfSeg"),b,{auto:0,full:1,lite:2}[v]);
    const val=page.querySelector("#perfValue"); if(val) val.textContent=perfDesc(v);
    showToast(ur?`کارکردگی: ${perfName(v)}`:`Performance: ${perfName(v)}`);
  });
  if(scanOn){
    const paintScan=()=>{
      const count=page.querySelector("#scanCount"),when=page.querySelector("#scanWhen"),btn=page.querySelector("#scanNow");
      if(!count||!when||!btn) return;
      const i=scanInfo(),needAccess=i.granted===false;
      count.textContent=needAccess?(ur?"اسٹوریج کی اجازت درکار ہے":"Storage access needed")
        :i.scanning?(ur?"تلاش جاری ہے…":"Scanning…")
        :ur?`${i.count} PDF فائلیں`:`${i.count} ${i.count===1?"PDF":"PDFs"}`;
      when.textContent=needAccess?(ur?"فون کی PDF فائلیں دکھانے کے لیے اجازت دیں":"Allow access to list the PDFs on this phone")
        :i.failed?(ur?"تلاش مکمل نہیں ہو سکی":"The scan could not finish"):scanAgo(i.at);
      btn.innerHTML=needAccess?`${icon("folder")}<span>${ur?"اجازت دیں":"Allow"}</span>`:`${icon("refresh")}<span>${ur?"ابھی تلاش کریں":"Scan now"}</span>`;
      btn.classList.toggle("is-spinning",i.scanning);
      btn.setAttribute("aria-disabled",String(i.scanning));
    };
    paintScan();
    let seen=false;
    const onVis=()=>{ if(document.visibilityState==="visible"&&page.isConnected) checkAccess(); };
    const off=onScanChange(()=>{
      if(page.isConnected) seen=true;
      else{ if(seen){ off(); document.removeEventListener("visibilitychange",onVis); } return; }
      paintScan();
    });
    document.addEventListener("visibilitychange",onVis);
    checkAccess();
    page.querySelectorAll("[data-scan]").forEach(b=>b.onclick=()=>{
      const v=b.dataset.scan; if(v===getScanMode()) return;
      setScanMode(v);
      pressSeg(page.querySelector("#scanSeg"),b,v==="auto"?0:1);
      const hint=page.querySelector("#scanModeHint"); if(hint) hint.textContent=scanModeDesc(v);
      showToast(ur?`تلاش: ${scanModeName(v)}`:`Scan: ${scanModeName(v)}`);
    });
    page.querySelector("#scanNow").addEventListener("click",async()=>{
      const i=scanInfo(); if(i.scanning) return;
      if(i.granted===false){ requestAccess(); return; }
      const ok=await runScan();
      const n=scanInfo().count;
      if(ok) showToast(ur?`${n} PDF فائلیں ملیں`:`${n} ${n===1?"PDF":"PDFs"} found`);
      else if(scanInfo().failed) showToast(ur?"تلاش مکمل نہیں ہو سکی":"The scan could not finish");
    });
  }
  const switchLang=(code,btn)=>{
    if(currentLang()===code) return;
    pressSeg(page.querySelector("#langSeg"),btn,code==="ur"?0:1);
    setTimeout(()=>{state.language=code;setLanguage(code);render();},240);
  };
  page.querySelector("#ur").onclick=e=>switchLang("ur",e.currentTarget);
  page.querySelector("#en").onclick=e=>switchLang("en",e.currentTarget);
  page.querySelector("#openRights").onclick=()=>showInfoSheet(
    lang==="ur"?"ذرائع اور حقوق":"Sources & Rights",
    lang==="ur"?"ہر کتاب کے اصل ماخذ کو جہاں ممکن ہو نمایاں کیا جاتا ہے۔ مواد کو خودکار طور پر دوبارہ ہوسٹ نہیں کیا جاتا۔":"Each listing identifies its original source where available. Content is linked from external sources rather than automatically re-hosted."
  );
  page.querySelector("#openAbout").onclick=()=>showInfoSheet(L.aboutApp,
    `${L.tagline}\n\n`+(lang==="ur"
      ?"رازداری: کوئی لاگ اِن نہیں اور کوئی ٹریکنگ نہیں۔ پسندیدہ، تاریخ، بک مارک اور ترتیبات صرف آپ کے فون پر محفوظ رہتی ہیں۔ بیک اپ آپ خود محفوظ اور بحال کرتے ہیں۔"
      :"Privacy: no login and no tracking. Favorites, history, bookmarks and settings stay on your phone only. Backups are saved and restored by you.")+`\n\n${BUILD_TAG}`);

  const toggle=page.querySelector("#dataSectionToggle"), panel=page.querySelector("#dataSectionPanel");
  panel.inert=true;
  toggle.onclick=()=>{const open=toggle.getAttribute("aria-expanded")==="true";toggle.setAttribute("aria-expanded",String(!open));panel.classList.toggle("open",!open);panel.inert=open;};

  const paintCoverInfo=async()=>{
    const el=page.querySelector("#coverCacheInfo"); if(!el) return;
    try{
      const {count,bytes}=await getCoverCacheInfo();
      const mb=bytes/1048576, size=mb>=10?mb.toFixed(0):mb.toFixed(1);
      el.textContent=count?(ur?`محفوظ کورز: ${count} (${size} MB) — یہ آف لائن بھی نظر آتے ہیں۔`:`Saved covers: ${count} (${size} MB) — they also show offline.`)
        :(ur?"ابھی کوئی کور محفوظ نہیں۔":"No covers saved yet.");
    }catch{ el.textContent=""; }
  };
  paintCoverInfo();
  page.querySelector("#clearCovers").onclick=async()=>{
    await clearCoverCache(); await paintCoverInfo();
    showToast(ur?"کورز کی کیش صاف ہو گئی۔":"Cover cache cleared.");
  };
  page.querySelector("#backupData").onclick=async e=>{
    const btn=e.currentTarget; btn.disabled=true;
    const r=await saveBackup(); btn.disabled=false;
    const msg={shared:ur?"بیک اپ تیار ہے۔":"Backup ready.",downloaded:ur?"بیک اپ فائل ڈاؤنلوڈ ہو گئی۔":"Backup file downloaded.",
      copied:ur?"بیک اپ کا متن کاپی ہو گیا۔ اسے نوٹس یا واٹس ایپ میں محفوظ کر لیں۔":"Backup copied. Paste it into Notes or WhatsApp to keep it.",
      failed:ur?"بیک اپ نہیں بن سکا۔":"Could not create the backup."}[r];
    if(msg) showToast(msg);
  };
  page.querySelector("#restoreData").onclick=()=>openRestoreDialog({ur,onDone:message=>{showToast(message);render();}});
  page.querySelector("#clearHistory").onclick=async()=>{const ok=await confirmDialog(L.clearHistory,lang==="ur"?"اس ڈیوائس سے مطالعہ کی تاریخ صاف کر دی جائے؟":"Clear reading history from this device?",lang==="ur"?"صاف کریں":"Clear",true);if(ok){clearHistory();showToast(L.historyCleared);render();}};
  page.querySelector("#clearData").onclick=async()=>{const ok=await confirmDialog(L.clearData,L.confirmClear,lang==="ur"?"سب صاف کریں":"Clear all",true);if(ok){localStorage.removeItem("krul:v1:favorites");clearHistory();clearProgress();showToast(L.dataCleared);render();}};

}

function formatBytes(n){
  n=Number(n)||0;
  if(n>=1073741824)return (n/1073741824).toFixed(1)+" GB";
  if(n>=1048576)return (n/1048576).toFixed(1)+" MB";
  if(n>=1024)return Math.round(n/1024)+" KB";
  return n+" B";
}
function renderDownloads(){
  renderLibrary({
    lang:currentLang(), shell, books:()=>data.books, navigate, showToast, confirmDialog,
    downloadBookPdf, coverMarkup, wireCover, escapeHTML
  });
}

// Downloaded and still on the phone -> read it in the premium offline reader; otherwise the online reader.
async function openReader(id){
  try{
    const rec=getDownloadRecord(id), plugin=getNativePlugin();
    if(rec && plugin){
      const info=await plugin.fileInfo({id:rec.downloadId});
      if(info?.exists){navigate("local",{book:id});return;}
    }
  }catch{}
  navigate("reader",{id});
}

function renderLocal(params){
  const lang=currentLang();
  let opts=null;
  if(params.book){
    const rec=getDownloadRecord(params.book);
    if(!rec)return navigate("downloads",{},{replace:true});
    const b=data.books.find(x=>x.id===rec.bookId);
    const title=lang==="ur"?(b?.title||rec.title):(b?.titleEn||rec.titleEn||b?.title||rec.title);
    if(b)addHistory(b.id);
    opts={lang,title,subtitle:(lang==="ur"?(b?.author||rec.author):(b?.authorEn||rec.authorEn||b?.author||rec.author))||"",source:{id:rec.downloadId},progressKey:rec.bookId};
  }else if(params.path){
    const name=(params.name||"PDF").replace(/\.pdf$/i,"");
    opts={lang,title:name,source:{path:params.path},progressKey:`file:${params.path}`,legacyKey:`file:${name}`};
  }else if(params.uri){
    const name=(params.name||"PDF").replace(/\.pdf$/i,"");
    opts={lang,title:name,source:{uri:params.uri},progressKey:`file:${params.uri}`,legacyKey:`file:${name}`};
  }
  if(!opts)return navigate("downloads",{},{replace:true});
  if(!nativeReaderWanted()){
    showToast(lang==="ur"?"یہ فیچر صرف اینڈرائیڈ ایپ میں دستیاب ہے۔":"This feature is only available in the Android app.");
    goBackInApp();
    return;
  }
  // Native MuPDF reader. When it closes (or cannot open the file) we return to the previous screen.
  app.innerHTML=`<main class="boot"><div class="boot-bar"></div></main>`;
  openInNativeReader({...opts,onFallback:m=>showToast((lang==="ur"?"ریڈر نہیں کھل سکا: ":"Reader could not open the file: ")+String(m).slice(0,110))})
    .catch(()=>{})
    .then(()=>{ if(readRoute().route==="local") goBackInApp(); });
}

// "Open with" -> another app (file manager, WhatsApp...) handed us a PDF.
async function checkPendingOpen(){
  const plugin=getNativePlugin();
  if(!plugin)return;
  try{
    const res=await plugin.getPendingOpen();
    if(res?.uri)navigate("local",{uri:res.uri,name:res.name||"PDF"});
  }catch{}
}
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible")checkPendingOpen();});

function showInfoSheet(title,message){
  const lang=currentLang();
  const existing=document.querySelector(".more-info-dialog");
  existing?.querySelector("[data-close]")?.click();
  existing?.remove();
  const dialog=document.createElement("div");
  dialog.className="more-info-dialog";
  dialog.innerHTML=`<div class="more-info-dialog-backdrop" data-close></div><section class="more-info-dialog-panel" role="dialog" aria-modal="true" aria-labelledby="moreInfoTitle"><div class="more-info-dialog-head"><h2 id="moreInfoTitle">${escapeHTML(title)}</h2><button class="icon-btn" type="button" data-close aria-label="${escapeHTML(lang==="ur"?"بند کریں":"Close")}"><i class="fa-solid fa-xmark"></i></button></div><p>${escapeHTML(message)}</p></section>`;
  document.body.appendChild(dialog);
  const release=trapFocus(dialog);
  const onKey=e=>{ if(e.key==="Escape") close(); };
  const close=()=>{ document.removeEventListener("keydown",onKey); dialog.remove(); release(); };
  document.addEventListener("keydown",onKey);
  dialog.querySelectorAll("[data-close]").forEach(el=>el.addEventListener("click",close));
  requestAnimationFrame(()=>{ dialog.classList.add("is-open"); dialog.querySelector("button[data-close]")?.focus({preventScroll:true}); });
}

let readerCleanup = null;

async function downloadBookPdf(book){
  const L=t[currentLang()];
  if(book?.isArchive && !book.pdfUrl){
    // Archive.org books: find the real PDF file name first (one small request), then download normally.
    if(typeof navigator!=="undefined" && navigator.onLine===false){ showToast(L.offline); return; }
    const ur=currentLang()==="ur";
    showToast(ur?"ڈاؤنلوڈ لنک تیار ہو رہا ہے…":"Preparing download…");
    try{ await resolveArchivePdf(book); }
    catch(err){ console.warn("Archive PDF lookup failed",err); showToast(ur?"Archive.org سے رابطہ نہیں ہو سکا۔":"Could not reach Archive.org."); return; }
    if(!book.pdfUrl){ showToast(ur?"اس کتاب کی PDF فائل Archive.org پر دستیاب نہیں۔ آپ اسے پڑھ سکتے ہیں۔":"No PDF file is available for this item on Archive.org. You can still read it here."); return; }
  }
  const url=downloadUrlForBook(book);
  if(!url){ showToast(L.sourceMissing); return; }
  if(typeof navigator !== "undefined" && navigator.onLine === false){
    showToast(L.offline);
    return;
  }
  try{
    // Android app: the system DownloadManager saves into Downloads. Browser: the link is opened directly.
    return await downloadManager.download(book,url,{ nativeDownload:true });
  }catch(err){
    // The Download Manager already shows the failure / retry state.
    console.error("Maktabah PDF download failed",{bookId:book?.id,error:err});
  }
}

function renderReader(id){
  if(readerCleanup){ readerCleanup(); readerCleanup=null; }
  const lang=currentLang(), L=t[lang], ur=lang==="ur", b=data.books.find(x=>x.id===id) || getArchiveBook(id);
  if(!b || b.status!=="available") return navigate("book",{id});
  addHistory(id);

  const title=ur?b.title:(b.titleEn||b.title);
  const labels = ur ? {
    more:"مزید", download:"ڈاؤنلوڈ", source:"اصل ماخذ کھولیں", details:"کتاب کی تفصیل", loading:"کتاب لوڈ ہو رہی ہے…",
    hint:"اگر کتاب نظر نہ آئے تو مینو سے «اصل ماخذ کھولیں» استعمال کریں۔", noSource:"اس کتاب کا ریڈر ماخذ دستیاب نہیں ہے۔",
    srcArchive:"Archive.org", srcDrive:"Google Drive", srcOther:"آن لائن", showBar:"اوپر کی پٹی دکھائیں"
  } : {
    more:"More", download:"Download", source:"Open source", details:"Book details", loading:"Loading book…",
    hint:"If the book does not appear, use “Open source” from the menu.", noSource:"No reader source is available for this book.",
    srcArchive:"Archive.org", srcDrive:"Google Drive", srcOther:"Online", showBar:"Show top bar"
  };
  const readerSource=readerSourceForBook(b);
  const sourceLabel=readerSource?.kind==="archive"?labels.srcArchive:readerSource?.kind==="drive"?labels.srcDrive:labels.srcOther;

  app.innerHTML=`<main class="reader-shell reader-immersive" aria-label="${escapeHTML(title)}">
    <header class="reader-top">
      <button class="icon-btn" id="back" aria-label="${L.back}">
        <i class="fa-solid ${ur?"fa-arrow-right":"fa-arrow-left"}"></i>
      </button>
      <div class="reader-heading"><strong class="reader-title" title="${escapeHTML(title)}">${escapeHTML(title)}</strong><small class="reader-sub" id="readerSub">${escapeHTML(readerSource?sourceLabel:"")}</small></div>
      <div class="reader-more-wrap">
        <button class="icon-btn" id="more" aria-label="${labels.more}" aria-haspopup="menu" aria-expanded="false">
          <i class="fa-solid fa-ellipsis-vertical"></i>
        </button>
        <div class="reader-more-menu" id="readerMoreMenu" role="menu" hidden>
          <button type="button" role="menuitem" data-action="download"><i class="fa-solid fa-download"></i><span>${labels.download}</span></button>
          <button type="button" role="menuitem" data-action="source"><i class="fa-solid fa-arrow-up-right-from-square"></i><span>${labels.source}</span></button>
          <button type="button" role="menuitem" data-action="details"><i class="fa-solid fa-circle-info"></i><span>${labels.details}</span></button>
        </div>
      </div>
    </header>

    <section class="reader-body external-mode" id="readerBody" tabindex="0" aria-label="${escapeHTML(title)}">
      <div class="reader-loading" id="readerLoading">
        <div class="rl-ring" aria-hidden="true"></div><span class="rl-title">${labels.loading}</span>
        <small id="readerViewerHint" class="rl-hint"></small>
        <div class="detail-actions rl-late">
          <button class="btn" id="readerOpenSource"><i class="fa-solid fa-arrow-up-right-from-square"></i>${labels.source}</button>
        </div>
      </div>
      <iframe id="readerExternalFrame" class="reader-external-frame" title="${escapeHTML(title)}" sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-forms allow-presentation" referrerpolicy="no-referrer" allow="fullscreen" allowfullscreen></iframe>
      <button type="button" class="reader-peek" id="readerPeek" aria-label="${labels.showBar}"><span></span></button>
    </section>
  </main>`;

  const $r=s=>app.querySelector(s), shellEl=$r(".reader-shell"), body=$r("#readerBody"), loading=$r("#readerLoading"),
    frame=$r("#readerExternalFrame"), moreBtn=$r("#more"), moreMenu=$r("#readerMoreMenu");
  let destroyed=false, loaded=false, hintTimer=null, barTimer=null;

  const openSource=()=>{
    const url=b.source?.pageUrl || b.pdfUrl || readerSource?.url;
    if(url) openExternal(url);
  };
  const closeMore=()=>{ moreMenu.hidden=true; moreBtn.setAttribute("aria-expanded","false"); };
  const toggleMore=()=>{
    const open=moreMenu.hidden;
    moreMenu.hidden=!open;
    moreBtn.setAttribute("aria-expanded",String(open));
    if(open) moreMenu.querySelector("button")?.focus();
  };

  // The embedded viewer has its own toolbar, so our bar is tucked away; a small handle brings it back.
  const hideBar=()=>{ clearTimeout(barTimer); if(!moreMenu.hidden){ barTimer=setTimeout(hideBar,2500); return; } shellEl.classList.remove("rt-show"); };
  const showBar=(ms=4000)=>{ shellEl.classList.add("rt-show"); clearTimeout(barTimer); barTimer=setTimeout(hideBar,ms); };
  $r("#readerPeek").addEventListener("click",()=>{ shellEl.classList.contains("rt-show")?hideBar():showBar(); });

  $r("#back").onclick=()=>{ closeMore(); history.back(); };
  $r("#readerOpenSource").onclick=openSource;
  moreBtn.onclick=e=>{ e.stopPropagation(); toggleMore(); };
  moreMenu.addEventListener("click",async e=>{
    const item=e.target.closest("[data-action]");
    if(!item) return;
    const action=item.dataset.action;
    closeMore();
    if(action==="download") await downloadBookPdf(b);
    else if(action==="source") openSource();
    else if(action==="details") history.back();
  });
  const onOutside=e=>{ if(!e.target.closest(".reader-more-wrap")) closeMore(); };
  document.addEventListener("click",onOutside);

  readerCleanup=()=>{
    destroyed=true;
    clearTimeout(hintTimer); clearTimeout(barTimer);
    document.removeEventListener("click",onOutside);
    try{ frame.src="about:blank"; }catch{}
  };

  if(!readerSource){
    loading.innerHTML=`<i class="fa-solid fa-triangle-exclamation"></i><strong>${escapeHTML(labels.noSource)}</strong>
      <div class="detail-actions"><button class="btn" id="readerOpenSource2"><i class="fa-solid fa-arrow-up-right-from-square"></i>${labels.source}</button></div>`;
    $r("#readerOpenSource2").onclick=openSource;
    frame.hidden=true;
    showBar(60000);
    return;
  }

  frame.addEventListener("load",()=>{
    if(destroyed) return;
    loaded=true;
    clearTimeout(hintTimer);
    loading.hidden=true;
    body.classList.add("reader-ready");
    showBar(1200);
  });
  showBar(60000);
  const hint=$r("#readerViewerHint");
  if(hint) hint.textContent=sourceLabel;
  hintTimer=setTimeout(()=>{ if(!destroyed && !loaded && hint) hint.textContent=labels.hint; },5000);
  frame.src=readerSource.url;
}

// Quietly keep covers of favourites, downloads and recently read books on the device, so they also show offline.
function scheduleCoverPrefetch(){
  const run=()=>{
    try{
      const urls=[];
      const bookOf=id=>data.byId?.get(id)||getArchiveBook(id);
      getFavorites().forEach(id=>urls.push(bookOf(id)?.cover));
      getDownloads().forEach(r=>urls.push(bookOf(r.bookId)?.cover||r.cover));
      getHistory().slice(0,12).forEach(id=>urls.push(bookOf(id)?.cover));
      prefetchCovers(urls.filter(Boolean));
    }catch(err){ console.warn("Cover prefetch skipped",err); }
  };
  setTimeout(()=>{ (window.requestIdleCallback||(f=>setTimeout(f,0)))(run,{timeout:6000}); },3000);
}

function render(){document.querySelector(".fv-undo")?.remove();if(readerCleanup){ readerCleanup(); readerCleanup=null; }cleanupLibrary();setDirection();applyTheme(state.theme);const r=readRoute();state.prevRoute=state.shownRoute;state.shownRoute=r.route;state.route=r.route;state.params=r.params;switch(r.route){case"home":renderHome();break;case"catalogue":renderClass(null,true);break;case"classes":renderClasses();break;case"class":renderClass(r.params.id);break;case"categories":renderCategories();break;case"category":renderCategory(r.params.id);break;case"favorites":renderFavorites();break;case"search":renderSearch(r.params.q||"");break;case"book":renderBook(r.params.id);break;case"reader":renderReader(r.params.id);break;case"downloads":renderDownloads();break;case"local":renderLocal(r.params);break;case"more":renderMore();break;default:navigate("home",{}, {replace:true});}
  // The dock belongs to the five tab screens only; every other screen (book, reader, search ...) hides it.
  if(!BOTTOM_NAV_TABS.includes(r.route)) hideBottomNav();}
let lastRenderedRoute = "";
async function renderRouteOnce(){
  const raw = location.hash || "#home";
  if(raw === lastRenderedRoute) return;
  lastRenderedRoute = raw;
  const routeName = raw.slice(1).split('?')[0];
  const needsCompleteCatalogue = ['catalogue','classes','class','categories','category'].includes(routeName);
  if(routeName === "book" || routeName === "reader"){
    // One book does not need the whole catalogue: ask for just this book if it is not loaded yet.
    const bookId = readRoute().params.id;
    if(bookId && isArchiveId(bookId)){
      if(!getArchiveBook(bookId)){
        await Promise.race([
          hydrateArchiveBook(bookId).catch(() => null),
          new Promise(resolve => setTimeout(resolve, 8000))
        ]);
      }
    } else if(bookId && !data.byId?.get(bookId)){
      await Promise.race([
        fetchBooksByIds([bookId]).catch(() => []),
        new Promise(resolve => setTimeout(resolve, 8000))
      ]);
    }
    ensureAllBooksLoaded().catch(() => {});   // related books fill in quietly; no redraw
  }
  if(needsCompleteCatalogue) {
    // Show the screen after a short deadline even if the remaining catalogue pages are still
    // loading (slow network); when they arrive, draw the same screen again with the full list.
    const all = ensureAllBooksLoaded();
    const deadline = 2500;
    const finished = await Promise.race([
      all.then(() => true, error => { console.error('Maktabah catalogue load failed', error); return true; }),
      new Promise(resolve => setTimeout(() => resolve(false), deadline))
    ]);
    if(!finished && routeName !== "reader"){
      all.then(() => {
        if(location.hash !== raw || document.querySelector(".class-search-panel.is-open")) return;
        lastRenderedRoute = ""; renderRouteOnce();
      }, () => {});
    }
  }
  // Read the saved scroll position BEFORE building the screen: building it changes the page height,
  // which fires scroll events that would otherwise overwrite the saved value with 0.
  const savedY = Math.max(0, Number(history.state?.scrollY) || 0);
  if(routeName !== "reader" && savedY > 0) lockScrollSave(true);
  render();
  // New routes start at the top; a Back/Forward navigation restores the scroll position saved on that
  // history entry. Screens fill in asynchronously, so keep trying until the page is tall enough.
  if(routeName !== "reader") restoreScroll(savedY); else lockScrollSave(false);
}
let scrollRestoreToken = 0;
function restoreScroll(y){
  const token = ++scrollRestoreToken;
  if(!(y > 0)){ lockScrollSave(false); window.scrollTo({ top: 0, left: 0, behavior: "auto" }); return; }
  let stop = false;
  const halt = () => { stop = true; };
  ["touchstart","wheel","keydown","mousedown"].forEach(ev => window.addEventListener(ev, halt, { once: true, passive: true }));
  const delays = [0, 60, 150, 300, 500, 800, 1200, 1800, 2600];
  const step = i => {
    if(token !== scrollRestoreToken) return;
    if(stop || i >= delays.length){ lockScrollSave(false); return; }
    setTimeout(() => {
      if(token !== scrollRestoreToken) return;
      if(stop){ lockScrollSave(false); return; }
      const max = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
      window.scrollTo({ top: Math.min(y, max), left: 0, behavior: "auto" });
      if(max >= y - 1 && Math.abs(window.scrollY - y) <= 2){ lockScrollSave(false); history.replaceState({ ...history.state, scrollY: Math.round(window.scrollY) }, ""); return; }
      step(i + 1);
    }, delays[i]);
  };
  requestAnimationFrame(() => step(0));
}
window.addEventListener("popstate",e=>{
  const route=readRoute().route;
  const openPanel=document.querySelector(".class-search-panel.is-open");
  if((route==="class"||route==="catalogue") && openPanel && !e.state?.classSearchOpen){
    window.__krClassSearchClose?.();
    return;
  }
  const openCategoryPanel=document.querySelector(".category-topbar .class-search-panel.is-open");
  if(route==="category" && openCategoryPanel && !e.state?.categorySearchOpen){
    window.__krCategorySearchClose?.();
    return;
  }
  window.__krClassSearchClose=null;
  window.__krCategorySearchClose=null;
  renderRouteOnce();
});
window.addEventListener("hashchange",()=>{ syncHashNavigation(); renderRouteOnce(); });
window.addEventListener("DOMContentLoaded",watchSystemTheme);
let lastRuntimeToast=0;
function runtimeFailure(reason){
  console.warn("Maktabah runtime error",reason);
  if(reason&&(reason.name==="AbortError"||/ResizeObserver|AbortError|Load failed|Failed to fetch/i.test(String(reason.message||reason)))) return;
  if(navigator.onLine===false) return;
  const now=Date.now(); if(now-lastRuntimeToast<8000) return; lastRuntimeToast=now;
  showToast(currentLang()==="ur"?"کچھ گڑبڑ ہو گئی۔ دوبارہ کوشش کریں۔":"Something went wrong. Please try again.");
}
window.addEventListener("error",e=>{
  if(document.querySelector(".boot")) renderBootError(e.error||e.message);
  else if(e.error) runtimeFailure(e.error);
});
window.addEventListener("unhandledrejection",e=>runtimeFailure(e.reason));
window.addEventListener("offline",()=>announceNetworkStatus("offline"));
window.addEventListener("krul:storage-full",()=>showToast(currentLang()==="ur"?"فون کی اسٹوریج بھر گئی ہے، کچھ ڈیٹا محفوظ نہیں ہو سکا۔ جگہ خالی کریں۔":"Storage is full, so some data could not be saved. Free up space."));
window.addEventListener("online",()=>announceNetworkStatus("online"));
function renderBootError(err){
  hideBottomNav();
  const ur=currentLang()==="ur";
  app.innerHTML=`<main class="load-error" role="alert"><div class="le-ico"><i class="fa-solid fa-triangle-exclamation"></i></div>
    <h1>${ur?"لائبریری لوڈ نہیں ہو سکی":"Couldn't load the library"}</h1>
    <p>${ur?"انٹرنیٹ کنکشن چیک کریں اور دوبارہ کوشش کریں۔ پہلے سے محفوظ شدہ کتب آف لائن بھی کھل جاتی ہیں۔":"Check your connection and try again. Books you saved for offline reading still open without internet."}</p>
    <div class="le-actions"><button class="primary" id="bootRetry" type="button">${ur?"دوبارہ کوشش کریں":"Try again"}</button><button id="bootDownloads" type="button">${ur?"محفوظ شدہ کتب":"Saved books"}</button></div>
    <details><summary>Details</summary>${escapeHTML(String(err&&err.message||err||""))}</details></main>`;
  app.querySelector("#bootRetry").onclick=()=>location.reload();
  app.querySelector("#bootDownloads").onclick=()=>{ location.hash="#downloads"; location.reload(); };
}
(async function init(){try{watchInsets();initPerf();initHeaderBehavior();ensureUrduFont(m=>console.warn("Maktabah: Urdu font not loaded:",m));ensureAppHistory();installPullToRefresh();watchNativePtr(()=>readRoute().route);startBootWatchdog();data=await loadLibraryData();state.dataReady=true;updateNetworkStatus(null);lastRenderedRoute = "";renderRouteOnce();scheduleCoverPrefetch();checkPendingOpen();recoverPendingDownloads().catch(()=>{});if(libraryNeedsSync()) backgroundSync();}catch(err){console.error("Maktabah failed to start",err);renderBootError(err);}})();
