package com.kr.urdulibrary;

import android.Manifest;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.view.Window;
import android.view.WindowManager;
import android.util.Base64;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import androidx.activity.result.ActivityResult;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(name = "KRDownloader")
public class KRDownloaderPlugin extends Plugin {

    // ------------------------------------------------------------------
    // Open files kept open while the in-app reader is using them
    // ------------------------------------------------------------------
    private static final class OpenFile {
        final ParcelFileDescriptor pfd;
        final FileInputStream in;
        final FileChannel channel;
        final long size;
        byte[] buf;                       // reused by readChunk (no 1 MB allocation per call)

        OpenFile(ParcelFileDescriptor pfd, FileInputStream in, FileChannel channel, long size) {
            this.pfd = pfd;
            this.in = in;
            this.channel = channel;
            this.size = size;
        }

        void close() {
            try { channel.close(); } catch (Exception ignored) { }
            try { in.close(); } catch (Exception ignored) { }
            try { pfd.close(); } catch (Exception ignored) { }
        }
    }

    private final Map<Integer, OpenFile> openFiles = new HashMap<>();
    private int nextHandle = 1;

    // ------------------------------------------------------------------
    // "Open with" support: MainActivity stores the incoming PDF here
    // ------------------------------------------------------------------
    private static String pendingUri = null;
    private static String pendingName = null;

    static synchronized void setPendingIntent(Context context, Intent intent) {
        if (intent == null) return;
        if (!Intent.ACTION_VIEW.equals(intent.getAction())) return;
        Uri uri = intent.getData();
        if (uri == null) return;
        pendingUri = uri.toString();
        pendingName = displayName(context, uri);
    }

    private static String displayName(Context context, Uri uri) {
        Cursor c = null;
        try {
            c = context.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && !c.isNull(i)) return c.getString(i);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "PDF" : last;
    }

    private long querySize(Uri uri) {
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(uri, new String[]{OpenableColumns.SIZE}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0 && !c.isNull(i)) return c.getLong(i);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return -1;
    }

    private DownloadManager manager() {
        return (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
    }

    private String msg(Throwable e, String fallback) {
        return e.getMessage() != null ? e.getMessage() : fallback;
    }

    // ------------------------------------------------------------------
    // Downloading (Android DownloadManager -> public Downloads folder)
    // ------------------------------------------------------------------
    @PluginMethod
    public void start(PluginCall call) {
        String url = call.getString("url");
        String filename = call.getString("filename", "book.pdf");
        String title = call.getString("title", filename);
        if (url == null || url.isEmpty()) {
            call.reject("url is required");
            return;
        }
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(title);
            request.setDescription("Maktabah");
            request.setMimeType("application/pdf");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
            long id = manager().enqueue(request);
            JSObject ret = new JSObject();
            ret.put("id", id);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(msg(e, "Could not start download"));
        }
    }

    @PluginMethod
    public void status(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        Cursor c = null;
        try {
            JSObject ret = new JSObject();
            c = manager().query(new DownloadManager.Query().setFilterById(id));
            if (c != null && c.moveToFirst()) {
                ret.put("found", true);
                ret.put("status", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)));
                ret.put("downloaded", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
                ret.put("total", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
                ret.put("reason", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)));
                int mimeCol = c.getColumnIndex(DownloadManager.COLUMN_MEDIA_TYPE);
                String mime = mimeCol >= 0 ? c.getString(mimeCol) : null;
                ret.put("mime", mime == null ? "" : mime);
                String uri = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI));
                ret.put("uri", uri == null ? "" : uri);
            } else {
                ret.put("found", false);
            }
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(msg(e, "Could not read download status"));
        } finally {
            if (c != null) c.close();
        }
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        try {
            manager().remove(id);
            call.resolve();
        } catch (Exception e) {
            call.reject(msg(e, "Could not cancel download"));
        }
    }

    // ------------------------------------------------------------------
    // Reading a file straight from storage (no copy is made)
    // ------------------------------------------------------------------
    @PluginMethod
    public void openFile(PluginCall call) {
        ParcelFileDescriptor pfd = null;
        boolean stored = false;
        try {
            JSObject data = call.getData();
            String uriStr = data.optString("uri", "");
            String pathStr = data.optString("path", "");
            if (pathStr != null && !pathStr.isEmpty()) {
                pfd = ParcelFileDescriptor.open(new File(pathStr), ParcelFileDescriptor.MODE_READ_ONLY);
            } else if (uriStr != null && !uriStr.isEmpty()) {
                pfd = getContext().getContentResolver().openFileDescriptor(Uri.parse(uriStr), "r");
            } else {
                long id = data.optLong("id", -1);
                pfd = manager().openDownloadedFile(id);
            }
            if (pfd == null) {
                call.reject("Cannot open file");
                return;
            }
            long size = pfd.getStatSize();
            if (size <= 0 && uriStr != null && !uriStr.isEmpty()) {
                size = querySize(Uri.parse(uriStr));
            }
            if (size <= 0) {
                pfd.close();
                call.reject("File size is unknown");
                return;
            }
            FileInputStream in = new FileInputStream(pfd.getFileDescriptor());
            FileChannel channel = in.getChannel();
            int handle;
            synchronized (openFiles) {
                handle = nextHandle++;
                openFiles.put(handle, new OpenFile(pfd, in, channel, size));
                stored = true;
            }
            JSObject ret = new JSObject();
            ret.put("handle", handle);
            ret.put("size", size);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("openFile failed: " + msg(e, "unknown error"));
        } finally {
            if (!stored && pfd != null) { try { pfd.close(); } catch (Exception ignored) { } }   // never leak the descriptor on a failed open
        }
    }

    @PluginMethod
    public void readChunk(PluginCall call) {
        try {
            JSObject data = call.getData();
            int handle = data.optInt("handle", -1);
            long offset = data.optLong("offset", 0);
            int length = data.optInt("length", 0);
            OpenFile f;
            synchronized (openFiles) {
                f = openFiles.get(handle);
            }
            if (f == null) {
                call.reject("File is not open");
                return;
            }
            JSObject ret = new JSObject();
            if (length <= 0 || offset < 0 || offset >= f.size) {
                ret.put("data", "");
                ret.put("bytes", 0);
                call.resolve(ret);
                return;
            }
            if (length > 1048576) length = 1048576;
            if (offset + length > f.size) length = (int) (f.size - offset);
            int total = 0;
            String encoded;
            synchronized (f) {
                if (f.buf == null || f.buf.length < length) f.buf = new byte[length];
                ByteBuffer buf = ByteBuffer.wrap(f.buf, 0, length);
                while (total < length) {
                    int n = f.channel.read(buf, offset + total);
                    if (n < 0) break;
                    total += n;
                }
                encoded = Base64.encodeToString(f.buf, 0, total, Base64.NO_WRAP);
            }
            ret.put("data", encoded);
            ret.put("bytes", total);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("readChunk failed: " + msg(e, "unknown error"));
        }
    }

    /** WebView / activity is going away: nothing on the JS side can close these any more. */
    @Override
    protected void handleOnDestroy() {
        List<OpenFile> left;
        synchronized (openFiles) {
            left = new ArrayList<>(openFiles.values());
            openFiles.clear();
        }
        for (OpenFile f : left) { try { f.close(); } catch (Throwable ignored) { } }
        try { thumbExecutor.shutdownNow(); } catch (Throwable ignored) { }
        super.handleOnDestroy();
    }

    @PluginMethod
    public void closeFile(PluginCall call) {
        int handle = call.getData().optInt("handle", -1);
        OpenFile f;
        synchronized (openFiles) {
            f = openFiles.remove(handle);
        }
        if (f != null) f.close();
        call.resolve();
    }

    @PluginMethod
    public void fileInfo(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        JSObject ret = new JSObject();
        ret.put("exists", false);
        ParcelFileDescriptor pfd = null;
        try {
            pfd = manager().openDownloadedFile(id);
            if (pfd != null) {
                ret.put("exists", true);
                ret.put("size", pfd.getStatSize());
                if (call.getData().optBoolean("pages", false)) {      // page count, asked for once per book
                    PdfRenderer pr = null;
                    try {
                        pr = new PdfRenderer(pfd);
                        ret.put("pages", pr.getPageCount());
                    } catch (Throwable ignored) {
                    } finally {
                        try { if (pr != null) pr.close(); } catch (Exception ignored) { }
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (pfd != null) {
                try { pfd.close(); } catch (Exception ignored) { }
            }
        }
        call.resolve(ret);
    }

    @PluginMethod
    public void deleteDownload(PluginCall call) {
        long id = call.getData().optLong("id", -1);
        try {
            manager().remove(id);
            call.resolve();
        } catch (Exception e) {
            call.reject(msg(e, "Could not delete file"));
        }
    }

    // ------------------------------------------------------------------
    // "Open with" hand-over to the web layer
    // ------------------------------------------------------------------
    @PluginMethod
    public void getPendingOpen(PluginCall call) {
        JSObject ret = new JSObject();
        synchronized (KRDownloaderPlugin.class) {
            if (pendingUri != null) {
                ret.put("uri", pendingUri);
                ret.put("name", pendingName == null ? "" : pendingName);
                pendingUri = null;
                pendingName = null;
            }
        }
        call.resolve(ret);
    }

    // ------------------------------------------------------------------
    // Storage access (needed to list every PDF on the phone)
    // ------------------------------------------------------------------
    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    @PluginMethod
    public void checkStorageAccess(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("granted", hasStorageAccess());
        ret.put("sdk", Build.VERSION.SDK_INT);
        call.resolve(ret);
    }

    @PluginMethod
    public void requestStorageAccess(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getContext().getPackageName()));
                try {
                    getActivity().startActivity(intent);
                } catch (Exception e) {
                    getActivity().startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                }
            } else {
                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 7301);
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(msg(e, "Could not request storage access"));
        }
    }

    // ------------------------------------------------------------------
    // Find every PDF on the phone's main storage
    // ------------------------------------------------------------------
    private final List<PluginCall> scanWaiters = new ArrayList<>();

    @PluginMethod
    public void scanPdfs(final PluginCall call) {
        synchronized (scanWaiters) {
            scanWaiters.add(call);
            if (scanWaiters.size() > 1) return;       // a scan is already running: this call gets its result
        }
        new Thread(() -> {
            JSObject done = null;
            String failure = null;
            try {
                if (!hasStorageAccess()) {
                    failure = "Storage access not granted";
                    return;
                }
                final int limit = 5000;
                int count = 0;
                File rootDir = Environment.getExternalStorageDirectory();
                String root = rootDir.getAbsolutePath();
                String skipData = root + "/Android/data";
                String skipObb = root + "/Android/obb";
                JSArray files = new JSArray();
                ArrayDeque<File> stack = new ArrayDeque<>();
                Set<String> seen = new HashSet<>();          // a folder reached twice (symlink loop) is read once
                stack.push(rootDir);
                while (!stack.isEmpty() && count < limit) {
                    File dir = stack.pop();
                    try { if (!seen.add(dir.getCanonicalPath())) continue; } catch (Exception e) { continue; }
                    File[] children = dir.listFiles();
                    if (children == null) continue;
                    for (File f : children) {
                        String name = f.getName();
                        if (name.startsWith(".")) continue;
                        if (f.isDirectory()) {
                            String path = f.getAbsolutePath();
                            if (path.equals(skipData) || path.equals(skipObb)) continue;
                            stack.push(f);
                        } else if (name.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
                            long len = f.length();
                            if (len <= 0) continue;
                            JSObject o = new JSObject();
                            o.put("path", f.getAbsolutePath());
                            o.put("name", name);
                            o.put("size", len);
                            o.put("modified", f.lastModified());
                            files.put(o);
                            count++;
                            if (count >= limit) break;
                        }
                    }
                }
                JSObject ret = new JSObject();
                ret.put("files", files);
                ret.put("truncated", count >= limit);
                done = ret;
            } catch (Throwable e) {
                failure = "scan failed: " + (e.getMessage() != null ? e.getMessage() : "error");
            } finally {
                List<PluginCall> waiting;
                synchronized (scanWaiters) { waiting = new ArrayList<>(scanWaiters); scanWaiters.clear(); }
                for (PluginCall c : waiting) {
                    try {
                        if (done != null) c.resolve(done); else c.reject(failure != null ? failure : "scan failed");
                    } catch (Throwable ignored) { }
                }
            }
        }).start();
    }

    // ------------------------------------------------------------------
    // First-page thumbnails (small JPEGs cached in the app's cache folder)
    // ------------------------------------------------------------------
    private final ExecutorService thumbExecutor = Executors.newSingleThreadExecutor();

    private static byte[] readAll(File f) throws java.io.IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private static String md5Hex(String v) {
        try {
            byte[] d = MessageDigest.getInstance("MD5").digest(v.getBytes("UTF-8"));
            StringBuilder b = new StringBuilder();
            for (byte x : d) b.append(String.format(Locale.ROOT, "%02x", x));
            return b.toString();
        } catch (Exception e) {
            return Integer.toHexString(v.hashCode()) + "_" + v.length();
        }
    }

    private boolean thumbsTrimmed = false;
    /** Thumbnails are never needed twice for a replaced file: keep the newest ~300, once per app run. */
    private void trimThumbsOnce(File dir) {
        if (thumbsTrimmed) return;
        thumbsTrimmed = true;
        try {
            File[] all = dir.listFiles();
            if (all == null || all.length <= 600) return;
            Arrays.sort(all, new Comparator<File>() {
                @Override public int compare(File a, File b) { return Long.compare(b.lastModified(), a.lastModified()); }
            });
            for (int i = 400; i < all.length; i++) { try { all[i].delete(); } catch (Throwable ignored) { } }
        } catch (Throwable ignored) { }
    }

    private static void writePages(File f, int n) {
        if (n < 1) return;
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(String.valueOf(n).getBytes());
        } catch (Exception ignored) {
        }
    }

    @PluginMethod
    public void thumbnail(final PluginCall call) {
        final JSObject data = call.getData();
        thumbExecutor.execute(() -> {
            ParcelFileDescriptor pfd = null;
            PdfRenderer renderer = null;
            PdfRenderer.Page page = null;
            try {
                String path = data.optString("path", "");
                String key = data.optString("key", path);
                int width = Math.max(40, Math.min(1200, data.optInt("width", 240)));
                if (path.isEmpty()) {
                    call.reject("path is required");
                    return;
                }
                File dir = new File(getContext().getCacheDir(), "thumbs");
                if (!dir.exists()) dir.mkdirs();
                trimThumbsOnce(dir);
                File srcFile = new File(path);
                // the name changes when the PDF is replaced, so an old thumbnail is never shown for a new file
                File cached = new File(dir, md5Hex(key + "|" + srcFile.length() + "|" + srcFile.lastModified()) + ".jpg");
                byte[] jpg;
                File pgFile = new File(dir, cached.getName() + ".pg");
                int pageCount = 0;
                try {
                    if (pgFile.exists()) pageCount = Integer.parseInt(new String(readAll(pgFile)).trim());
                } catch (Throwable ignored) { }
                if (cached.exists() && cached.length() > 0) {
                    jpg = readAll(cached);
                    if (pageCount < 1) {            // thumbnail made by an older version: read the page count once
                        try {
                            pfd = ParcelFileDescriptor.open(new File(path), ParcelFileDescriptor.MODE_READ_ONLY);
                            renderer = new PdfRenderer(pfd);
                            pageCount = renderer.getPageCount();
                            writePages(pgFile, pageCount);
                        } catch (Throwable ignored) { }
                    }
                } else {
                    pfd = ParcelFileDescriptor.open(new File(path), ParcelFileDescriptor.MODE_READ_ONLY);
                    renderer = new PdfRenderer(pfd);
                    if (renderer.getPageCount() < 1) {
                        call.reject("empty pdf");
                        return;
                    }
                    pageCount = renderer.getPageCount();
                    writePages(pgFile, pageCount);
                    page = renderer.openPage(0);
                    int pw = Math.max(1, page.getWidth());
                    int h = Math.max(1, Math.min(width * 2,
                            Math.round((float) page.getHeight() * width / pw)));
                    Bitmap bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888);
                    bmp.eraseColor(Color.WHITE);
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 72, out);
                    bmp.recycle();
                    jpg = out.toByteArray();
                    try (FileOutputStream fos = new FileOutputStream(cached)) {
                        fos.write(jpg);
                    } catch (Exception ignored) {
                    }
                }
                JSObject ret = new JSObject();
                ret.put("data", "data:image/jpeg;base64," + Base64.encodeToString(jpg, Base64.NO_WRAP));
                if (pageCount > 0) ret.put("pages", pageCount);
                call.resolve(ret);
            } catch (Throwable e) {
                call.reject("thumbnail failed: " + (e.getMessage() != null ? e.getMessage() : "error"));
            } finally {
                try { if (page != null) page.close(); } catch (Exception ignored) { }
                try { if (renderer != null) renderer.close(); } catch (Exception ignored) { }
                try { if (pfd != null) pfd.close(); } catch (Exception ignored) { }
            }
        });
    }

    // ------------------------------------------------------------------
    // Reader comfort: keep the screen awake / hide system bars while reading
    // ------------------------------------------------------------------
    @PluginMethod
    public void setKeepScreenOn(final PluginCall call) {
        final boolean on = call.getData().optBoolean("on", false);
        if (getActivity() == null) {
            call.resolve();
            return;
        }
        getActivity().runOnUiThread(() -> {
            try {
                Window w = getActivity().getWindow();
                if (on) w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                call.resolve();
            } catch (Exception e) {
                call.reject(msg(e, "Could not change screen setting"));
            }
        });
    }

    @PluginMethod
    public void setImmersive(final PluginCall call) {
        final boolean on = call.getData().optBoolean("on", false);
        if (getActivity() == null) {
            call.resolve();
            return;
        }
        getActivity().runOnUiThread(() -> {
            try {
                Window w = getActivity().getWindow();
                WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
                if (c != null) {
                    if (on) {
                        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                        c.hide(WindowInsetsCompat.Type.systemBars());
                    } else {
                        c.show(WindowInsetsCompat.Type.systemBars());
                    }
                }
                call.resolve();
            } catch (Exception e) {
                call.reject(msg(e, "Could not change system bars"));
            }
        });
    }

    // ------------------------------------------------------------------
    // Theme sync: colour the window + status/navigation bars like the app background
    // ------------------------------------------------------------------
    @PluginMethod
    public void setSystemBars(final PluginCall call) {
        final String hex = call.getData().optString("color", "#f7f7f5");
        final boolean light = call.getData().optBoolean("light", true);
        if (getActivity() == null) {
            call.resolve();
            return;
        }
        getActivity().runOnUiThread(() -> {
            try {
                MainActivity.applySystemBars(getActivity(), Color.parseColor(hex), light);
                call.resolve();
            } catch (Exception e) {
                call.reject(msg(e, "Could not change system bar colours"));
            }
        });
    }

    // ------------------------------------------------------------------
    // Native MuPDF reader (MuReaderActivity). The activity class is looked up by name so that a build
    // without MuPDF still compiles and simply reports "unavailable" (the web layer then uses pdf.js).
    // ------------------------------------------------------------------
    /** The real file of a finished download, but only when this app can really read it (else null -> copy fallback). */
    @SuppressWarnings("deprecation")
    private File downloadedFile(long id) {
        Cursor c = null;
        try {
            c = manager().query(new DownloadManager.Query().setFilterById(id));
            if (c != null && c.moveToFirst()
                    && c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL) {
                String p = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_FILENAME));
                if (p != null && !p.isEmpty()) {
                    File f = new File(p);
                    if (f.isFile() && f.length() > 0) {
                        try (FileInputStream probe = new FileInputStream(f)) {
                            if (probe.read() >= 0) return f;
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return null;
    }

    private File resolveReadableFile(JSObject data) throws Exception {
        String path = data.optString("path", "");
        if (path != null && !path.isEmpty()) {
            File f = new File(path);
            if (!f.exists()) throw new java.io.FileNotFoundException(path);
            return f;
        }
        String uriStr = data.optString("uri", "");
        if (uriStr == null || uriStr.isEmpty()) {
            // A finished download of this app: read the real file in Downloads, no copy into app storage.
            File direct = downloadedFile(data.optLong("id", -1));
            if (direct != null) return direct;
        }
        ParcelFileDescriptor pfd;
        String key;
        if (uriStr != null && !uriStr.isEmpty()) {
            pfd = getContext().getContentResolver().openFileDescriptor(Uri.parse(uriStr), "r");
            key = "u" + Integer.toHexString(uriStr.hashCode());
        } else {
            long id = data.optLong("id", -1);
            pfd = manager().openDownloadedFile(id);
            key = "d" + id;
        }
        if (pfd == null) throw new Exception("Cannot open file");
        try {
            long size = pfd.getStatSize();
            File dir = new File(getContext().getCacheDir(), "mu");
            dir.mkdirs();
            File out = new File(dir, key + ".pdf");
            if (out.exists() && size > 0 && out.length() == size) {
                out.setLastModified(System.currentTimeMillis());   // so the cache pruning is really "least recently used"
                return out;
            }
            try (FileInputStream in = new FileInputStream(pfd.getFileDescriptor());
                 FileOutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
            pruneMuCache(dir, out);
            return out;
        } finally {
            try { pfd.close(); } catch (Exception ignored) { }
        }
    }

    /** Keeps the copy cache (files that had to be copied out of content:// or downloads) under ~300 MB. */
    private static void pruneMuCache(File dir, File keep) {
        try {
            File[] all = dir.listFiles();
            if (all == null) return;
            long total = 0;
            for (File f : all) total += f.length();
            java.util.Arrays.sort(all, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
            for (File f : all) {
                if (total <= 300L * 1024 * 1024) break;
                if (f.equals(keep)) continue;
                total -= f.length();
                f.delete();
            }
        } catch (Throwable ignored) { }
    }

    @PluginMethod
    public void openMuReader(final PluginCall call) {
        final Class<?> cls;
        try {
            cls = Class.forName("com.kr.urdulibrary.MuReaderActivity");
        } catch (Throwable t) {
            call.unavailable("MuPDF reader not included in this build");
            return;
        }
        new Thread(() -> {
            try {
                JSObject data = call.getData();
                File f = resolveReadableFile(data);
                final Intent i = new Intent(getContext(), cls);
                i.putExtra("path", f.getAbsolutePath());
                i.putExtra("title", data.optString("title", "PDF"));
                i.putExtra("lang", data.optString("lang", "ur"));
                i.putExtra("page", data.optInt("page", 1));
                i.putExtra("frac", (float) data.optDouble("frac", 0));
                i.putExtra("theme", data.optString("theme", "paper"));
                i.putExtra("dim", (float) data.optDouble("dim", 0));
                i.putExtra("keepAwake", data.optBoolean("keepAwake", false));
                i.putExtra("autoHide", data.optBoolean("autoHide", true));
                org.json.JSONArray ma = data.optJSONArray("marks");
                if (ma != null) {
                    int[] marks = new int[ma.length()];
                    for (int k = 0; k < marks.length; k++) marks[k] = ma.optInt(k, 0);
                    i.putExtra("marks", marks);
                }
                org.json.JSONArray ha = data.optJSONArray("highlights");
                if (ha != null) {
                    String hj = ha.toString();
                    if (hj.length() < 100000) i.putExtra("highlights", hj);      // big lists go through a file (Binder limit)
                    else {
                        File hf = new File(getContext().getCacheDir(), "mu_hl_in.json");
                        try (java.io.FileOutputStream fo = new java.io.FileOutputStream(hf)) {
                            fo.write(hj.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                            i.putExtra("highlightsFile", hf.getAbsolutePath());
                        } catch (Throwable e) { i.putExtra("highlights", hj); }
                    }
                }
                if (getActivity() == null) { call.reject("No activity"); return; }
                getActivity().runOnUiThread(() -> {
                    try { startActivityForResult(call, i, "muReaderResult"); }
                    catch (Throwable e) { call.reject("Could not start reader: " + msg(e, "error")); }
                });
            } catch (Throwable e) {
                call.reject("openMuReader failed: " + msg(e, "unknown error"));
            }
        }).start();
    }

    @ActivityCallback
    private void muReaderResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent d = result != null ? result.getData() : null;
        if (d != null && d.hasExtra("error")) {
            call.reject("MuPDF: " + d.getStringExtra("error"));
            return;
        }
        JSObject ret = new JSObject();
        if (d != null) {
            ret.put("page", d.getIntExtra("page", 0));
            ret.put("frac", d.getFloatExtra("frac", 0f));
            ret.put("total", d.getIntExtra("total", 0));
            ret.put("theme", d.getStringExtra("theme"));
            ret.put("dim", d.getFloatExtra("dim", 0f));
            ret.put("keepAwake", d.getBooleanExtra("keepAwake", false));
            JSArray arr = new JSArray();
            int[] marks = d.getIntArrayExtra("marks");
            if (marks != null) for (int m : marks) arr.put(m);
            ret.put("marks", arr);
            String hs = d.getStringExtra("highlights");
            String hfPath = d.getStringExtra("highlightsFile");
            if (hfPath != null) {
                try {
                    File hf = new File(hfPath);
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    try (FileInputStream fi = new FileInputStream(hf)) {
                        byte[] buf = new byte[16384];
                        int n;
                        while ((n = fi.read(buf)) > 0) bo.write(buf, 0, n);
                    }
                    hs = new String(bo.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
                    hf.delete();
                } catch (Throwable ignored) { }
            }
            if (hs != null) { try { ret.put("highlights", new JSArray(hs)); } catch (Exception ignored) { } }
        }
        call.resolve(ret);
    }

    // ------------------------------------------------------------------
    // Native pull-to-refresh bridge (see MainActivity.installNativePullRefresh)
    // ------------------------------------------------------------------
    @PluginMethod
    public void setPullRefresh(PluginCall call) {
        Integer bg = null, fg = null;
        try { String b = call.getString("bg"); if (b != null) bg = android.graphics.Color.parseColor(b); } catch (Throwable ignored) { }
        try { String f = call.getString("fg"); if (f != null) fg = android.graphics.Color.parseColor(f); } catch (Throwable ignored) { }
        MainActivity.configurePtr(Boolean.TRUE.equals(call.getBoolean("enabled", false)), bg, fg);
        JSObject r = new JSObject();
        r.put("native", MainActivity.ptr != null);
        call.resolve(r);
    }

    @PluginMethod
    public void refreshDone(PluginCall call) {
        MainActivity.finishPtr();
        call.resolve();
    }

    // ------------------------------------------------------------------
    // Device capability, used by the web layer's Performance "Auto" mode (js/features/perf.js).
    // Raw numbers only; the Lite/Full decision and its thresholds live in JS so they can be tuned
    // without touching native code.
    // ------------------------------------------------------------------
    @PluginMethod
    public void getDeviceInfo(PluginCall call) {
        JSObject r = new JSObject();
        try {
            android.app.ActivityManager am =
                    (android.app.ActivityManager) getContext().getSystemService(Context.ACTIVITY_SERVICE);
            if (am != null) {
                android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                r.put("totalMemMb", mi.totalMem / (1024L * 1024L));
                r.put("lowRam", am.isLowRamDevice());
                r.put("memoryClassMb", am.getMemoryClass());
            }
        } catch (Throwable ignored) { }
        try { r.put("cores", Runtime.getRuntime().availableProcessors()); } catch (Throwable ignored) { }
        try { r.put("sdk", Build.VERSION.SDK_INT); } catch (Throwable ignored) { }
        try {
            if (getActivity() != null) {
                r.put("refreshHz", (double) getActivity().getWindowManager().getDefaultDisplay().getRefreshRate());
            }
        } catch (Throwable ignored) { }
        call.resolve(r);
    }

    // ------------------------------------------------------------------
    // Safe-area insets measured natively: how far the WebView REALLY extends under the status /
    // navigation bar. The web layer uses these (as --sat / --sab) instead of guessing from CSS env(),
    // which double-counts when Android already places the WebView below the status bar.
    // ------------------------------------------------------------------
    @PluginMethod
    public void getSafeInsets(final PluginCall call) {
        if (getActivity() == null || getBridge() == null || getBridge().getWebView() == null) {
            JSObject none = new JSObject();
            none.put("top", 0);
            none.put("bottom", 0);
            none.put("known", false);
            call.resolve(none);
            return;
        }
        getActivity().runOnUiThread(() -> {
            try {
                final android.webkit.WebView wv = getBridge().getWebView();
                final android.view.View decor = getActivity().getWindow().getDecorView();
                WindowInsetsCompat root = androidx.core.view.ViewCompat.getRootWindowInsets(wv);
                if (root == null) {
                    JSObject none = new JSObject();
                    none.put("top", 0);
                    none.put("bottom", 0);
                    none.put("known", false);
                    call.resolve(none);
                    return;
                }
                androidx.core.graphics.Insets status = root.getInsets(WindowInsetsCompat.Type.statusBars());
                androidx.core.graphics.Insets nav = root.getInsets(WindowInsetsCompat.Type.navigationBars());
                androidx.core.graphics.Insets cut = root.getInsets(WindowInsetsCompat.Type.displayCutout());
                int[] w = new int[2];
                int[] d = new int[2];
                wv.getLocationOnScreen(w);
                decor.getLocationOnScreen(d);
                int topEdge = w[1] - d[1];                                              // WebView top inside the window
                int bottomEdge = (d[1] + decor.getHeight()) - (w[1] + wv.getHeight());  // space left below the WebView
                int overTop = Math.max(0, Math.max(status.top, cut.top) - topEdge);
                int overBottom = Math.max(0, Math.max(nav.bottom, cut.bottom) - bottomEdge);
                float density = getActivity().getResources().getDisplayMetrics().density;
                JSObject out = new JSObject();
                out.put("top", Math.round(overTop / density));
                out.put("bottom", Math.round(overBottom / density));
                out.put("known", true);
                call.resolve(out);
            } catch (Exception e) {
                call.reject(msg(e, "Could not read safe-area insets"));
            }
        });
    }
}
