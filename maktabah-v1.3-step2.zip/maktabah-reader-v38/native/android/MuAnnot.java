package com.kr.urdulibrary;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Region;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * One annotation on a page. This is the single place to extend when a new kind is added (sticker, note pin...):
 * add a type constant, then handle it in toJson / fromJson, draw, hit and bounds.
 *
 * TEXT   - line boxes over selected text, in page points (rects).
 * STROKE - a drawn line (marker or pen), points in page-width units (pts).
 * BOX    - a rectangle (marker = filled, pen = outline), pts = x0,y0,x1,y1 in page-width units.
 * STICKER - a sticky-note icon the reader drags anywhere on a page. pts = x,y of its centre in page-width units
 *           (so it stays put on the page), alpha = opacity, color / rgb = paper colour, note = the text written on it.
 *           size = its width in page-width units (0 = default), so it scales with zoom like every other mark.
 *
 * "Page-width units" = x / pageWidth and y / pageWidth, so a mark looks the same on every page size and zoom.
 */
final class MuAnnot {
    static final int TEXT = 0, STROKE = 1, BOX = 2, STICKER = 3;
    static final float STICKER_DEF = 0.085f;    // default sticker width, page-width units (about 30dp on a phone at zoom 1)
    static final float STICKER_MIN = 0.012f, STICKER_MAX = 0.60f;

    static final int[] FILL = {0xFFFFE066, 0xFF8FE3A5, 0xFF8EC9FF, 0xFFFFA3C7, 0xFFD2A8FF, 0xFFFFC48A, 0xFFFF9E9E, 0xFF3A3F3C};
    static final int[] INK = {0xFFF2B705, 0xFF2FB36A, 0xFF3B8EEA, 0xFFEA5A95, 0xFF9B6BE8, 0xFFF08A24, 0xFFE5484D, 0xFF1F2522};
    static final int TEXT_COLORS = 7;            // the last (dark) colour is for the pen only
    static final int MAX = 1500;

    String id = "";
    int type;
    int page0;
    int color;
    int rgb;                                     // custom colour (0xFFRRGGBB); 0 = use the palette entry `color`
    int style;                                   // TEXT: 0 highlight, 1 underline, 2 strike-through
    String note = "";
    String text = "";
    long created;
    float[] rects = new float[0];
    float[] pts = new float[0];
    float width;                                 // page-width units
    float size;                                  // STICKER: width in page-width units (0 = default)
    int alpha = 100;                             // percent
    boolean marker = true;                       // STROKE / BOX: highlighter (multiply) or pen
    boolean flat = true;                         // flat (chisel) ends
    List<float[]> cuts = new ArrayList<>();      // rubbed-out parts (freehand eraser): {width, x0,y0, x1,y1, ...} in page-width units
    float[] liveCut;                             // the finger trail while it is still down (not saved)
    int liveCutN;
    float liveCutW;

    int fillC() { return rgb != 0 ? rgb : FILL[Math.max(0, Math.min(FILL.length - 1, color))]; }
    int inkC() { return rgb != 0 ? rgb : INK[Math.max(0, Math.min(INK.length - 1, color))]; }

    private static int seq = 0;
    static String newId() { return Long.toString(System.currentTimeMillis(), 36) + Integer.toString(++seq, 36); }

    // ------------------------------------------------------------------ json
    private static JSONArray arr(float[] a, float scale) throws org.json.JSONException {
        JSONArray r = new JSONArray();
        for (float f : a) r.put(Math.round(f * scale) / (double) scale);
        return r;
    }

    JSONObject toJson() throws org.json.JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id); o.put("k", type); o.put("p", page0 + 1);
        o.put("c", color); if (rgb != 0) o.put("rgb", rgb); o.put("s", style); o.put("n", note); o.put("t", text); o.put("d", created);
        if (type == TEXT) o.put("r", arr(rects, 100f));
        else {
            o.put("pt", arr(pts, 10000f));
            o.put("w", Math.round(width * 100000f) / 100000.0);
            o.put("a", alpha); o.put("m", marker ? 1 : 0); o.put("f", flat ? 1 : 0);
            if (type == STICKER && size > 0f) o.put("z", Math.round(size * 10000f) / 10000.0);
        }
        if (!cuts.isEmpty()) {
            JSONArray e = new JSONArray();
            for (float[] k : cuts) e.put(arr(k, 10000f));
            o.put("e", e);
        }
        return o;
    }

    static MuAnnot fromJson(JSONObject o) {
        if (o == null) return null;
        int p = o.optInt("p", 0);
        if (p < 1) return null;
        MuAnnot a = new MuAnnot();
        a.type = Math.max(0, Math.min(3, o.optInt("k", TEXT)));
        a.id = o.optString("id", "");
        if (a.id.isEmpty()) a.id = newId();
        a.page0 = p - 1;
        a.color = Math.max(0, Math.min(FILL.length - 1, o.optInt("c", 0)));
        a.rgb = o.optInt("rgb", 0);
        a.style = Math.max(0, Math.min(2, o.optInt("s", 0)));
        a.note = o.optString("n", "");
        a.text = o.optString("t", "");
        a.created = o.optLong("d", 0L);
        JSONArray src = o.optJSONArray(a.type == TEXT ? "r" : "pt");
        if (src == null) return null;
        int n = src.length() - src.length() % (a.type == TEXT ? 4 : 2);
        float[] f = new float[n];
        for (int i = 0; i < n; i++) f[i] = (float) src.optDouble(i, 0);
        if (a.type == TEXT) { if (n < 4) return null; a.rects = f; }
        else {
            if (n < 2 || (a.type == BOX && n < 4)) return null;
            a.pts = f;
            a.width = (float) o.optDouble("w", 0.01);
            a.alpha = Math.max(5, Math.min(100, o.optInt("a", 100)));
            a.marker = o.optInt("m", 1) != 0;
            a.flat = o.optInt("f", 1) != 0;
            if (a.type == STICKER) a.size = (float) o.optDouble("z", 0);
        }
        JSONArray ea = o.optJSONArray("e");
        if (ea != null) {
            for (int i = 0; i < ea.length() && i < 400; i++) {
                JSONArray ja = ea.optJSONArray(i);
                if (ja == null || ja.length() < 3) continue;
                int m = 1 + (ja.length() - 1) / 2 * 2;
                float[] k = new float[m];
                for (int j = 0; j < m; j++) k[j] = (float) ja.optDouble(j, 0);
                a.cuts.add(k);
            }
        }
        return a;
    }

    static String toJson(List<MuAnnot> list) {
        JSONArray arr = new JSONArray();
        if (list != null) for (MuAnnot a : list) {
            try { arr.put(a.toJson()); } catch (Throwable ignored) { }
        }
        return arr.toString();
    }

    static List<MuAnnot> parse(String json) {
        List<MuAnnot> out = new ArrayList<>();
        if (json == null || json.isEmpty()) return out;
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length() && out.size() < MAX; i++) {
                MuAnnot a = fromJson(arr.optJSONObject(i));
                if (a != null) out.add(a);
            }
        } catch (Throwable ignored) { }
        return out;
    }

    // ------------------------------------------------------------------ geometry
    boolean isInk() { return type == STROKE || type == BOX; }
    boolean isSticker() { return type == STICKER; }
    float stkSize() { return size > 0f ? Math.max(STICKER_MIN, Math.min(STICKER_MAX, size)) : STICKER_DEF; }
    transient boolean lifted;                   // sticker is being dragged (drawn a bit bigger)

    /** Bounds in page-width units: out = x0, y0, x1, y1. pw = page width in points (only TEXT needs it). */
    boolean bounds(float pw, float[] out) {
        float a = Float.MAX_VALUE, b = Float.MAX_VALUE, c = -Float.MAX_VALUE, d = -Float.MAX_VALUE;
        if (type == TEXT) {
            if (rects.length < 4 || pw <= 0f) return false;
            for (int i = 0; i + 3 < rects.length; i += 4) {
                a = Math.min(a, rects[i]); b = Math.min(b, rects[i + 1]); c = Math.max(c, rects[i + 2]); d = Math.max(d, rects[i + 3]);
            }
            out[0] = a / pw; out[1] = b / pw; out[2] = c / pw; out[3] = d / pw;
            return true;
        }
        if (type == STICKER) {
            if (pts.length < 2) return false;
            float h = stkSize() / 2f;
            out[0] = pts[0] - h; out[1] = pts[1] - h; out[2] = pts[0] + h; out[3] = pts[1] + h;
            return true;
        }
        if (pts.length < 2) return false;
        for (int i = 0; i + 1 < pts.length; i += 2) {
            a = Math.min(a, pts[i]); b = Math.min(b, pts[i + 1]); c = Math.max(c, pts[i]); d = Math.max(d, pts[i + 1]);
        }
        float h = width / 2f;
        out[0] = a - h; out[1] = b - h; out[2] = c + h; out[3] = d + h;
        return true;
    }

    private static float segDist(float px, float py, float ax, float ay, float bx, float by) {
        float dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
        float t = l2 == 0f ? 0f : ((px - ax) * dx + (py - ay) * dy) / l2;
        t = Math.max(0f, Math.min(1f, t));
        return (float) Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
    }

    /** Is the point (page-width units) on this annotation? tol is in the same units. */
    boolean hit(float nx, float ny, float tol, float pw) {
        if (type == STICKER) return false;     // the view tests stickers in screen units; the eraser leaves them alone
        if (type == TEXT) {
            float px = nx * pw, py = ny * pw, t = tol * pw;
            for (int i = 0; i + 3 < rects.length; i += 4) {
                if (px >= rects[i] - t && px <= rects[i + 2] + t && py >= rects[i + 1] - t && py <= rects[i + 3] + t) return true;
            }
            return false;
        }
        if (type == BOX && pts.length >= 4) {
            float x0 = Math.min(pts[0], pts[2]), x1 = Math.max(pts[0], pts[2]), y0 = Math.min(pts[1], pts[3]), y1 = Math.max(pts[1], pts[3]);
            boolean inside = nx >= x0 - tol && nx <= x1 + tol && ny >= y0 - tol && ny <= y1 + tol;
            if (marker) return inside;
            float t = tol + width / 2f;
            boolean inner = nx > x0 + t && nx < x1 - t && ny > y0 + t && ny < y1 - t;
            return inside && !inner;
        }
        float lim = tol + width / 2f;
        if (pts.length == 2) return Math.hypot(nx - pts[0], ny - pts[1]) <= lim;
        for (int i = 0; i + 3 < pts.length; i += 2) {
            if (segDist(nx, ny, pts[i], pts[i + 1], pts[i + 2], pts[i + 3]) <= lim) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ drawing
    /** Everything needed to draw on one page; reused between annotations to avoid allocations. */
    static final class Ctx {
        Canvas cv;
        float left, top;          // page origin on screen
        float k;                  // page points -> px
        float S;                  // page width in px (page-width units -> px)
        float dens, viewW;
        int theme;                // 2 = night
        float flash;              // 0..1 pulse strength
        final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path path = new Path();
        final RectF r = new RectF();
        final PorterDuffXfermode multiply = new PorterDuffXfermode(PorterDuff.Mode.MULTIPLY);
        final Matrix mat = new Matrix();
        final Path tmp = new Path();
    }

    /** Opaque colour for MULTIPLY blending: fades toward white as opacity drops (alpha would darken it). */
    static int multColor(int color, int pct) {
        int p = Math.max(0, Math.min(100, pct));
        int r = 255 - (255 - ((color >> 16) & 255)) * p / 100;
        int g = 255 - (255 - ((color >> 8) & 255)) * p / 100;
        int b = 255 - (255 - (color & 255)) * p / 100;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    static int alphaOf(int color, float pct) {
        int a = Math.round(Math.max(0f, Math.min(100f, pct)) * 2.55f);
        return (color & 0x00FFFFFF) | (a << 24);
    }

    void draw(Ctx c) {
        if (!cuts.isEmpty() || (liveCut != null && liveCutN >= 2)) drawCut(c); else drawBody(c);
        if (c.flash > 0.01f) drawFlash(c);
    }

    private void drawBody(Ctx c) {
        if (type == STICKER) drawSticker(c);
        else if (type == TEXT) drawText(c);
        else if (type == STROKE) drawStroke(c);
        else drawBox(c);
    }

    private static final float U = 1000f;        // cut outlines are kept in page-width units * U so the stroker stays precise
    private static final Paint OUT = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<Path> cutPaths;
    private List<float[]> cutPathsSrc;
    private int cutPathsN = -1;

    private static Path outline(float[] a, int from, int to, float w) {
        Path dst = new Path();
        float sw = Math.max(0.5f, w * U);
        if (to - from < 4) { dst.addCircle(a[from] * U, a[from + 1] * U, sw / 2f, Path.Direction.CW); return dst; }
        Path src = new Path();
        src.moveTo(a[from] * U, a[from + 1] * U);
        for (int i = from + 2; i + 1 < to; i += 2) src.lineTo(a[i] * U, a[i + 1] * U);
        OUT.setStyle(Paint.Style.STROKE);
        OUT.setStrokeCap(Paint.Cap.ROUND);
        OUT.setStrokeJoin(Paint.Join.ROUND);
        OUT.setStrokeWidth(sw);
        OUT.getFillPath(src, dst);
        return dst;
    }

    /** Draws the mark with the rubbed-out parts cut out of the canvas clip, so only what the finger touched disappears. */
    private void drawCut(Ctx c) {
        if (cutPaths == null || cutPathsSrc != cuts || cutPathsN != cuts.size()) {
            cutPaths = new ArrayList<>();
            for (float[] k : cuts) if (k.length >= 3) cutPaths.add(outline(k, 1, k.length, k[0]));
            cutPathsSrc = cuts;
            cutPathsN = cuts.size();
        }
        Matrix m = c.mat;
        m.setScale(c.S / U, c.S / U);
        m.postTranslate(c.left, c.top);
        c.cv.save();
        for (Path p : cutPaths) {
            c.tmp.reset();
            p.transform(m, c.tmp);
            c.cv.clipPath(c.tmp, Region.Op.DIFFERENCE);
        }
        if (liveCut != null && liveCutN >= 2) {
            c.tmp.reset();
            outline(liveCut, 0, liveCutN, liveCutW).transform(m, c.tmp);
            c.cv.clipPath(c.tmp, Region.Op.DIFFERENCE);
        }
        drawBody(c);
        c.cv.restore();
    }

    private void drawText(Ctx c) {
        int fill = fillC(), ink = inkC();
        for (int r = 0; r + 3 < rects.length; r += 4) {
            float l = c.left + rects[r] * c.k, t = c.top + rects[r + 1] * c.k, rr = c.left + rects[r + 2] * c.k, b = c.top + rects[r + 3] * c.k;
            float lh = b - t;
            if (style == 0) {
                c.r.set(l - c.dens, t + lh * 0.04f, rr + c.dens, b - lh * 0.02f);
                if (c.theme == 2) { c.fill.setXfermode(null); c.fill.setColor((fill & 0x00FFFFFF) | 0x66000000); }
                else { c.fill.setXfermode(c.multiply); c.fill.setColor(fill); }
                c.fill.setStyle(Paint.Style.FILL);
                c.cv.drawRoundRect(c.r, 3f * c.dens, 3f * c.dens, c.fill);
                c.fill.setXfermode(null);
            } else {
                float y = style == 1 ? b - lh * 0.07f : t + lh * 0.56f;
                c.line.setXfermode(null);
                c.line.setStyle(Paint.Style.STROKE);
                c.line.setStrokeCap(Paint.Cap.ROUND);
                c.line.setStrokeWidth(Math.max(1.6f * c.dens, lh * 0.075f));
                c.line.setColor(ink);
                c.cv.drawLine(l, y, rr, y, c.line);
            }
        }
    }

    private void paintFor(Ctx c, Paint p) {
        float w = Math.max(c.dens, width * c.S);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w);
        p.setStrokeCap(flat ? Paint.Cap.BUTT : Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        if (marker) {
            if (c.theme == 2) { p.setXfermode(null); p.setColor(alphaOf(fillC(), alpha * 0.45f)); }
            else { p.setXfermode(c.multiply); p.setColor(multColor(fillC(), alpha)); }
        } else {
            p.setXfermode(null);
            p.setColor(alphaOf(inkC(), alpha));
        }
    }

    private void buildPath(Ctx c) {
        Path p = c.path;
        p.reset();
        int n = pts.length / 2;
        p.moveTo(c.left + pts[0] * c.S, c.top + pts[1] * c.S);
        if (n == 2) { p.lineTo(c.left + pts[2] * c.S, c.top + pts[3] * c.S); return; }
        for (int i = 1; i < n - 1; i++) {
            float x = c.left + pts[2 * i] * c.S, y = c.top + pts[2 * i + 1] * c.S;
            float nx = c.left + pts[2 * i + 2] * c.S, ny = c.top + pts[2 * i + 3] * c.S;
            p.quadTo(x, y, (x + nx) / 2f, (y + ny) / 2f);
        }
        p.lineTo(c.left + pts[2 * n - 2] * c.S, c.top + pts[2 * n - 1] * c.S);
    }

    private void drawStroke(Ctx c) {
        if (pts.length < 2) return;
        if (pts.length == 2) {                      // a single tap with the pen: a dot
            c.fill.setXfermode(null);
            c.fill.setStyle(Paint.Style.FILL);
            c.fill.setColor(alphaOf(marker ? fillC() : inkC(), alpha));
            c.cv.drawCircle(c.left + pts[0] * c.S, c.top + pts[1] * c.S, Math.max(c.dens, width * c.S) / 2f, c.fill);
            return;
        }
        buildPath(c);
        paintFor(c, c.line);
        c.cv.drawPath(c.path, c.line);
        c.line.setXfermode(null);
    }

    private void drawBox(Ctx c) {
        if (pts.length < 4) return;
        float x0 = c.left + Math.min(pts[0], pts[2]) * c.S, x1 = c.left + Math.max(pts[0], pts[2]) * c.S;
        float y0 = c.top + Math.min(pts[1], pts[3]) * c.S, y1 = c.top + Math.max(pts[1], pts[3]) * c.S;
        c.r.set(x0, y0, x1, y1);
        if (marker) {
            if (c.theme == 2) { c.fill.setXfermode(null); c.fill.setColor(alphaOf(fillC(), alpha * 0.45f)); }
            else { c.fill.setXfermode(c.multiply); c.fill.setColor(multColor(fillC(), alpha)); }
            c.fill.setStyle(Paint.Style.FILL);
            c.cv.drawRoundRect(c.r, 2f * c.dens, 2f * c.dens, c.fill);
            c.fill.setXfermode(null);
        } else {
            paintFor(c, c.line);
            c.line.setStrokeCap(Paint.Cap.ROUND);
            c.cv.drawRoundRect(c.r, 2f * c.dens, 2f * c.dens, c.line);
        }
    }

    private void drawFlash(Ctx c) {
        int ink = inkC();
        int a = (int) (170f * c.flash);
        c.line.setXfermode(null);
        c.fill.setXfermode(null);
        if (type == TEXT) {
            c.fill.setStyle(Paint.Style.FILL);
            c.fill.setColor((ink & 0x00FFFFFF) | (a << 24));
            for (int r = 0; r + 3 < rects.length; r += 4) {
                c.r.set(c.left + rects[r] * c.k - 3f * c.dens, c.top + rects[r + 1] * c.k, c.left + rects[r + 2] * c.k + 3f * c.dens, c.top + rects[r + 3] * c.k);
                c.cv.drawRoundRect(c.r, 4f * c.dens, 4f * c.dens, c.fill);
            }
        } else if (type == STICKER && pts.length >= 2) {
            float cx = c.left + pts[0] * c.S, cy = c.top + pts[1] * c.S, rr = stkSize() * c.S * 0.5f;
            c.line.setStyle(Paint.Style.STROKE);
            c.line.setStrokeWidth(3f * c.dens);
            c.line.setColor((inkC() & 0x00FFFFFF) | (a << 24));
            c.r.set(cx - rr - 4f * c.dens, cy - rr - 4f * c.dens, cx + rr + 4f * c.dens, cy + rr + 4f * c.dens);
            c.cv.drawRoundRect(c.r, 9f * c.dens, 9f * c.dens, c.line);
        } else if (type == STROKE && pts.length >= 4) {
            buildPath(c);
            c.line.setStyle(Paint.Style.STROKE);
            c.line.setStrokeCap(Paint.Cap.ROUND);
            c.line.setStrokeWidth(Math.max(c.dens, width * c.S) + 6f * c.dens);
            c.line.setColor((ink & 0x00FFFFFF) | (a << 24));
            c.cv.drawPath(c.path, c.line);
        } else if (type == BOX && pts.length >= 4) {
            c.fill.setStyle(Paint.Style.FILL);
            c.fill.setColor((ink & 0x00FFFFFF) | (a << 24));
            c.r.set(c.left + Math.min(pts[0], pts[2]) * c.S - 3f * c.dens, c.top + Math.min(pts[1], pts[3]) * c.S - 3f * c.dens,
                    c.left + Math.max(pts[0], pts[2]) * c.S + 3f * c.dens, c.top + Math.max(pts[1], pts[3]) * c.S + 3f * c.dens);
            c.cv.drawRoundRect(c.r, 4f * c.dens, 4f * c.dens, c.fill);
        }
    }

    /** Centre of the sticker on screen (px). */
    boolean stickerPos(Ctx c, float[] o) {
        if (type != STICKER || pts.length < 2) return false;
        o[0] = c.left + pts[0] * c.S;
        o[1] = c.top + pts[1] * c.S;
        return true;
    }

    private final Path stkBody = new Path(), stkFold = new Path();

    private static int shade(int color, float t) {      // t > 0 darker, t < 0 lighter
        int r = (color >> 16) & 255, g = (color >> 8) & 255, b = color & 255;
        if (t >= 0f) { r = Math.round(r * (1f - t)); g = Math.round(g * (1f - t)); b = Math.round(b * (1f - t)); }
        else { r = Math.round(r + (255 - r) * -t); g = Math.round(g + (255 - g) * -t); b = Math.round(b + (255 - b) * -t); }
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** A sticky note: coloured square, folded corner, a few text lines. Opacity applies to the whole thing. */
    private void drawSticker(Ctx c) {
        if (pts.length < 2) return;
        float cx = c.left + pts[0] * c.S, cy = c.top + pts[1] * c.S;
        float sz = stkSize() * c.S * (lifted ? 1.14f : 1f), h = sz / 2f, d = sz / 30f;
        if (cx < -sz || cy < -sz || cx > c.viewW + sz) return;
        int a = Math.max(13, Math.min(255, Math.round(alpha * 2.55f)));
        int paper = fillC();
        float x0 = cx - h, y0 = cy - h, x1 = cx + h, y1 = cy + h, f = sz * 0.30f;
        c.fill.setXfermode(null);
        c.line.setXfermode(null);
        // soft shadow
        c.fill.setStyle(Paint.Style.FILL);
        for (int i = 3; i >= 1; i--) {
            c.fill.setColor(((int) (a * 0.09f) << 24));
            c.r.set(x0 - i * d, y0 - i * d + 1.6f * d, x1 + i * d, y1 + i * d + 1.6f * d);
            c.cv.drawRoundRect(c.r, 6f * d + i * d, 6f * d + i * d, c.fill);
        }
        // body with the bottom-right corner folded
        stkBody.reset();
        stkBody.moveTo(x0, y0); stkBody.lineTo(x1, y0); stkBody.lineTo(x1, y1 - f); stkBody.lineTo(x1 - f, y1); stkBody.lineTo(x0, y1); stkBody.close();
        c.fill.setPathEffect(new android.graphics.CornerPathEffect(5f * d));
        c.fill.setColor((paper & 0x00FFFFFF) | (a << 24));
        c.cv.drawPath(stkBody, c.fill);
        c.fill.setPathEffect(null);
        c.line.setStyle(Paint.Style.STROKE);
        c.line.setStrokeWidth(1f * d);
        c.line.setColor((shade(paper, 0.28f) & 0x00FFFFFF) | ((a * 3 / 4) << 24));
        c.line.setPathEffect(new android.graphics.CornerPathEffect(5f * d));
        c.cv.drawPath(stkBody, c.line);
        c.line.setPathEffect(null);
        stkFold.reset();
        stkFold.moveTo(x1 - f, y1); stkFold.lineTo(x1, y1 - f); stkFold.lineTo(x1 - f, y1 - f); stkFold.close();
        c.fill.setColor((shade(paper, 0.16f) & 0x00FFFFFF) | (a << 24));
        c.cv.drawPath(stkFold, c.fill);
        // text lines (a real note has them darker)
        boolean has = note != null && !note.isEmpty();
        c.line.setStyle(Paint.Style.STROKE);
        c.line.setStrokeCap(Paint.Cap.ROUND);
        c.line.setStrokeWidth(2f * d);
        c.line.setColor((shade(paper, 0.62f) & 0x00FFFFFF) | (((has ? 200 : 110) * a / 255) << 24));
        float lx0 = x0 + 6f * d, lx1 = x1 - 6f * d;
        c.cv.drawLine(lx0, y0 + 9f * d, lx1, y0 + 9f * d, c.line);
        c.cv.drawLine(lx0, y0 + 15f * d, lx1 - 2f * d, y0 + 15f * d, c.line);
        c.cv.drawLine(lx0, y0 + 21f * d, x1 - f - 3f * d, y0 + 21f * d, c.line);
        c.line.setStrokeCap(Paint.Cap.BUTT);
    }
}
