// Backup & restore of everything the reader keeps only on this phone:
// favourites, history, progress, bookmarks, reading positions and highlights.
// Restoring MERGES into the current data; it never deletes or replaces anything.
import { exportUserData, importUserData } from "../utils/storage.js";
import { exportReaderData, importReaderData } from "./reader-prefs.js";
import { escapeHTML } from "../utils/helpers.js";

const APP = "maktabah";
const SCHEMA = 1;
const MAX_CHARS = 20 * 1024 * 1024;

export async function buildBackup() {
  return { app: APP, schema: SCHEMA, exportedAt: new Date().toISOString(), ...exportUserData(), reader: await exportReaderData() };
}

function fileName() {
  return `maktabah-backup-${new Date().toISOString().slice(0, 10)}.json`;
}

const isNativeApp = () => Boolean(window.Capacitor?.isNativePlatform?.() || window.Capacitor?.getPlatform?.() === "android");

async function copyText(text) {
  try {
    if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(text); return true; }
  } catch { /* fall through */ }
  try {
    const ta = document.createElement("textarea");
    ta.value = text; ta.setAttribute("readonly", ""); ta.style.cssText = "position:fixed;opacity:0;top:0;left:0";
    document.body.appendChild(ta); ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch { return false; }
}

/** Resolves "shared" | "downloaded" | "copied" | "cancelled" | "failed". */
export async function saveBackup() {
  let json;
  try { json = JSON.stringify(await buildBackup()); } catch { return "failed"; }
  const name = fileName();
  try {
    const file = new File([json], name, { type: "application/json" });
    if (navigator.canShare?.({ files: [file] })) {
      try { await navigator.share({ files: [file], title: "Maktabah backup" }); return "shared"; }
      catch (e) { if (e && e.name === "AbortError") return "cancelled"; }
    }
  } catch { /* File constructor unavailable */ }
  // A blob download does nothing inside the Android WebView, so there the backup text is copied instead.
  if (!isNativeApp()) {
    try {
      const url = URL.createObjectURL(new Blob([json], { type: "application/json" }));
      const a = document.createElement("a");
      a.href = url; a.download = name; a.rel = "noopener"; a.style.display = "none";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 30000);
      return "downloaded";
    } catch { /* fall through to copy */ }
  }
  return (await copyText(json)) ? "copied" : "failed";
}

/** { ok:true, data } or { ok:false, reason: "empty" | "size" | "format" | "newer" }. */
export function parseBackup(text) {
  const raw = String(text || "").trim();
  if (!raw) return { ok: false, reason: "empty" };
  if (raw.length > MAX_CHARS) return { ok: false, reason: "size" };
  let data;
  try { data = JSON.parse(raw); } catch { return { ok: false, reason: "format" }; }
  if (!data || typeof data !== "object" || data.app !== APP || !Number.isInteger(data.schema)) return { ok: false, reason: "format" };
  if (data.schema > SCHEMA) return { ok: false, reason: "newer" };
  return { ok: true, data };
}

export async function restoreBackup(data) {
  const a = importUserData(data);
  const b = await importReaderData(data.reader && typeof data.reader === "object" ? data.reader : {});
  return { ...a, ...b };
}

const REASONS = {
  ur: { empty: "پہلے بیک اپ فائل چنیں یا اس کا متن چسپاں کریں۔", size: "بیک اپ بہت بڑا ہے۔", format: "یہ مکتبہ کا بیک اپ نہیں لگتا۔ پوری فائل یا پورا متن چنیں۔", newer: "یہ بیک اپ ایپ کے نئے ورژن سے بنا ہے۔ پہلے ایپ اپڈیٹ کریں۔" },
  en: { empty: "Choose a backup file or paste its text first.", size: "This backup is too large.", format: "This does not look like a Maktabah backup. Use the whole file or the whole text.", newer: "This backup was made by a newer version of the app. Update the app first." }
};

export function describeRestore(r, ur) {
  const parts = [];
  if (r.favorites) parts.push(ur ? `${r.favorites} پسندیدہ` : `${r.favorites} favorites`);
  if (r.progress) parts.push(ur ? `${r.progress} کتب کی پیش رفت` : `${r.progress} reading progress`);
  if (r.history) parts.push(ur ? `${r.history} حالیہ` : `${r.history} recent`);
  if (r.marks) parts.push(ur ? `${r.marks} بک مارک` : `${r.marks} bookmarks`);
  if (r.highlights) parts.push(ur ? `${r.highlights} ہائی لائٹ` : `${r.highlights} highlights`);
  if (!parts.length) return ur ? "کچھ نیا شامل نہیں ہوا؛ یہ سب پہلے سے موجود ہے۔" : "Nothing new to add; you already have everything in this backup.";
  return (ur ? "بحال ہوا: " : "Restored: ") + parts.join(ur ? "، " : ", ") + (ur ? "۔" : ".");
}

/** Modal with a file picker and a paste box. Errors show inline; success closes it and calls onDone(message). */
export function openRestoreDialog({ ur, onDone }) {
  const T = ur
    ? { title: "بیک اپ بحال کریں", hint: "بیک اپ فائل چنیں یا اس کا متن یہاں چسپاں کریں۔ موجودہ ڈیٹا نہیں ہٹے گا، بیک اپ کا ڈیٹا اس میں شامل ہوگا۔", pick: "فائل چنیں", ph: "یا یہاں متن چسپاں کریں", cancel: "منسوخ", go: "بحال کریں", read: "فائل نہیں پڑھی جا سکی۔" }
    : { title: "Restore backup", hint: "Choose a backup file or paste its text here. Your current data stays; the backup is added to it.", pick: "Choose file", ph: "Or paste the backup text here", cancel: "Cancel", go: "Restore", read: "Could not read that file." };
  const reasons = ur ? REASONS.ur : REASONS.en;

  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  backdrop.innerHTML = `<section class="modal modal-restore" role="dialog" aria-modal="true" aria-labelledby="restoreTitle">
    <h2 id="restoreTitle">${escapeHTML(T.title)}</h2>
    <p>${escapeHTML(T.hint)}</p>
    <input type="file" accept=".json,application/json" hidden id="restoreFile">
    <button type="button" class="btn modal-pick" id="restorePick">${escapeHTML(T.pick)}</button>
    <textarea class="modal-field" id="restoreText" rows="5" dir="ltr" spellcheck="false" autocomplete="off" aria-label="${escapeHTML(T.title)}" placeholder="${escapeHTML(T.ph)}"></textarea>
    <p class="modal-msg" id="restoreMsg" role="alert" hidden></p>
    <div class="modal-actions"><button type="button" class="btn" id="restoreCancel">${escapeHTML(T.cancel)}</button><button type="button" class="btn primary" id="restoreGo">${escapeHTML(T.go)}</button></div>
  </section>`;
  document.body.appendChild(backdrop);

  const $ = s => backdrop.querySelector(s);
  const text = $("#restoreText"), msg = $("#restoreMsg"), go = $("#restoreGo"), fileInput = $("#restoreFile");
  const showMsg = m => { msg.textContent = m; msg.hidden = !m; };
  const onKey = e => { if (!backdrop.isConnected) { document.removeEventListener("keydown", onKey); return; } if (e.key === "Escape") close(); };
  const close = () => { document.removeEventListener("keydown", onKey); backdrop.remove(); };

  $("#restoreCancel").onclick = close;
  backdrop.addEventListener("click", e => { if (e.target === backdrop && !text.value.trim()) close(); });
  document.addEventListener("keydown", onKey);
  $("#restorePick").onclick = () => fileInput.click();
  text.addEventListener("input", () => showMsg(""));

  fileInput.addEventListener("change", async () => {
    const file = fileInput.files && fileInput.files[0];
    fileInput.value = "";
    if (!file) return;
    if (file.size > MAX_CHARS) { showMsg(reasons.size); return; }
    try { text.value = await file.text(); showMsg(""); } catch { showMsg(T.read); }
  });

  go.onclick = async () => {
    const parsed = parseBackup(text.value);
    if (!parsed.ok) { showMsg(reasons[parsed.reason] || reasons.format); text.focus(); return; }
    go.disabled = true;
    try {
      const result = await restoreBackup(parsed.data);
      close();
      onDone?.(describeRestore(result, ur));
    } catch {
      go.disabled = false;
      showMsg(reasons.format);
    }
  };
  text.focus();
}
