package com.maktabah.kaif;

import android.app.AlertDialog;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.app.DownloadManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Reads up to four books at once: split panes (stacked / side by side), draggable dividers, a tab strip to switch or maximise. */
public class MuMultiActivity extends Activity {
    static final int MAX = 4;

    private float density;
    private JSONObject cat;
    private boolean ur;
    private int theme;
    private float dim;
    private int bg, barBg, fg, sub, accent, sheetBg, chipBg, line;

    private FrameLayout root;
    private LinearLayout col, tabRow;
    private HorizontalScrollView tabScroll;
    private TextView titleTv;
    private IconV layoutBtn, addBtn, backBtn;
    private PaneArea area;
    private final ArrayList<Pane> panes = new ArrayList<>();
    private int focus = 0, maxIdx = -1, mode = -1;
    private float r1 = .5f, r2 = .5f;
    private Dialog picker;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private int dp(float v) { return Math.round(v * density); }

    // ------------------------------------------------------------------ strings
    private String s(String k) {
        String[] v = STR.get(k);
        if (v == null) return k;
        return ur ? v[1] : v[0];
    }

    private static final java.util.HashMap<String, String[]> STR = new java.util.HashMap<>();
    static {
        STR.put("title", new String[]{"Multi window", "ملٹی ونڈو"});
        STR.put("add", new String[]{"Add book", "کتاب شامل کریں"});
        STR.put("choose", new String[]{"Choose books", "کتابیں منتخب کریں"});
        STR.put("search", new String[]{"Search…", "تلاش کریں…"});
        STR.put("open", new String[]{"Open", "کھولیں"});
        STR.put("cancel", new String[]{"Cancel", "منسوخ"});
        STR.put("no_books", new String[]{"No offline books yet. Download a book first.", "ابھی کوئی آف لائن کتاب نہیں۔ پہلے کوئی کتاب ڈاؤنلوڈ کریں۔"});
        STR.put("max", new String[]{"Up to 4 books at once", "ایک وقت میں زیادہ سے زیادہ 4 کتابیں"});
        STR.put("dup", new String[]{"Already open", "یہ کتاب پہلے سے کھلی ہے"});
        STR.put("maximize", new String[]{"Maximise", "بڑا کریں"});
        STR.put("restore", new String[]{"Back to split", "تقسیم پر واپس"});
        STR.put("earlier", new String[]{"Move earlier", "پہلے لائیں"});
        STR.put("later", new String[]{"Move later", "بعد میں لے جائیں"});
        STR.put("close", new String[]{"Close book", "کتاب بند کریں"});
        STR.put("side", new String[]{"Side by side", "برابر برابر"});
        STR.put("stack", new String[]{"Stacked", "اوپر نیچے"});
        STR.put("layout", new String[]{"Change layout", "ترتیب بدلیں"});
        STR.put("back", new String[]{"Back", "واپس"});
        STR.put("failed", new String[]{"Could not open this book", "یہ کتاب نہیں کھل سکی"});
        STR.put("missing", new String[]{"File not found: ", "فائل نہیں ملی: "});
        STR.put("pw", new String[]{"This PDF is password protected", "یہ PDF پاس ورڈ سے محفوظ ہے"});
        STR.put("pw_wrong", new String[]{"Wrong password, try again", "پاس ورڈ غلط ہے، دوبارہ کوشش کریں"});
        STR.put("ok", new String[]{"OK", "ٹھیک ہے"});
        STR.put("copy", new String[]{"Copy", "کاپی"});
        STR.put("copied", new String[]{"Copied", "کاپی ہوگیا"});
        STR.put("selected", new String[]{"selected", "منتخب"});
    }

    // ------------------------------------------------------------------ life cycle
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        density = getResources().getDisplayMetrics().density;
        cat = MuMultiStore.catalog(this);
        ur = "ur".equals(cat.optString("lang", "ur"));
        String th = cat.optString("theme", "paper");
        theme = "night".equals(th) ? 2 : "sepia".equals(th) ? 1 : 0;
        dim = (float) cat.optDouble("dim", 0);
        if (cat.optBoolean("keepAwake", false)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        look();
        buildUi();

        Intent in = getIntent();
        String start = in != null ? in.getStringExtra("start") : null;
        if (!"new".equals(start)) restoreSession();
        handleIntent(in);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        cat = MuMultiStore.catalog(this);
        handleIntent(intent);
    }

    private void handleIntent(Intent in) {
        String start = in != null ? in.getStringExtra("start") : null;
        if (start == null) start = "resume";
        if ("new".equals(start)) {
            closeAll();
            mode = -1; r1 = .5f; r2 = .5f;
            showPicker();
        } else if ("add".equals(start) && in != null && in.getStringExtra("addPath") != null) {
            addPane(in.getStringExtra("addPath"), in.getStringExtra("addTitle"), in.getStringExtra("addKey"),
                    in.getIntExtra("addPage", 1), in.getFloatExtra("addFrac", 0f));
            if (panes.size() < 2) showPicker();
        } else if (panes.isEmpty()) {
            showPicker();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveAll();
    }

    @Override
    protected void onDestroy() {
        try { if (picker != null && picker.isShowing()) picker.dismiss(); } catch (Throwable ignored) { }
        for (Pane p : panes) p.view.destroy();
        panes.clear();
        io.shutdown();
        super.onDestroy();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        for (Pane p : panes) p.view.trimMemory(level);
    }

    @Override
    public void onBackPressed() {
        if (maxIdx >= 0) { setMax(-1); return; }
        finish();
    }

    // ------------------------------------------------------------------ session
    private void restoreSession() {
        JSONObject s = MuMultiStore.session(this);
        mode = s.optInt("mode", -1);
        r1 = clampRatio((float) s.optDouble("r1", .5));
        r2 = clampRatio((float) s.optDouble("r2", .5));
        JSONArray a = s.optJSONArray("panes");
        if (a == null) return;
        for (int i = 0; i < a.length() && panes.size() < MAX; i++) {
            JSONObject p = a.optJSONObject(i);
            if (p == null) continue;
            String path = p.optString("path", "");
            if (path.isEmpty() || !new File(path).isFile()) continue;
            createPane(path, p.optString("title", "PDF"), p.optString("key", ""), p.optInt("page", 1), (float) p.optDouble("frac", 0));
        }
        focus = Math.max(0, Math.min(panes.size() - 1, s.optInt("focus", 0)));
        refreshAll();
    }

    private void saveAll() {
        try {
            JSONObject s = new JSONObject();
            JSONArray a = new JSONArray();
            for (Pane p : panes) {
                p.sync();
                JSONObject o = new JSONObject();
                o.put("path", p.path); o.put("title", p.title); o.put("key", p.key);
                o.put("page", p.page); o.put("frac", p.frac); o.put("total", p.total);
                a.put(o);
                if (p.opened) MuMultiStore.putProgress(this, p.key, p.page, p.frac, p.total);
            }
            s.put("panes", a); s.put("mode", mode); s.put("r1", r1); s.put("r2", r2); s.put("focus", focus);
            MuMultiStore.saveSession(this, s);
            KRMultiWidget.refresh(this);
        } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------------ look
    private void look() {
        if (theme == 2) { bg = 0xFF101512; barBg = 0xFF151B17; fg = 0xFFE6ECE8; sub = 0xFF9AA8A0; accent = 0xFF55B88B; sheetBg = 0xFF171D19; chipBg = 0xFF232B26; line = 0xFF2A332D; }
        else if (theme == 1) { bg = 0xFFE9DFC8; barBg = 0xFFEFE6D2; fg = 0xFF2B2418; sub = 0xFF7A6D55; accent = 0xFF176B4D; sheetBg = 0xFFF4ECD8; chipBg = 0xFFE7DCC2; line = 0xFFD2C6A8; }
        else { bg = 0xFFE9EBE7; barBg = 0xFFF7F7F5; fg = 0xFF1C2420; sub = 0xFF6B7770; accent = 0xFF176B4D; sheetBg = 0xFFFFFFFF; chipBg = 0xFFEDEDE8; line = 0xFFD5D9D3; }
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView text(String t, float sp, boolean bold, int color) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return v;
    }

    private void toast(String m) { try { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { } }

    // ------------------------------------------------------------------ UI
    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(bg);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(barBg);
        top.setPadding(dp(4), 0, dp(6), 0);
        backBtn = new IconV(this, IconV.BACK, fg);
        backBtn.setContentDescription(s("back"));
        backBtn.setOnClickListener(v -> onBackPressed());
        top.addView(backBtn, new LinearLayout.LayoutParams(dp(44), dp(46)));
        titleTv = text(s("title"), 16f, true, fg);
        titleTv.setSingleLine(true);
        titleTv.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(titleTv, new LinearLayout.LayoutParams(0, -2, 1f));
        layoutBtn = new IconV(this, IconV.LAYOUT_STACK, fg);
        layoutBtn.setContentDescription(s("layout"));
        layoutBtn.setOnClickListener(v -> toggleLayout());
        top.addView(layoutBtn, new LinearLayout.LayoutParams(dp(44), dp(46)));
        addBtn = new IconV(this, IconV.PLUS, accent);
        addBtn.setContentDescription(s("add"));
        addBtn.setOnClickListener(v -> showPicker());
        top.addView(addBtn, new LinearLayout.LayoutParams(dp(44), dp(46)));
        col.addView(top, new LinearLayout.LayoutParams(-1, dp(46)));

        tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabScroll.setBackgroundColor(barBg);
        tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(dp(8), dp(2), dp(8), dp(8));
        tabScroll.addView(tabRow, new ViewGroup.LayoutParams(-2, -2));
        col.addView(tabScroll, new LinearLayout.LayoutParams(-1, -2));

        area = new PaneArea(this);
        col.addView(area, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets sb = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            col.setPadding(sb.left, sb.top, sb.right, sb.bottom);
            return insets;
        });
        Window w = getWindow();
        w.setBackgroundDrawable(new ColorDrawable(bg));
        try { w.setStatusBarColor(barBg); w.setNavigationBarColor(bg); } catch (Throwable ignored) { }
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
        if (c != null) { c.setAppearanceLightStatusBars(theme != 2); c.setAppearanceLightNavigationBars(theme != 2); }
        refreshAll();
    }

    private boolean effectiveSide() {
        if (mode == 0) return false;
        if (mode == 1) return true;
        return area.getWidth() > area.getHeight() && area.getWidth() > 0;
    }

    private void toggleLayout() {
        boolean side = effectiveSide();
        mode = side ? 0 : 1;
        toast(s(side ? "stack" : "side"));
        refreshAll();
        area.requestLayout();
    }

    /** Titles, tab strip, layout icon and the order of the panes. */
    private void refreshAll() {
        int n = panes.size();
        titleTv.setText(s("title") + (n > 0 ? "  ·  " + n + "/" + MAX : ""));
        layoutBtn.setVisibility(n >= 2 ? View.VISIBLE : View.GONE);
        layoutBtn.setType(effectiveSide() ? IconV.LAYOUT_SIDE : IconV.LAYOUT_STACK);
        addBtn.setAlpha(n >= MAX ? .35f : 1f);
        area.setOrder(panes);
        for (int i = 0; i < n; i++) {
            Pane p = panes.get(i);
            p.box.setVisibility(maxIdx < 0 || maxIdx == i ? View.VISIBLE : View.GONE);
            p.view.limitMemory(Math.max(2, n));
            p.styleBorder(i == focus);
        }
        tabRow.removeAllViews();
        tabScroll.setVisibility(n >= 2 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < n; i++) {
            final int idx = i;
            boolean on = maxIdx >= 0 ? maxIdx == i : focus == i;
            TextView chip = text((i + 1) + "  " + panes.get(i).title, 12.5f, true, on ? 0xFFFFFFFF : fg);
            chip.setSingleLine(true);
            chip.setEllipsize(TextUtils.TruncateAt.END);
            chip.setMaxWidth(dp(170));
            chip.setPadding(dp(12), dp(7), dp(12), dp(7));
            chip.setBackground(round(on ? accent : chipBg, 16));
            chip.setOnClickListener(v -> {
                if (maxIdx >= 0) setMax(idx);
                setFocus(idx);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMarginEnd(dp(6));
            tabRow.addView(chip, lp);
        }
        area.requestLayout();
    }

    private void setFocus(int i) {
        if (i < 0 || i >= panes.size() || focus == i) return;
        focus = i;
        for (int k = 0; k < panes.size(); k++) panes.get(k).styleBorder(k == focus);
        refreshAll();
    }

    private void setMax(int i) {
        maxIdx = i;
        if (i >= 0) focus = i;
        refreshAll();
    }

    // ------------------------------------------------------------------ panes
    private void addPane(String path, String title, String key, int page, float frac) {
        if (path == null) return;
        for (int i = 0; i < panes.size(); i++) {
            if (path.equals(panes.get(i).path)) { toast(s("dup")); setFocus(i); return; }
        }
        if (panes.size() >= MAX) { toast(s("max")); return; }
        createPane(path, title == null || title.isEmpty() ? "PDF" : title, key == null ? "" : key, page, frac);
        focus = panes.size() - 1;
        if (maxIdx >= 0) maxIdx = -1;
        refreshAll();
        saveAll();
    }

    private void createPane(String path, String title, String key, int page, float frac) {
        Pane p = new Pane(path, title, key, page, frac);
        panes.add(p);
        area.addView(p.box);
        p.start(null);
    }

    private void closePane(Pane p) {
        int i = panes.indexOf(p);
        if (i < 0) return;
        p.sync();
        if (p.opened) MuMultiStore.putProgress(this, p.key, p.page, p.frac, p.total);
        panes.remove(i);
        area.removeView(p.box);
        p.view.destroy();
        if (maxIdx >= 0) maxIdx = -1;
        focus = Math.max(0, Math.min(focus, panes.size() - 1));
        refreshAll();
        saveAll();
        if (panes.isEmpty()) showPicker();
    }

    private void closeAll() {
        for (Pane p : panes) {
            p.sync();
            if (p.opened) MuMultiStore.putProgress(this, p.key, p.page, p.frac, p.total);
            area.removeView(p.box);
            p.view.destroy();
        }
        panes.clear();
        maxIdx = -1; focus = 0;
        refreshAll();
    }

    private void movePane(Pane p, int delta) {
        int i = panes.indexOf(p), j = i + delta;
        if (i < 0 || j < 0 || j >= panes.size()) return;
        Collections.swap(panes, i, j);
        if (focus == i) focus = j; else if (focus == j) focus = i;
        refreshAll();
        saveAll();
    }

    /** One book: a slim header (title, page, menu, close) over a MuPDF view. */
    private final class Pane implements MuPdfView.Host {
        String path, title, key;
        int page, total;
        float frac;
        boolean opened;
        LinearLayout box;
        TextView titleV, pageV, msg, copyChip;
        IconV menuBtn, closeBtn;
        MuPdfView view;
        FrameLayout holder;

        Pane(String path, String title, String key, int page, float frac) {
            this.path = path; this.title = title; this.key = key;
            this.page = Math.max(1, page); this.frac = frac;
            box = new LinearLayout(MuMultiActivity.this);
            box.setOrientation(LinearLayout.VERTICAL);
            int bw = dp(2);
            box.setPadding(bw, bw, bw, bw);

            LinearLayout head = new LinearLayout(MuMultiActivity.this);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.setBackgroundColor(barBg);
            head.setPadding(dp(8), 0, dp(2), 0);
            titleV = text(title, 12.5f, true, fg);
            titleV.setSingleLine(true);
            titleV.setEllipsize(TextUtils.TruncateAt.END);
            head.addView(titleV, new LinearLayout.LayoutParams(0, -2, 1f));
            pageV = text("", 11f, false, sub);
            pageV.setSingleLine(true);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-2, -2);
            plp.setMarginStart(dp(6));
            head.addView(pageV, plp);
            menuBtn = new IconV(MuMultiActivity.this, IconV.MORE, sub);
            menuBtn.setOnClickListener(v -> showMenu());
            head.addView(menuBtn, new LinearLayout.LayoutParams(dp(34), dp(34)));
            closeBtn = new IconV(MuMultiActivity.this, IconV.CLOSE, sub);
            closeBtn.setContentDescription(s("close"));
            closeBtn.setOnClickListener(v -> closePane(this));
            head.addView(closeBtn, new LinearLayout.LayoutParams(dp(34), dp(34)));
            head.setOnClickListener(v -> setFocus(panes.indexOf(this)));
            box.addView(head, new LinearLayout.LayoutParams(-1, dp(34)));

            holder = new FrameLayout(MuMultiActivity.this);
            view = new MuPdfView(MuMultiActivity.this);
            view.setHost(this);
            view.setLook(theme, dim);
            view.setOnTouchListener((v, ev) -> {
                if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) setFocus(panes.indexOf(this));
                return false;
            });
            holder.addView(view, new FrameLayout.LayoutParams(-1, -1));
            msg = text("", 13f, false, sub);
            msg.setGravity(Gravity.CENTER);
            msg.setPadding(dp(16), dp(16), dp(16), dp(16));
            msg.setVisibility(View.GONE);
            holder.addView(msg, new FrameLayout.LayoutParams(-1, -1));
            copyChip = text(s("copy"), 13f, true, 0xFFFFFFFF);
            copyChip.setPadding(dp(14), dp(8), dp(14), dp(8));
            copyChip.setBackground(round(0xE6222B26, 14));
            copyChip.setVisibility(View.GONE);
            copyChip.setOnClickListener(v -> {
                try {
                    String t = view.selectionText();
                    if (t != null && !t.isEmpty()) {
                        ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("text", t));
                        toast(s("copied"));
                    }
                } catch (Throwable ignored) { }
                view.clearSelection();
                copyChip.setVisibility(View.GONE);
            });
            holder.addView(copyChip, new FrameLayout.LayoutParams(-2, -2));
            box.addView(holder, new LinearLayout.LayoutParams(-1, 0, 1f));
            styleBorder(false);
            updatePage();
        }

        void start(String password) {
            final int p0 = Math.max(0, page - 1);
            view.post(() -> view.open(path, password, p0, frac));
        }

        void styleBorder(boolean focused) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(bg);
            g.setCornerRadius(dp(6));
            g.setStroke(dp(focused ? 2 : 1), focused ? accent : line);
            box.setBackground(g);
        }

        void sync() {
            if (opened && view != null) {
                try { page = view.currentPage0() + 1; frac = view.currentFrac(); total = view.pageCount() > 0 ? view.pageCount() : total; } catch (Throwable ignored) { }
            }
        }

        void updatePage() {
            pageV.setText(opened && total > 0 ? page + " / " + total : "");
        }

        void showMenu() {
            PopupMenu m = new PopupMenu(MuMultiActivity.this, menuBtn);
            int i = panes.indexOf(this);
            m.getMenu().add(0, 1, 0, s(maxIdx == i ? "restore" : "maximize"));
            if (i > 0) m.getMenu().add(0, 2, 1, s("earlier"));
            if (i < panes.size() - 1) m.getMenu().add(0, 3, 2, s("later"));
            m.getMenu().add(0, 4, 3, s("close"));
            m.setOnMenuItemClickListener(it -> {
                switch (it.getItemId()) {
                    case 1: setMax(maxIdx == panes.indexOf(this) ? -1 : panes.indexOf(this)); break;
                    case 2: movePane(this, -1); break;
                    case 3: movePane(this, 1); break;
                    default: closePane(this); break;
                }
                return true;
            });
            m.show();
        }

        void showMsg(String t) {
            msg.setText(t);
            msg.setVisibility(View.VISIBLE);
        }

        // ---- MuPdfView.Host
        @Override public void onOpened(int pageCount, boolean hasOutline) { opened = true; total = pageCount; msg.setVisibility(View.GONE); updatePage(); }
        @Override public void onOpenFailed(String message) { opened = false; showMsg(s("failed")); }
        @Override public void onNeedPassword(boolean wrongBefore) { askPassword(this, wrongBefore); }
        @Override public void onPageChanged(int page0, int t) { page = page0 + 1; total = t; opened = true; updatePage(); }
        @Override public void onTap() { setFocus(panes.indexOf(this)); }
        @Override public void onUserScroll() { }
        @Override public void onExternalLink(String uri) {
            try {
                if (uri != null && (uri.startsWith("http://") || uri.startsWith("https://"))) startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(uri)));
            } catch (Throwable ignored) { }
        }
        @Override public void onOutline(java.util.List<MuPdfView.OutlineItem> items) { }
        @Override public void onSelectionStart() { copyChip.setVisibility(View.GONE); }
        @Override public void onSelectionMenu(RectF anchor) {
            if (anchor == null) { copyChip.setVisibility(View.GONE); return; }
            int w = dp(84), h = dp(38);
            int x = Math.round(anchor.centerX() - w / 2f);
            int y = Math.round(anchor.top - h - dp(10));
            if (y < dp(4)) y = Math.round(anchor.bottom + dp(14));
            x = Math.max(dp(4), Math.min(Math.max(dp(4), holder.getWidth() - w - dp(4)), x));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
            lp.leftMargin = x; lp.topMargin = Math.max(dp(4), y);
            copyChip.setLayoutParams(lp);
            copyChip.setVisibility(View.VISIBLE);
        }
        @Override public void onSelectionEnd() { copyChip.setVisibility(View.GONE); }
        @Override public void onHighlightTap(MuAnnot h, RectF anchor) { }
        @Override public void onStickerTap(MuAnnot st, RectF anchor) { }
        @Override public void onStickerDragStart() { }
        @Override public void onNotice(int code) { }
    }

    private void askPassword(final Pane p, boolean wrong) {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        et.setSingleLine(true);
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(p.title)
                .setMessage(s(wrong ? "pw_wrong" : "pw"))
                .setView(et)
                .setCancelable(false)
                .setPositiveButton(s("ok"), (x, w) -> p.start(et.getText().toString()))
                .setNegativeButton(s("cancel"), (x, w) -> closePane(p))
                .create();
        d.show();
    }

    // ------------------------------------------------------------------ book picker
    private String resolvePath(JSONObject it) {
        try {
            String p = it.optString("p", "");
            if (!p.isEmpty()) { File f = new File(p); return f.isFile() ? f.getAbsolutePath() : null; }
            long id = it.optLong("id", -1);
            if (id < 0) return null;
            File f;
            if (KRDownloadEngine.isOwn(id)) f = KRDownloadEngine.publicFile(this, id);
            else f = legacyFile(id);
            return f != null ? f.getAbsolutePath() : null;
        } catch (Throwable e) {
            return null;
        }
    }

    private File legacyFile(long id) {
        Cursor c = null;
        try {
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            c = dm.query(new DownloadManager.Query().setFilterById(id));
            if (c != null && c.moveToFirst()
                    && c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL) {
                String p = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_FILENAME));
                if (p != null && !p.isEmpty()) {
                    File f = new File(p);
                    if (f.isFile() && f.length() > 0) {
                        try (FileInputStream probe = new FileInputStream(f)) { if (probe.read() >= 0) return f; }
                    }
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) c.close();
        }
        return null;
    }

    private void showPicker() {
        if (picker != null && picker.isShowing()) return;
        final int room = MAX - panes.size();
        if (room <= 0) { toast(s("max")); return; }
        JSONArray arr = cat.optJSONArray("items");
        if (arr == null || arr.length() == 0) {
            toast(s("no_books"));
            if (panes.isEmpty()) finish();
            return;
        }
        final ArrayList<JSONObject> all = new ArrayList<>();
        final LinkedHashSet<String> open = new LinkedHashSet<>();
        for (Pane p : panes) open.add(p.key);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && !open.contains(o.optString("k", ""))) all.add(o);
        }
        final ArrayList<JSONObject> shown = new ArrayList<>(all);
        final LinkedHashSet<String> picked = new LinkedHashSet<>();
        final boolean[] opening = {false};

        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable sbg = new GradientDrawable();
        sbg.setColor(sheetBg);
        float rr = dp(22);
        sbg.setCornerRadii(new float[]{rr, rr, rr, rr, 0, 0, 0, 0});
        sheet.setBackground(sbg);
        sheet.setPadding(dp(16), dp(14), dp(16), dp(12));

        final TextView head = text(s("choose"), 17f, true, fg);
        sheet.addView(head, new LinearLayout.LayoutParams(-1, -2));
        final EditText q = new EditText(this);
        q.setHint(s("search"));
        q.setHintTextColor(sub);
        q.setTextColor(fg);
        q.setTextSize(14f);
        q.setSingleLine(true);
        q.setPadding(dp(14), dp(10), dp(14), dp(10));
        q.setBackground(round(chipBg, 14));
        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(-1, -2);
        qlp.topMargin = dp(10); qlp.bottomMargin = dp(8);
        sheet.addView(q, qlp);

        final ListView list = new ListView(this);
        list.setDivider(null);
        list.setSelector(new ColorDrawable(Color.TRANSPARENT));
        final Button2 openBtn = new Button2(this, s("open"), true);
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View cv, ViewGroup parent) {
                JSONObject o = shown.get(i);
                LinearLayout row = new LinearLayout(MuMultiActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(10), dp(12), dp(10));
                boolean on = picked.contains(o.optString("k", ""));
                row.setBackground(round(on ? ((accent & 0x00FFFFFF) | 0x26000000) : Color.TRANSPARENT, 12));
                LinearLayout tx = new LinearLayout(MuMultiActivity.this);
                tx.setOrientation(LinearLayout.VERTICAL);
                TextView t = text(o.optString("t", "PDF"), 14.5f, true, fg);
                t.setMaxLines(2);
                t.setEllipsize(TextUtils.TruncateAt.END);
                tx.addView(t);
                String a = o.optString("a", "");
                if (!a.isEmpty()) {
                    TextView at = text(a, 12f, false, sub);
                    at.setSingleLine(true);
                    at.setEllipsize(TextUtils.TruncateAt.END);
                    tx.addView(at);
                }
                row.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
                if (on) row.addView(text("✓", 17f, true, accent));
                return row;
            }
        };
        list.setAdapter(ad);
        final Runnable upd = () -> {
            openBtn.set(s("open") + (picked.isEmpty() ? "" : " (" + picked.size() + ")"));
            openBtn.setAlpha(picked.isEmpty() ? .45f : 1f);
            head.setText(s("choose") + "  ·  " + picked.size() + "/" + room + " " + s("selected"));
        };
        upd.run();
        list.setOnItemClickListener((pa, v, pos, id) -> {
            String k = shown.get(pos).optString("k", "");
            if (picked.contains(k)) picked.remove(k);
            else if (picked.size() >= room) { toast(s("max")); return; }
            else picked.add(k);
            ad.notifyDataSetChanged();
            upd.run();
        });
        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int n) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int n) { }
            @Override public void afterTextChanged(Editable e) {
                String f = e.toString().trim().toLowerCase(Locale.ROOT);
                shown.clear();
                for (JSONObject o : all) {
                    if (f.isEmpty() || (o.optString("t", "") + " " + o.optString("a", "")).toLowerCase(Locale.ROOT).contains(f)) shown.add(o);
                }
                ad.notifyDataSetChanged();
            }
        });
        sheet.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        Button2 cancel = new Button2(this, s("cancel"), false);
        cancel.setOnClickListener(v -> d.dismiss());
        LinearLayout.LayoutParams c1 = new LinearLayout.LayoutParams(0, dp(46), 1f);
        c1.setMarginEnd(dp(8));
        btns.addView(cancel, c1);
        openBtn.setOnClickListener(v -> {
            if (picked.isEmpty()) return;
            final ArrayList<JSONObject> chosen = new ArrayList<>();
            for (JSONObject o : all) if (picked.contains(o.optString("k", ""))) chosen.add(o);
            opening[0] = true;
            d.dismiss();
            io.execute(() -> {
                final ArrayList<String[]> ok = new ArrayList<>();
                final ArrayList<JSONObject> items = new ArrayList<>();
                final ArrayList<String> missing = new ArrayList<>();
                for (JSONObject o : chosen) {
                    String path = resolvePath(o);
                    if (path == null) missing.add(o.optString("t", "PDF"));
                    else { ok.add(new String[]{path}); items.add(o); }
                }
                runOnUiThread(() -> {
                    for (int i = 0; i < items.size(); i++) {
                        JSONObject o = items.get(i);
                        addPane(ok.get(i)[0], o.optString("t", "PDF"), o.optString("k", ""), o.optInt("pg", 1), (float) o.optDouble("fr", 0));
                    }
                    for (String m : missing) toast(s("missing") + m);
                    if (panes.isEmpty()) finish();
                });
            });
        });
        btns.addView(openBtn, new LinearLayout.LayoutParams(0, dp(46), 1.4f));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
        blp.topMargin = dp(10);
        sheet.addView(btns, blp);

        d.setContentView(sheet);
        d.setOnDismissListener(x -> { if (!opening[0] && panes.isEmpty() && !isFinishing()) finish(); });
        picker = d;
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int h = (int) (getResources().getDisplayMetrics().heightPixels * 0.84f);
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, h);
            w.setGravity(Gravity.BOTTOM);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        d.show();
    }

    /** Rounded text button. */
    private final class Button2 extends TextView {
        Button2(Context c, String label, boolean primary) {
            super(c);
            setText(label);
            setGravity(Gravity.CENTER);
            setTextSize(14.5f);
            setTypeface(Typeface.DEFAULT_BOLD);
            setTextColor(primary ? (theme == 2 ? 0xFF0B1410 : 0xFFFFFFFF) : fg);
            setBackground(round(primary ? accent : chipBg, 16));
            setSingleLine(true);
        }
        void set(String t) { setText(t); }
    }

    // ------------------------------------------------------------------ split container
    private final class PaneArea extends ViewGroup {
        private final ArrayList<View> order = new ArrayList<>();
        private final Rect[] rc = new Rect[MAX];
        private final Rect[] dv = new Rect[2];
        private final boolean[] dvVert = new boolean[2];
        private int drag = -1;
        private final int gap = dp(10);
        private final Paint pill = new Paint(Paint.ANTI_ALIAS_FLAG);

        PaneArea(Context c) {
            super(c);
            setWillNotDraw(false);
            pill.setColor(sub);
            pill.setAlpha(150);
        }

        void setOrder(ArrayList<Pane> ps) {
            order.clear();
            for (Pane p : ps) order.add(p.box);
        }

        private Rect R(int l, int t, int r, int b) { return new Rect(l, t, r, b); }

        private void compute(int W, int H) {
            for (int i = 0; i < MAX; i++) rc[i] = null;
            dv[0] = null; dv[1] = null;
            int n = order.size();
            if (n == 0) return;
            if (maxIdx >= 0 && maxIdx < n) { rc[maxIdx] = R(0, 0, W, H); return; }
            boolean side = effectiveSide();
            if (n == 1) {
                rc[0] = R(0, 0, W, H);
            } else if (n == 2) {
                if (!side) {
                    int h = (int) ((H - gap) * r1);
                    rc[0] = R(0, 0, W, h); rc[1] = R(0, h + gap, W, H);
                    dv[0] = R(0, h, W, h + gap); dvVert[0] = false;
                } else {
                    int w = (int) ((W - gap) * r1);
                    rc[0] = R(0, 0, w, H); rc[1] = R(w + gap, 0, W, H);
                    dv[0] = R(w, 0, w + gap, H); dvVert[0] = true;
                }
            } else if (n == 3) {
                if (!side) {
                    int h = (int) ((H - gap) * r1), w = (int) ((W - gap) * r2);
                    rc[0] = R(0, 0, W, h); rc[1] = R(0, h + gap, w, H); rc[2] = R(w + gap, h + gap, W, H);
                    dv[0] = R(0, h, W, h + gap); dvVert[0] = false;
                    dv[1] = R(w, h + gap, w + gap, H); dvVert[1] = true;
                } else {
                    int w = (int) ((W - gap) * r1), h = (int) ((H - gap) * r2);
                    rc[0] = R(0, 0, w, H); rc[1] = R(w + gap, 0, W, h); rc[2] = R(w + gap, h + gap, W, H);
                    dv[0] = R(w, 0, w + gap, H); dvVert[0] = true;
                    dv[1] = R(w + gap, h, W, h + gap); dvVert[1] = false;
                }
            } else {
                int h = (int) ((H - gap) * r1), w = (int) ((W - gap) * r2);
                rc[0] = R(0, 0, w, h); rc[1] = R(w + gap, 0, W, h);
                rc[2] = R(0, h + gap, w, H); rc[3] = R(w + gap, h + gap, W, H);
                dv[0] = R(0, h, W, h + gap); dvVert[0] = false;
                dv[1] = R(w, 0, w + gap, H); dvVert[1] = true;
            }
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            setMeasuredDimension(MeasureSpec.getSize(wSpec), MeasureSpec.getSize(hSpec));
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int W = r - l, H = b - t;
            compute(W, H);
            for (int i = 0; i < order.size(); i++) {
                View v = order.get(i);
                Rect q = rc[i];
                if (q == null || q.width() <= 0 || q.height() <= 0) continue;
                v.measure(MeasureSpec.makeMeasureSpec(q.width(), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(q.height(), MeasureSpec.EXACTLY));
                v.layout(q.left, q.top, q.right, q.bottom);
            }
            if (changed) post(MuMultiActivity.this::refreshLayoutIcon);
        }

        @Override
        protected void onDraw(Canvas cv) {
            for (int k = 0; k < 2; k++) {
                Rect d = dv[k];
                if (d == null) continue;
                float cx = d.exactCenterX(), cy = d.exactCenterY();
                float len = dp(38), th = dp(4);
                RectF pr = dvVert[k] ? new RectF(cx - th / 2, cy - len / 2, cx + th / 2, cy + len / 2)
                        : new RectF(cx - len / 2, cy - th / 2, cx + len / 2, cy + th / 2);
                cv.drawRoundRect(pr, th, th, pill);
            }
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent ev) {
            if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                int slop = dp(12);
                for (int k = 1; k >= 0; k--) {
                    Rect d = dv[k];
                    if (d == null) continue;
                    if (ev.getX() >= d.left - (dvVert[k] ? slop : 0) && ev.getX() <= d.right + (dvVert[k] ? slop : 0)
                            && ev.getY() >= d.top - (dvVert[k] ? 0 : slop) && ev.getY() <= d.bottom + (dvVert[k] ? 0 : slop)) {
                        drag = k;
                        return true;
                    }
                }
            }
            return false;
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            if (drag < 0) return false;
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_MOVE: {
                    float v = dvVert[drag] ? (ev.getX() - gap / 2f) / Math.max(1, getWidth() - gap)
                            : (ev.getY() - gap / 2f) / Math.max(1, getHeight() - gap);
                    v = clampRatio(v);
                    if (drag == 0) r1 = v; else r2 = v;
                    requestLayout();
                    invalidate();
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    drag = -1;
                    saveAll();
                    return true;
                default:
                    return true;
            }
        }
    }

    private void refreshLayoutIcon() {
        if (layoutBtn != null) layoutBtn.setType(effectiveSide() ? IconV.LAYOUT_SIDE : IconV.LAYOUT_STACK);
    }

    private static float clampRatio(float v) { return Math.max(.2f, Math.min(.8f, Float.isNaN(v) ? .5f : v)); }

    // ------------------------------------------------------------------ tiny line icons
    static final class IconV extends View {
        static final int BACK = 0, PLUS = 1, CLOSE = 2, MORE = 3, LAYOUT_STACK = 4, LAYOUT_SIDE = 5;
        private int type;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        IconV(Context c, int type, int color) {
            super(c);
            this.type = type;
            float d = c.getResources().getDisplayMetrics().density;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2f * d);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setColor(color);
            setClickable(true);
            setFocusable(true);
        }

        void setType(int t) { if (t != type) { type = t; invalidate(); } }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f;
            float u = Math.min(w, h) * .2f;
            path.reset();
            switch (type) {
                case BACK:
                    path.moveTo(cx + u * .5f, cy - u); path.lineTo(cx - u * .6f, cy); path.lineTo(cx + u * .5f, cy + u);
                    cv.drawPath(path, p);
                    break;
                case PLUS:
                    cv.drawLine(cx - u, cy, cx + u, cy, p);
                    cv.drawLine(cx, cy - u, cx, cy + u, p);
                    break;
                case CLOSE:
                    cv.drawLine(cx - u * .8f, cy - u * .8f, cx + u * .8f, cy + u * .8f, p);
                    cv.drawLine(cx + u * .8f, cy - u * .8f, cx - u * .8f, cy + u * .8f, p);
                    break;
                case MORE: {
                    Paint.Style old = p.getStyle();
                    p.setStyle(Paint.Style.FILL);
                    float r = u * .26f;
                    cv.drawCircle(cx, cy - u * .85f, r, p); cv.drawCircle(cx, cy, r, p); cv.drawCircle(cx, cy + u * .85f, r, p);
                    p.setStyle(old);
                    break;
                }
                case LAYOUT_SIDE:
                    cv.drawRoundRect(new RectF(cx - u * 1.2f, cy - u, cx + u * 1.2f, cy + u), u * .4f, u * .4f, p);
                    cv.drawLine(cx, cy - u, cx, cy + u, p);
                    break;
                default:
                    cv.drawRoundRect(new RectF(cx - u * 1.2f, cy - u, cx + u * 1.2f, cy + u), u * .4f, u * .4f, p);
                    cv.drawLine(cx - u * 1.2f, cy, cx + u * 1.2f, cy, p);
                    break;
            }
        }
    }
}
