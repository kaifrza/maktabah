package com.kr.urdulibrary;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Freehand erasing: cuts a moving round eraser (a capsule A-B with radius r) out of an annotation.
 * Ink geometry is in page-width units; TEXT marks are in page points (pw = page width in points).
 */
final class MuEraser {
    private MuEraser() { }

    /** Returns null when the eraser does not touch a; otherwise what is left of it (possibly nothing). */
    static List<MuAnnot> cut(MuAnnot a, float ax, float ay, float bx, float by, float r, float pw) {
        if (a.type == MuAnnot.TEXT) return cutText(a, ax, ay, bx, by, r, pw);
        MuAnnot s = a;
        if (a.type == MuAnnot.BOX) {
            s = boxToStroke(a);
            if (s == null) return null;
        }
        return cutStroke(s, a.note, ax, ay, bx, by, r);
    }

    private static float segDist(float px, float py, float ax, float ay, float bx, float by) {
        float dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
        float t = l2 == 0f ? 0f : ((px - ax) * dx + (py - ay) * dy) / l2;
        t = Math.max(0f, Math.min(1f, t));
        return (float) Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
    }

    // ------------------------------------------------------------------ boxes become strokes so they can be cut
    private static MuAnnot boxToStroke(MuAnnot a) {
        if (a.pts.length < 4) return null;
        float x0 = Math.min(a.pts[0], a.pts[2]), x1 = Math.max(a.pts[0], a.pts[2]);
        float y0 = Math.min(a.pts[1], a.pts[3]), y1 = Math.max(a.pts[1], a.pts[3]);
        MuAnnot c = MuAnnotStore.copy(a);
        c.type = MuAnnot.STROKE;
        if (a.marker) {                                  // a filled box = one flat stroke as tall as the box
            float cy = (y0 + y1) / 2f;
            c.pts = new float[]{x0, cy, x1, cy};
            c.width = Math.max(0.0005f, y1 - y0);
            c.flat = true;
            return c;
        }
        c.flat = false;                                  // outline: a closed line with tight corners
        float e = Math.min(0.002f, Math.min(x1 - x0, y1 - y0) / 4f);
        float[][] k = {{x0, y0}, {x1, y0}, {x1, y1}, {x0, y1}};
        List<Float> o = new ArrayList<>();
        o.add(k[0][0]); o.add(k[0][1]);
        for (int i = 1; i <= 4; i++) {
            float[] pv = k[i - 1], cu = k[i % 4], nx = k[(i + 1) % 4];
            float d1x = Math.signum(cu[0] - pv[0]), d1y = Math.signum(cu[1] - pv[1]);
            float d2x = Math.signum(nx[0] - cu[0]), d2y = Math.signum(nx[1] - cu[1]);
            o.add(cu[0] - e * d1x); o.add(cu[1] - e * d1y);
            o.add(cu[0]); o.add(cu[1]);
            if (i < 4) { o.add(cu[0] + e * d2x); o.add(cu[1] + e * d2y); }
        }
        c.pts = new float[o.size()];
        for (int i = 0; i < c.pts.length; i++) c.pts[i] = o.get(i);
        return c;
    }

    // ------------------------------------------------------------------ strokes
    private static final class Buf {
        float[] v = new float[64];
        int n;
        void add(float x, float y) {
            if (n + 2 > v.length) v = java.util.Arrays.copyOf(v, v.length * 2);
            v[n++] = x; v[n++] = y;
        }
        float length() {
            float l = 0f;
            for (int i = 2; i + 1 < n; i += 2) l += (float) Math.hypot(v[i] - v[i - 2], v[i + 1] - v[i - 1]);
            return l;
        }
    }

    private static List<MuAnnot> cutStroke(MuAnnot s, String note, float ax, float ay, float bx, float by, float r) {
        float[] p = s.pts;
        int n = p.length / 2;
        if (n < 1) return null;
        float cr = r + s.width * 0.5f;
        if (n == 1) return segDist(p[0], p[1], ax, ay, bx, by) <= cr ? new ArrayList<MuAnnot>() : null;

        float minX = Math.min(ax, bx) - cr, maxX = Math.max(ax, bx) + cr;
        float minY = Math.min(ay, by) - cr, maxY = Math.max(ay, by) + cr;
        float step = Math.max(0.0012f, cr / 3f);
        float minLen = Math.max(0.002f, s.width * 0.12f);

        List<MuAnnot> out = new ArrayList<>();
        Buf cur = new Buf();
        boolean touched = false;
        String[] noteLeft = {note == null ? "" : note};

        float px = p[0], py = p[1];
        if (segDist(px, py, ax, ay, bx, by) <= cr) touched = true; else cur.add(px, py);
        for (int i = 1; i < n; i++) {
            float qx = p[2 * i], qy = p[2 * i + 1];
            boolean near = !(Math.max(px, qx) < minX || Math.min(px, qx) > maxX || Math.max(py, qy) < minY || Math.min(py, qy) > maxY);
            if (!near) {
                cur.add(qx, qy);
            } else {
                float len = (float) Math.hypot(qx - px, qy - py);
                int steps = Math.max(1, Math.min(600, (int) Math.ceil(len / step)));
                for (int k = 1; k <= steps; k++) {
                    float t = k / (float) steps;
                    float sx = px + (qx - px) * t, sy = py + (qy - py) * t;
                    if (segDist(sx, sy, ax, ay, bx, by) <= cr) {
                        touched = true;
                        flush(cur, s, minLen, noteLeft, out);
                    } else cur.add(sx, sy);
                }
            }
            px = qx; py = qy;
        }
        if (!touched) return null;
        flush(cur, s, minLen, noteLeft, out);
        return out;
    }

    private static void flush(Buf cur, MuAnnot s, float minLen, String[] noteLeft, List<MuAnnot> out) {
        if (cur.n >= 4 && cur.length() >= minLen) {
            MuAnnot c = MuAnnotStore.copy(s);
            c.id = MuAnnot.newId();
            c.pts = java.util.Arrays.copyOf(cur.v, cur.n);
            c.note = noteLeft[0];
            noteLeft[0] = "";
            out.add(c);
        }
        cur.n = 0;
    }

    // ------------------------------------------------------------------ text highlights / underlines (cut sideways)
    private static List<MuAnnot> cutText(MuAnnot a, float ax, float ay, float bx, float by, float r, float pw) {
        if (pw <= 0f || a.rects.length < 4) return null;
        float rp = r * pw;
        float x0 = ax * pw, y0 = ay * pw, x1 = bx * pw, y1 = by * pw;
        float len = (float) Math.hypot(x1 - x0, y1 - y0);
        int ns = Math.max(1, Math.min(300, (int) Math.ceil(len / Math.max(1f, rp / 3f))));
        List<Float> out = new ArrayList<>();
        boolean touched = false;
        for (int i = 0; i + 3 < a.rects.length; i += 4) {
            float l = a.rects[i], t = a.rects[i + 1], rr = a.rects[i + 2], b = a.rects[i + 3];
            float lh = b - t, vt = t, vb = b;
            if (a.style == 0) { vt = t + lh * 0.04f; vb = b - lh * 0.02f; }
            else if (a.style == 1) { float y = b - lh * 0.07f; vt = y - lh * 0.06f; vb = y + lh * 0.06f; }
            else { float y = t + lh * 0.56f; vt = y - lh * 0.06f; vb = y + lh * 0.06f; }
            List<float[]> cuts = new ArrayList<>();
            for (int k = 0; k <= ns; k++) {
                float f = k / (float) ns;
                float cx = x0 + (x1 - x0) * f, cy = y0 + (y1 - y0) * f;
                float dy = cy < vt ? vt - cy : (cy > vb ? cy - vb : 0f);
                if (dy >= rp) continue;
                float dx = (float) Math.sqrt(rp * rp - dy * dy);
                if (cx + dx > l && cx - dx < rr) cuts.add(new float[]{cx - dx, cx + dx});
            }
            if (cuts.isEmpty()) { addRect(out, l, t, rr, b, 0f); continue; }
            touched = true;
            Collections.sort(cuts, new Comparator<float[]>() {
                @Override public int compare(float[] u, float[] v) { return Float.compare(u[0], v[0]); }
            });
            float from = l;
            for (float[] c : cuts) {
                if (c[0] > from) addRect(out, from, t, Math.min(c[0], rr), b, 1.5f);
                from = Math.max(from, c[1]);
                if (from >= rr) break;
            }
            if (from < rr) addRect(out, from, t, rr, b, 1.5f);
        }
        if (!touched) return null;
        List<MuAnnot> res = new ArrayList<>();
        if (out.size() >= 4) {
            MuAnnot c = MuAnnotStore.copy(a);
            c.id = MuAnnot.newId();
            c.rects = new float[out.size()];
            for (int i = 0; i < c.rects.length; i++) c.rects[i] = out.get(i);
            res.add(c);
        }
        return res;
    }

    private static void addRect(List<Float> out, float l, float t, float r, float b, float minW) {
        if (r - l < minW) return;
        out.add(l); out.add(t); out.add(r); out.add(b);
    }
}
