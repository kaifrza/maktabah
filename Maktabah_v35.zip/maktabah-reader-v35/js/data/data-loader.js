import { supabase, SUPABASE_URL, resetServerHealth } from './supabase.js';
import { searchBooks, normalize } from '../features/search.js';
import { deriveCoverUrl } from '../utils/cover-source.js';

let cache = null;
const COVER_BUCKET = 'covers';
const PERSISTENT_CACHE_KEY = 'kr-urdu-library-catalogue-v1';
const PERSISTENT_CACHE_VERSION = 6;
const LEGACY_PERSISTENT_CACHE_VERSIONS = new Set([2, 3, 5]);
const PERSISTENT_CACHE_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

// Resolves a stored cover_path to a directly-fetchable Supabase Storage URL.
// - Already-absolute URLs (new records, saved by the Manager) pass through unchanged.
// - Legacy relative paths (old records saved before covers were uploaded to Storage) are
//   resolved by filename against the same public "covers" bucket the Manager uploads to.
function resolveCoverUrl(coverPath) {
  if (!coverPath) return '';
  if (/^https?:\/\//i.test(coverPath)) return coverPath;
  const fileName = coverPath.split('/').pop();
  if (!fileName) return '';
  // Same URL supabase.storage.getPublicUrl() builds, but needs no client and no network.
  return `${SUPABASE_URL}/storage/v1/object/public/${COVER_BUCKET}/${encodeURIComponent(fileName)}`;
}

async function fetchJSON(url, timeoutMs = 5000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let value;
  try {
    const response = await fetch(url, { cache: 'default', signal: controller.signal });
    if (!response.ok) throw new Error(`Could not load ${url} (${response.status})`);
    value = await response.json();
  } finally {
    clearTimeout(timer);
  }
  if (!Array.isArray(value)) throw new Error(`Invalid data format: ${url}`);
  return value;
}

function normalizeBooks(books) {
  const seen = new Set();
  return books.filter(book => {
    if (!book || typeof book !== 'object' || !book.id || seen.has(book.id)) return false;
    seen.add(book.id);
    book.categoryIds = Array.isArray(book.categoryIds) ? book.categoryIds : [];
    book.classIds = Array.isArray(book.classIds) ? [...new Set(book.classIds.filter(Boolean))] : (book.classId ? [book.classId] : []);
    if (book.classId && !book.classIds.includes(book.classId)) book.classIds.unshift(book.classId);
    book.keywords = Array.isArray(book.keywords) ? book.keywords : [];
    book.status = ['available', 'review', 'unavailable'].includes(book.status) ? book.status : 'review';
    book.bookType = book.bookType === 'sharah' ? 'sharah' : 'matn';
    book.source = book.source && typeof book.source === 'object' ? book.source : {};
    // No cover in the backend: use the PDF's own thumbnail (Archive.org / Drive) instead of only the typeset cover.
    if (!book.cover) book.cover = deriveCoverUrl(book);
    return true;
  });
}

function normalizeLookup(list) {
  return list.filter(item => item && typeof item === 'object' && item.id);
}

function mapBook(row, categoryIds = [], classIds = []) {
  const normalizedClassIds = Array.isArray(classIds) ? [...new Set(classIds.filter(Boolean))] : [];
  const legacyClassId = row.class_id || '';
  if (legacyClassId && !normalizedClassIds.includes(legacyClassId)) normalizedClassIds.unshift(legacyClassId);
  return {
    id: row.id,
    title: row.title,
    titleEn: row.title_en || '',
    author: row.author || '',
    description: row.description || '',
    classId: normalizedClassIds[0] || legacyClassId,
    classIds: normalizedClassIds,
    bookType: row.book_type || 'matn',
    pages: row.pages ?? null,
    cover: resolveCoverUrl(row.cover_path),
    pdfUrl: row.pdf_url || '',
    pdfSourceType: row.pdf_source_type || 'external',
    driveFileId: row.drive_file_id || '',
    source: { name: row.source_name || '', pageUrl: row.source_page_url || '' },
    status: row.status || 'review',
    keywords: Array.isArray(row.keywords) ? row.keywords : [],
    categoryIds,
    addedAt: row.added_at || row.created_at || '',
    createdAt: row.created_at || row.added_at || ''
  };
}


function buildLibraryIndexes(library) {
  const byId = new Map();
  const byClass = new Map();
  const byCategory = new Map();
  const recentBooks = [...library.books].sort((a,b) => String(b.addedAt).localeCompare(String(a.addedAt)));

  library.books.forEach(book => {
    byId.set(book.id, book);
    const classIds = Array.isArray(book.classIds) && book.classIds.length ? book.classIds : (book.classId ? [book.classId] : []);
    classIds.forEach(classId => {
      if (!byClass.has(classId)) byClass.set(classId, []);
      byClass.get(classId).push(book);
    });
    (book.categoryIds || []).forEach(categoryId => {
      if (!byCategory.has(categoryId)) byCategory.set(categoryId, []);
      byCategory.get(categoryId).push(book);
    });
  });

  return Object.assign(library, { byId, byClass, byCategory, recentBooks });
}

const BOOK_PAGE_SIZE = 20;        // first page: small, so Home appears fast
const NEXT_PAGE_SIZE = 100;       // later pages: fewer round-trips
const BOOK_COLUMNS = 'id,title,title_en,author,description,class_id,book_type,pages,cover_path,pdf_url,source_name,source_page_url,pdf_source_type,drive_file_id,status,keywords,added_at,created_at';
let paging = { nextOffset: 0, done: false, loading: null, cursor: null };
let classStats = null;
let classStatsLoading = null;
let categoryStats = null;
let categoryStatsLoading = null;


async function fetchBookPageFromSupabase(offset, size = BOOK_PAGE_SIZE, cursor = null) {
  let query = supabase.from('books')
    .select(BOOK_COLUMNS)
    .order('added_at', { ascending: false })
    .order('created_at', { ascending: false })
    .order('id', { ascending: false });

  // Keyset pagination keeps a stable catalogue boundary while new books are
  // inserted during a session. Offset pagination can skip rows when the
  // catalogue changes between requests. The first page establishes a cursor;
  // later pages only read rows after that cursor in the same ordering.
  if (cursor?.addedAt && cursor?.createdAt && cursor?.id) {
    const a = String(cursor.addedAt).replace(/[(),]/g, ' ');
    const c = String(cursor.createdAt).replace(/[(),]/g, ' ');
    const id = String(cursor.id).replace(/[(),]/g, ' ');
    query = query.or(`added_at.lt.${a},and(added_at.eq.${a},created_at.lt.${c}),and(added_at.eq.${a},created_at.eq.${c},id.lt.${id})`);
    query = query.limit(size);
  } else {
    query = query.range(offset, offset + size - 1);
  }

  const booksRes = await query;
  if (booksRes.error) throw booksRes.error;
  const ids = (booksRes.data || []).map(row => row.id);
  const categoryMap = new Map();
  const classMap = new Map();
  if(ids.length){
    const [categoriesRes, classesRes] = await Promise.all([
      supabase.from('book_categories').select('book_id,category_id').in('book_id', ids),
      supabase.from('book_classes').select('book_id,class_id').in('book_id', ids)
    ]);
    if (categoriesRes.error) throw categoriesRes.error;
    if (classesRes.error) throw classesRes.error;
    (categoriesRes.data || []).forEach(row => {
      if (!categoryMap.has(row.book_id)) categoryMap.set(row.book_id, []);
      categoryMap.get(row.book_id).push(row.category_id);
    });
    (classesRes.data || []).forEach(row => {
      if (!classMap.has(row.book_id)) classMap.set(row.book_id, []);
      classMap.get(row.book_id).push(row.class_id);
    });
  }
  return (booksRes.data || []).map(row => mapBook(row, categoryMap.get(row.id) || [], classMap.get(row.id) || []));
}

function readPersistentCache({ allowStale = false } = {}) {
  try {
    const raw = localStorage.getItem(PERSISTENT_CACHE_KEY);
    if (!raw) return null;
    const saved = JSON.parse(raw);
    if (!saved || !Array.isArray(saved.books)) return null;
    // Older builds wrongly saved the 1-book bundled sample as if it were the real catalogue.
    // Caches written now carry `origin`; an origin-less cache with <= 1 book is such a leftover.
    if (!saved.origin && saved.books.length <= 1) return null;
    const version = Number(saved.version);
    if (version !== PERSISTENT_CACHE_VERSION && !LEGACY_PERSISTENT_CACHE_VERSIONS.has(version)) return null;
    const age = saved.savedAt ? Math.max(0, Date.now() - Number(saved.savedAt)) : Infinity;
    if (!allowStale && age > PERSISTENT_CACHE_MAX_AGE_MS) return null;
    return { ...saved, version: PERSISTENT_CACHE_VERSION, stale: age > PERSISTENT_CACHE_MAX_AGE_MS, migratedFrom: version !== PERSISTENT_CACHE_VERSION ? version : null };
  } catch {
    return null;
  }
}

let persistentWriteTimer = null;

function writePersistentCache(library, { immediate = false } = {}) {
  // Bundled sample data / empty library are only an emergency fallback: never save them as
  // the catalogue, or the app would keep showing them for days instead of asking the server.
  if (!library || library.source === 'local-fallback' || library.source === 'empty') return;
  const save = () => {
    try {
      localStorage.setItem(PERSISTENT_CACHE_KEY, JSON.stringify({
        version: PERSISTENT_CACHE_VERSION,
        origin: library.source === 'supabase' ? 'supabase' : 'cache',
        savedAt: Date.now(),
        booksComplete: Boolean(paging.done),
        books: library.books,
        classes: library.classes,
        categories: library.categories,
        classStats: classStats && typeof classStats === 'object' ? classStats : null,
        paginationCursor: paging.cursor || null
      }));
    } catch (error) {
      // Storage can be full or unavailable in private/WebView contexts. The in-memory cache still works.
      console.warn('Maktabah persistent catalogue cache unavailable.', error);
    }
  };
  if (persistentWriteTimer) clearTimeout(persistentWriteTimer);
  if (immediate) save();
  else persistentWriteTimer = setTimeout(() => { persistentWriteTimer = null; save(); }, 250);
}

function flushPersistentCache() {
  if (!persistentWriteTimer || !cache) return;
  clearTimeout(persistentWriteTimer);
  persistentWriteTimer = null;
  writePersistentCache(cache, { immediate: true });
}

function clearPersistentCache() {
  if (persistentWriteTimer) { clearTimeout(persistentWriteTimer); persistentWriteTimer = null; }
  try { localStorage.removeItem(PERSISTENT_CACHE_KEY); } catch {}
}

if (typeof window !== 'undefined') window.addEventListener('pagehide', flushPersistentCache);

function loadFromPersistentCache({ allowStale = false } = {}) {
  const saved = readPersistentCache({ allowStale });
  if (!saved) return null;
  const books = normalizeBooks(saved.books || []);
  if (!books.length) return null;
  paging = {
    nextOffset: books.length,
    done: Boolean(saved.booksComplete),
    loading: null,
    cursor: saved.paginationCursor && typeof saved.paginationCursor === 'object' ? saved.paginationCursor : null
  };
  const library = buildLibraryIndexes({
    books,
    classes: normalizeLookup(saved.classes || []),
    categories: normalizeLookup(saved.categories || [])
  });
  classStats = saved.classStats && typeof saved.classStats === 'object' ? saved.classStats : null;
  library.source = 'persistent-cache';
  library.savedAt = Number(saved.savedAt) || 0;
  library.cacheStale = Boolean(saved.stale);
  if (saved.migratedFrom) writePersistentCache(library, { immediate: true });
  return library;
}

async function loadFromSupabase() {
  const [firstBooks, classesRes, categoriesRes] = await Promise.all([
    fetchBookPageFromSupabase(0),
    supabase.from('classes').select('id,name_ur,name_en,sort_order').eq('is_active', true).order('sort_order', { ascending: true }),
    supabase.from('categories').select('id,name_ur,name_en,sort_order').eq('is_active', true).order('sort_order', { ascending: true })
  ]);
  for (const result of [classesRes, categoriesRes]) {
    if (result.error) throw result.error;
  }
  const firstLast = firstBooks[firstBooks.length - 1];
  paging = {
    nextOffset: firstBooks.length,
    done: firstBooks.length < BOOK_PAGE_SIZE,
    loading: null,
    cursor: firstLast ? { addedAt: firstLast.addedAt, createdAt: firstLast.createdAt, id: firstLast.id } : null
  };
  classStats = null;
  classStatsLoading = null;
  categoryStats = null;
  categoryStatsLoading = null;
  const library = buildLibraryIndexes({
    books: normalizeBooks(firstBooks),
    classes: normalizeLookup((classesRes.data || []).map(c => ({ id:c.id, name:c.name_ur, nameEn:c.name_en, sortOrder:c.sort_order }))),
    categories: normalizeLookup((categoriesRes.data || []).map(c => ({ id:c.id, name:c.name_ur, nameEn:c.name_en, sortOrder:c.sort_order })))
  });
  library.source = 'supabase';
  library.cacheStale = false;
  writePersistentCache(library, { immediate: true });
  return library;
}

function emptyLibrary() {
  paging = { nextOffset: 0, done: true, loading: null, cursor: null };
  const library = buildLibraryIndexes({ books: [], classes: [], categories: [] });
  library.source = 'empty';
  library.cacheStale = false;
  return library;
}

// Bundled data: instant, works with no network. It is NOT saved to the persistent cache.
async function loadLocalFallback() {
  const [booksRes, classesRes, categoriesRes] = await Promise.allSettled([
    fetchJSON('./data/books.json'), fetchJSON('./data/classes.json'), fetchJSON('./data/categories.json')
  ]);
  const books = booksRes.status === 'fulfilled' ? booksRes.value : [];
  const classes = classesRes.status === 'fulfilled' ? classesRes.value : [];
  const categories = categoriesRes.status === 'fulfilled' ? categoriesRes.value : [];
  if (!books.length && !classes.length && !categories.length) return emptyLibrary();
  paging = { nextOffset: books.length, done: true, loading: null, cursor: null };
  const library = buildLibraryIndexes({ books: normalizeBooks(books), classes: normalizeLookup(classes), categories: normalizeLookup(categories) });
  library.source = 'local-fallback';
  library.cacheStale = false;
  return library;
}


async function fetchClassStatsFromSupabase(classes = []) {
  const activeClasses = normalizeLookup(classes);
  if (!activeClasses.length) return {};
  const classIds = activeClasses.map(c => c.id);
  const mappingsRes = await supabase
    .from('book_classes')
    .select('class_id,book_id,books!inner(book_type)')
    .in('class_id', classIds);
  if (mappingsRes.error) throw mappingsRes.error;
  const stats = Object.fromEntries(classIds.map(id => [id, { total: 0, matn: 0, sharah: 0 }]));
  (mappingsRes.data || []).forEach(row => {
    const stat = stats[row.class_id];
    if (!stat) return;
    stat.total += 1;
    const type = row.books?.book_type;
    if (type === 'matn') stat.matn += 1;
    else if (type === 'sharah') stat.sharah += 1;
  });
  return stats;
}

export async function loadClassStats({ force = false } = {}) {
  if (!cache) await loadLibraryData();
  if (!force && classStats && typeof classStats === 'object') return classStats;
  if (classStatsLoading) return classStatsLoading;

  // A complete local catalogue is authoritative enough to calculate these stats
  // without another network round-trip (local fallback or fully paginated cache).
  if (!force && paging.done) {
    const calculated = {};
    cache.classes.forEach(c => {
      const books = cache.byClass?.get(c.id) || [];
      calculated[c.id] = {
        total: books.length,
        matn: books.filter(b => b.bookType === 'matn').length,
        sharah: books.filter(b => b.bookType === 'sharah').length
      };
    });
    classStats = calculated;
    writePersistentCache(cache, { immediate: true });
    return classStats;
  }

  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return null;
  }

  classStatsLoading = (async () => {
    try {
      classStats = await fetchClassStatsFromSupabase(cache.classes);
      writePersistentCache(cache, { immediate: true });
      return classStats;
    } finally {
      classStatsLoading = null;
    }
  })();
  return classStatsLoading;
}


async function fetchCategoryStatsFromSupabase(categories = []) {
  const active = normalizeLookup(categories);
  if (!active.length) return {};
  // One cheap head-count request per category: exact, and not limited by the API's row cap.
  const results = await Promise.all(active.map(c =>
    supabase.from('book_categories').select('book_id', { count: 'exact', head: true }).eq('category_id', c.id)
  ));
  const stats = {};
  active.forEach((c, i) => {
    if (results[i].error) throw results[i].error;
    stats[c.id] = { total: results[i].count || 0 };
  });
  return stats;
}

export async function loadCategoryStats({ force = false } = {}) {
  if (!cache) await loadLibraryData();
  if (!force && categoryStats && typeof categoryStats === 'object') return categoryStats;
  if (categoryStatsLoading) return categoryStatsLoading;

  // A fully loaded catalogue is authoritative, no network round-trip needed.
  if (!force && paging.done) {
    const calculated = {};
    cache.categories.forEach(c => { calculated[c.id] = { total: (cache.byCategory?.get(c.id) || []).length }; });
    categoryStats = calculated;
    return categoryStats;
  }

  if (typeof navigator !== 'undefined' && navigator.onLine === false) return null;

  categoryStatsLoading = (async () => {
    try {
      categoryStats = await fetchCategoryStatsFromSupabase(cache.categories);
      return categoryStats;
    } finally {
      categoryStatsLoading = null;
    }
  })();
  return categoryStatsLoading;
}


const SEARCH_CANDIDATE_PAGE_SIZE = 100;
let searchPaging = { query: '', offset: 0, done: false, loading: null, pending: [], seen: new Set(), generation: 0 };
let searchGeneration = 0;

function escapeIlike(value = '') {
  return String(value).replace(/[\\%_(),]/g, ' ').replace(/\s+/g, ' ').trim();
}

function escapePgArrayElement(value = '') {
  return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}

// The server filter only has to be a SUPERSET of what the local matcher accepts (searchBooks() does the exact
// check afterwards). Stored text can carry harakat or letter variants (ي ك ه ...) that the normalized query no
// longer has, so for Arabic-script tokens a "%" is allowed between letters and variant letters become "_".
const ARABIC_SCRIPT = /[؀-ۿ]/;
const VARIANT_LETTERS = new Set(['ی', 'ي', 'ى', 'ئ', 'ک', 'ك', 'ہ', 'ۀ', 'ه', 'ھ', 'و', 'ؤ', 'ا', 'أ', 'إ', 'آ']);

function serverPattern(safe) {
  if (!ARABIC_SCRIPT.test(safe)) return `%${safe}%`;
  const letters = [...safe].map(ch => (VARIANT_LETTERS.has(ch) ? '_' : ch));
  return `%${letters.join('%')}%`;
}

export function buildSearchOr(tokens) {
  const fields = ['title','title_en','author','description'];
  const clauses = [];
  tokens.forEach(token => {
    const safe = escapeIlike(token);
    if (!safe) return;
    const pattern = serverPattern(safe);
    fields.forEach(field => clauses.push(`${field}.ilike.${pattern}`));
    // PostgreSQL array containment needs a valid array literal. Quoting and
    // escaping the token prevents commas/braces/quotes in user input from
    // changing the PostgREST filter expression.
    const keyword = escapePgArrayElement(safe);
    clauses.push(`keywords.cs.{"${keyword}"}`);
  });
  return clauses.join(',');
}

function resetSearchPaging(query) {
  const normalized = String(query || '').trim();
  if (searchPaging.query === normalized) return;
  searchPaging = { query: normalized, offset: 0, done: false, loading: null, pending: [], seen: new Set(), generation: searchGeneration };
}

export async function searchBooksPage(query, { pageSize = 20 } = {}) {
  const normalized = normalize(query || '');
  if (searchPaging.generation !== searchGeneration) searchPaging = { query: '', offset: 0, done: false, loading: null, pending: [], seen: new Set(), generation: searchGeneration };
  resetSearchPaging(normalized);
  // Everything below works on THIS query's state object. A newer query replaces the global one, and an
  // older request still in flight must never write into (or clear the loading flag of) the newer one.
  const sp = searchPaging;
  if (!normalized) return { results: [], done: true, totalLoaded: 0 };
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    const offlineError = new Error('Offline: using cached search results.');
    offlineError.code = 'OFFLINE';
    offlineError.retryable = false;
    throw offlineError;
  }
  if (sp.done && sp.pending.length === 0) {
    return { results: [], done: true, totalLoaded: sp.seen.size };
  }
  if (sp.loading) return sp.loading;

  const tokens = normalized.split(/\s+/).filter(Boolean);
  sp.loading = (async () => {
    try {
      // Drain already-fetched candidates before asking Supabase for another page.
      const results = sp.pending.splice(0, pageSize);
      if (results.length >= pageSize || (sp.done && sp.pending.length === 0)) {
        return {
          results,
          done: sp.done && sp.pending.length === 0,
          totalLoaded: sp.seen.size
        };
      }

      while (results.length < pageSize && !sp.done) {
        if (searchPaging !== sp) break;   // a newer query took over: stop fetching for this one
        const from = sp.offset;
        const to = from + SEARCH_CANDIDATE_PAGE_SIZE - 1;
        const res = await supabase.from('books')
          .select(BOOK_COLUMNS)
          .or(buildSearchOr(tokens))
          .order('added_at', { ascending: false })
          .order('created_at', { ascending: false })
          .order('id', { ascending: false })
          .range(from, to);
        if (res.error) throw res.error;
        const rows = res.data || [];
        sp.offset += rows.length;
        if (rows.length < SEARCH_CANDIDATE_PAGE_SIZE) sp.done = true;
        if (!rows.length) break;

        const ids = rows.map(row => row.id);
        const categoryMap = new Map();
        const classMap = new Map();
        const [categoriesRes, classesRes] = await Promise.all([
          supabase.from('book_categories').select('book_id,category_id').in('book_id', ids),
          supabase.from('book_classes').select('book_id,class_id').in('book_id', ids)
        ]);
        if (categoriesRes.error) throw categoriesRes.error;
        if (classesRes.error) throw classesRes.error;
        (categoriesRes.data || []).forEach(row => {
          if (!categoryMap.has(row.book_id)) categoryMap.set(row.book_id, []);
          categoryMap.get(row.book_id).push(row.category_id);
        });
        (classesRes.data || []).forEach(row => {
          if (!classMap.has(row.book_id)) classMap.set(row.book_id, []);
          classMap.get(row.book_id).push(row.class_id);
        });
        const books = rows.map(row => mapBook(row, categoryMap.get(row.id) || [], classMap.get(row.id) || []));
        const normalizedBooks = normalizeBooks(books);
        // The server filter is a broad superset; the canonical local matcher decides what is shown.
        const localMatches = searchBooks(normalizedBooks, normalized).filter(book => {
          if (sp.seen.has(book.id)) return false;
          sp.seen.add(book.id);
          return true;
        });
        sp.pending.push(...localMatches);

        const remaining = pageSize - results.length;
        if (remaining > 0 && sp.pending.length) {
          results.push(...sp.pending.splice(0, remaining));
        }
      }
      return {
        results,
        done: sp.done && sp.pending.length === 0,
        totalLoaded: sp.seen.size
      };
    } finally {
      sp.loading = null;
    }
  })();
  return sp.loading;
}

/** Fetches specific books by id (favourites, history, a deep-linked book) and merges them into the library. */
export async function fetchBooksByIds(ids = []) {
  const wanted = [...new Set((ids || []).filter(Boolean).map(String))].slice(0, 60);
  if (!wanted.length) return [];
  if (!cache) await loadLibraryData();
  const res = await supabase.from('books').select(BOOK_COLUMNS).in('id', wanted);
  if (res.error) throw res.error;
  const rows = res.data || [];
  if (!rows.length) return [];
  const rowIds = rows.map(row => row.id);
  const [categoriesRes, classesRes] = await Promise.all([
    supabase.from('book_categories').select('book_id,category_id').in('book_id', rowIds),
    supabase.from('book_classes').select('book_id,class_id').in('book_id', rowIds)
  ]);
  if (categoriesRes.error) throw categoriesRes.error;
  if (classesRes.error) throw classesRes.error;
  const categoryMap = new Map();
  const classMap = new Map();
  (categoriesRes.data || []).forEach(row => {
    if (!categoryMap.has(row.book_id)) categoryMap.set(row.book_id, []);
    categoryMap.get(row.book_id).push(row.category_id);
  });
  (classesRes.data || []).forEach(row => {
    if (!classMap.has(row.book_id)) classMap.set(row.book_id, []);
    classMap.get(row.book_id).push(row.class_id);
  });
  const books = normalizeBooks(rows.map(row => mapBook(row, categoryMap.get(row.id) || [], classMap.get(row.id) || [])));
  mergeBooksIntoLibrary(books);
  return books;
}


export function mergeBooksIntoLibrary(books = []) {
  if (!cache || !Array.isArray(books) || !books.length) return cache;
  const normalized = normalizeBooks(books);
  if (!normalized.length) return cache;

  // Upsert by stable book id instead of append-only merging. A Manager edit
  // must replace the cached metadata immediately; otherwise an edited title,
  // cover, source, status, or class/category mapping can remain stale until
  // the user performs a full refresh.
  const byId = new Map(cache.books.map(book => [book.id, book]));
  let changed = false;
  normalized.forEach(book => {
    const previous = byId.get(book.id);
    if (!previous || JSON.stringify(previous) !== JSON.stringify(book)) changed = true;
    byId.set(book.id, book);
  });
  if (!changed) return cache;

  cache.books = [...byId.values()];
  buildLibraryIndexes(cache);
  writePersistentCache(cache);
  return cache;
}

export async function loadNextBookPage() {
  if (!cache || paging.done) return { data: cache, added: [], done: true };
  if (paging.loading) return paging.loading;
  const offset = paging.nextOffset;
  const cursor = paging.cursor;
  paging.loading = (async () => {
    try {
      const added = normalizeBooks(await fetchBookPageFromSupabase(offset, NEXT_PAGE_SIZE, cursor));
      const before = new Map(cache.books.map(book => [book.id, book]));
      let changed = false;
      added.forEach(book => {
        const previous = before.get(book.id);
        if (!previous) changed = true;
        else if (JSON.stringify(previous) !== JSON.stringify(book)) changed = true;
        before.set(book.id, book);
      });
      cache.books = [...before.values()];
      buildLibraryIndexes(cache);
      paging.nextOffset += added.length;
      if (added.length) {
        const last = added[added.length - 1];
        paging.cursor = { addedAt: last.addedAt, createdAt: last.createdAt, id: last.id };
      }
      paging.done = added.length < NEXT_PAGE_SIZE;
      if (changed) writePersistentCache(cache);
      return { data: cache, added, done: paging.done };
    } finally {
      paging.loading = null;
    }
  })();
  return paging.loading;
}

export async function ensureAllBooksLoaded() {
  if (!cache) await loadLibraryData();
  while (!paging.done) await loadNextBookPage();
  return cache;
}

export function clearLibraryCache({ persistent = true } = {}) {
  cache = null;
  classStats = null;
  classStatsLoading = null;
  categoryStats = null;
  categoryStatsLoading = null;
  searchGeneration += 1;
  searchPaging = { query: '', offset: 0, done: false, loading: null, pending: [], seen: new Set(), generation: searchGeneration };
  paging = { nextOffset: 0, done: false, loading: null, cursor: null };
  if (persistent) clearPersistentCache();
}

export function getLibraryCacheInfo() {
  if (!cache) return { source: 'none', stale: false, books: 0, complete: false };
  return { source: cache.source || 'memory', stale: Boolean(cache.cacheStale), books: cache.books?.length || 0, complete: Boolean(paging.done) };
}

export function resetSearchState() {
  searchGeneration += 1;
  searchPaging = { query: '', offset: 0, done: false, loading: null, pending: [], seen: new Set(), generation: searchGeneration };
}

// What the app can show RIGHT NOW without any network: saved catalogue (even if old) ->
// bundled data -> empty. This is what lets the app open instantly on a bad connection.
async function loadLibraryInstant() {
  const persisted = loadFromPersistentCache({ allowStale: true });
  if (persisted) { cache = persisted; return cache; }
  try {
    cache = await loadLocalFallback();
  } catch (error) {
    console.warn('Bundled catalogue unavailable; starting with an empty library.', error);
    cache = emptyLibrary();
  }
  return cache;
}

/** True when the library on screen is only a placeholder / out of date and should be refreshed from the server. */
export function libraryNeedsSync() {
  if (!cache) return true;
  return cache.source === 'local-fallback' || cache.source === 'empty' || Boolean(cache.cacheStale);
}

/** Last-resort library so the UI can render even if loading somehow stalled. */
export function loadEmergencyLibrary() {
  if (!cache) cache = emptyLibrary();
  return cache;
}

/**
 * Without options: returns what is available instantly (never touches the network).
 * With { force: true }: asks the server. It either returns the new library or THROWS; on failure
 * the library currently in use is left untouched (it is never replaced by sample data).
 */
export async function loadLibraryData(options = {}) {
  const force = Boolean(options?.force);
  if (!force) return cache || loadLibraryInstant();
  resetServerHealth();
  const next = await loadFromSupabase();
  resetSearchState();
  cache = next;
  cache.cacheStale = false;
  return cache;
}
