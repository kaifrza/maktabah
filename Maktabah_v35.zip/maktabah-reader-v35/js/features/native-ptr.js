// Native pull-to-refresh (Android SwipeRefreshLayout around the WebView).
// Native handles the gesture, physics and spinner; the web layer only says WHERE it may be used
// (screens + no dialog open) and does the actual refresh. If the APK has no native support the
// plugin call fails and the JS fallback in app.js keeps working.
import { getNativePlugin } from "./download-manager.js";

const ROUTES = new Set(["home","catalogue","classes","class","categories","category","favorites","search","more","downloads"]);
let last = "", timer = 0, lastRoute = "";

function cssVar(name){
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return /^#[0-9a-f]{6}$/i.test(v) ? v : undefined;
}

export function syncNativePtr(route){
  lastRoute = route;
  clearTimeout(timer);
  timer = setTimeout(async () => {
    const plugin = getNativePlugin();
    if(!plugin || typeof plugin.setPullRefresh !== "function") return;
    const blocked = document.querySelector(".modal-backdrop, .more-info-dialog, .class-search-panel.is-open, .lr-sheet-wrap.open");
    // Search: only while results are on screen (the start screen with recent searches has nothing to refresh).
    const searchIdle = route === "search" && !document.querySelector(".sr-screen #libPanel");
    const enabled = ROUTES.has(route) && !blocked && !searchIdle;
    const bg = cssVar("--surface"), fg = cssVar("--accent");
    const sig = `${enabled}|${bg}|${fg}`;
    if(sig === last) return;
    try{
      const r = await plugin.setPullRefresh({ enabled, bg, fg });
      last = sig;
      window.__krNativePtr = Boolean(r && r.native);
      document.documentElement.classList.toggle("kr-native-ptr", window.__krNativePtr);
    }catch{ window.__krNativePtr = false; document.documentElement.classList.remove("kr-native-ptr"); }
  }, 60);
}

export function watchNativePtr(getRoute){
  if(!getNativePlugin()) return;
  const run = () => syncNativePtr(getRoute());
  window.addEventListener("popstate", run);
  window.addEventListener("hashchange", run);
  // Theme switch (light/dark/system) only changes <html data-theme>. Re-sync so the native spinner
  // gets the new --surface/--accent colours (before, it kept the colours of the first sync).
  const themeSync = () => { last = ""; syncNativePtr(lastRoute || getRoute()); };
  new MutationObserver(themeSync).observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
  const mo = new MutationObserver(run);
  mo.observe(document.body, { childList: true });
  const app = document.getElementById("app");
  if(app) mo.observe(app, { childList: true });
  setTimeout(run, 300); setTimeout(run, 1500);
}
