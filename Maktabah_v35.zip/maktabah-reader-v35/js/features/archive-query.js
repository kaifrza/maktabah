// Query understanding + ranking for the Archive.org search. Pure functions (no network), so it is easy to test.
//
// The problems this solves (real examples):
//   * "Bahar e Shareeat" found only Roman-Urdu books. Archive's Urdu books are titled "Bahar E Shariat بہار شریعت"
//     or "bahar-e-shariat-jild-1": different SPELLING ("Shariat"), and an exact-match-every-word query drops them.
//   * Books whose title is only in Urdu script can never match a Roman query.
// So one search becomes several searches that are merged and re-ranked here:
//   S1  every word, but each word may be spelled several ways (shareeat / shariat / sharia ...)
//   S2  any word (wide net, ranked by how many words match)
//   S3  the same words in Urdu script (Roman -> Urdu dictionary), with the usual Arabic/Urdu letter variants
//   S4  fuzzy words (one letter off)

/* ------------------------------------------------------------------ text folding */

const ARABIC_MARKS = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640\u200B-\u200F\u202A-\u202E\uFEFF]/g;

/** Urdu/Arabic-script text -> one canonical spelling, no vowel marks. Used for BOTH query and titles. */
export function foldUrdu(text) {
  return String(text || "").normalize("NFKC").replace(ARABIC_MARKS, "")
    .replace(/[يىېۍێ]/g, "ی").replace(/ك/g, "ک").replace(/[هةۃ]/g, "ہ").replace(/[ۓ]/g, "ے")
    .replace(/[أإٱ]/g, "ا").replace(/ؤ/g, "ؤ");
}

/** Latin text -> lowercase ASCII-ish (ī -> i, ḥ -> h, removes ʻ ʼ ' and similar). */
export function foldLatin(text) {
  return String(text || "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[ʻʼʿʾ'’`´]/g, "").toLowerCase();
}

const hasUrduScript = s => /[\u0600-\u06FF\u0750-\u077F]/.test(s);
export { hasUrduScript };

/** Words of any script (letters + digits). */
function words(text) {
  return String(text || "").split(/[^\p{L}\p{N}]+/u).filter(Boolean);
}

/** Everything searchable about an item, folded: Latin words (folded) and Urdu words (folded). */
function foldAll(text) {
  return words(foldUrdu(foldLatin(text))).join(" ");
}

/* ------------------------------------------------------------------ Roman-Urdu spelling variants */

// Words that carry no meaning for matching ("Bahar-e-Shariat", "Ahle Sunnat", "Al Quran").
const CONNECTORS = new Set(["e", "i", "o", "a", "ki", "ka", "ke", "ko", "ul", "ud", "ur", "un", "us", "al", "el", "wa", "va", "ba", "bin"]);
// Words people add that are not in titles.
const NOISE = new Set(["pdf", "book", "books", "download", "free", "ebook", "online", "kitab", "kitaab", "full", "by"]);
const LANG_HINTS = { urdu: "ur", english: "en", arabic: "ar", hindi: "hi", farsi: "fa", persian: "fa" };

// Ordered by how common the alternative spelling is. Each rule is tried once per word, two levels deep.
const RULES = [
  ["ee", "i"], ["i", "ee"], ["aa", "a"], ["a", "aa"], ["oo", "u"], ["u", "oo"], ["ai", "ay"], ["ay", "ai"],
  ["q", "k"], ["k", "q"], ["w", "v"], ["v", "w"], ["ph", "f"], ["f", "ph"], ["th", "t"], ["dh", "d"],
  ["gh", "g"], ["ou", "o"], ["ie", "i"], ["iy", "i"], ["z", "j"], ["oo", "o"], ["ae", "ai"], ["ea", "ee"],
];

function applyOnce(word, from, to) {
  const out = new Set();
  let i = word.indexOf(from);
  while (i !== -1) {
    out.add(word.slice(0, i) + to + word.slice(i + from.length));
    i = word.indexOf(from, i + 1);
  }
  return out;
}

/** Likely alternative spellings of one Roman word (max `limit`), original first. */
export function romanVariants(word, limit = 9) {
  const base = foldLatin(word).replace(/[^a-z0-9]/g, "");
  if (!base || /^\d+$/.test(base)) return base ? [base] : [];
  const seen = new Set([base]);
  let frontier = [base];
  for (let depth = 0; depth < 2 && seen.size < limit; depth++) {
    const next = [];
    for (const w of frontier) {
      for (const [from, to] of RULES) {
        for (const v of applyOnce(w, from, to)) {
          if (v.length >= 3 && !seen.has(v) && !/(.)\1\1/.test(v)) { seen.add(v); next.push(v); }
          if (seen.size >= limit) break;
        }
        if (seen.size >= limit) break;
      }
      if (seen.size >= limit) break;
    }
    frontier = next;
  }
  return [...seen].slice(0, limit);
}

/** Consonant skeleton: shareeat / shariat / sharia'at -> same key; bahar / bahaar -> same key. */
export function skeleton(word) {
  let s = foldLatin(word).replace(/[^a-z]/g, "");
  s = s.replace(/sh/g, "S").replace(/kh/g, "K").replace(/gh/g, "G").replace(/ch/g, "C")
    .replace(/th/g, "t").replace(/dh/g, "d").replace(/ph/g, "f")
    .replace(/h/g, "").replace(/[aeiouy]/g, "").replace(/q/g, "k").replace(/c/g, "k").replace(/w/g, "v")
    .replace(/(.)\1+/g, "$1");
  return s;
}

/* ------------------------------------------------------------------ Roman -> Urdu dictionary */

// urdu = roman forms separated by |. Not exhaustive: it only has to cover the words people type for Urdu/Islamic books.
const DICTIONARY = `
قرآن=quran|quraan|kuran|koran
حدیث=hadees|hadis|hadith
احادیث=ahadees|ahadith
تفسیر=tafseer|tafsir
فقہ=fiqh|fiqah|fiqa
شریعت=shariat|shareeat|shariyat|sharia|shariah
طریقت=tariqat|tareeqat|tariqah
حقیقت=haqeeqat|haqiqat
معرفت=marifat|maarifat|marfat
بہار=bahar|bahaar
نماز=namaz|namaaz|salat|salah|salaat
روزہ=roza|rozah|roze
حج=hajj|haj
عمرہ=umrah|umra
زکوٰۃ=zakat|zakaat|zakah
نکاح=nikah|nikaah
طلاق=talaq|talaaq
سیرت=seerat|sirat|siyrat
نبی=nabi|nabee
رسول=rasool|rasul
صحابہ=sahaba|sahabah|sahaaba
اہل=ahl|ahle|ahal
بیت=bait|bayt|beit
امام=imam|imaam
غوث=ghous|ghaus|ghaws
ولی=wali|walee
اولیاء=auliya|awliya|aulia
کرامات=karamat|karaamat
دعا=dua|duaa
دعائیں=duain|duaen|duayen
درود=durood|darood|durud
وظائف=wazaif|wazaaif|wazayif
فضائل=fazail|fazayil|fazaail
مسائل=masail|masayil|masaail
فتاویٰ=fatawa|fatawah|fatawaa
فتویٰ=fatwa|fatwah|fatva
احکام=ahkam|ahkaam
جنت=jannat|jannah
جہنم=jahannam|jahanam
قبر=qabr|qabar|kabar
قیامت=qayamat|qiyamat|qayaamat
آخرت=aakhirat|akhirat|aakhrat
دنیا=dunya|duniya
ایمان=iman|eman|imaan|eeman
اسلام=islam|islaam
اسلامی=islami|islamic|islaami
مسلمان=musalman|musalmaan
مسلم=muslim
تاریخ=tareekh|tarikh
حیات=hayat|hayaat
حضرت=hazrat|hazarat
مفتی=mufti
مولانا=maulana|maulaana
مولوی=maulvi|molvi
علامہ=allama|allamah
شاہ=shah|shaah
خان=khan|khaan
رضا=raza|riza|reza|ridha|rida
احمد=ahmad|ahmed
محمد=muhammad|mohammad|mohammed|muhammed
امجد=amjad
علی=ali|aali
اعظمی=azmi|azami|aazmi|aazami
کنز=kanz|kunz
سنت=sunnat|sunnah|sunat
بدعت=bidat|bidah
شرک=shirk
توحید=tauheed|tawheed|tauhid
اخلاق=akhlaq|akhlaaq
ادب=adab
علم=ilm|ilam
علماء=ulama|ulema|ulamaa
دین=deen|din
درس=dars
جلد=jild|jeld|jald
حصہ=hissa|hissah|hisa
اردو=urdu
عربی=arabi|arabic
فارسی=farsi|persian
ترجمہ=tarjuma|tarjumah|tarjama
شرح=sharh|sharah
بخاری=bukhari|bokhari
ترمذی=tirmizi|tirmidhi|tirmazi
ابو=abu|abo
داؤد=dawood|daud|dawud
ماجہ=majah|maja
نسائی=nasai|nasayi
مشکوٰۃ=mishkat|mishkaat|mishkah
ریاض=riyaz|riyadh|riaz
الصالحین=saliheen|salihin|saaliheen
احیاء=ihya|ihyaa
علوم=uloom|ulum|aloom
کیمیا=kimiya|kimia|keemiya
سعادت=saadat|saadah
گلستان=gulistan|gulistaan
بوستان=bostan|bustan|bostaan
مثنوی=masnavi|masnawi|mathnawi
دیوان=deewan|diwan|dewan
غزل=ghazal|ghazl
شاعری=shayari|shairi
افسانہ=afsana|afsanah
ناول=novel|naavel
نعت=naat|nat
حمد=hamd|hamad
منقبت=manqabat|manqibat
سلام=salam|salaam
میلاد=milad|meelad
محرم=muharram|moharram
کربلا=karbala|karbalaa
حسین=hussain|husain|hussein
حسن=hasan|hassan
فاطمہ=fatima|fatimah|fatma
عائشہ=ayesha|aisha|ayeshah|aaisha
صدیق=siddiq|siddique
صادق=sadiq|saadiq
عمر=umar|omar
عثمان=usman|uthman|osman
حیدر=haider|hyder|haidar
عبد=abdul|abd|abdel
قادر=qadir|qaadir|kadir
جیلانی=jilani|gilani|jeelani
اشرف=ashraf
سید=syed|sayyid|saiyed|sayed
چشتی=chishti|chishty|chisti
نقشبندی=naqshbandi|naqshbandy
سہروردی=suhrawardi|suharwardi
بریلوی=barelvi|bareilvi|barailvi|brelvi
دیوبندی=deobandi|devbandi
تصوف=tasawwuf|tasawuf
معارف=maarif|maaarif
مکتوبات=maktoobat|maktubat
مجموعہ=majmua|majmooa|majmuah
رسائل=rasail|rasayil
عقائد=aqaid|aqayid|aqaaid
عقیدہ=aqeeda|aqidah|aqida
کلام=kalam|kalaam
منطق=mantiq|mantaq
فلسفہ=falsafa|falsafah
طب=tib|tibb
وصیت=wasiyat|wasiyyat
اربعین=arbaeen|arbain
تذکرہ=tazkira|tazkirah|tazkara
حالات=halat|halaat
زندگی=zindagi|zindagee
سوانح=sawaneh|sawanih
عمری=umri|umree
نصیحت=naseehat|nasihat|nasiyat
خطبات=khutbat|khutbaat
خطبہ=khutba|khutbah
وعظ=waz|wazz
بیان=bayan|bayaan|byan
ملفوظات=malfoozat|malfuzat
انوار=anwar|anwaar
نور=noor|nur|nuur
ضیاء=zia|ziya|ziaa
منیر=munir|muneer
مصطفیٰ=mustafa|mustafaa|mustapha
مرتضیٰ=murtaza|murtuza
قادری=qadri|qaadri|kadri
رضوی=razvi|rizvi|razavi|rizwi
نوری=noori|nuri
عبادات=ibadat|ibaadat
معاملات=muamalat|muamlaat
وراثت=wirasat|virasat
وضو=wuzu|wudu|wazu
غسل=ghusl|ghusal
تیمم=tayammum|tayamum
طہارت=taharat|tahaarat
جنازہ=janaza|janazah|janaaza
قربانی=qurbani|qurbaani
عید=eid|eed
رمضان=ramzan|ramadan|ramazan
قدر=qadr|kadr
معراج=meraj|miraj|mehraj
ہجرت=hijrat|hijrah
جہاد=jihad|jihaad
شہید=shaheed|shahid
شہادت=shahadat|shahaadat
`;

const byForm = new Map();       // exact folded roman form -> Set(urdu)
const bySkeleton = new Map();   // consonant skeleton (len >= 2) -> Set(urdu)
for (const line of DICTIONARY.split("\n")) {
  const [urdu, forms] = line.split("=");
  if (!urdu || !forms) continue;
  for (const form of forms.split("|")) {
    const f = foldLatin(form).replace(/[^a-z]/g, "");
    if (!f) continue;
    if (!byForm.has(f)) byForm.set(f, new Set());
    byForm.get(f).add(urdu);
    const sk = skeleton(f);
    if (sk.length >= 2) {
      if (!bySkeleton.has(sk)) bySkeleton.set(sk, new Set());
      bySkeleton.get(sk).add(urdu);
    }
  }
}

/** Urdu-script words that a Roman word probably means ([] if unknown). */
export function urduCandidates(word) {
  const f = foldLatin(word).replace(/[^a-z]/g, "");
  if (!f) return [];
  const exact = byForm.get(f);
  if (exact) return [...exact];
  const sk = skeleton(f);
  if (sk.length >= 2 && bySkeleton.has(sk)) return [...bySkeleton.get(sk)];
  // "kanzul", "noorul", "mirrat-ul": a word with the Arabic article stuck on the end -> look up the word itself.
  const stem = f.replace(/(ul|ol|ur|us|ud|un)$/, "");
  if (stem.length >= 3 && stem !== f) return urduCandidates(stem);
  return [];
}

/** Spelling variants an Arabic-script word may have in an item's metadata (ی/ي, ک/ك, ہ/ه). */
export function urduSpellings(word, limit = 6) {
  const base = foldUrdu(word);
  const out = new Set([base]);
  const swaps = [["ی", "ي"], ["ک", "ك"], ["ہ", "ه"]];
  for (const [from, to] of swaps) {
    if (!base.includes(from)) continue;
    for (const v of [...out]) { if (out.size < limit) out.add(v.split(from).join(to)); }
  }
  return [...out].slice(0, limit);
}

/* ------------------------------------------------------------------ analysis */

/**
 * Turns what the user typed into everything the search needs.
 * Returns { core: [{ raw, latin: [...variants], urdu: [...urdu words] , isUrduScript }], numbers, hints, urduQuery, ... }
 */
export function analyzeQuery(input) {
  const raw = String(input || "").trim();
  const tokens = words(foldLatin(raw).replace(/[-_/.]/g, " ")).map(t => hasUrduScript(t) ? foldUrdu(t) : t);
  const hints = { lang: null };
  const core = [], numbers = [], hintWords = [];
  const estimate = tokens.filter(t => !/^\d+$/.test(t) && !CONNECTORS.has(t) && !NOISE.has(t) && !LANG_HINTS[t] && t.length >= 2).length;
  const variantLimit = estimate >= 4 ? 4 : estimate === 3 ? 5 : 8;      // keeps the web address short
  for (const t of tokens) {
    if (/^\d+$/.test(t)) { numbers.push(t); continue; }
    if (hasUrduScript(t)) {
      if (t.length >= 2) core.push({ raw: t, latin: [], urdu: [t], isUrduScript: true });
      continue;
    }
    if (LANG_HINTS[t]) { hints.lang = LANG_HINTS[t]; hintWords.push(t); continue; }
    if (CONNECTORS.has(t) || NOISE.has(t) || t.length < 2) continue;
    core.push({ raw: t, latin: romanVariants(t, variantLimit), urdu: urduCandidates(t), isUrduScript: false });
  }
  // Only connector / language words typed (e.g. "urdu"): fall back to the plain words so the search is not empty.
  if (!core.length) {
    if (hintWords.length) hints.lang = null;
    for (const t of tokens) {
      if (/^\d+$/.test(t) || t.length < 2) continue;
      core.push(hasUrduScript(t) ? { raw: t, latin: [], urdu: [t], isUrduScript: true } : { raw: t, latin: romanVariants(t), urdu: urduCandidates(t), isUrduScript: false });
    }
  }
  const mapped = core.filter(c => c.urdu.length);
  const urduQuery = !core.length ? "" : core.filter(c => c.urdu.length).map(c => c.urdu[0]).join(" ");
  const anyRoman = core.some(c => !c.isUrduScript);
  return { raw, core, numbers, hints, urduQuery: mapped.length && anyRoman ? urduQuery : "", anyRoman, anyUrduScript: core.some(c => c.isUrduScript) };
}

/* ------------------------------------------------------------------ Lucene query building */

const LUCENE_SPECIAL = /[+\-&|!(){}\[\]^"~*?:\\\/]/g;
const clean = w => String(w).replace(LUCENE_SPECIAL, "").trim();
const orList = list => [...new Set(list.map(clean).filter(Boolean))].join(" OR ");

function termGroup(variants, fields) {
  const v = orList(variants);
  if (!v) return "";
  return "(" + fields.map(f => `${f}:(${v})`).join(" OR ") + ")";
}

const STRICT_FIELDS = ["title", "subject", "creator"];
const WIDE_FIELDS = ["title", "subject", "creator", "description"];
const BOOKS_ONLY = "mediatype:(texts)";

function languageClause(hints) {
  if (hints.lang === "ur") return ' AND (language:(Urdu) OR language:(urd) OR language:(ur))';
  if (hints.lang === "en") return ' AND (language:(English) OR language:(eng))';
  return "";
}

/** The group of spellings for one word: Roman variants + (for Arabic-script words) their letter variants. */
function variantsOf(c) {
  return c.isUrduScript ? urduSpellings(c.raw) : c.latin;
}

/**
 * The searches to run. Each is { id, q, weight }. A search that cannot be built (e.g. no Urdu words) is left out.
 * `fuzzyOk` lets the caller switch fuzzy matching off if the server did not accept it.
 */
export function buildStrategies(analysis, { fuzzyOk = true } = {}) {
  const { core, hints } = analysis;
  if (!core.length) return [];
  const lang = languageClause(hints);
  const out = [];

  // S1: every word, each in all its spellings. For Urdu-script words the description is searched too.
  const s1 = core.map(c => termGroup(variantsOf(c), c.isUrduScript ? WIDE_FIELDS : STRICT_FIELDS)).filter(Boolean);
  if (s1.length) out.push({ id: "all", q: `${s1.join(" AND ")} AND ${BOOKS_ONLY}${lang}`, weight: 3 });

  // S3: the same words in Urdu script (Roman input only).
  if (analysis.urduQuery) {
    const groups = core.filter(c => c.urdu.length).map(c => {
      const forms = c.urdu.flatMap(u => urduSpellings(u));
      return termGroup(forms, WIDE_FIELDS);
    }).filter(Boolean);
    if (groups.length) out.push({ id: "urdu", q: `${groups.join(" AND ")} AND ${BOOKS_ONLY}`, weight: 4 });
  }

  // S2: any word (only useful with 2+ words). Ranked afterwards by how many words an item really matches.
  if (core.length >= 2) {
    const any = core.map(c => termGroup(variantsOf(c).concat(c.urdu.flatMap(u => urduSpellings(u))), WIDE_FIELDS)).filter(Boolean);
    out.push({ id: "any", q: `(${any.join(" OR ")}) AND ${BOOKS_ONLY}${lang}`, weight: 1 });
  }

  // S4: one letter off (Roman words of 5+ letters).
  if (fuzzyOk) {
    const fz = core.filter(c => !c.isUrduScript && c.raw.length >= 5);
    if (fz.length) {
      const groups = core.map(c => c.isUrduScript || c.raw.length < 5
        ? termGroup(variantsOf(c), STRICT_FIELDS)
        : "(" + ["title", "subject"].map(f => `${f}:(${orList(c.latin)} OR ${clean(c.raw)}~1)`).join(" OR ") + ")");
      out.push({ id: "fuzzy", q: `${groups.join(" AND ")} AND ${BOOKS_ONLY}${lang}`, weight: 2, fuzzy: true });
    }
  }
  return out;
}

/* ------------------------------------------------------------------ ranking */

/** Does this item's text look like Urdu (Urdu script title, or language says Urdu)? */
export function isUrduItem(item) {
  const lang = String(item.language || "").toLowerCase();
  return /(^|[^a-z])(urdu|urd|ur)([^a-z]|$)/.test(lang) || hasUrduScript(item.title || "");
}

/**
 * Higher = better. `hits` is the set of strategy ids that returned the item.
 * Looks at how many of the user's words really appear in the title / topics / author (in any spelling).
 */
export function scoreItem(item, analysis, hits) {
  const titleText = foldAll(item.title);
  const metaText = foldAll([item.creator, ...(Array.isArray(item.subject) ? item.subject : [item.subject])].filter(Boolean).join(" "));
  const idText = foldAll(String(item.identifier || "").replace(/[-_.]/g, " "));
  const hay = new Set(words(`${titleText} ${metaText} ${idText}`));
  const titleWords = new Set(words(titleText));
  const startsWith = (set, w) => { for (const x of set) if (x === w || (w.length >= 4 && x.startsWith(w))) return true; return false; };

  let score = 0, matched = 0, inTitle = 0;
  for (const c of analysis.core) {
    const forms = new Set([...variantsOf(c), ...c.urdu.flatMap(u => urduSpellings(u))].map(f => foldUrdu(foldLatin(f))));
    let hit = false, titleHit = false;
    for (const f of forms) {
      if (startsWith(titleWords, f)) { hit = titleHit = true; break; }
      if (startsWith(hay, f)) hit = true;
    }
    if (hit) matched++;
    if (titleHit) inTitle++;
  }
  const total = analysis.core.length || 1;
  score += (matched / total) * 55 + (inTitle / total) * 30;
  if (matched === total) score += 20;                          // every word matched
  for (const n of analysis.numbers) if (hay.has(n)) score += 4; // "jild 1"
  for (const id of hits) score += id === "urdu" || id === "all" ? 6 : 2;

  if (isUrduItem(item)) score += 18;                            // this is an Urdu app: Urdu books first
  const wantUrdu = analysis.hints.lang === "ur" || analysis.anyUrduScript;
  if (wantUrdu && !isUrduItem(item)) score -= 12;
  if (analysis.hints.lang === "en" && !isUrduItem(item)) score += 12;

  const downloads = Number(Array.isArray(item.downloads) ? item.downloads[0] : item.downloads) || 0;
  score += Math.min(10, Math.log10(downloads + 1) * 2.4);       // popularity, small tie-breaker
  const restricted = String(item["access-restricted-item"] || "").toLowerCase() === "true";
  if (restricted) score -= 10;                                  // borrow-only: cannot be read/downloaded freely
  return score;
}
