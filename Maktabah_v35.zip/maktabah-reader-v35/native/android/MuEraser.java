package com.kr.urdulibrary;

import java.util.ArrayList;
import java.util.List;

/**
 * Freehand eraser helpers. A rub-out is stored on the mark as a "cut": {width, x0,y0, x1,y1, ...} in page-width units,
 * drawn with CLEAR on top of the mark (see MuAnnot.drawCut), so only the pixels under the finger disappear.
 */
final class MuEraser {
    private MuEraser() { }

    /** The parts of the finger trail that come near mark a, as cuts. trail = x,y pairs (n floats), w = eraser width. */
    static List<float[]> clip(float[] trail, int n, float w, MuAnnot a, float pw) {
        List<float[]> out = new ArrayList<>();
        float[] b = new float[4];
        if (n < 2 || !a.bounds(pw, b)) return out;
        float pad = w / 2f + 0.004f;
        float x0 = b[0] - pad, y0 = b[1] - pad, x1 = b[2] + pad, y1 = b[3] + pad;
        int cnt = n / 2;
        float[] run = new float[n + 1];
        int rn = 0;
        boolean any = false;
        for (int i = 0; i < cnt; i++) {
            float x = trail[2 * i], y = trail[2 * i + 1];
            boolean in = x >= x0 && x <= x1 && y >= y0 && y <= y1;
            if (in) {
                if (rn == 0) {
                    run[rn++] = w;
                    if (i > 0) { run[rn++] = trail[2 * i - 2]; run[rn++] = trail[2 * i - 1]; }
                }
                run[rn++] = x; run[rn++] = y;
                any = true;
            } else if (rn > 0) {
                run[rn++] = x; run[rn++] = y;
                out.add(java.util.Arrays.copyOf(run, rn));
                rn = 0;
            }
        }
        if (rn > 0) out.add(java.util.Arrays.copyOf(run, rn));
        if (!any) out.clear();
        return out;
    }

    private static float segDist(float px, float py, float ax, float ay, float bx, float by) {
        float dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
        float t = l2 == 0f ? 0f : ((px - ax) * dx + (py - ay) * dy) / l2;
        t = Math.max(0f, Math.min(1f, t));
        return (float) Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
    }

    private static boolean covered(MuAnnot a, float x, float y) {
        for (float[] k : a.cuts) {
            float half = k[0] / 2f - a.width / 2f;
            if (half <= 0f) continue;
            if (k.length < 5) { if (Math.hypot(x - k[1], y - k[2]) <= half) return true; continue; }
            for (int i = 1; i + 3 < k.length; i += 2) {
                if (segDist(x, y, k[i], k[i + 1], k[i + 2], k[i + 3]) <= half) return true;
            }
        }
        return false;
    }

    /** True when a drawn line has been rubbed out completely, so the empty mark can be dropped. */
    static boolean erased(MuAnnot a) {
        if (a.type != MuAnnot.STROKE || a.cuts.isEmpty() || a.pts.length < 2) return false;
        if (a.pts.length == 2) return covered(a, a.pts[0], a.pts[1]);
        for (int i = 0; i + 3 < a.pts.length; i += 2) {
            float ax = a.pts[i], ay = a.pts[i + 1], bx = a.pts[i + 2], by = a.pts[i + 3];
            float len = (float) Math.hypot(bx - ax, by - ay);
            int steps = Math.max(1, Math.min(400, (int) Math.ceil(len / 0.003f)));
            for (int s = 0; s <= steps; s++) {
                float t = s / (float) steps;
                if (!covered(a, ax + (bx - ax) * t, ay + (by - ay) * t)) return false;
            }
        }
        return true;
    }
}
