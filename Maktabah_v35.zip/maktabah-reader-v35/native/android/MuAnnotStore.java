package com.kr.urdulibrary;

import java.util.ArrayList;
import java.util.List;

/**
 * Holds all annotations and the undo/redo history. Every change goes through here so that
 * undo works the same for highlights, ink and (later) stickers or notes.
 * Not thread-safe: use it from the UI thread only.
 */
final class MuAnnotStore {
    interface Listener { void onChanged(); }

    private static final int HISTORY = 80;

    private static final class Op {
        final List<MuAnnot> added = new ArrayList<>();
        final List<MuAnnot> removed = new ArrayList<>();
        final List<int[]> removedAt = new ArrayList<>();   // index each removed item had, for exact restore
        final List<MuAnnot[]> swaps = new ArrayList<>();   // {edited, old copy} pairs (freehand erase)
    }

    private final List<MuAnnot> items = new ArrayList<>();
    private final ArrayList<Op> undo = new ArrayList<>();
    private final ArrayList<Op> redo = new ArrayList<>();
    private Listener listener;

    void setListener(Listener l) { listener = l; }

    List<MuAnnot> all() { return items; }
    int size() { return items.size(); }
    boolean canUndo() { return !undo.isEmpty(); }
    boolean canRedo() { return !redo.isEmpty(); }

    void load(List<MuAnnot> list) {
        items.clear();
        if (list != null) items.addAll(list);
        undo.clear();
        redo.clear();
        fire();
    }

    MuAnnot byId(String id) {
        if (id == null) return null;
        for (MuAnnot a : items) if (id.equals(a.id)) return a;
        return null;
    }

    private void fire() { if (listener != null) listener.onChanged(); }

    private void push(Op op) {
        undo.add(op);
        if (undo.size() > HISTORY) undo.remove(0);
        redo.clear();
    }

    /** Adds annotations, optionally removing others in the same step (e.g. recolouring covered text). */
    void apply(List<MuAnnot> add, List<MuAnnot> remove) {
        Op op = new Op();
        if (remove != null) for (MuAnnot r : remove) {
            int i = items.indexOf(r);
            if (i >= 0) { items.remove(i); op.removed.add(r); op.removedAt.add(new int[]{i}); }
        }
        if (add != null) for (MuAnnot a : add) {
            if (items.size() >= MuAnnot.MAX) break;
            items.add(a);
            op.added.add(a);
        }
        if (op.added.isEmpty() && op.removed.isEmpty()) return;
        push(op);
        fire();
    }

    /**
     * One freehand-erase drag as one undo step. edited[i] was changed in place (olds[i] is its copy from before);
     * removed marks were rubbed out completely (their cuts must already be back to the old state).
     */
    void applyErase(List<MuAnnot> edited, List<MuAnnot> olds, List<MuAnnot> removed) {
        Op op = new Op();
        for (int i = 0; i < edited.size(); i++) op.swaps.add(new MuAnnot[]{edited.get(i), olds.get(i)});
        for (MuAnnot r : removed) {
            int i = items.indexOf(r);
            if (i >= 0) { items.remove(i); op.removed.add(r); op.removedAt.add(new int[]{i}); }
        }
        if (op.swaps.isEmpty() && op.removed.isEmpty()) return;
        push(op);
        fire();
    }

    void add(MuAnnot a) {
        List<MuAnnot> l = new ArrayList<>(1);
        l.add(a);
        apply(l, null);
    }

    void remove(MuAnnot a) {
        List<MuAnnot> l = new ArrayList<>(1);
        l.add(a);
        apply(null, l);
    }

    void removeAll(List<MuAnnot> list) { apply(null, new ArrayList<>(list)); }

    void clear() { if (!items.isEmpty()) removeAll(items); }

    /** Run a property edit on one annotation as one undoable step (copy-on-write so undo restores the old look). */
    void edit(MuAnnot a, Runnable change) {
        int i = items.indexOf(a);
        if (i < 0) return;
        MuAnnot old = copy(a);
        change.run();
        Op op = new Op();
        // undo = put the old copy back in place of the edited object
        op.removed.add(a);
        op.removedAt.add(new int[]{i});
        op.added.add(old);
        edits.add(new Object[]{op, a, old});
        pushEdit(op);
        fire();
    }

    private final List<Object[]> edits = new ArrayList<>();

    private void pushEdit(Op op) {
        undo.add(op);
        if (undo.size() > HISTORY) undo.remove(0);
        redo.clear();
    }

    /** Edits are stored as "swap a for old": undoing swaps in the old copy, redoing swaps the edited one back. */
    boolean undo() {
        if (undo.isEmpty()) return false;
        Op op = undo.remove(undo.size() - 1);
        Object[] e = editFor(op);
        if (!op.swaps.isEmpty()) {
            revert(op);
            for (MuAnnot[] s : op.swaps) swap(s[0], s[1]);
        } else if (e != null) swap((MuAnnot) e[1], (MuAnnot) e[2]);
        else revert(op);
        redo.add(op);
        fire();
        return true;
    }

    boolean redo() {
        if (redo.isEmpty()) return false;
        Op op = redo.remove(redo.size() - 1);
        Object[] e = editFor(op);
        if (!op.swaps.isEmpty()) {
            replay(op);
            for (MuAnnot[] s : op.swaps) swap(s[1], s[0]);
        } else if (e != null) swap((MuAnnot) e[2], (MuAnnot) e[1]);
        else replay(op);
        undo.add(op);
        fire();
        return true;
    }

    private Object[] editFor(Op op) {
        for (Object[] e : edits) if (e[0] == op) return e;
        return null;
    }

    private void swap(MuAnnot from, MuAnnot to) {
        int i = items.indexOf(from);
        if (i >= 0) items.set(i, to);
        else if (!items.contains(to)) items.add(to);
    }

    private void revert(Op op) {
        for (MuAnnot a : op.added) items.remove(a);
        for (int i = op.removed.size() - 1; i >= 0; i--) {
            int at = Math.min(items.size(), op.removedAt.get(i)[0]);
            items.add(at, op.removed.get(i));
        }
    }

    private void replay(Op op) {
        for (MuAnnot r : op.removed) items.remove(r);
        for (MuAnnot a : op.added) items.add(a);
    }

    static MuAnnot copy(MuAnnot a) {
        MuAnnot c = new MuAnnot();
        c.id = a.id; c.type = a.type; c.page0 = a.page0; c.color = a.color; c.rgb = a.rgb; c.style = a.style;
        c.note = a.note; c.text = a.text; c.created = a.created;
        c.rects = a.rects.clone(); c.pts = a.pts.clone();
        c.width = a.width; c.alpha = a.alpha; c.marker = a.marker; c.flat = a.flat;
        c.cuts = new ArrayList<>();
        for (float[] k : a.cuts) c.cuts.add(k.clone());
        return c;
    }

    /** Annotations on one page (small lists, so a plain scan is fine). */
    void onPage(int page0, List<MuAnnot> out) {
        out.clear();
        for (MuAnnot a : items) if (a.page0 == page0) out.add(a);
    }
}
