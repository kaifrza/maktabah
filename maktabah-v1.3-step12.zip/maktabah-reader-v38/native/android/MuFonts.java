package com.maktabah.kaif;

import android.content.Context;
import android.graphics.Typeface;
import android.widget.TextView;

/** Bundled Urdu fonts for the native screens: Amiri for interface text (Noto Nastaliq is used for sticky notes). */
final class MuFonts {
    private static Typeface amiri;
    private static boolean tried;

    private MuFonts() { }

    static boolean hasArabic(CharSequence t) {
        if (t == null) return false;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if ((c >= 0x0600 && c <= 0x06FF) || (c >= 0x0750 && c <= 0x077F) || (c >= 0xFB50 && c <= 0xFDFF) || (c >= 0xFE70 && c <= 0xFEFF)) return true;
        }
        return false;
    }

    static synchronized Typeface amiri(Context c) {
        if (tried) return amiri;
        tried = true;
        try { amiri = Typeface.createFromAsset(c.getApplicationContext().getAssets(), "fonts/Amiri-Regular.ttf"); } catch (Throwable ignored) { amiri = null; }
        return amiri;
    }

    /** Arabic-script text gets Amiri (bold when asked); Latin text keeps whatever the view already has. */
    static void apply(TextView v, CharSequence t, boolean bold) {
        try {
            if (!hasArabic(t)) return;
            Typeface f = amiri(v.getContext());
            if (f != null) v.setTypeface(bold ? Typeface.create(f, Typeface.BOLD) : f);
        } catch (Throwable ignored) { }
    }
}
