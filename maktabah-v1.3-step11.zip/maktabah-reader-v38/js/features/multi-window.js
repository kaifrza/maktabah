// Multi-window reading (native): several books on one screen, started from the Library tab or the home-screen widget.
// The web layer only keeps the native side informed (book list, language, reader look) and collects the pages read.
import { getNativePlugin } from "./download-manager.js";
import { getDownloads } from "./downloads-store.js";
import { cachedFiles } from "./device-scan.js";
import { getReaderPrefs, getReadingPosition, saveReadingPosition } from "./reader-prefs.js";
import { setProgress } from "../utils/storage.js";

let hooks = { lang: () => "ur", books: () => [] };
let timer = 0;

export const multiSupported = () => {
  const p = getNativePlugin();
  return Boolean(p && typeof p.openMultiReader === "function" && window.__krMuOk !== false);
};

function buildCatalog(){
  const lang = hooks.lang(), ur = lang === "ur";
  const books = hooks.books() || [];
  const byId = new Map(books.map(b => [b.id, b]));
  const items = [], seen = new Set();
  getDownloads().forEach(rec => {
    const b = byId.get(rec.bookId);
    const t = ur ? (b?.title || rec.title) : (b?.titleEn || rec.titleEn || b?.title || rec.title);
    const a = ur ? (b?.author || rec.author) : (b?.authorEn || rec.authorEn || b?.author || rec.author);
    const pos = getReadingPosition(rec.bookId);
    items.push({ t: t || "PDF", a: a || "", k: rec.bookId, id: rec.downloadId, pg: pos?.page || 1, fr: pos?.frac || 0 });
    seen.add(`${String(rec.filename || "").toLowerCase()}|${rec.size}`);
  });
  cachedFiles().slice(0, 500).forEach(f => {
    if(seen.has(`${String(f.name).toLowerCase()}|${f.size}`)) return;
    const key = `file:${f.path}`, pos = getReadingPosition(key);
    items.push({ t: String(f.name).replace(/\.pdf$/i, ""), a: "", k: key, p: f.path, pg: pos?.page || 1, fr: pos?.frac || 0 });
  });
  const prefs = getReaderPrefs();
  return { lang, theme: prefs.theme, dim: prefs.dim, keepAwake: Boolean(prefs.keepAwake), items };
}

/** Tells the native side what can be opened (debounced; also feeds the home-screen widget). */
export function syncMultiCatalog(now = false){
  if(!multiSupported()) return;
  clearTimeout(timer);
  const run = () => { try{ getNativePlugin().setMultiCatalog(buildCatalog()).catch(() => {}); }catch{} };
  if(now) run(); else timer = setTimeout(run, 800);
}

/** Pages read in the multi-window reader go into the normal reading progress. */
export async function collectMultiProgress(){
  if(!multiSupported()) return;
  try{
    const res = await getNativePlugin().takeMultiProgress();
    Object.entries(res?.progress || {}).forEach(([key, v]) => {
      const page = Number(v.page) || 0, total = Number(v.total) || 0;
      if(!page) return;
      if(total) setProgress(key, { page, totalPages: total, percent: Math.round(page / total * 100) });
      saveReadingPosition(key, page, Number(v.frac) || 0);
    });
  }catch{}
}

/** start: "new" (pick books) | "resume" (last session). */
export async function openMulti(start = "new"){
  if(!multiSupported()) return false;
  syncMultiCatalog(true);
  try{
    await getNativePlugin().openMultiReader({ start });
    return true;
  }catch(err){
    const m = String(err && (err.message || err.code) || "");
    if(/not implemented|unavailable|not included/i.test(m)) window.__krMuOk = false;
    return false;
  }
}

export async function multiSessionTitles(){
  if(!multiSupported()) return [];
  try{ return (await getNativePlugin().getMultiSession())?.titles || []; }catch{ return []; }
}

export function initMultiWindow(h){
  hooks = { ...hooks, ...h };
  if(!multiSupported()) return;
  collectMultiProgress();
  syncMultiCatalog();
  document.addEventListener("visibilitychange", () => {
    if(document.visibilityState === "visible") collectMultiProgress();
    else syncMultiCatalog(true);
  });
}
