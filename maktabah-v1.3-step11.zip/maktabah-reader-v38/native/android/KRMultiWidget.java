package com.maktabah.kaif;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

/** Home-screen widget: start a multi-window reading session, or pick the last one up again. */
public class KRMultiWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) {
            try { mgr.updateAppWidget(id, build(ctx)); } catch (Throwable ignored) { }
        }
    }

    /** Called whenever the session or the language changes. */
    static void refresh(Context ctx) {
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
            int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, KRMultiWidget.class));
            if (ids == null || ids.length == 0) return;
            RemoteViews rv = build(ctx);
            for (int id : ids) mgr.updateAppWidget(id, rv);
        } catch (Throwable ignored) { }
    }

    private static PendingIntent launch(Context ctx, String start, int req) {
        Intent i = new Intent();
        try { i.setClassName(ctx.getPackageName(), "com.maktabah.kaif.MuMultiActivity"); } catch (Throwable ignored) { }
        i.setAction("com.maktabah.kaif.MULTI_" + start.toUpperCase());
        i.putExtra("start", start);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(ctx, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static RemoteViews build(Context ctx) {
        boolean ur = "ur".equals(MuMultiStore.catalog(ctx).optString("lang", "ur"));
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.kr_multi_widget);
        rv.setTextViewText(R.id.krw_title, ur ? "ملٹی ونڈو" : "Multi window");
        rv.setTextViewText(R.id.krw_hint, ur ? "ایک ساتھ 4 کتابیں پڑھیں" : "Read up to 4 books together");
        rv.setTextViewText(R.id.krw_new, ur ? "＋  نئی ونڈو" : "＋  New window");
        rv.setOnClickPendingIntent(R.id.krw_new, launch(ctx, "new", 1));
        rv.setOnClickPendingIntent(R.id.krw_root, launch(ctx, "resume", 2));
        JSONArray panes = MuMultiStore.session(ctx).optJSONArray("panes");
        if (panes != null && panes.length() > 0) {
            StringBuilder sb = new StringBuilder();
            for (int k = 0; k < panes.length() && k < 4; k++) {
                JSONObject p = panes.optJSONObject(k);
                if (p == null) continue;
                if (sb.length() > 0) sb.append("  ·  ");
                sb.append(p.optString("title", "PDF"));
            }
            rv.setTextViewText(R.id.krw_resume, (ur ? "جاری رکھیں" : "Resume") + " (" + panes.length() + ")");
            rv.setTextViewText(R.id.krw_list, sb.toString());
            rv.setViewVisibility(R.id.krw_resume, View.VISIBLE);
            rv.setViewVisibility(R.id.krw_list, View.VISIBLE);
            rv.setOnClickPendingIntent(R.id.krw_resume, launch(ctx, "resume", 3));
        } else {
            rv.setViewVisibility(R.id.krw_resume, View.GONE);
            rv.setViewVisibility(R.id.krw_list, View.GONE);
        }
        return rv;
    }
}
