package com.maktabah.kaif;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/** Disk state of the multi-window reader: the book catalogue (written by the web layer), the open session, and reading progress. */
final class MuMultiStore {
    private static final String PREFS = "kr_multi";
    private static final String CAT_FILE = "multi_catalog.json";

    private MuMultiStore() { }

    private static SharedPreferences sp(Context c) { return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static void writeCatalog(Context c, String json) {
        try (FileOutputStream o = new FileOutputStream(new File(c.getFilesDir(), CAT_FILE))) {
            o.write(json.getBytes(StandardCharsets.UTF_8));
        } catch (Throwable ignored) { }
    }

    /** {lang, theme, dim, keepAwake, items:[{t, a, k, id | p}]} - never null. */
    static JSONObject catalog(Context c) {
        try (FileInputStream in = new FileInputStream(new File(c.getFilesDir(), CAT_FILE))) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
        } catch (Throwable e) {
            return new JSONObject();
        }
    }

    /** {panes:[{path,title,key,page,frac,total}], mode:-1|0|1, r1, r2, focus} - never null. */
    static JSONObject session(Context c) {
        try { return new JSONObject(sp(c).getString("session", "{}")); } catch (Throwable e) { return new JSONObject(); }
    }

    static void saveSession(Context c, JSONObject s) {
        try { sp(c).edit().putString("session", s.toString()).apply(); } catch (Throwable ignored) { }
    }

    static int sessionCount(Context c) {
        JSONArray a = session(c).optJSONArray("panes");
        return a == null ? 0 : a.length();
    }

    /** Remember the pages read (key -> page/frac/total); the web layer collects them the next time it is shown. */
    static void putProgress(Context c, String key, int page, float frac, int total) {
        if (key == null || key.isEmpty() || page <= 0) return;
        try {
            JSONObject all = new JSONObject(sp(c).getString("progress", "{}"));
            JSONObject o = new JSONObject();
            o.put("page", page); o.put("frac", frac); o.put("total", total);
            all.put(key, o);
            sp(c).edit().putString("progress", all.toString()).apply();
        } catch (Throwable ignored) { }
    }

    static JSONObject takeProgress(Context c) {
        JSONObject all;
        try { all = new JSONObject(sp(c).getString("progress", "{}")); } catch (Throwable e) { all = new JSONObject(); }
        try { sp(c).edit().remove("progress").apply(); } catch (Throwable ignored) { }
        return all;
    }
}
