package com.kr.urdulibrary;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.LruCache;
import android.view.GestureDetector;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.OverScroller;

import com.artifex.mupdf.fitz.Document;
import com.artifex.mupdf.fitz.Link;
import com.artifex.mupdf.fitz.Location;
import com.artifex.mupdf.fitz.Outline;
import com.artifex.mupdf.fitz.Page;
import com.artifex.mupdf.fitz.Quad;
import com.artifex.mupdf.fitz.android.AndroidDrawDevice;

import java.io.File;
import java.lang.reflect.Method;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Continuous-scroll PDF view backed by MuPDF.
 * - every MuPDF call runs on ONE worker thread (documents are not thread-safe)
 * - pages are drawn from a bitmap cache; when zoomed in only the visible patch is re-rendered
 * - pinch zoom, double tap, fling, links, text search highlights, night / sepia themes
 */
public class MuPdfView extends View {

    public interface Host {
        void onOpened(int pageCount, boolean hasOutline);
        void onOpenFailed(String message);
        void onNeedPassword(boolean wrongBefore);
        void onPageChanged(int page0, int total);
        void onTap();
        void onUserScroll();
        void onExternalLink(String uri);
        void onOutline(List<OutlineItem> items);
        /** A text selection was started (long-press): the host hides its bars and any open menu. */
        void onSelectionStart();
        /** The selection settled (anchor = its area in view pixels) or is being moved (anchor == null: hide the menu). */
        void onSelectionMenu(RectF anchor);
        void onSelectionEnd();
        /** A saved highlight was tapped. */
        void onHighlightTap(MuAnnot h, RectF anchor);
        /** A sticker note was tapped (anchor = its box in view pixels). */
        void onStickerTap(MuAnnot s, RectF anchor);
        /** A sticker was picked up by a long-press: the host closes any note overlay. */
        void onStickerDragStart();
        void onNotice(int code);
    }

    public static final int NOTICE_NO_TEXT = 1, NOTICE_NO_TEXT_HERE = 2, NOTICE_NO_LINE = 3;

    public static final int[] HL_FILL = MuAnnot.FILL;
    public static final int[] HL_INK = MuAnnot.INK;
    public static final int HL_MAX = MuAnnot.MAX;

    public static String highlightsToJson(List<MuAnnot> list) { return MuAnnot.toJson(list); }
    public static List<MuAnnot> parseHighlights(String json) { return MuAnnot.parse(json); }

    public static final class OutlineItem {
        public final String title; public final int level; public int page0;
        OutlineItem(String t, int l, int p) { title = t; level = l; page0 = p; }
    }

    public static final class Hit {
        public final int page0; public final float x0, y0, x1, y1;
        Hit(int p, float a, float b, float c, float d) { page0 = p; x0 = a; y0 = b; x1 = c; y1 = d; }
    }

    public interface SearchListener { void onProgress(int hits, boolean done); }

    /** Called on every scroll change with the position in the book (0 = top, 1 = end): drives the scrub handle. */
    public interface ScrollListener { void onScrolled(float fraction); }

    // ---------------------------------------------------------------- worker
    private static final class Task implements Runnable, Comparable<Task> {
        final int prio; final long seq; final Runnable r;
        private static long counter = 0;
        Task(int prio, Runnable r) { this.prio = prio; this.r = r; synchronized (Task.class) { seq = counter++; } }
        @Override public void run() { r.run(); }
        @Override public int compareTo(Task o) { return prio != o.prio ? Integer.compare(prio, o.prio) : Long.compare(seq, o.seq); }
    }

    // Two workers, each with its OWN Document instance (a MuPDF document must never be used by two threads at
    // once). A: opening, page bitmaps, links.  B: sharp zoom patches, page measuring, search.
    // This keeps page bitmaps coming even while a heavy zoom patch or a search is being rendered.
    private static final java.util.concurrent.ThreadFactory RENDER_THREADS = new java.util.concurrent.ThreadFactory() {
        @Override public Thread newThread(final Runnable r) {
            return new Thread(new Runnable() {
                @Override public void run() {
                    try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND - 2); } catch (Throwable ignored) { }
                    r.run();
                }
            }, "mupdf-render");
        }
    };
    private final ThreadPoolExecutor exec = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS,
            new PriorityBlockingQueue<Runnable>(), RENDER_THREADS);
    private final ThreadPoolExecutor execB = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS,
            new PriorityBlockingQueue<Runnable>(), RENDER_THREADS);
    private Document docB;
    private String password;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean destroyed = false;
    private volatile boolean scrubbing = false;      // the reader is dragging the scrub handle
    private ScrollListener scrollListener;
    private float lastFracNotified = -1f;

    // ---------------------------------------------------------------- document state
    private Document doc;
    private int pageCount = 0;
    private float[] pw, ph;           // page size in points
    private boolean[] sized;
    private float defaultRatio = 1.414f;
    private Host host;
    private String path;

    // ---------------------------------------------------------------- layout (zoom 1 pixels)
    private float[] top1;             // top of each page at zoom 1
    private float[] h1;               // height of each page at zoom 1
    private float total1 = 0;
    private float pageW1 = 0;         // page width at zoom 1 (<= view width)
    private float gap;
    private float maxPagePx;
    private float zoom = 1f, minZoom = 1f, maxZoom = 5f;
    private float scrollX = 0f, scrollY = 0f;
    private int lastPage0 = -1;

    // anchor kept while pages get measured
    private int pendingAnchorPage = -1; private float pendingAnchorFrac = 0f; private boolean haveSizes0 = false;

    // ---------------------------------------------------------------- bitmaps
    private final LruCache<Integer, Bitmap> cache;
    private final LruCache<Integer, Bitmap> lowCache;      // quick, blurry previews shown while the sharp page renders
    private final java.util.concurrent.atomic.AtomicBoolean pumping = new java.util.concurrent.atomic.AtomicBoolean(false);
    private volatile int scrollDir = 1;
    private static final class Patch { int page0; float zoom; int x, y, w, h; Bitmap bmp; }
    private final Map<Integer, Patch> patches = new HashMap<>();
    private final Set<Integer> pendingPatch = new HashSet<>();
    private volatile int visFirst = 0, visLast = 0;
    private volatile float curZoomForTasks = 1f;
    private volatile boolean flinging = false;
    private volatile float avgFullMs = 200f;                 // moving average of full-page render time
    private final java.util.concurrent.atomic.AtomicBoolean pumpingB = new java.util.concurrent.atomic.AtomicBoolean(false);
    private final Set<Integer> inFlight = java.util.Collections.synchronizedSet(new HashSet<Integer>());

    // ---- cancellable renders + memory of pages that failed ------------------------------------------------
    // A heavy page (big scan, JPX/JBIG2 layers) can take seconds. Every page render carries a MuPDF "cookie"
    // so it can be stopped the moment the reader has scrolled away; before this the single worker stayed
    // busy with the old page and the page the reader was actually looking at stayed white.
    private static final class Job {
        final int page; final Object cookie; final boolean prefetch; volatile boolean cancelled;
        Job(int page, Object cookie) { this(page, cookie, false); }
        Job(int page, Object cookie, boolean prefetch) { this.page = page; this.cookie = cookie; this.prefetch = prefetch; }
    }
    private volatile Job jobA, jobB;
    private final Map<Integer, long[]> failures = new HashMap<>();   // page -> { failCount, retryAtMillis }
    private volatile long openedAtMs = 0L;

    // Reflection keeps the build independent of the exact MuPDF version: without a cookie everything works as before.
    private static Object newCookie() {
        try { return Class.forName("com.artifex.mupdf.fitz.Cookie").getConstructor().newInstance(); }
        catch (Throwable t) { return null; }
    }
    private static void abortCookie(Object c) {
        if (c == null) return;
        try { c.getClass().getMethod("abort").invoke(c); } catch (Throwable ignored) { }
    }
    private void cancelJob(Job j) { if (j == null) return; j.cancelled = true; abortCookie(j.cookie); }

    /** Pages worth rendering right now: the visible ones plus a little in the scroll direction. */
    private boolean wanted(int page) {
        int lo = visFirst - (scrollDir < 0 ? 3 : 1), hi = visLast + (scrollDir >= 0 ? 3 : 1);
        return page >= lo && page <= hi;
    }
    /** A background (disk) prefetch is dropped as soon as the page on screen is not ready or the reader moved far away. */
    private boolean jobStale(Job j) {
        if (j.prefetch) return !visibleReady() || j.page < visFirst - 3 || j.page > visLast + PREFETCH_PAGES + 1;
        return !wanted(j.page);
    }
    private void cancelStaleJobs() {
        Job a = jobA; if (a != null && !a.cancelled && jobStale(a)) cancelJob(a);
        Job b = jobB; if (b != null && !b.cancelled && jobStale(b)) cancelJob(b);
    }

    private void noteFailure(final int i) {
        final long wait;
        synchronized (failures) {
            long[] f = failures.get(i);
            int n = f == null ? 1 : (int) f[0] + 1;
            wait = Math.min(20000L, n * 2500L);                        // retry after 2.5 s, 5 s, ... never a tight loop
            failures.put(i, new long[] { n, System.currentTimeMillis() + wait });
        }
        ui.postDelayed(new Runnable() { @Override public void run() { if (!destroyed) invalidate(); } }, wait + 50);
    }
    private boolean coolingDown(int i) {
        synchronized (failures) { long[] f = failures.get(i); return f != null && System.currentTimeMillis() < f[1]; }
    }
    private void clearFailure(int i) { synchronized (failures) { failures.remove(i); } }

    // ---- disk cache of rendered pages ------------------------------------------------------------------
    // Heavy books (e.g. Internet Archive scans: two 600 dpi JPEG2000 layers + a JBIG2 mask on every page) need
    // many seconds per page on a phone. A page is rendered ONCE, saved here, and shown instantly afterwards,
    // also after the book was closed and opened again. Cheap pages are not saved (no point).
    private static final int PREFETCH_PAGES = 8;
    private static final long DISK_CACHE_MAX = 200L * 1024 * 1024;
    private volatile File diskDir;

    private File computeDiskDir(String filePath) {
        try {
            File f = new File(filePath);
            long len = f.length();
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            md.update(("v1|" + len).getBytes("UTF-8"));      // size + first/last 64 KB: same book = same key, even if the file is copied
            java.io.RandomAccessFile raf = new java.io.RandomAccessFile(f, "r");
            try {
                byte[] buf = new byte[65536];
                int n = raf.read(buf); if (n > 0) md.update(buf, 0, n);
                if (len > 131072L) { raf.seek(len - 65536L); n = raf.read(buf); if (n > 0) md.update(buf, 0, n); }
            } finally { raf.close(); }
            StringBuilder sb = new StringBuilder();
            for (byte x : md.digest()) sb.append(String.format("%02x", x));
            File root = new File(getContext().getCacheDir(), "mu_pages");
            File d = new File(root, sb.toString());
            if (!d.isDirectory() && !d.mkdirs()) return null;
            final File fr = root;
            Thread t = new Thread(new Runnable() { @Override public void run() { trimDiskCache(fr, DISK_CACHE_MAX); } }, "mupdf-trim");
            t.setPriority(Thread.MIN_PRIORITY); t.start();
            return d;
        } catch (Throwable t) { return null; }
    }

    /** Keeps the page cache under the size limit: oldest files go first. */
    private static void trimDiskCache(File root, long maxBytes) {
        try {
            File[] dirs = root.listFiles(); if (dirs == null) return;
            ArrayList<File> files = new ArrayList<>(); long total = 0;
            for (File d : dirs) { File[] fs = d.listFiles(); if (fs == null) continue; for (File f : fs) { files.add(f); total += f.length(); } }
            if (total <= maxBytes) return;
            java.util.Collections.sort(files, new java.util.Comparator<File>() {
                @Override public int compare(File a, File b) { return Long.compare(a.lastModified(), b.lastModified()); }
            });
            for (File f : files) { if (total <= maxBytes) break; long l = f.length(); if (f.delete()) total -= l; }
        } catch (Throwable ignored) { }
    }

    private boolean diskHas(int i, int w) {
        File d = diskDir; if (d == null) return false;
        File f = new File(d, i + "_" + w + ".jpg");
        return f.isFile() && f.length() > 100;
    }

    private Bitmap diskLoad(int i, int w) {
        File d = diskDir; if (d == null) return null;
        File f = new File(d, i + "_" + w + ".jpg");
        if (!f.isFile() || f.length() <= 100) return null;
        try {
            Bitmap bm = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath());
            if (bm != null) { try { f.setLastModified(System.currentTimeMillis()); } catch (Throwable ignored) { } try { bm.prepareToDraw(); } catch (Throwable ignored) { } }
            return bm;
        } catch (Throwable t) { return null; }
    }

    private void diskSave(int i, int w, Bitmap bm) {
        File d = diskDir; if (d == null || bm == null) return;
        File tmp = new File(d, i + "_" + w + ".tmp"), out = new File(d, i + "_" + w + ".jpg");
        java.io.FileOutputStream fo = null;
        try {
            fo = new java.io.FileOutputStream(tmp);
            boolean ok = bm.compress(Bitmap.CompressFormat.JPEG, 90, fo);
            fo.flush(); fo.close(); fo = null;
            if (ok) tmp.renameTo(out); else tmp.delete();
        } catch (Throwable t) {
            try { tmp.delete(); } catch (Throwable ignored) { }
        } finally { if (fo != null) try { fo.close(); } catch (Throwable ignored) { } }
    }

    /** True when every page on screen already has its sharp bitmap (or cannot get one right now). */
    private boolean visibleReady() {
        if (pageCount == 0) return false;
        int last = Math.min(pageCount - 1, visLast);
        for (int i = visFirst; i <= last; i++) if (cache.get(i) == null && !coolingDown(i)) return false;
        return true;
    }
    private final RectF dstRect = new RectF(), patchRect = new RectF();

    // ---------------------------------------------------------------- look
    private int theme = 0;            // 0 paper, 1 sepia, 2 night
    private float dim = 0f;
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint fill = new Paint();
    private final Paint hitPaint = new Paint();
    private final Paint dimPaint = new Paint();
    private int bgColor = 0xFFE9E7E2, pageColor = Color.WHITE;

    // ---------------------------------------------------------------- search
    private final List<Hit> hits = new ArrayList<>();
    private int currentHit = -1;
    private volatile int searchToken = 0;

    // ---------------------------------------------------------------- touch
    private final GestureDetector gd;
    private final ScaleGestureDetector sgd;
    private final OverScroller scroller;
    private boolean scaling = false;

    // ---------------------------------------------------------------- selection + highlights
    private final float dens;
    private final MuAnnotStore store = new MuAnnotStore();
    private final MuInk ink = new MuInk();
    private boolean inkStroking = false;
    private final List<MuAnnot> eraseTouched = new ArrayList<>(), eraseOld = new ArrayList<>();   // freehand erase in progress: marks the finger touched, and their copies from before
    private float[] eraseTrail = new float[128];                                                  // finger path, page-width units
    private int eraseTrailN = 0;
    private float eraseX, eraseY;
    private final Paint eraseRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int inkPage = -1;
    private long lastNoLine = 0L;
    private Runnable annotChanged;
    private final LruCache<Integer, PageText> textCache = new LruCache<>(24);
    private final Set<Integer> textLoading = java.util.Collections.synchronizedSet(new HashSet<Integer>());
    private PageText selPt;
    private int selPage = -1, selA = -1, selB = -1;
    private float[] selRects;
    private int dragMode = 0;                 // 0 none, 1 start handle, 2 end handle, 3 extending after the long-press
    private int fixedFirst, fixedLast;
    private float grabDy, lastTx, lastTy;
    private boolean touching = false, selShown = false;
    private String flashId;
    private long flashStart;
    private final Paint selPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hlPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint inkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmpR = new RectF();
    private int handleColor = 0xFF3B82F6;

    public MuPdfView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        dens = d;
        gap = 10 * d;
        maxPagePx = 900 * d;
        int maxKb = (int) (Runtime.getRuntime().maxMemory() / 1024);
        cache = new LruCache<Integer, Bitmap>(Math.max(16 * 1024, maxKb / 5)) {
            @Override protected int sizeOf(Integer k, Bitmap b) { return b.getByteCount() / 1024; }
        };
        lowCache = new LruCache<Integer, Bitmap>(Math.max(4 * 1024, maxKb / 16)) {
            @Override protected int sizeOf(Integer k, Bitmap b) { return b.getByteCount() / 1024; }
        };
        scroller = new OverScroller(c);
        gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { scroller.forceFinished(true); return true; }
            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (scaling || inkStroking) return true;
                scrollBy(dx, dy); host_userScroll(); return true;
            }
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (scaling || inkStroking) return true;
                scrollDir = vy < 0 ? 1 : -1;
                scroller.fling((int) scrollX, (int) scrollY, (int) -vx, (int) -vy, 0, (int) maxScrollX(), 0, (int) maxScrollY());
                postInvalidateOnAnimation(); host_userScroll(); return true;
            }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) { if (!ink.active()) handleTap(e.getX(), e.getY()); return true; }
            @Override public void onLongPress(MotionEvent e) { if (stk != null) return; if (!scaling && !ink.active()) startSelectionAt(e.getX(), e.getY()); }
            @Override public boolean onDoubleTap(MotionEvent e) {
                if (ink.active()) return true;
                setZoomAround(zoom > 1.3f ? 1f : Math.min(maxZoom, 2.4f), e.getX(), e.getY()); return true;
            }
        });
        sgd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(ScaleGestureDetector d) { scaling = true; scroller.forceFinished(true); return true; }
            @Override public boolean onScale(ScaleGestureDetector d) {
                setZoomAround(zoom * d.getScaleFactor(), d.getFocusX(), d.getFocusY()); return true;
            }
            @Override public void onScaleEnd(ScaleGestureDetector d) { scaling = false; scheduleDetail(); }
        });
        store.setListener(new MuAnnotStore.Listener() {
            @Override public void onChanged() { invalidate(); if (annotChanged != null) annotChanged.run(); }
        });
        hitPaint.setStyle(Paint.Style.FILL);
        selPaint.setStyle(Paint.Style.FILL);
        hlPaint.setStyle(Paint.Style.FILL);
        inkPaint.setStyle(Paint.Style.FILL);
        inkPaint.setStrokeCap(Paint.Cap.ROUND);
        knobPaint.setStyle(Paint.Style.FILL);
        setLayerType(LAYER_TYPE_NONE, null);
        applyTheme();
    }

    private void submit(Task t) { try { exec.execute(t); } catch (Throwable ignored) { } }
    private void submitB(Task t) { try { execB.execute(t); } catch (Throwable ignored) { } }

    /** Second document instance, only ever touched from the B worker thread. */
    private Document docB() throws Exception {
        if (docB == null) {
            Document d = Document.openDocument(path);
            if (d.needsPassword() && (password == null || !d.authenticatePassword(password))) throw new RuntimeException("locked");
            docB = d;
        }
        return docB;
    }

    public void setHost(Host h) { host = h; }
    private void host_userScroll() { if (host != null) host.onUserScroll(); }

    // ================================================================= opening
    public void open(final String filePath, final String password, final int startPage0, final float startFrac) {
        path = filePath;
        openedAtMs = System.currentTimeMillis();
        submit(new Task(0, new Runnable() {
            @Override public void run() {
                try {
                    if (diskDir == null) diskDir = computeDiskDir(filePath);
                    if (doc == null) {
                        doc = Document.openDocument(filePath);
                    }
                    if (doc.needsPassword()) {
                        boolean ok = password != null && doc.authenticatePassword(password);
                        if (!ok) {
                            final boolean wrong = password != null;
                            ui.post(new Runnable() { @Override public void run() { if (host != null) host.onNeedPassword(wrong); } });
                            return;
                        }
                    }
                    MuPdfView.this.password = password;
                    final int n = doc.countPages();
                    if (n <= 0) throw new RuntimeException("Empty document");
                    final float[] w = new float[n], h = new float[n];
                    final boolean[] s = new boolean[n];
                    int first = Math.max(0, Math.min(n - 1, startPage0));
                    measure(0, w, h, s);
                    if (first != 0) measure(first, w, h, s);
                    final List<OutlineItem> items = loadOutlineSafe();
                    ui.post(new Runnable() { @Override public void run() {
                        if (destroyed) return;
                        pageCount = n; pw = w; ph = h; sized = s;
                        defaultRatio = s[0] ? h[0] / w[0] : 1.414f;
                        haveSizes0 = true;
                        pendingAnchorPage = Math.max(0, Math.min(n - 1, startPage0)); pendingAnchorFrac = startFrac;
                        relayout(false);
                        if (top1 != null) { restoreAnchor(pendingAnchorPage, pendingAnchorFrac); pendingAnchorPage = -1; }
                        if (host != null) { host.onOpened(n, items != null && !items.isEmpty()); host.onOutline(items); }
                        invalidate();
                        measureRest(n);
                    } });
                } catch (final Throwable t) {
                    ui.post(new Runnable() { @Override public void run() { if (host != null) host.onOpenFailed(String.valueOf(t.getMessage())); } });
                }
            }
        }));
    }

    private void measure(int i, float[] w, float[] h, boolean[] s) {
        Page p = null;
        try {
            p = doc.loadPage(i);
            com.artifex.mupdf.fitz.Rect b = p.getBounds();
            float ww = b.x1 - b.x0, hh = b.y1 - b.y0;
            if (ww > 1 && hh > 1) { w[i] = ww; h[i] = hh; s[i] = true; }
        } catch (Throwable ignored) {
        } finally { if (p != null) try { p.destroy(); } catch (Throwable ignored) { } }
    }

    private void measureRest(final int n) {
        if (destroyed) return;
        // Measuring every page also opens the 2nd copy of the document. Do it only once the first screen is
        // drawn (or after 8 s), so the first page gets all the CPU instead of sharing it.
        if (!visibleReady() && System.currentTimeMillis() - openedAtMs < 8000L) {
            ui.postDelayed(new Runnable() { @Override public void run() { measureRest(n); } }, 300);
            return;
        }
        final int batch = 8;
        for (int start = 0; start < n; start += batch) {
            final int a = start, b = Math.min(n, start + batch);
            submitB(new Task(5, new Runnable() {
                @Override public void run() {
                    if (destroyed) return;
                    final float[] w = new float[b - a], h = new float[b - a]; final boolean[] s = new boolean[b - a];
                    for (int i = a; i < b; i++) {
                        if (sized[i]) { w[i - a] = pw[i]; h[i - a] = ph[i]; s[i - a] = true; continue; }
                        Page p = null;
                        try {
                            p = docB().loadPage(i);
                            com.artifex.mupdf.fitz.Rect r = p.getBounds();
                            float ww = r.x1 - r.x0, hh = r.y1 - r.y0;
                            if (ww > 1 && hh > 1) { w[i - a] = ww; h[i - a] = hh; s[i - a] = true; }
                        } catch (Throwable ignored) {
                        } finally { if (p != null) try { p.destroy(); } catch (Throwable ignored) { } }
                    }
                    ui.post(new Runnable() { @Override public void run() {
                        if (destroyed) return;
                        int ap = anchorPage(); float af = anchorFrac(ap);
                        boolean changed = false;
                        for (int i = a; i < b; i++) {
                            if (s[i - a] && (!sized[i] || pw[i] != w[i - a] || ph[i] != h[i - a])) {
                                pw[i] = w[i - a]; ph[i] = h[i - a]; sized[i] = true; changed = true;
                            }
                        }
                        if (changed) { relayout(false); restoreAnchor(ap, af); invalidate(); }
                    } });
                }
            }));
        }
    }

    private List<OutlineItem> loadOutlineSafe() {
        try {
            Outline[] o = doc.loadOutline();
            if (o == null) return new ArrayList<>();
            List<OutlineItem> out = new ArrayList<>();
            flatten(o, 0, out);
            return out;
        } catch (Throwable t) { return new ArrayList<>(); }
    }

    private void flatten(Outline[] arr, int level, List<OutlineItem> out) {
        if (arr == null || out.size() > 3000) return;
        for (Outline o : arr) {
            if (o == null) continue;
            int pg = resolvePage(o, o.uri);
            out.add(new OutlineItem(o.title == null ? "" : o.title.trim(), level, pg));
            if (o.down != null) flatten(o.down, level + 1, out);
        }
    }

    /** Resolves an outline entry or link to a 0-based page. Tolerates API differences between MuPDF versions. */
    private int resolvePage(Object target, String uri) {
        try {
            for (Method m : Document.class.getMethods()) {
                if (!m.getName().equals("resolveLink") || m.getParameterTypes().length != 1) continue;
                Class<?> pt = m.getParameterTypes()[0];
                Object arg = null;
                if (pt != String.class && target != null && pt.isInstance(target)) arg = target;
                else if (pt == String.class && uri != null) arg = uri;
                if (arg == null) continue;
                Object res = m.invoke(doc, arg);
                if (res instanceof Integer) return (Integer) res;
                if (res instanceof Location) {
                    Location l = (Location) res;
                    try { return doc.pageNumberFromLocation(l); } catch (Throwable t) { return l.page; }
                }
            }
        } catch (Throwable ignored) { }
        return -1;
    }

    // ================================================================= layout / scroll maths
    private void relayout(boolean keepAnchor) {
        int ap = keepAnchor ? anchorPage() : 0; float af = keepAnchor ? anchorFrac(ap) : 0f;
        int vw = getWidth();
        if (pageCount == 0 || vw <= 0) return;
        pageW1 = Math.min(vw, maxPagePx);
        if (top1 == null || top1.length != pageCount) { top1 = new float[pageCount]; h1 = new float[pageCount]; }
        float y = gap;
        for (int i = 0; i < pageCount; i++) {
            float ratio = (sized != null && sized[i]) ? ph[i] / pw[i] : defaultRatio;
            top1[i] = y; h1[i] = pageW1 * ratio; y += h1[i] + gap;
        }
        total1 = y;
        clampScroll();
        if (keepAnchor) restoreAnchor(ap, af);
    }

    private float contentW() { return Math.max(getWidth(), pageW1 * zoom); }
    private float contentH() { return total1 * zoom; }
    private float maxScrollX() { return Math.max(0, contentW() - getWidth()); }
    private float maxScrollY() { return Math.max(0, contentH() - getHeight()); }
    private void clampScroll() {
        scrollX = Math.max(0, Math.min(scrollX, maxScrollX()));
        scrollY = Math.max(0, Math.min(scrollY, maxScrollY()));
    }
    private void scrollBy(float dx, float dy) { if (dy != 0) scrollDir = dy > 0 ? 1 : -1; scrollX += dx; scrollY += dy; clampScroll(); onMoved(); postInvalidateOnAnimation(); }

    private float anchorY() { return getHeight() * 0.35f; }

    private int pageAtContentY(float yz) {
        if (top1 == null || pageCount == 0) return 0;
        float y = yz / zoom;
        int lo = 0, hi = pageCount - 1;
        while (lo < hi) {
            int mid = (lo + hi + 1) >>> 1;
            if (top1[mid] <= y) lo = mid; else hi = mid - 1;
        }
        return lo;
    }

    private int anchorPage() { return pageAtContentY(scrollY + anchorY()); }
    private float anchorFrac(int p) {
        if (top1 == null || p < 0 || p >= pageCount) return 0f;
        float f = ((scrollY + anchorY()) / zoom - top1[p]) / Math.max(1f, h1[p]);
        return Math.max(0f, Math.min(1f, f));
    }
    private void restoreAnchor(int p, float frac) {
        if (top1 == null || p < 0 || p >= pageCount) return;
        scrollY = (top1[p] + frac * h1[p]) * zoom - anchorY();
        clampScroll(); onMoved();
    }

    public int currentPage0() { return anchorPage(); }
    public float currentFrac() { return anchorFrac(anchorPage()); }
    public int pageCount() { return pageCount; }
    public float zoom() { return zoom; }

    public void goToPage(int p0) {
        if (top1 == null) return;
        p0 = Math.max(0, Math.min(pageCount - 1, p0));
        scroller.forceFinished(true);
        scrollY = top1[p0] * zoom - gap * zoom;
        clampScroll(); onMoved(); invalidate();
    }

    public void setScrollListener(ScrollListener l) { scrollListener = l; }

    /** Jumps to a position in the book: 0 = top, 1 = end (used while the scrub handle is dragged). */
    public void scrollToFraction(float f) {
        if (top1 == null) return;
        scroller.forceFinished(true);
        float target = Math.max(0f, Math.min(1f, f)) * maxScrollY();
        scrollBy(0, target - scrollY);
    }

    /** While scrubbing, heavy books do not start new page renders for pages that are only flying past. */
    public void setScrubbing(boolean on) {
        scrubbing = on;
        if (!on) { invalidate(); scheduleDetail(); }
    }

    public void resetZoom() { setZoomAround(1f, getWidth() / 2f, getHeight() / 2f); }

    private void setZoomAround(float z, float fx, float fy) {
        z = Math.max(minZoom, Math.min(maxZoom, z));
        if (Math.abs(z - zoom) < 0.0001f) return;
        float cx = (scrollX + fx) / zoom, cy = (scrollY + fy) / zoom;
        zoom = z;
        // horizontally centred when narrower than the view
        scrollX = cx * zoom - fx;
        scrollY = cy * zoom - fy;
        clampScroll(); onMoved(); invalidate();
        if (!scaling) scheduleDetail();
    }

    private void onMoved() {
        if (pageCount == 0) return;
        if (scrollListener != null) {
            float mx = maxScrollY(), f = mx > 1f ? scrollY / mx : 0f;
            if (Math.abs(f - lastFracNotified) > 0.0002f) { lastFracNotified = f; scrollListener.onScrolled(f); }
        }
        int p = anchorPage();
        if (p != lastPage0) { lastPage0 = p; if (host != null) host.onPageChanged(p, pageCount); }
        if (selPage >= 0 && dragMode == 0) selMoved();
    }

    // ================================================================= look
    public void setLook(int themeIdx, float dimAmount) {
        theme = themeIdx; dim = dimAmount; applyTheme();
        synchronized (patches) { patches.clear(); }
        invalidate();
    }

    private void applyTheme() {
        if (theme == 2) { bgColor = 0xFF0B0F0D; pageColor = 0xFF111613; }
        else if (theme == 1) { bgColor = 0xFFD9CFB8; pageColor = 0xFFF4ECD8; }
        else { bgColor = 0xFFE9E7E2; pageColor = Color.WHITE; }
        ColorMatrix cm = new ColorMatrix();
        if (theme == 2) {
            cm.set(new float[]{
                    -0.86f, 0, 0, 0, 255 * 0.86f,
                    0, -0.89f, 0, 0, 255 * 0.89f,
                    0, 0, -0.87f, 0, 255 * 0.87f,
                    0, 0, 0, 1, 0});
            bmpPaint.setColorFilter(new ColorMatrixColorFilter(cm));
        } else if (theme == 1) {
            cm.setScale(0.957f, 0.925f, 0.847f, 1f);
            bmpPaint.setColorFilter(new ColorMatrixColorFilter(cm));
        } else {
            bmpPaint.setColorFilter(null);
        }
        dimPaint.setColor(Color.argb((int) (Math.max(0f, Math.min(0.7f, dim)) * 255), 0, 0, 0));
    }

    public int backgroundColor() { return bgColor; }

    // ================================================================= drawing
    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (pageCount > 0) {
            if (w != ow) { synchronized (cache) { cache.evictAll(); } synchronized (lowCache) { lowCache.evictAll(); } synchronized (patches) { patches.clear(); } }
            if (top1 == null && pendingAnchorPage >= 0) {
                relayout(false); restoreAnchor(pendingAnchorPage, pendingAnchorFrac); pendingAnchorPage = -1;
            } else relayout(true);
            invalidate();
        }
    }

    @Override public void computeScroll() {
        if (scroller.computeScrollOffset()) {
            flinging = true;
            scrollX = scroller.getCurrX(); scrollY = scroller.getCurrY();
            clampScroll(); onMoved(); postInvalidateOnAnimation();
        } else if (scroller.isFinished()) {
            if (flinging) { flinging = false; invalidate(); }   // fling ended -> render look-ahead pages now
            // settled -> sharpen
            if (zoom > 1.15f) scheduleDetail();
        }
    }

    @Override protected void onDraw(Canvas canvas) {
        canvas.drawColor(bgColor);
        if (pageCount == 0 || top1 == null) return;
        int vw = getWidth(), vh = getHeight();
        float cw = contentW();
        float left0 = (cw - pageW1 * zoom) / 2f - scrollX;
        int first = pageAtContentY(scrollY);
        int last = pageAtContentY(scrollY + vh);
        visFirst = first; visLast = last; curZoomForTasks = zoom;
        cancelStaleJobs();
        for (int i = first; i <= last && i < pageCount; i++) {
            float t = top1[i] * zoom - scrollY;
            float w = pageW1 * zoom, h = h1[i] * zoom;
            dstRect.set(left0, t, left0 + w, t + h);
            RectF dst = dstRect;
            fill.setColor(pageColor);
            canvas.drawRect(dst, fill);
            Bitmap b = cache.get(i);
            if (b == null) b = lowCache.get(i);
            if (b != null) canvas.drawBitmap(b, null, dst, bmpPaint);
            Patch pt;
            synchronized (patches) { pt = patches.get(i); }
            if (pt != null && pt.bmp != null && !pt.bmp.isRecycled()) {
                float k = zoom / pt.zoom;
                float pl = left0 + pt.x * k, ptp = t + pt.y * k;
                patchRect.set(pl, ptp, pl + pt.w * k, ptp + pt.h * k);
                canvas.drawBitmap(pt.bmp, null, patchRect, bmpPaint);
            }
            drawHits(canvas, i, left0, t, w, h);
            if (sized[i]) {
                float k = w / pw[i];
                if (store.size() > 0 || ink.cur != null) drawHighlights(canvas, i, left0, t, k);
                if (i == selPage && selRects != null) drawSelection(canvas, left0, t, k);
            }
        }
        if (selPage >= 0 && selRects != null && selPage >= first && selPage <= last) drawHandles(canvas, left0);
        if (inkStroking && ink.tool == MuInk.ERASER && ink.eraseMode == MuInk.FREEHAND) drawEraserRing(canvas);
        if (flashId != null) {
            if (SystemClock.uptimeMillis() - flashStart > 1600L) flashId = null; else postInvalidateOnAnimation();
        }
        if (!flinging && !scrubbing) prefetchText(first, last);
        if (needsWork()) { kickPump(); kickPumpB(); }
        if (dim > 0.001f) canvas.drawRect(0, 0, vw, vh, dimPaint);
        if (zoom > 1.15f && !scaling && scroller.isFinished()) scheduleDetailOnce();
    }

    private void drawHits(Canvas canvas, int page0, float left, float top, float w, float h) {
        if (hits.isEmpty() || !sized[page0]) return;
        float sx = w / pw[page0], sy = h / ph[page0];
        for (int k = 0; k < hits.size(); k++) {
            Hit ht = hits.get(k);
            if (ht.page0 != page0) continue;
            hitPaint.setColor(k == currentHit ? 0x77FF8A00 : 0x55FFD800);
            canvas.drawRect(left + ht.x0 * sx, top + ht.y0 * sy, left + ht.x1 * sx, top + ht.y1 * sy, hitPaint);
        }
    }

    // ================================================================= rendering requests
    // ---- page render pump -------------------------------------------------------------------
    // One render per task; before every render it re-decides what is needed *right now* (visible pages
    // first, then the pages in the scroll direction), so a fast fling never works on pages it has left.
    private int[] candidates() {
        int first = visFirst, last = Math.min(pageCount - 1, visLast);
        ArrayList<Integer> c = new ArrayList<>();
        for (int i = first; i <= last; i++) c.add(i);
        int ahead = scrollDir >= 0 ? 1 : -1;
        int lookAhead = adaptiveLookAhead(last - first + 1);
        for (int k = 1; k <= lookAhead; k++) { int i = ahead > 0 ? last + k : first - k; if (i >= 0 && i < pageCount) c.add(i); }
        for (int k = 1; k <= 1; k++) { int i = ahead > 0 ? first - k : last + k; if (i >= 0 && i < pageCount) c.add(i); }
        int[] out = new int[c.size()];
        for (int i = 0; i < out.length; i++) out[i] = c.get(i);
        return out;
    }

    /** How many pages ahead we may pre-render without evicting pages that are on screen (cache is byte-limited). */
    private int adaptiveLookAhead(int visCount) {
        float pageKb = Math.max(1f, pageW1 * pageW1 * defaultRatio * 4f / 1024f);
        int fit = (int) (cache.maxSize() / pageKb);          // full pages the cache can hold
        int spare = fit - visCount - 1;                      // minus visible pages and one behind
        return Math.max(0, Math.min(3, spare));
    }

    private boolean needsWork() {
        if (pageCount == 0 || destroyed) return false;
        for (int i : candidates()) if (cache.get(i) == null && !coolingDown(i)) return true;
        return false;
    }

    private void kickPumpB() {
        if (destroyed || flinging) return;
        if (pumpingB.compareAndSet(false, true)) submitB(new Task(3, pumpTaskB));
    }

    /** Pre-renders the pages AFTER the visible ones on the second core, while worker A keeps the visible pages first. */
    private final Runnable pumpTaskB = new Runnable() {
        @Override public void run() {
            boolean more = false;
            try {
                if (destroyed || pageCount == 0 || flinging || (scrubbing && avgFullMs > 150f)) return;
                if (!visibleReady()) return;   // never compete with the page the reader is waiting for
                int[] cand = candidates();
                int visCount = Math.max(0, Math.min(pageCount - 1, visLast) - visFirst + 1);
                int vw = Math.max(1, (int) pageW1);
                for (int k = visCount; k < cand.length; k++) {
                    int i = cand[k];
                    if (cache.get(i) == null && !coolingDown(i) && inFlight.add(i)) {
                        try { renderInto(docB(), i, vw, cache, true); } finally { inFlight.remove(i); }
                        more = true; return;
                    }
                }
                // Everything on screen and just ahead is ready. A heavy book keeps rendering the next pages to the
                // DISK cache in the background, so they open instantly later (also after closing the book).
                if (diskDir != null && avgFullMs > 600f) {
                    int dirn = scrollDir >= 0 ? 1 : -1;
                    for (int k = 1; k <= PREFETCH_PAGES; k++) {
                        int i = dirn > 0 ? Math.min(pageCount - 1, visLast) + k : visFirst - k;
                        if (i < 0 || i >= pageCount) break;
                        if (cache.get(i) != null || diskHas(i, vw) || coolingDown(i)) continue;
                        if (inFlight.add(i)) {
                            try { prefetchInto(docB(), i, vw); } finally { inFlight.remove(i); }
                            more = true; return;
                        }
                    }
                }
            } catch (Throwable ignored) {
            } finally {
                pumpingB.set(false);
                if (more && !destroyed) kickPumpB();
            }
        }
    };

    private void kickPump() {
        if (destroyed) return;
        if (pumping.compareAndSet(false, true)) submit(new Task(1, pumpTask));
    }

    private final Runnable pumpTask = new Runnable() {
        @Override public void run() {
            boolean more = false;
            try {
                if (destroyed || doc == null || (scrubbing && avgFullMs > 150f)) return;
                int[] cand = candidates();
                int vw = Math.max(1, (int) pageW1);
                // 1) quick previews for pages that are on screen
                int visCount = Math.max(0, Math.min(pageCount - 1, visLast) - visFirst + 1);
                for (int k = 0; k < cand.length; k++) {
                    int i = cand[k];
                    if (k < visCount && avgFullMs > 90f && cache.get(i) == null && lowCache.get(i) == null && !coolingDown(i) && !diskHas(i, vw)) {
                        renderInto(doc, i, Math.max(1, vw / 3), lowCache, false);
                        more = true; return;
                    }
                }
                // 2) full-resolution pages, nearest first
                int limit = flinging ? Math.min(visCount, cand.length) : cand.length;
                for (int k = 0; k < limit; k++) {
                    int i = cand[k];
                    if (cache.get(i) == null && !coolingDown(i) && inFlight.add(i)) {
                        try { renderInto(doc, i, vw, cache, false); } finally { inFlight.remove(i); }
                        more = true; return;
                    }
                }
            } catch (Throwable ignored) {
            } finally {
                pumping.set(false);
                if (more && !destroyed) kickPump();
            }
        }
    };

    /** Renders one page only into the disk cache (nothing stays in memory). */
    private void prefetchInto(Document d, int i, int w) {
        Page p = null;
        final Job job = new Job(i, newCookie(), true);
        jobB = job;
        boolean failed = false;
        try {
            p = d.loadPage(i);
            com.artifex.mupdf.fitz.Rect b = p.getBounds();
            float rbw = b.x1 - b.x0, rbh = b.y1 - b.y0;
            float ratio = (rbw > 1 && rbh > 1) ? rbh / rbw : defaultRatio;
            int h = Math.max(1, Math.round(w * ratio));
            Bitmap bm = renderPatch(p, w, h, 0, 0, w, h, job.cookie);
            if (job.cancelled) bm = null;
            if (bm != null) { diskSave(i, w, bm); try { bm.recycle(); } catch (Throwable ignored) { } }
            else if (!job.cancelled) failed = true;
        } catch (Throwable t) {
            if (!job.cancelled) failed = true;
        } finally {
            if (p != null) try { p.destroy(); } catch (Throwable ignored) { }
            if (jobB == job) jobB = null;
        }
        if (failed) noteFailure(i);
    }

    private void renderInto(Document d, final int i, int w, LruCache<Integer, Bitmap> target, boolean onB) {
        Page p = null;
        long t0 = System.nanoTime();
        float rbw = 0, rbh = 0;
        final Job job = new Job(i, newCookie());
        if (onB) jobB = job; else jobA = job;
        boolean failed = false;
        try {
            p = d.loadPage(i);
            com.artifex.mupdf.fitz.Rect b = p.getBounds();
            rbw = b.x1 - b.x0; rbh = b.y1 - b.y0;
            float ratio = (rbw > 1 && rbh > 1) ? rbh / rbw : ((sized != null && sized[i]) ? ph[i] / pw[i] : defaultRatio);
            int h = Math.max(1, Math.round(w * ratio));
            Bitmap bm = null;
            boolean fromDisk = false;
            if (target == cache) { bm = diskLoad(i, w); fromDisk = bm != null; }      // rendered before: instant
            if (bm == null) bm = renderPatch(p, w, h, 0, 0, w, h, job.cookie);
            if (job.cancelled) bm = null;                    // stopped half-way: a half-drawn page is never cached
            if (bm != null) {
                target.put(i, bm);
                clearFailure(i);
                if (target == cache && !fromDisk) {
                    long ms = (System.nanoTime() - t0) / 1000000L;
                    avgFullMs = avgFullMs * 0.7f + ms * 0.3f;
                    if (ms > 250L) diskSave(i, w, bm);       // only pages that were expensive are worth keeping
                }
            } else if (!job.cancelled) failed = true;
        } catch (Throwable t) {
            if (!job.cancelled) failed = true;
        } finally {
            if (p != null) try { p.destroy(); } catch (Throwable ignored) { }
            if (onB) { if (jobB == job) jobB = null; } else { if (jobA == job) jobA = null; }
        }
        if (failed) noteFailure(i);                          // do not retry this page in a tight loop
        final float fw = rbw, fh = rbh;
        ui.post(new Runnable() { @Override public void run() {
            if (destroyed) return;
            if (sized != null && i < pageCount && !sized[i] && fw > 1 && fh > 1) {
                int ap = anchorPage(); float af = anchorFrac(ap);
                pw[i] = fw; ph[i] = fh; sized[i] = true;
                relayout(false); restoreAnchor(ap, af);
            }
            invalidate();
        } });
    }

    // ---- MuPDF drawing ------------------------------------------------------------------------------
    // Draws the rectangle (px,py,pw,ph) -- in pixels of a page that is pageW x pageH pixels in total -- into a
    // new bitmap. Uses only the basic Device API (works across MuPDF 1.2x versions).
    private static Bitmap renderPatch(Page p, int pageW, int pageH, int px, int py, int pw, int ph) throws Exception {
        return renderPatch(p, pageW, pageH, px, py, pw, ph, null);
    }

    private static Bitmap renderPatch(Page p, int pageW, int pageH, int px, int py, int pw, int ph, Object cookie) throws Exception {
        com.artifex.mupdf.fitz.Rect b = p.getBounds();
        float bw = Math.max(1f, b.x1 - b.x0), bh = Math.max(1f, b.y1 - b.y0);
        float sx = pageW / bw, sy = pageH / bh;
        com.artifex.mupdf.fitz.Matrix ctm = new com.artifex.mupdf.fitz.Matrix(sx, 0f, 0f, sy, -b.x0 * sx, -b.y0 * sy);
        Bitmap bm = Bitmap.createBitmap(Math.max(1, pw), Math.max(1, ph), Bitmap.Config.ARGB_8888);
        bm.eraseColor(Color.WHITE);
        com.artifex.mupdf.fitz.Device dev = newDrawDevice(bm, px, py);
        try {
            try {
                p.run(dev, ctm, (com.artifex.mupdf.fitz.Cookie) cookie);
                dev.close();
            } catch (OutOfMemoryError oom) {
                throw oom;
            } catch (Throwable runError) {
                // A page that breaks half-way (one bad image or font) keeps what was drawn so far
                // instead of staying white; an aborted render is thrown away by the caller.
            }
        } finally {
            try { dev.destroy(); } catch (Throwable ignored) { }
        }
        try { bm.prepareToDraw(); } catch (Throwable ignored) { }   // upload to the GPU here, not during the first frame
        return bm;
    }

    private static com.artifex.mupdf.fitz.Device newDrawDevice(Bitmap bm, int px, int py) throws Exception {
        try {
            return (com.artifex.mupdf.fitz.Device) AndroidDrawDevice.class
                    .getConstructor(Bitmap.class, int.class, int.class).newInstance(bm, px, py);
        } catch (NoSuchMethodException e) {
            return (com.artifex.mupdf.fitz.Device) AndroidDrawDevice.class
                    .getConstructor(Bitmap.class, int.class, int.class, int.class, int.class, int.class, int.class)
                    .newInstance(bm, px, py, px, py, px + bm.getWidth(), py + bm.getHeight());
        }
    }

    private boolean detailQueued = false;
    private final Runnable detailRunnable = new Runnable() {
        @Override public void run() { detailQueued = false; requestDetail(); }
    };
    private void scheduleDetail() { removeCallbacks(detailRunnable); detailQueued = true; postDelayed(detailRunnable, 90); }
    /** Called from onDraw (every frame): queue at most one pending request instead of re-posting each frame. */
    private void scheduleDetailOnce() { if (!detailQueued) { detailQueued = true; postDelayed(detailRunnable, 90); } }

    /** Re-renders the visible part of each visible page at the current zoom (only when zoomed in). */
    private void requestDetail() {
        if (destroyed || pageCount == 0 || zoom <= 1.15f || top1 == null) return;
        int vw = getWidth(), vh = getHeight();
        float cw = contentW();
        float left0 = (cw - pageW1 * zoom) / 2f - scrollX;
        int first = pageAtContentY(scrollY), last = pageAtContentY(scrollY + vh);
        prunePatches(first, last);
        for (int i = first; i <= last && i < pageCount; i++) {
            float t = top1[i] * zoom - scrollY;
            float w = pageW1 * zoom, h = h1[i] * zoom;
            // visible rectangle of the page in page-pixel coordinates, with a margin
            int margin = (int) (vh * 0.12f);
            int x0 = (int) Math.max(0, -left0 - margin), x1 = (int) Math.min(w, vw - left0 + margin);
            int y0 = (int) Math.max(0, -t - margin), y1 = (int) Math.min(h, vh - t + margin);
            if (x1 - x0 < 8 || y1 - y0 < 8) continue;
            Patch have;
            synchronized (patches) { have = patches.get(i); }
            if (have != null && Math.abs(have.zoom - zoom) < 0.01f
                    && have.x <= x0 + margin / 2 && have.y <= y0 + margin / 2
                    && have.x + have.w >= x1 - margin / 2 && have.y + have.h >= y1 - margin / 2) continue;
            requestPatch(i, zoom, Math.round(w), Math.round(h), x0, y0, x1 - x0, y1 - y0);
        }
    }

    /** Sharp patches are big: keep only those of the pages on screen (and only for the current zoom). */
    private void prunePatches(int first, int last) {
        synchronized (patches) {
            java.util.Iterator<Map.Entry<Integer, Patch>> it = patches.entrySet().iterator();
            while (it.hasNext()) {
                Patch pt = it.next().getValue();
                if (pt.page0 < first - 1 || pt.page0 > last + 1 || Math.abs(pt.zoom - zoom) > 0.35f * zoom) it.remove();
            }
        }
    }

    private void requestPatch(final int i, final float z, final int pageWpx, final int pageHpx,
                              final int x, final int y, final int w, final int h) {
        synchronized (pendingPatch) { if (!pendingPatch.add(i)) return; }
        submitB(new Task(2, new Runnable() {
            @Override public void run() {
                Bitmap bm = null;
                try {
                    if (!destroyed && i >= visFirst - 1 && i <= visLast + 1 && Math.abs(curZoomForTasks - z) < 0.05f) {
                        Page p = docB().loadPage(i);
                        try { bm = renderPatch(p, pageWpx, pageHpx, x, y, w, h); }
                        finally { try { p.destroy(); } catch (Throwable ignored) { } }
                    }
                } catch (Throwable ignored) { }
                final Bitmap result = bm;
                ui.post(new Runnable() { @Override public void run() {
                    synchronized (pendingPatch) { pendingPatch.remove(i); }
                    if (destroyed) return;
                    if (result != null) {
                        Patch pt = new Patch(); pt.page0 = i; pt.zoom = z; pt.x = x; pt.y = y; pt.w = w; pt.h = h; pt.bmp = result;
                        synchronized (patches) { patches.put(i, pt); }
                        invalidate();
                        scheduleDetail();   // the view may have moved while rendering
                    }
                } });
            }
        }));
    }

    // ================================================================= touch
    @Override public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) touching = true;
        else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) touching = false;
        if (act == MotionEvent.ACTION_DOWN && selPage >= 0 && selRects != null) {
            int hnd = hitHandle(e.getX(), e.getY());
            if (hnd != 0) { beginHandleDrag(hnd, e); return true; }
        }
        if (stickerTouch(e)) return true;
        if (ink.active() && dragMode == 0 && inkTouch(e)) return true;
        if (dragMode != 0) return dragTouch(e);
        sgd.onTouchEvent(e);
        if (!sgd.isInProgress()) gd.onTouchEvent(e);
        if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            if (zoom > 1.15f) scheduleDetail();
        }
        return true;
    }

    private void handleTap(float x, float y) {
        if (selPage >= 0) { clearSelection(); return; }
        MuAnnot sk = stickerAt(x, y);
        if (sk != null) { if (host != null) host.onStickerTap(sk, stickerRect(sk)); return; }
        MuAnnot th = highlightAt(x, y);
        if (th != null) { if (host != null) host.onHighlightTap(th, anchorOf(th)); return; }
        if (pageCount == 0 || top1 == null) { if (host != null) host.onTap(); return; }
        float cw = contentW();
        float left0 = (cw - pageW1 * zoom) / 2f - scrollX;
        int p = pageAtContentY(scrollY + y);
        float t = top1[p] * zoom - scrollY;
        float w = pageW1 * zoom, h = h1[p] * zoom;
        if (!sized[p] || x < left0 || x > left0 + w || y < t || y > t + h) { if (host != null) host.onTap(); return; }
        final float px = (x - left0) / w * pw[p], py = (y - t) / h * ph[p];
        final int page = p;
        submit(new Task(0, new Runnable() {
            @Override public void run() {
                String uri = null; int target = -1; boolean hit = false;
                Page pg = null;
                try {
                    pg = doc.loadPage(page);
                    Link[] links = pg.getLinks();
                    if (links != null) {
                        for (Link l : links) {
                            com.artifex.mupdf.fitz.Rect b = l.getBounds();
                            if (b != null && px >= b.x0 && px <= b.x1 && py >= b.y0 && py <= b.y1) {
                                hit = true; uri = l.getURI();
                                if (uri != null && (uri.startsWith("http:") || uri.startsWith("https:") || uri.startsWith("mailto:"))) break;
                                target = resolvePage(l, uri);
                                break;
                            }
                        }
                    }
                } catch (Throwable ignored) {
                } finally { if (pg != null) try { pg.destroy(); } catch (Throwable ignored) { } }
                final boolean fh = hit; final String fu = uri; final int ft = target;
                ui.post(new Runnable() { @Override public void run() {
                    if (destroyed) return;
                    if (fh && ft >= 0) goToPage(ft);
                    else if (fh && fu != null && (fu.startsWith("http") || fu.startsWith("mailto:"))) { if (host != null) host.onExternalLink(fu); }
                    else if (host != null) host.onTap();
                } });
            }
        }));
    }

    // ================================================================= search
    public void search(final String query, final SearchListener listener) {
        final int token = ++searchToken;
        hits.clear(); currentHit = -1; invalidate();
        if (query == null || query.trim().isEmpty() || pageCount == 0) { if (listener != null) listener.onProgress(0, true); return; }
        final String q = query.trim();
        final int n = pageCount, batch = 4;
        for (int start = 0; start < n; start += batch) {
            final int a = start, b = Math.min(n, start + batch);
            submitB(new Task(6, new Runnable() {
                @Override public void run() {
                    if (destroyed || token != searchToken) return;
                    final List<Hit> found = new ArrayList<>();
                    for (int i = a; i < b && token == searchToken; i++) {
                        Page p = null;
                        try {
                            p = docB().loadPage(i);
                            collect(p, q, i, found);
                        } catch (Throwable ignored) {
                        } finally { if (p != null) try { p.destroy(); } catch (Throwable ignored) { } }
                    }
                    final boolean done = b >= n;
                    ui.post(new Runnable() { @Override public void run() {
                        if (destroyed || token != searchToken) return;
                        if (hits.size() < 800) hits.addAll(found);
                        if (currentHit < 0 && !hits.isEmpty()) { currentHit = 0; showHit(0); }
                        invalidate();
                        if (listener != null) listener.onProgress(hits.size(), done);
                    } });
                }
            }));
        }
    }

    private void collect(Page p, String q, int pageIdx, List<Hit> out) throws Exception {
        Method m = Page.class.getMethod("search", String.class);
        Object res = m.invoke(p, q);
        addHits(res, pageIdx, out);
    }

    private void addHits(Object o, int pageIdx, List<Hit> out) {
        if (o == null) return;
        if (o instanceof com.artifex.mupdf.fitz.Rect) {
            com.artifex.mupdf.fitz.Rect r = (com.artifex.mupdf.fitz.Rect) o;
            out.add(new Hit(pageIdx, r.x0, r.y0, r.x1, r.y1));
        } else if (o instanceof Quad) {
            Quad qd = (Quad) o;
            float x0 = Math.min(Math.min(qd.ul_x, qd.ll_x), Math.min(qd.ur_x, qd.lr_x));
            float x1 = Math.max(Math.max(qd.ul_x, qd.ll_x), Math.max(qd.ur_x, qd.lr_x));
            float y0 = Math.min(Math.min(qd.ul_y, qd.ll_y), Math.min(qd.ur_y, qd.lr_y));
            float y1 = Math.max(Math.max(qd.ul_y, qd.ll_y), Math.max(qd.ur_y, qd.lr_y));
            out.add(new Hit(pageIdx, x0, y0, x1, y1));
        } else if (o instanceof Object[]) {
            for (Object x : (Object[]) o) addHits(x, pageIdx, out);
        }
    }

    public int hitCount() { return hits.size(); }
    public int currentHitIndex() { return currentHit; }
    public void clearSearch() { searchToken++; hits.clear(); currentHit = -1; invalidate(); }

    public void nextHit(int dir) {
        if (hits.isEmpty()) return;
        currentHit = (currentHit + dir + hits.size()) % hits.size();
        showHit(currentHit); invalidate();
    }

    private void showHit(int k) {
        if (k < 0 || k >= hits.size() || top1 == null) return;
        Hit h = hits.get(k);
        if (h.page0 >= pageCount) return;
        float ratio = h1[h.page0] / (sized[h.page0] ? ph[h.page0] : 1f);
        float yz = (top1[h.page0] + h.y0 * ratio) * zoom;
        scroller.forceFinished(true);
        scrollY = yz - getHeight() * 0.3f;
        clampScroll(); onMoved();
    }

    // ================================================================= text selection + highlights
    private interface TextCb { void got(PageText pt); }

    /** Characters of one page in reading order, with their boxes in page points (origin = top-left of the page). */
    private static final class PageText {
        int n, lines, words;
        boolean failed;
        int[] cp, line, block, word, lineFirst, lineLast, wFirst, wLast;
        float[] x0, y0, x1, y1, lx0, ly0, lx1, ly1;
        boolean[] lineRtl;

        static PageText empty(boolean failed) {
            PageText t = new PageText();
            t.failed = failed;
            t.cp = new int[0]; t.line = new int[0]; t.block = new int[0]; t.word = new int[0];
            t.lineFirst = new int[0]; t.lineLast = new int[0]; t.wFirst = new int[0]; t.wLast = new int[0];
            t.x0 = new float[0]; t.y0 = new float[0]; t.x1 = new float[0]; t.y1 = new float[0];
            t.lx0 = new float[0]; t.ly0 = new float[0]; t.lx1 = new float[0]; t.ly1 = new float[0];
            t.lineRtl = new boolean[0];
            return t;
        }

        static boolean isSpace(int c) { return c <= 32 || c == 0xA0 || Character.isSpaceChar(c); }

        static PageText make(int n, int[] cp, int[] ln, int[] bl, float[] bx) {
            PageText t = empty(false);
            if (n == 0) return t;
            t.n = n; t.cp = cp; t.line = ln; t.block = bl;
            t.x0 = new float[n]; t.y0 = new float[n]; t.x1 = new float[n]; t.y1 = new float[n];
            for (int i = 0; i < n; i++) { t.x0[i] = bx[i * 4]; t.y0[i] = bx[i * 4 + 1]; t.x1[i] = bx[i * 4 + 2]; t.y1[i] = bx[i * 4 + 3]; }
            int lines = ln[n - 1] + 1;
            t.lines = lines;
            t.lineFirst = new int[lines]; t.lineLast = new int[lines];
            Arrays.fill(t.lineFirst, -1);
            for (int i = 0; i < n; i++) { int l = ln[i]; if (t.lineFirst[l] < 0) t.lineFirst[l] = i; t.lineLast[l] = i; }
            // words
            t.word = new int[n];
            int wc = 0; boolean prevSpace = true; int prevLine = -1;
            int[] wf = new int[64], wl = new int[64];
            for (int i = 0; i < n; i++) {
                if (isSpace(cp[i])) { t.word[i] = -1; prevSpace = true; continue; }
                if (prevSpace || ln[i] != prevLine) {
                    if (wc == wf.length) { wf = Arrays.copyOf(wf, wc * 2); wl = Arrays.copyOf(wl, wc * 2); }
                    wf[wc++] = i;
                }
                t.word[i] = wc - 1; wl[wc - 1] = i;
                prevSpace = false; prevLine = ln[i];
            }
            t.words = wc; t.wFirst = Arrays.copyOf(wf, wc); t.wLast = Arrays.copyOf(wl, wc);
            // line boxes + direction
            t.lx0 = new float[lines]; t.ly0 = new float[lines]; t.lx1 = new float[lines]; t.ly1 = new float[lines];
            t.lineRtl = new boolean[lines];
            boolean[] known = new boolean[lines];
            int rtlLines = 0, ltrLines = 0;
            for (int l = 0; l < lines; l++) {
                if (t.lineFirst[l] < 0) continue;
                float a = Float.MAX_VALUE, b = Float.MAX_VALUE, c = -Float.MAX_VALUE, d = -Float.MAX_VALUE;
                int firstI = -1, lastI = -1;
                for (int i = t.lineFirst[l]; i <= t.lineLast[l]; i++) {
                    if (t.word[i] < 0 || t.x1[i] - t.x0[i] <= 0.01f || t.y1[i] - t.y0[i] <= 0.01f) continue;
                    a = Math.min(a, t.x0[i]); b = Math.min(b, t.y0[i]); c = Math.max(c, t.x1[i]); d = Math.max(d, t.y1[i]);
                    if (firstI < 0) firstI = i;
                    lastI = i;
                }
                if (firstI < 0) continue;
                t.lx0[l] = a; t.ly0[l] = b; t.lx1[l] = c; t.ly1[l] = d;
                if (lastI != firstI) {
                    float c0 = (t.x0[firstI] + t.x1[firstI]) / 2f, c1 = (t.x0[lastI] + t.x1[lastI]) / 2f;
                    if (Math.abs(c0 - c1) > 2f) { known[l] = true; t.lineRtl[l] = c0 > c1; if (t.lineRtl[l]) rtlLines++; else ltrLines++; }
                }
            }
            boolean pageRtl = rtlLines > ltrLines;
            for (int l = 0; l < lines; l++) if (!known[l]) t.lineRtl[l] = pageRtl;
            return t;
        }

        /** Nearest letter to a point (page points). limit: give up when the point is far from every line. */
        int charAt(float px, float py, boolean limit) {
            int bl = -1; float bs = Float.MAX_VALUE;
            for (int l = 0; l < lines; l++) {
                if (ly1[l] <= ly0[l]) continue;
                float dy = py < ly0[l] ? ly0[l] - py : (py > ly1[l] ? py - ly1[l] : 0f);
                float dx = px < lx0[l] ? lx0[l] - px : (px > lx1[l] ? px - lx1[l] : 0f);
                float s = dy + dx * 0.25f;
                if (s < bs) { bs = s; bl = l; }
            }
            if (bl < 0) return -1;
            if (limit) {
                float dy = py < ly0[bl] ? ly0[bl] - py : (py > ly1[bl] ? py - ly1[bl] : 0f);
                if (dy > Math.max(8f, (ly1[bl] - ly0[bl]) * 0.9f)) return -1;
            }
            int best = -1; float bd = Float.MAX_VALUE;
            for (int i = lineFirst[bl]; i <= lineLast[bl]; i++) {
                if (word[i] < 0) continue;
                float dx = px < x0[i] ? x0[i] - px : (px > x1[i] ? px - x1[i] : 0f);
                float cd = dx + 0.001f * Math.abs(px - (x0[i] + x1[i]) / 2f);
                if (cd < bd) { bd = cd; best = i; }
            }
            return best;
        }

        /** One box per line for the letters a..b (the gaps between words are included). */
        float[] rectsFor(int a, int b) {
            float[] out = new float[16]; int m = 0;
            int i = a;
            while (i <= b) {
                int l = line[i];
                int e = Math.min(b, lineLast[l]);
                float rx0 = Float.MAX_VALUE, rx1 = -Float.MAX_VALUE;
                for (int k = i; k <= e; k++) {
                    if (word[k] < 0 || x1[k] - x0[k] <= 0.01f) continue;
                    rx0 = Math.min(rx0, x0[k]); rx1 = Math.max(rx1, x1[k]);
                }
                if (rx1 > rx0 && ly1[l] > ly0[l]) {
                    if (m + 4 > out.length) out = Arrays.copyOf(out, out.length * 2);
                    out[m++] = rx0 - 0.5f; out[m++] = ly0[l] - 0.5f; out[m++] = rx1 + 0.5f; out[m++] = ly1[l] + 0.5f;
                }
                i = e + 1;
            }
            return Arrays.copyOf(out, m);
        }

        String textFor(int a, int b) {
            StringBuilder sb = new StringBuilder();
            for (int i = a; i <= b && i < n; i++) {
                if (i > a && line[i] != line[i - 1]) {
                    if (block[i] != block[i - 1]) sb.append('\n');
                    else if (sb.length() > 0 && sb.charAt(sb.length() - 1) != ' ' && sb.charAt(sb.length() - 1) != '\n') sb.append(' ');
                }
                int c = cp[i];
                if (c == 0xA0 || (c < 32)) c = ' ';
                if (c == ' ' && sb.length() > 0 && sb.charAt(sb.length() - 1) == ' ') continue;
                if (Character.isValidCodePoint(c)) sb.appendCodePoint(c);
            }
            return sb.toString().trim();
        }
    }

    private static final java.util.concurrent.ConcurrentHashMap<String, java.lang.reflect.Field> FIELDS = new java.util.concurrent.ConcurrentHashMap<>();
    private static Object fld(Object o, String name) {
        if (o == null) return null;
        try {
            String key = o.getClass().getName() + "#" + name;
            java.lang.reflect.Field f = FIELDS.get(key);
            if (f == null) { f = o.getClass().getField(name); FIELDS.put(key, f); }
            return f.get(o);
        } catch (Throwable t) { return null; }
    }

    /** Reads the page text through reflection, so the build does not depend on the exact MuPDF version. */
    private static PageText buildText(Page p) throws Exception {
        com.artifex.mupdf.fitz.Rect bd = p.getBounds();
        float ox = bd.x0, oy = bd.y0;
        com.artifex.mupdf.fitz.StructuredText st = p.toStructuredText();
        try {
            Object[] blocks = (Object[]) st.getClass().getMethod("getBlocks").invoke(st);
            int cap = 1024, n = 0;
            int[] cp = new int[cap], ln = new int[cap], bl = new int[cap];
            float[] bx = new float[cap * 4];
            int line = -1, blk = -1;
            if (blocks != null) for (Object b : blocks) {
                Object[] lns = b == null ? null : (Object[]) fld(b, "lines");
                if (lns == null) continue;
                blk++;
                for (Object l : lns) {
                    Object[] chs = l == null ? null : (Object[]) fld(l, "chars");
                    if (chs == null || chs.length == 0) continue;
                    line++;
                    for (Object ch : chs) {
                        if (ch == null) continue;
                        Object cv = fld(ch, "c");
                        int c = cv instanceof Integer ? (Integer) cv : 0;
                        float a0 = 0, b0 = 0, a1 = 0, b1 = 0;
                        Object q = fld(ch, "quad");
                        if (q instanceof Quad) {
                            Quad qd = (Quad) q;
                            a0 = Math.min(Math.min(qd.ul_x, qd.ll_x), Math.min(qd.ur_x, qd.lr_x));
                            a1 = Math.max(Math.max(qd.ul_x, qd.ll_x), Math.max(qd.ur_x, qd.lr_x));
                            b0 = Math.min(Math.min(qd.ul_y, qd.ll_y), Math.min(qd.ur_y, qd.lr_y));
                            b1 = Math.max(Math.max(qd.ul_y, qd.ll_y), Math.max(qd.ur_y, qd.lr_y));
                        } else {
                            Object r = fld(ch, "bbox");
                            if (r instanceof com.artifex.mupdf.fitz.Rect) {
                                com.artifex.mupdf.fitz.Rect rc = (com.artifex.mupdf.fitz.Rect) r;
                                a0 = rc.x0; b0 = rc.y0; a1 = rc.x1; b1 = rc.y1;
                            }
                        }
                        if (n == cap) {
                            cap *= 2;
                            cp = Arrays.copyOf(cp, cap); ln = Arrays.copyOf(ln, cap); bl = Arrays.copyOf(bl, cap); bx = Arrays.copyOf(bx, cap * 4);
                        }
                        cp[n] = c; ln[n] = line; bl[n] = blk;
                        bx[n * 4] = a0 - ox; bx[n * 4 + 1] = b0 - oy; bx[n * 4 + 2] = a1 - ox; bx[n * 4 + 3] = b1 - oy;
                        n++;
                    }
                }
            }
            return PageText.make(n, cp, ln, bl, bx);
        } finally { try { st.destroy(); } catch (Throwable ignored) { } }
    }

    private static PageText loadText(Document d, int i) {
        Page p = null;
        try {
            p = d.loadPage(i);
            return buildText(p);
        } catch (Throwable t) {
            return PageText.empty(true);
        } finally { if (p != null) try { p.destroy(); } catch (Throwable ignored) { } }
    }

    private void withText(final int p, final TextCb cb) {
        PageText c = textCache.get(p);
        if (c != null && !c.failed) { cb.got(c); return; }
        submit(new Task(0, new Runnable() {
            @Override public void run() {
                PageText t = null;
                if (doc != null && !destroyed) t = loadText(doc, p);
                final PageText ft = t;
                if (ft != null && !ft.failed) textCache.put(p, ft);
                ui.post(new Runnable() { @Override public void run() { if (!destroyed) cb.got(ft == null || ft.failed ? null : ft); } });
            }
        }));
    }

    /** Reads the text of the pages on screen in the background, so a long-press answers at once. */
    private void prefetchText(int first, int last) {
        if (pageCount == 0) return;
        int lim = Math.min(Math.min(last, first + 2), pageCount - 1);
        for (int i = first; i <= lim; i++) {
            if (textCache.get(i) != null || !textLoading.add(i)) continue;
            final int pg = i;
            submitB(new Task(4, new Runnable() {
                @Override public void run() {
                    try {
                        if (!destroyed) textCache.put(pg, loadText(docB(), pg));
                    } catch (Throwable t) {
                        textCache.put(pg, PageText.empty(true));
                    } finally { textLoading.remove(pg); }
                }
            }));
        }
    }

    // ---- geometry
    private float left0() { return (contentW() - pageW1 * zoom) / 2f - scrollX; }

    private boolean pageReady(int p) { return top1 != null && p >= 0 && p < pageCount && sized != null && sized[p] && pw[p] > 0f; }

    // ---- selection
    private void startSelectionAt(float x, float y) {
        if (pageCount == 0 || top1 == null || destroyed) return;
        final int p = pageAtContentY(scrollY + y);
        if (!pageReady(p)) return;
        final float k = pageW1 * zoom / pw[p];
        final float px = (x - left0()) / k, py = (y - (top1[p] * zoom - scrollY)) / k;
        lastTx = x; lastTy = y;
        withText(p, new TextCb() {
            @Override public void got(PageText pt) {
                if (pt == null || pt.n == 0) { if (host != null) host.onNotice(NOTICE_NO_TEXT); return; }
                int c = pt.charAt(px, py, true);
                if (c < 0) { if (host != null) host.onNotice(NOTICE_NO_TEXT_HERE); return; }
                int w = pt.word[c];
                selPt = pt; selPage = p; selA = pt.wFirst[w]; selB = pt.wLast[w];
                selRects = pt.rectsFor(selA, selB);
                fixedFirst = selA; fixedLast = selB;
                dragMode = touching ? 3 : 0;
                grabDy = 0f;
                selShown = false;
                removeCallbacks(reportSel);
                try { performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS); } catch (Throwable ignored) { }
                if (host != null) host.onSelectionStart();
                invalidate();
                if (dragMode == 0) postDelayed(reportSel, 60); else postOnAnimation(autoScroll);
            }
        });
    }

    public boolean hasSelection() { return selPage >= 0; }
    public String selectionText() { return selPt == null || selPage < 0 ? "" : selPt.textFor(selA, selB); }

    public void clearSelection() {
        boolean had = selPage >= 0;
        selPage = -1; selA = selB = -1; selRects = null; selPt = null; dragMode = 0; selShown = false;
        removeCallbacks(reportSel); removeCallbacks(autoScroll);
        invalidate();
        if (had && host != null) host.onSelectionEnd();
    }

    private void selMoved() {
        if (selShown) { selShown = false; if (host != null) host.onSelectionMenu(null); }
        removeCallbacks(reportSel);
        postDelayed(reportSel, 180);
    }

    private final Runnable reportSel = new Runnable() {
        @Override public void run() {
            if (selPage < 0 || dragMode != 0 || destroyed) return;
            if (touching || !scroller.isFinished()) { postDelayed(this, 120); return; }
            RectF a = selectionAnchor();
            selShown = a != null;
            if (host != null) host.onSelectionMenu(a);
        }
    };

    private final Runnable autoScroll = new Runnable() {
        @Override public void run() {
            if (dragMode == 0 || destroyed) return;
            float edge = 80f * dens, v = 0f;
            if (lastTy < edge) v = -(edge - lastTy) / edge * 16f * dens;
            else if (lastTy > getHeight() - edge) v = (lastTy - (getHeight() - edge)) / edge * 16f * dens;
            if (v != 0f) { scrollBy(0, v); updateDrag(); }
            postOnAnimation(this);
        }
    };

    private RectF rectOf(float[] rects, int page0) {
        if (!pageReady(page0) || rects == null || rects.length < 4) return null;
        float left = left0(), top = top1[page0] * zoom - scrollY, k = pageW1 * zoom / pw[page0];
        RectF u = null;
        for (int r = 0; r + 3 < rects.length; r += 4) {
            RectF q = new RectF(left + rects[r] * k, top + rects[r + 1] * k, left + rects[r + 2] * k, top + rects[r + 3] * k);
            if (u == null) u = q; else u.union(q);
        }
        return u;
    }

    private RectF selectionAnchor() {
        RectF u = rectOf(selRects, selPage);
        if (u == null || u.bottom < 0 || u.top > getHeight()) return null;
        return u;
    }

    private RectF anchorOf(MuAnnot h) {
        if (h.type == MuAnnot.TEXT) return rectOf(h.rects, h.page0);
        if (!pageReady(h.page0)) return null;
        float[] b = new float[4];
        if (!h.bounds(pw[h.page0], b)) return null;
        float S = pageW1 * zoom, left = left0(), top = top1[h.page0] * zoom - scrollY;
        return new RectF(left + b[0] * S, top + b[1] * S, left + b[2] * S, top + b[3] * S);
    }

    private boolean handleGeom(int which, float[] o) {
        if (selPage < 0 || selRects == null || selRects.length < 4 || selPt == null || !pageReady(selPage)) return false;
        float left = left0(), top = top1[selPage] * zoom - scrollY, k = pageW1 * zoom / pw[selPage];
        int r = which == 1 ? 0 : selRects.length - 4;
        boolean rtl = selPt.lineRtl[selPt.line[which == 1 ? selA : selB]];
        float xs = ((which == 1) == !rtl) ? selRects[r] : selRects[r + 2];
        float yt = top + selRects[r + 1] * k, yb = top + selRects[r + 3] * k, kr = 7f * dens;
        o[0] = left + xs * k; o[1] = yt; o[2] = yb; o[3] = which == 1 ? yt - kr - 1f * dens : yb + kr + 1f * dens;
        return true;
    }

    private int hitHandle(float x, float y) {
        float[] s = new float[4], e = new float[4];
        if (!handleGeom(1, s) || !handleGeom(2, e)) return 0;
        float r = 28f * dens;
        float ds = (float) Math.hypot(x - s[0], y - s[3]), de = (float) Math.hypot(x - e[0], y - e[3]);
        if (ds <= r && ds <= de) return 1;
        if (de <= r) return 2;
        return 0;
    }

    private void beginHandleDrag(int which, MotionEvent e) {
        dragMode = which;
        lastTx = e.getX(); lastTy = e.getY();
        int other = which == 1 ? selB : selA;
        int w = selPt.word[other];
        if (w < 0) { fixedFirst = selA; fixedLast = selB; } else { fixedFirst = selPt.wFirst[w]; fixedLast = selPt.wLast[w]; }
        float[] g = new float[4];
        grabDy = handleGeom(which, g) ? e.getY() - (g[1] + g[2]) / 2f : 0f;
        selShown = false;
        removeCallbacks(reportSel);
        if (host != null) host.onSelectionMenu(null);
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        postOnAnimation(autoScroll);
        invalidate();
    }

    private void updateDrag() {
        if (selPage < 0 || selPt == null || !pageReady(selPage)) return;
        float k = pageW1 * zoom / pw[selPage];
        float px = (lastTx - left0()) / k, py = (lastTy - grabDy - (top1[selPage] * zoom - scrollY)) / k;
        int c = selPt.charAt(px, py, false);
        if (c < 0) return;
        int w = selPt.word[c];
        int a = Math.min(fixedFirst, selPt.wFirst[w]), b = Math.max(fixedLast, selPt.wLast[w]);
        if (a != selA || b != selB) {
            selA = a; selB = b;
            selRects = selPt.rectsFor(a, b);
            try { performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP); } catch (Throwable ignored) { }
            invalidate();
        }
    }

    private boolean dragTouch(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_MOVE:
                lastTx = e.getX(); lastTy = e.getY();
                updateDrag();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                dragMode = 0;
                removeCallbacks(autoScroll);
                MotionEvent c = MotionEvent.obtain(e);
                c.setAction(MotionEvent.ACTION_CANCEL);
                gd.onTouchEvent(c); sgd.onTouchEvent(c);
                c.recycle();
                postDelayed(reportSel, 40);
                invalidate();
                return true;
            }
            default:
                return true;
        }
    }

    // ---- drawing
    private void drawSelection(Canvas cv, float left, float top, float k) {
        selPaint.setColor(theme == 2 ? 0x663B82F6 : 0x4D3B82F6);
        for (int r = 0; r + 3 < selRects.length; r += 4) {
            tmpR.set(left + selRects[r] * k - dens, top + selRects[r + 1] * k, left + selRects[r + 2] * k + dens, top + selRects[r + 3] * k);
            cv.drawRoundRect(tmpR, 3f * dens, 3f * dens, selPaint);
        }
    }

    private void drawHandles(Canvas cv, float left0) {
        float[] g = new float[4];
        for (int which = 1; which <= 2; which++) {
            if (!handleGeom(which, g)) continue;
            if (g[3] < -30f * dens || g[3] > getHeight() + 30f * dens) continue;
            knobPaint.setColor(handleColor);
            tmpR.set(g[0] - dens, g[1], g[0] + dens, g[2]);
            cv.drawRect(tmpR, knobPaint);
            knobPaint.setColor(0xFFFFFFFF);
            cv.drawCircle(g[0], g[3], 9f * dens, knobPaint);
            knobPaint.setColor(handleColor);
            cv.drawCircle(g[0], g[3], 7f * dens, knobPaint);
        }
    }

    private final MuAnnot.Ctx actx = new MuAnnot.Ctx();

    private MuAnnot.Ctx ctxFor(int p) {
        MuAnnot.Ctx c = actx;
        c.left = left0(); c.top = top1[p] * zoom - scrollY;
        c.S = pageW1 * zoom; c.k = c.S / pw[p];
        c.dens = dens; c.viewW = getWidth(); c.theme = theme;
        return c;
    }

    private void drawHighlights(Canvas cv, int page0, float left, float top, float k) {
        MuAnnot.Ctx c = actx;
        c.cv = cv; c.left = left; c.top = top; c.k = k; c.S = pageW1 * zoom;
        c.dens = dens; c.viewW = getWidth(); c.theme = theme;
        long now = SystemClock.uptimeMillis();
        List<MuAnnot> all = store.all();
        for (int i = 0; i < all.size(); i++) {
            MuAnnot a = all.get(i);
            if (a.page0 != page0) continue;
            c.flash = 0f;
            if (flashId != null && flashId.equals(a.id)) {
                float e = now - flashStart;
                c.flash = Math.max(0f, (float) ((1f - e / 1500f) * (0.55 + 0.45 * Math.cos(e / 140.0))));
            } else if (!ink.erase.isEmpty() && ink.erase.contains(a)) c.flash = 0.55f;
            a.draw(c);
        }
        if (ink.cur != null && ink.cur.page0 == page0) { c.flash = 0f; ink.cur.draw(c); }
    }

    // ---- hit testing
    private MuAnnot highlightAt(float x, float y) {
        if (store.size() == 0 || top1 == null || pageCount == 0) return null;
        int p = pageAtContentY(scrollY + y);
        if (!pageReady(p)) return null;
        float S = pageW1 * zoom, nx = (x - left0()) / S, ny = (y - (top1[p] * zoom - scrollY)) / S, tol = 5f * dens / S;
        List<MuAnnot> l = store.all();
        for (int i = l.size() - 1; i >= 0; i--) {
            MuAnnot a = l.get(i);
            if (a.page0 == p && a.hit(nx, ny, tol, pw[p])) return a;
        }
        return null;
    }

    // ---- stickers: picked in screen units (they keep one size on screen), dragged anywhere on a page
    private MuAnnot stickerAt(float x, float y) {
        if (store.size() == 0 || top1 == null || pageCount == 0) return null;
        float S = pageW1 * zoom, left = left0(), dens7 = 7f * dens;
        List<MuAnnot> l = store.all();
        for (int i = l.size() - 1; i >= 0; i--) {
            MuAnnot a = l.get(i);
            if (a.type != MuAnnot.STICKER || a.pts.length < 2 || !pageReady(a.page0)) continue;
            float cx = left + a.pts[0] * S, cy = top1[a.page0] * zoom - scrollY + a.pts[1] * S;
            float reach = MuAnnot.STICKER_DP * a.scale * dens / 2f + dens7;
            if (Math.abs(x - cx) <= reach && Math.abs(y - cy) <= reach) return a;
        }
        return null;
    }

    private MuAnnot stk;                      // sticker under the finger
    private int stkPage0;
    private float stkX0, stkY0, stkS0, stkDownX, stkDownY, stkOffX, stkOffY;
    private boolean stkPinch;                 // two fingers on a lifted sticker: resize + move
    private float stkPinchD0, stkPinchS0;
    private boolean stkDrag, stkOwn;          // stkDrag: picked up by long-press; stkOwn: the view keeps the whole touch (ink mode)
    private long stkDownTime;
    private final Runnable stkLong = new Runnable() { @Override public void run() { if (stk != null && !stkDrag) beginStickerDrag(); } };

    /** Screen box of a sticker (view pixels), or null when its page is not ready. */
    private RectF stickerRect(MuAnnot a) {
        if (a == null || a.pts.length < 2 || top1 == null || !pageReady(a.page0)) return null;
        float S = pageW1 * zoom, r = MuAnnot.STICKER_DP * a.scale * dens * 0.5f;
        float cx = left0() + a.pts[0] * S, cy = top1[a.page0] * zoom - scrollY + a.pts[1] * S;
        return new RectF(cx - r, cy - r, cx + r, cy + r);
    }

    private void endStickerTouch() {
        removeCallbacks(stkLong);
        if (stk != null) stk.lifted = false;
        stk = null; stkDrag = false; stkOwn = false; stkPinch = false;
    }

    private void beginStickerDrag() {
        if (stk == null) return;
        stkDrag = true;
        stk.lifted = true;
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        scroller.forceFinished(true);
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        long now = SystemClock.uptimeMillis();
        MotionEvent c = MotionEvent.obtain(stkDownTime, now, MotionEvent.ACTION_CANCEL, stkDownX, stkDownY, 0);
        gd.onTouchEvent(c); sgd.onTouchEvent(c);
        c.recycle();
        if (host != null) host.onStickerDragStart();
        invalidate();
    }

    /** Sticker touch: long-press then drag = move it (one undo step); a plain tap or a swipe is left to the normal gestures. */
    private boolean stickerTouch(MotionEvent e) {
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) {
            endStickerTouch();
            if (selPage >= 0 || dragMode != 0) return false;
            MuAnnot a = stickerAt(e.getX(), e.getY());
            if (a == null) return false;
            stk = a; stkDrag = false; stkOwn = ink.active();
            stkPage0 = a.page0; stkX0 = a.pts[0]; stkY0 = a.pts[1]; stkS0 = a.scale;
            stkDownX = e.getX(); stkDownY = e.getY(); stkDownTime = e.getDownTime();
            float S = pageW1 * zoom;
            stkOffX = left0() + a.pts[0] * S - e.getX();                                  // keep the grab point under the finger
            stkOffY = top1[a.page0] * zoom - scrollY + a.pts[1] * S - e.getY();
            postDelayed(stkLong, ViewConfiguration.getLongPressTimeout());
            return stkOwn;
        }
        if (stk == null) return false;
        final float slop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
        if (!stkDrag) {
            if (act == MotionEvent.ACTION_MOVE) {
                if (Math.hypot(e.getX() - stkDownX, e.getY() - stkDownY) > slop) { boolean own = stkOwn; endStickerTouch(); return own; }
                return stkOwn;
            }
            if (act == MotionEvent.ACTION_UP) {
                boolean own = stkOwn; MuAnnot a = stk;
                endStickerTouch();
                if (own && host != null) host.onStickerTap(a, stickerRect(a));
                return own;
            }
            if (act == MotionEvent.ACTION_POINTER_DOWN || act == MotionEvent.ACTION_CANCEL) { boolean own = stkOwn; endStickerTouch(); return own; }
            return stkOwn;
        }
        switch (act) {
            case MotionEvent.ACTION_POINTER_DOWN: {
                if (e.getPointerCount() == 2) {
                    float S = pageW1 * zoom;
                    float mx = (e.getX(0) + e.getX(1)) / 2f, my = (e.getY(0) + e.getY(1)) / 2f;
                    stkPinch = true;
                    stkPinchD0 = Math.max(1f, (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)));
                    stkPinchS0 = stk.scale;
                    stkOffX = left0() + stk.pts[0] * S - mx;                    // keep the sticker's centre where it is vs. the fingers
                    stkOffY = top1[stk.page0] * zoom - scrollY + stk.pts[1] * S - my;
                }
                return true;
            }
            case MotionEvent.ACTION_POINTER_UP: {
                if (stkPinch && e.getPointerCount() == 2) {
                    int keep = e.getActionIndex() == 0 ? 1 : 0;
                    float S = pageW1 * zoom;
                    stkPinch = false;
                    stkOffX = left0() + stk.pts[0] * S - e.getX(keep);
                    stkOffY = top1[stk.page0] * zoom - scrollY + stk.pts[1] * S - e.getY(keep);
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                float fx, fy;
                if (stkPinch && e.getPointerCount() >= 2) {
                    float dist = Math.max(1f, (float) Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)));
                    stk.scale = Math.max(MuAnnot.SCALE_MIN, Math.min(MuAnnot.SCALE_MAX, stkPinchS0 * dist / stkPinchD0));
                    fx = (e.getX(0) + e.getX(1)) / 2f; fy = (e.getY(0) + e.getY(1)) / 2f;
                } else { fx = e.getX(); fy = e.getY(); }
                float cx = fx + stkOffX, cy = fy + stkOffY;
                int p = pageAtContentY(scrollY + cy);
                if (!pageReady(p)) { invalidate(); return true; }
                float S = pageW1 * zoom, hu = ph[p] / pw[p];
                stk.page0 = p;
                stk.pts[0] = Math.max(0.03f, Math.min(0.97f, (cx - left0()) / S));
                stk.pts[1] = Math.max(0.03f, Math.min(hu - 0.03f, (cy - (top1[p] * zoom - scrollY)) / S));
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP: {
                final MuAnnot a = stk;
                final int np = a.page0; final float nx = a.pts[0], ny = a.pts[1], ns = a.scale;
                endStickerTouch();
                a.page0 = stkPage0; a.pts[0] = stkX0; a.pts[1] = stkY0; a.scale = stkS0;   // back to how it was, so undo has the old look
                if (np != stkPage0 || Math.abs(nx - stkX0) > 0.0005f || Math.abs(ny - stkY0) > 0.0005f || Math.abs(ns - stkS0) > 0.002f) {
                    store.edit(a, new Runnable() { @Override public void run() { a.page0 = np; a.pts[0] = nx; a.pts[1] = ny; a.scale = ns; } });
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_CANCEL: {
                stk.page0 = stkPage0; stk.pts[0] = stkX0; stk.pts[1] = stkY0; stk.scale = stkS0;
                endStickerTouch();
                invalidate();
                return true;
            }
            default:
                return true;
        }
    }

    /** Drops a new sticker in the middle of the screen (on the page there) and pulses it. */
    public MuAnnot addStickerAtCenter() {
        if (top1 == null || pageCount == 0 || store.size() >= MuAnnot.MAX) return null;
        int p = pageAtContentY(scrollY + getHeight() / 2f);
        if (!pageReady(p)) return null;
        float S = pageW1 * zoom, hu = ph[p] / pw[p];
        float nx = Math.max(0.08f, Math.min(0.92f, (getWidth() / 2f - left0()) / S));
        float ny = Math.max(0.05f, Math.min(hu - 0.05f, (getHeight() / 2f - (top1[p] * zoom - scrollY)) / S));
        float step = 12f * dens / S;
        for (int tries = 0; tries < 12; tries++) {              // do not stack exactly on another sticker
            boolean busy = false;
            for (MuAnnot o : store.all()) if (o.type == MuAnnot.STICKER && o.page0 == p && Math.abs(o.pts[0] - nx) < step * 0.6f && Math.abs(o.pts[1] - ny) < step * 0.6f) { busy = true; break; }
            if (!busy) break;
            nx = Math.min(0.92f, nx + step); ny = Math.min(hu - 0.05f, ny + step);
        }
        MuAnnot a = new MuAnnot();
        a.type = MuAnnot.STICKER; a.id = MuAnnot.newId(); a.page0 = p;
        a.pts = new float[]{nx, ny};
        a.color = 0; a.alpha = 100; a.created = System.currentTimeMillis();
        store.add(a);
        flashId = a.id; flashStart = SystemClock.uptimeMillis();
        postInvalidateOnAnimation();
        return a;
    }

    // ---- annotation store (the activity owns persistence)
    public MuAnnotStore store() { return store; }
    public MuInk ink() { return ink; }
    public List<MuAnnot> highlights() { return store.all(); }
    public void setOnAnnotChanged(Runnable r) { annotChanged = r; }

    public void setHighlights(List<MuAnnot> list) { store.load(list); invalidate(); }

    public void refreshHighlights() { invalidate(); if (annotChanged != null) annotChanged.run(); }

    public void addHighlight(MuAnnot h) {
        if (h == null || store.all().contains(h)) return;
        store.add(h);
    }

    public void removeHighlight(MuAnnot h) { store.remove(h); }

    /** Saves the current selection as a highlight. Older plain highlights it fully covers are replaced (returned in removed). */
    public MuAnnot commitSelection(int color, int style, List<MuAnnot> removed) {
        if (selPage < 0 || selRects == null || selPt == null || store.size() >= MuAnnot.MAX) return null;
        MuAnnot h = new MuAnnot();
        h.type = MuAnnot.TEXT;
        h.id = MuAnnot.newId(); h.page0 = selPage; h.rects = selRects.clone();
        h.text = selPt.textFor(selA, selB);
        h.color = Math.max(0, Math.min(MuAnnot.TEXT_COLORS - 1, color));
        h.style = Math.max(0, Math.min(2, style));
        h.created = System.currentTimeMillis();
        List<MuAnnot> rem = new ArrayList<>();
        for (MuAnnot o : store.all()) {
            if (o.type == MuAnnot.TEXT && o.page0 == h.page0 && covers(h.rects, o.rects)) rem.add(o);
        }
        List<MuAnnot> add = new ArrayList<>(1);
        add.add(h);
        store.apply(add, rem);
        if (removed != null) removed.addAll(rem);
        clearSelection();
        return h;
    }

    private static boolean covers(float[] nw, float[] old) {
        if (old.length < 4) return false;
        for (int a = 0; a + 3 < old.length; a += 4) {
            boolean ok = false;
            for (int b = 0; b + 3 < nw.length; b += 4) {
                if (nw[b] <= old[a] + 1.5f && nw[b + 2] >= old[a + 2] - 1.5f && nw[b + 1] <= old[a + 1] + 2f && nw[b + 3] >= old[a + 3] - 2f) { ok = true; break; }
            }
            if (!ok) return false;
        }
        return true;
    }

    /** Scrolls to an annotation and pulses it. */
    public void goToHighlight(MuAnnot h) {
        if (h == null || !pageReady(h.page0)) return;
        float yz;
        if (h.type == MuAnnot.TEXT) {
            float y0 = h.rects.length >= 2 ? h.rects[1] : 0f;
            yz = (top1[h.page0] + y0 * (h1[h.page0] / ph[h.page0])) * zoom;
        } else {
            float[] b = new float[4];
            float y0 = h.bounds(pw[h.page0], b) ? b[1] : 0f;
            yz = (top1[h.page0] + y0 * pageW1) * zoom;
        }
        scroller.forceFinished(true);
        scrollY = yz - getHeight() * 0.3f;
        clampScroll(); onMoved(); invalidate();
        flashId = h.id; flashStart = SystemClock.uptimeMillis();
        postInvalidateOnAnimation();
    }

    // ================================================================= ink (marker / pen / eraser)
    public void setInkTool(int tool) {
        ink.cancel();
        ink.erase.clear();
        cancelErase();
        inkStroking = false;
        ink.tool = tool;
        if (tool != MuInk.OFF && selPage >= 0) clearSelection();
        invalidate();
    }

    private boolean inkTouch(MotionEvent e) {
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) inkStroking = !scaling && e.getPointerCount() == 1 && inkBegin(e.getX(), e.getY());
        if (!inkStroking) return false;                 // outside a page, or two fingers: normal scroll / zoom
        sgd.onTouchEvent(e);
        gd.onTouchEvent(e);
        switch (act) {
            case MotionEvent.ACTION_MOVE:
                if (e.getPointerCount() == 1) {
                    int hs = e.getHistorySize();
                    for (int i = 0; i < hs; i++) inkMove(e.getHistoricalX(i), e.getHistoricalY(i));
                    inkMove(e.getX(), e.getY());
                }
                break;
            case MotionEvent.ACTION_POINTER_DOWN:       // a second finger: drop the stroke, let pan / pinch take over
                inkAbort();
                break;
            case MotionEvent.ACTION_UP:
                inkEnd();
                break;
            case MotionEvent.ACTION_CANCEL:
                inkAbort();
                break;
            default: break;
        }
        return true;
    }

    private boolean inkBegin(float x, float y) {
        if (pageCount == 0 || top1 == null) return false;
        int p = pageAtContentY(scrollY + y);
        if (!pageReady(p)) return false;
        float S = pageW1 * zoom, nx = (x - left0()) / S, ny = (y - (top1[p] * zoom - scrollY)) / S;
        float hu = ph[p] / pw[p];
        if (nx < -0.02f || nx > 1.02f || ny < -0.02f || ny > hu + 0.02f) return false;
        inkPage = p;
        scroller.forceFinished(true);
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
        if (ink.tool == MuInk.ERASER) {
            ink.erase.clear();
            cancelErase();
            if (ink.eraseMode == MuInk.FREEHAND) { eraseX = x; eraseY = y; eraseFree(p, nx, ny); }
            else eraseAt(p, nx, ny);
            invalidate();
            return true;
        }
        float cy = 0f, ch = 0f;
        if (ink.isMarker() && ink.snap && ink.shape() != MuInk.BOX) {
            float[] b = snapBand(p, nx, ny);
            if (b != null) { cy = b[0]; ch = b[1]; }
            else {
                long now = SystemClock.uptimeMillis();
                if (host != null && now - lastNoLine > 4000L) { lastNoLine = now; host.onNotice(NOTICE_NO_LINE); }
            }
        }
        ink.begin(p, nx, ny, hu, cy, ch);
        invalidate();
        return true;
    }

    private void inkMove(float x, float y) {
        if (inkPage < 0 || !pageReady(inkPage)) return;
        float S = pageW1 * zoom, nx = (x - left0()) / S, ny = (y - (top1[inkPage] * zoom - scrollY)) / S;
        if (ink.tool == MuInk.ERASER) {
            if (ink.eraseMode == MuInk.FREEHAND) { eraseX = x; eraseY = y; eraseFree(inkPage, nx, ny); }
            else eraseAt(inkPage, nx, ny);
            invalidate();
            return;
        }
        if (ink.move(nx, ny) && ink.cur != null) { ink.publish(ink.cur); invalidate(); }
    }

    private void inkEnd() {
        inkStroking = false;
        if (ink.tool == MuInk.ERASER) {
            if (ink.eraseMode == MuInk.FREEHAND) commitErase();
            else if (!ink.erase.isEmpty()) store.removeAll(new ArrayList<>(ink.erase));
            ink.erase.clear();
            invalidate();
            return;
        }
        MuAnnot a = ink.end();
        if (a != null) store.add(a);
        invalidate();
    }

    private void inkAbort() {
        inkStroking = false;
        ink.cancel();
        ink.erase.clear();
        cancelErase();
        invalidate();
    }

    /** Freehand eraser: the finger path is a live "cut" on every mark it touches; it is saved when the finger lifts. */
    private void eraseFree(int p, float nx, float ny) {
        float r = ink.eraserW / 2f;
        float ax = nx, ay = ny;
        if (eraseTrailN >= 2) { ax = eraseTrail[eraseTrailN - 2]; ay = eraseTrail[eraseTrailN - 1]; }
        if (eraseTrailN == 0 || Math.hypot(nx - ax, ny - ay) >= Math.max(0.0015f, r * 0.2f)) {
            if (eraseTrailN + 2 > eraseTrail.length) eraseTrail = Arrays.copyOf(eraseTrail, eraseTrail.length * 2);
            eraseTrail[eraseTrailN++] = nx; eraseTrail[eraseTrailN++] = ny;
        }
        float len = (float) Math.hypot(nx - ax, ny - ay);
        int ns = Math.max(1, Math.min(120, (int) Math.ceil(len / Math.max(0.002f, r * 0.5f))));
        List<MuAnnot> all = store.all();
        float pwp = pw[p];
        for (int i = 0; i < all.size(); i++) {
            MuAnnot a = all.get(i);
            if (a.page0 != p || eraseTouched.contains(a)) continue;
            for (int k = 0; k <= ns; k++) {
                float t = k / (float) ns;
                if (a.hit(ax + (nx - ax) * t, ay + (ny - ay) * t, r, pwp)) {
                    eraseTouched.add(a);
                    eraseOld.add(MuAnnotStore.copy(a));
                    break;
                }
            }
        }
        for (int i = 0; i < eraseTouched.size(); i++) {
            MuAnnot a = eraseTouched.get(i);
            a.liveCut = eraseTrail; a.liveCutN = eraseTrailN; a.liveCutW = ink.eraserW;
        }
    }

    private void cancelErase() {
        for (int i = 0; i < eraseTouched.size(); i++) { eraseTouched.get(i).liveCut = null; eraseTouched.get(i).liveCutN = 0; }
        eraseTouched.clear();
        eraseOld.clear();
        eraseTrailN = 0;
    }

    private void commitErase() {
        List<MuAnnot> edited = new ArrayList<>(), olds = new ArrayList<>(), removed = new ArrayList<>();
        for (int i = 0; i < eraseTouched.size(); i++) {
            MuAnnot a = eraseTouched.get(i), old = eraseOld.get(i);
            a.liveCut = null; a.liveCutN = 0;
            List<float[]> add = MuEraser.clip(eraseTrail, eraseTrailN, ink.eraserW, a, pw[a.page0]);
            if (add.isEmpty()) continue;
            a.cuts.addAll(add);
            if (MuEraser.erased(a)) { a.cuts = old.cuts; removed.add(a); }
            else { edited.add(a); olds.add(old); }
        }
        eraseTouched.clear();
        eraseOld.clear();
        eraseTrailN = 0;
        if (!edited.isEmpty() || !removed.isEmpty()) store.applyErase(edited, olds, removed);
    }

    private void drawEraserRing(Canvas cv) {
        float rad = Math.max(6f * dens, ink.eraserW * pageW1 * zoom / 2f);
        eraseRing.setStyle(Paint.Style.FILL);
        eraseRing.setColor(0x26808080);
        cv.drawCircle(eraseX, eraseY, rad, eraseRing);
        eraseRing.setStyle(Paint.Style.STROKE);
        eraseRing.setStrokeWidth(1.5f * dens);
        eraseRing.setColor(0xCC808080);
        cv.drawCircle(eraseX, eraseY, rad, eraseRing);
    }

    private void eraseAt(int p, float nx, float ny) {
        float tol = 10f * dens / (pageW1 * zoom);
        List<MuAnnot> l = store.all();
        for (int i = 0; i < l.size(); i++) {
            MuAnnot a = l.get(i);
            if (a.page0 == p && !ink.erase.contains(a) && a.hit(nx, ny, tol, pw[p])) ink.erase.add(a);
        }
    }

    /** Finds the text line under (nx, ny) in the rendered page: returns {centre y, height} in page-width units, or null. */
    private float[] snapBand(int p, float nx, float ny) {
        try {
            Bitmap b = cache.get(p);
            if (b == null) b = lowCache.get(p);
            if (b == null || b.isRecycled()) return null;
            int bw = b.getWidth(), bh = b.getHeight();
            float hu = ph[p] / pw[p];
            int py = Math.round(ny / hu * bh), px = Math.round(nx * bw);
            int reach = Math.max(8, Math.round(0.03f * bw)), half = Math.round(0.22f * bw);
            float[] o = new float[2];
            if (!MuSnap.band(b, px - half, px + half, py, reach, o)) return null;
            float cy = (o[0] + o[1]) / 2f / bh * hu, hh = (o[1] - o[0]) / bh * hu;
            return new float[]{cy, Math.max(0.008f, Math.min(MuInk.MAX_W, hh * 1.12f))};
        } catch (Throwable t) { return null; }
    }

    /** A small picture of an annotation on its page (for lists). Null when the page is not in memory. */
    public Bitmap thumb(MuAnnot a, int wPx, int hPx) {
        try {
            if (a == null || !pageReady(a.page0) || wPx < 8 || hPx < 8) return null;
            Bitmap src = cache.get(a.page0);
            if (src == null) src = lowCache.get(a.page0);
            if (src == null || src.isRecycled()) return null;
            float[] bd = new float[4];
            if (!a.bounds(pw[a.page0], bd)) return null;
            int bw = src.getWidth(), bh = src.getHeight();
            float pad = 0.02f;
            float x0 = (bd[0] - pad) * bw, x1 = (bd[2] + pad) * bw, y0 = (bd[1] - pad) * bw, y1 = (bd[3] + pad) * bw;
            float cx = (x0 + x1) / 2f, cyy = (y0 + y1) / 2f, w = x1 - x0, h = y1 - y0;
            float asp = (float) wPx / hPx;
            if (w / h < asp) w = h * asp; else h = w / asp;
            w = Math.max(w, bw * 0.25f); h = w / asp;
            if (w > bw) { w = bw; h = w / asp; }
            float sx = Math.max(0f, Math.min(bw - w, cx - w / 2f)), sy = Math.max(0f, Math.min(bh - h, cyy - h / 2f));
            Bitmap out = Bitmap.createBitmap(wPx, hPx, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(out);
            cv.drawColor(pageColor);
            float sc = wPx / w;
            cv.drawBitmap(src, new android.graphics.Rect(Math.round(sx), Math.round(sy), Math.round(sx + w), Math.round(sy + h)),
                    new RectF(0, 0, wPx, hPx), bmpPaint);
            MuAnnot.Ctx c = new MuAnnot.Ctx();
            c.cv = cv; c.left = -sx * sc; c.top = -sy * sc; c.S = bw * sc; c.k = c.S / pw[a.page0];
            c.dens = dens; c.viewW = wPx; c.theme = theme; c.flash = 0f;
            a.draw(c);
            return out;
        } catch (Throwable t) { return null; }
    }

    /** Where a page sits on the scrub handle's track (0..1). */
    public float pageFraction(int page0) {
        if (top1 == null || page0 < 0 || page0 >= pageCount) return 0f;
        float mx = maxScrollY();
        if (mx <= 1f) return 0f;
        return Math.max(0f, Math.min(1f, (top1[page0] - gap) * zoom / mx));
    }

    // ================================================================= lifecycle
    /** Call from Activity.onTrimMemory(level). */
    public void trimMemory(int level) {
        synchronized (lowCache) { lowCache.evictAll(); }
        synchronized (patches) { patches.clear(); }
        if (level >= 60) { synchronized (cache) { cache.trimToSize(cache.size() / 4); } }   // TRIM_MEMORY_MODERATE and above
        else { synchronized (cache) { cache.trimToSize(cache.size() / 2); } }
    }

    public void destroy() {
        destroyed = true;
        searchToken++;
        cancelJob(jobA); cancelJob(jobB);
        removeCallbacks(detailRunnable);
        exec.getQueue().clear();
        execB.getQueue().clear();
        submit(new Task(0, new Runnable() {
            @Override public void run() {
                try { if (doc != null) doc.destroy(); } catch (Throwable ignored) { }
                doc = null;
            }
        }));
        submitB(new Task(0, new Runnable() {
            @Override public void run() {
                try { if (docB != null) docB.destroy(); } catch (Throwable ignored) { }
                docB = null;
            }
        }));
        exec.shutdown();
        execB.shutdown();
        synchronized (cache) { cache.evictAll(); }
        synchronized (lowCache) { lowCache.evictAll(); }
        synchronized (patches) { patches.clear(); }
        textCache.evictAll();
        removeCallbacks(reportSel); removeCallbacks(autoScroll);
    }
}
