// Library screen: books downloaded from this app + every PDF found on the phone.
// Files are read straight from storage; nothing is copied into app storage.
import { getDownloads, getDownloadRecord, removeDownloadRecord } from "./downloads-store.js";
import { getNativePlugin } from "./download-manager.js";
import { onScanChange, scanInfo, cachedFiles, needsAutoScan, checkAccess, runScan } from "./device-scan.js";
import { typesetCover, paletteIndex } from "../components/book-card.js";
import { icon } from "../utils/icons.js";

const PAGE = 60;
const VIEW_KEY = "krl_library_view_v1";
const PAGES_KEY = "krl_pages_v1";
const readView = () => { try{ return localStorage.getItem(VIEW_KEY) === "list" ? "list" : "grid"; }catch{ return "grid"; } };
const saveView = v => { try{ localStorage.setItem(VIEW_KEY, v); }catch{} };
// Survives re-renders (e.g. coming back from the reader) so the list looks exactly as it was left.
const remembered = { sort: "date", query: "", limit: PAGE, granted: false, src: "all" };
let activeCleanup = null;
let thumbChain = Promise.resolve();

// Page counts: found by the native side while it makes the thumbnail, remembered so every later visit shows them at once.
let pagesMap = null;
let pagesTimer = 0;
function loadPages(){
  if(pagesMap) return pagesMap;
  try{ pagesMap = JSON.parse(localStorage.getItem(PAGES_KEY) || "{}") || {}; }catch{ pagesMap = {}; }
  return pagesMap;
}
const pagesFor = key => Number(loadPages()[key]) || 0;
function rememberPages(key, n){
  n = Number(n) || 0;
  const map = loadPages();
  if(!n || map[key] === n) return;
  map[key] = n;
  clearTimeout(pagesTimer);
  pagesTimer = setTimeout(() => {
    try{
      const keys = Object.keys(map);
      if(keys.length > 4000) keys.slice(0, keys.length - 3000).forEach(k => delete map[k]);
      localStorage.setItem(PAGES_KEY, JSON.stringify(map));
    }catch{}
  }, 600);
}

// Where a PDF lives decides its source chip. Books downloaded through the app, and anything in a folder
// called "Maktabah", are "maktabah".
const SRC_ORDER = ["maktabah", "whatsapp", "documents", "download", "telegram", "other"];
const SRC_ICON = { maktabah: "doc", whatsapp: "whatsapp", documents: "folder", download: "download", telegram: "telegram", other: "folder" };
function sourceOf(path){
  const segs = String(path || "").toLowerCase().replace(/\\/g, "/").split("/").filter(Boolean);
  segs.pop();
  if(segs.some(x => x.includes("maktabah"))) return "maktabah";
  if(segs.some(x => x.includes("whatsapp"))) return "whatsapp";
  if(segs.some(x => x.includes("telegram"))) return "telegram";
  if(segs.some(x => x === "download" || x === "downloads")) return "download";
  if(segs.some(x => x === "documents")) return "documents";
  return "other";
}

export function cleanupLibrary(){
  if(!activeCleanup) return;
  const fn = activeCleanup;
  activeCleanup = null;
  try{ fn(); }catch{}
}

function formatBytes(n){
  n = Number(n) || 0;
  if(n >= 1073741824) return (n / 1073741824).toFixed(1) + " GB";
  if(n >= 1048576) return (n / 1048576).toFixed(1) + " MB";
  if(n >= 1024) return Math.round(n / 1024) + " KB";
  return n + " B";
}
function formatDate(ts, ur){
  try{ return new Date(ts).toLocaleDateString(ur ? "ur-PK" : "en-GB", { day: "numeric", month: "short", year: "numeric" }); }catch{ return ""; }
}
function folderOf(path){
  const parts = String(path).split("/").filter(Boolean);
  parts.pop();
  return parts.pop() || "";
}

export function renderLibrary(d){
  cleanupLibrary();
  const { lang, shell, books, navigate, showToast, confirmDialog, downloadBookPdf, coverMarkup, wireCover, escapeHTML } = d;
  const ur = lang === "ur";
  // Coming back from a book: the router restores scroll once, but this screen fills in asynchronously
  // (permission check, file scan), so the page may still be short at that moment. Keep re-applying the
  // saved position until the user touches the screen or ~3s have passed.
  const wantY = Math.max(0, Number(history.state?.scrollY) || 0);
  let restoreDone = wantY <= 0;
  const stopRestore = () => { restoreDone = true; };
  if(!restoreDone){
    window.addEventListener("touchstart", stopRestore, { once: true, passive: true });
    window.addEventListener("wheel", stopRestore, { once: true, passive: true });
    setTimeout(stopRestore, 3000);
  }
  function restoreScroll(){
    if(restoreDone) return;
    requestAnimationFrame(() => {
      if(restoreDone) return;
      const max = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
      const y = Math.min(wantY, max);
      if(Math.abs(window.scrollY - y) > 2) window.scrollTo({ top: y, left: 0, behavior: "auto" });
      if(max >= wantY) restoreDone = true;   // page is tall enough now: done
    });
  }
  const T = ur ? {
    title: "لائبریری", intro: "اس ایپ سے ڈاؤنلوڈ کی ہوئی کتابیں اور آپ کے فون کی تمام PDF فائلیں، سب آف لائن پڑھیں۔",
    search: "آف لائن کتابیں تلاش کریں…", sortDate: "تازہ ترین", sortName: "نام", sortSize: "سائز",
    krTitle: "KR لائبریری سے ڈاؤنلوڈ", devTitle: "فون کی دوسری PDF فائلیں",
    krEmpty: "ابھی کوئی کتاب ڈاؤنلوڈ نہیں ہوئی۔ کسی کتاب کا ڈاؤنلوڈ بٹن دبائیں۔",
    devEmpty: "کوئی PDF نہیں ملی۔", noMatch: "کوئی نتیجہ نہیں ملا۔",
    missing: "فائل نہیں ملی", del: "حذف کریں", delTitle: "فائل حذف کریں؟",
    delMsg: "یہ کتاب آپ کے فون کے ڈاؤنلوڈز فولڈر سے بھی حذف ہو جائے گی۔", deleted: "کتاب حذف ہوگئی۔",
    again: "دوبارہ ڈاؤنلوڈ کریں", againMsg: "یہ فائل فون میں موجود نہیں۔ کیا دوبارہ ڈاؤنلوڈ کریں؟",
    accessTitle: "فون کی PDF فائلیں دیکھنے کی اجازت دیں",
    accessText: "اجازت دینے کے بعد ایپ آپ کے فون کی تمام PDF فائلیں یہاں دکھا سکے گی۔ فائلیں کہیں کاپی یا اپلوڈ نہیں ہوتیں۔",
    accessBtn: "اجازت دیں", scanning: "PDF فائلیں تلاش کی جا رہی ہیں…", found: n => `${n} PDF فائلیں ملیں`,
    rescan: "دوبارہ تلاش کریں", more: "مزید دکھائیں", androidOnly: "یہ فہرست صرف اینڈرائیڈ ایپ میں کام کرتی ہے۔",
    scanFailed: "تلاش مکمل نہیں ہو سکی۔", scanNever: "فون کی PDF فائلیں ابھی تلاش نہیں ہوئیں۔ دستی تلاش کے لیے مزید ← فون کی PDF فائلیں کھولیں۔", openScan: "تلاش کی ترتیب", browse: "کتابیں دیکھیں", sortBy: "ترتیب", viewAs: "دکھانے کا انداز", viewGrid: "گرڈ", viewList: "فہرست",
    filterBy: "ذریعہ", src: { all: "سب", maktabah: "مکتبہ", whatsapp: "واٹس ایپ", documents: "دستاویزات", download: "ڈاؤنلوڈ", telegram: "ٹیلیگرام", other: "دیگر" },
    pages: n => `${n} صفحات`
  } : {
    title: "Library", intro: "Books downloaded from this app and every PDF on your phone, all readable offline.",
    search: "Search your offline books…", sortDate: "Newest", sortName: "Name", sortSize: "Size",
    krTitle: "Downloaded from KR Library", devTitle: "Other PDFs on this phone",
    krEmpty: "No books downloaded yet. Tap Download on any book.",
    devEmpty: "No PDFs found.", noMatch: "No results found.",
    missing: "File not found", del: "Delete", delTitle: "Delete this file?",
    delMsg: "The book will also be removed from your phone's Downloads folder.", deleted: "Book deleted.",
    again: "Download again", againMsg: "This file is no longer on your phone. Download it again?",
    accessTitle: "Allow access to PDFs on your phone",
    accessText: "Once allowed, the app can list every PDF on your phone here. Files are never copied or uploaded.",
    accessBtn: "Allow access", scanning: "Looking for PDFs…", found: n => `${n} PDFs found`,
    rescan: "Scan again", more: "Show more", androidOnly: "This list works in the Android app only.",
    scanFailed: "The scan could not finish.", scanNever: "Phone PDFs have not been scanned yet. Open More → Device PDFs to scan.", openScan: "Scan settings", browse: "Browse books", sortBy: "Sort by", viewAs: "View as", viewGrid: "Grid", viewList: "List",
    filterBy: "Source", src: { all: "All", maktabah: "Maktabah", whatsapp: "WhatsApp", documents: "Documents", download: "Download", telegram: "Telegram", other: "Other" },
    pages: n => n === 1 ? "1 Page" : `${n} Pages`
  };

  const plugin = getNativePlugin();
  const state = {
    query: remembered.query, sort: remembered.sort, src: remembered.src, view: readView(), limit: remembered.limit, granted: remembered.granted,
    scanning: scanInfo().scanning, scanError: false, files: cachedFiles(), missing: new Set(), shown: [], destroyed: false
  };
  const sortLabel = { date: T.sortDate, name: T.sortName, size: T.sortSize };

  const page = shell(T.title, `<section class="lib-page">
    <header class="tab-head lb-head"><div><h1 class="tab-title">${T.title}</h1><p class="tab-sub">${T.intro}</p></div></header>
    <div id="lbAccess"></div>
    <form class="search-pill lb-search" id="lbSearchForm" role="search"><span class="search-pill-icon" aria-hidden="true">${icon("search")}</span><input id="lbSearch" type="search" placeholder="${T.search}" aria-label="${T.search}" autocomplete="off" enterkeyhint="search"></form>
    <div class="lb-chips" id="lbChips" role="radiogroup" aria-label="${T.filterBy}"></div>
    <div class="lb-toolbar">
      <p class="lb-status" id="lbStatus" role="status"></p>
      <div class="lb-sortwrap">
        <button type="button" class="lb-sortbtn" id="lbSortBtn" aria-haspopup="menu" aria-expanded="false" aria-label="${T.sortBy}"><span id="lbSortLabel">${sortLabel[state.sort]}</span>${icon("chevdown")}</button>
        <div class="lb-menu" id="lbMenu" role="menu" aria-label="${T.sortBy}" hidden>
          ${["date", "name", "size"].map(k => `<button type="button" role="menuitemradio" aria-checked="${k === state.sort}" data-sort="${k}">${sortLabel[k]}</button>`).join("")}
        </div>
      </div>
      <div class="lb-view" id="lbView" role="radiogroup" aria-label="${T.viewAs}">
        <button type="button" role="radio" aria-checked="${state.view === "grid"}" data-view="grid" aria-label="${T.viewGrid}" title="${T.viewGrid}">${icon("grid")}</button>
        <button type="button" role="radio" aria-checked="${state.view === "list"}" data-view="list" aria-label="${T.viewList}" title="${T.viewList}">${icon("list")}</button>
      </div>
    </div>
    <section class="lb-section" id="lbList"></section>
  </section>`, "downloads");
  page.classList.add("library-page");

  const $ = s => page.querySelector(s);
  const accessBox = $("#lbAccess"), listBox = $("#lbList"), chipsBox = $("#lbChips"), statusEl = $("#lbStatus");
  $("#lbSearch").value = state.query;
  const remember = () => { remembered.sort = state.sort; remembered.query = state.query; remembered.limit = state.limit; remembered.granted = state.granted; remembered.src = state.src; };

  function recordInfo(rec){
    const b = books().find(x => x.id === rec.bookId);
    return {
      rec, b,
      name: ur ? (b?.title || rec.title) : (b?.titleEn || rec.titleEn || b?.title || rec.title),
      author: ur ? (b?.author || rec.author) : (b?.authorEn || rec.authorEn || b?.author || rec.author),
      cover: b?.cover || rec.cover || ""
    };
  }

  // One list: books downloaded here + every other PDF on the phone, each tagged with its source.
  function allItems(){
    const recs = getDownloads();
    const out = recs.map(rec => {
      const x = recordInfo(rec);
      const key = `kr|${rec.bookId}|${rec.size}`;
      return {
        kind: "kr", id: rec.bookId, title: x.name || "", author: x.author || "", cover: x.cover, size: rec.size, date: rec.savedAt,
        src: "maktabah", pagesKey: key, pages: Number(x.b?.pages) || pagesFor(key), rec,
        hay: `${x.name || ""} ${x.author || ""}`.toLowerCase()
      };
    });
    if(plugin && state.granted){
      const krKeys = new Set(recs.map(r => `${String(r.filename).toLowerCase()}|${r.size}`));
      state.files.forEach(f => {
        if(krKeys.has(`${String(f.name).toLowerCase()}|${f.size}`)) return;
        const key = `${f.path}|${f.size}|${f.modified}`;
        const title = String(f.name).replace(/\.pdf$/i, "");
        out.push({ kind: "dev", path: f.path, name: f.name, title, author: "", size: f.size, date: f.modified, src: sourceOf(f.path), pagesKey: key, pages: pagesFor(key), hay: title.toLowerCase() });
      });
    }
    return out;
  }
  const cmp = () => (a, b) => {
    if(state.sort === "name") return String(a.title).localeCompare(String(b.title));
    if(state.sort === "size") return (b.size || 0) - (a.size || 0);
    return (b.date || 0) - (a.date || 0);
  };

  const empty = (ico, text, cta = "") => `<div class="lb-empty">${icon(ico)}<p>${text}</p>${cta}</div>`;
  // File sizes ("17.5 MB") stay left-to-right even inside Urdu (RTL) text.
  const ltr = text => `\u2066${text}\u2069`;
  const meta = (...parts) => `<span class="file-meta">${parts.filter(Boolean).map(x => `<span>${escapeHTML(x)}</span>`).join("")}</span>`;
  // Pages when known; until the thumbnail reports them, the size takes the same place so nothing jumps.
  const pgText = (n, fallback, tail) => n ? T.pages(n) + (tail ? ` · ${tail}` : "") : (fallback || "");
  const pgRow = (x, cls, tail = "") => {
    const fb = ltr(formatBytes(x.size));
    return `<span class="${cls}" data-pg="${escapeHTML(x.pagesKey)}" data-fb="${escapeHTML(fb)}" data-tail="${escapeHTML(tail)}">${icon("book")}<span>${escapeHTML(pgText(x.pages, fb, tail))}</span></span>`;
  };
  const srcRow = (x, cls) => `<span class="${cls} src-${x.src}">${icon(SRC_ICON[x.src] || "folder")}<span>${escapeHTML(T.src[x.src] || "")}</span></span>`;
  function applyPages(key, n){
    if(!n) return;
    page.querySelectorAll("[data-pg]").forEach(el => {
      if(el.dataset.pg !== key) return;
      const t = el.lastElementChild;
      if(t) t.textContent = pgText(n, "", el.dataset.tail);
    });
  }

  function paintAccess(){
    if(!plugin){
      accessBox.innerHTML = `<div class="lb-note">${icon("phone")}<span>${T.androidOnly}</span></div>`;
      return;
    }
    if(!state.granted){
      accessBox.innerHTML = `<div class="lb-card"><span class="lb-medal">${icon("folder")}</span><div><strong>${T.accessTitle}</strong><p>${T.accessText}</p>
        <button class="cta-btn" id="lbAllow" type="button">${T.accessBtn}${icon("arrow")}</button></div></div>`;
      $("#lbAllow").onclick = () => { plugin.requestStorageAccess().catch(() => {}); };
      return;
    }
    accessBox.innerHTML = "";
  }

  function paintStatus(count){
    const busy = state.granted && state.scanning;
    const text = busy ? T.scanning : (state.granted && state.scanError ? T.scanFailed : T.found(count));
    statusEl.className = `lb-status${busy ? " is-busy" : ""}${state.granted && state.scanError && !busy ? " is-error" : ""}`;
    statusEl.innerHTML = `${busy ? '<i class="lb-spin"></i>' : '<i class="lb-dot"></i>'}<span>${escapeHTML(text)}</span>`;
  }

  // Chips: All + Maktabah always, the other sources only when there is something in them.
  function paintChips(){
    const counts = {};
    allItems().forEach(x => { counts[x.src] = (counts[x.src] || 0) + 1; });
    const keys = ["all", "maktabah", ...SRC_ORDER.filter(k => k !== "maktabah" && counts[k])];
    if(!keys.includes(state.src)){ state.src = "all"; remember(); }
    chipsBox.innerHTML = keys.map(k => `<button type="button" class="lb-chip" role="radio" aria-checked="${k === state.src}" data-src="${k}">${escapeHTML(T.src[k])}</button>`).join("");
  }

  const observer = "IntersectionObserver" in window ? new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(!entry.isIntersecting) return;
      observer.unobserve(entry.target);
      const box = entry.target;
      const file = { path: box.dataset.path, size: Number(box.dataset.size), modified: Number(box.dataset.mod) };
      thumbChain = thumbChain.then(async () => {
        if(state.destroyed || !box.isConnected || !plugin) return;
        try{
          const key = `${file.path}|${file.size}|${file.modified}`;
          const res = await plugin.thumbnail({ path: file.path, key, width: 240 });
          if(res?.pages){ rememberPages(key, res.pages); applyPages(key, Number(res.pages)); }
          if(res?.data && box.isConnected){
            const img = new Image();
            img.alt = "";
            img.addEventListener("load", () => img.classList.add("is-loaded"), { once: true });
            img.src = res.data;
            box.appendChild(img);
          }
        }catch{}
      });
    });
  }, { rootMargin: "300px" }) : null;

  function cardHTML(x, i, grid){
    const title = escapeHTML(x.title);
    if(x.kind === "kr"){
      const missing = state.missing.has(x.id);
      const id = escapeHTML(x.id);
      const art = `${typesetCover(x.title, x.author, x.id)}${x.cover ? coverMarkup(escapeHTML(x.cover)) : ""}`;
      if(grid) return `
      <article class="file-card${missing ? " is-missing" : ""}" data-book="${id}">
        <button class="file-card-main" type="button" data-read="${id}">
          <span class="cover file-card-cover file-thumb">${art}${missing ? `<span class="file-card-flag">${icon("alert")}</span>` : ""}</span>
          <strong class="file-card-title">${title}</strong>
          ${srcRow(x, "file-card-src")}
          ${pgRow(x, "file-card-pg")}
          ${missing ? `<span class="file-sr">${T.missing}</span>` : ""}
        </button>
        <button class="file-card-delete" type="button" data-delete="${id}" aria-label="${T.del}" title="${T.del}">${icon("trash")}</button>
      </article>`;
      return `
      <article class="file-row${missing ? " is-missing" : ""}" data-book="${id}">
        <button class="file-main" type="button" data-read="${id}">
          <span class="cover is-mini file-thumb">${art}</span>
          <span class="file-info">
            <strong class="file-title">${title}</strong>
            ${x.author ? `<span class="file-sub"><span>${escapeHTML(x.author)}</span></span>` : ""}
            ${srcRow(x, "file-sub file-src")}
            ${pgRow(x, "file-sub file-pg", formatDate(x.date, ur))}
            ${missing ? `<span class="file-flag">${icon("alert")}${T.missing}</span>` : ""}
          </span>
        </button>
        <button class="file-delete" type="button" data-delete="${id}" aria-label="${T.del}" title="${T.del}">${icon("trash")}</button>
      </article>`;
    }
    const thumb = `data-path="${escapeHTML(x.path)}" data-size="${x.size}" data-mod="${x.date}"`;
    if(grid) return `
      <article class="file-card">
        <button class="file-card-main" type="button" data-open="${i}">
          <span class="cover file-card-cover file-thumb is-pdf" ${thumb}>${icon("pdf", "file-glyph")}<b class="file-ext">PDF</b></span>
          <strong class="file-card-title">${title}</strong>
          ${srcRow(x, "file-card-src")}
          ${pgRow(x, "file-card-pg")}
        </button>
      </article>`;
    return `
      <article class="file-row">
        <button class="file-main" type="button" data-open="${i}">
          <span class="cover is-mini file-thumb is-pdf" ${thumb}>${icon("pdf", "file-glyph")}<b class="file-ext">PDF</b></span>
          <span class="file-info">
            <strong class="file-title">${title}</strong>
            ${srcRow(x, "file-sub file-src")}
            ${pgRow(x, "file-sub file-pg", formatDate(x.date, ur))}
          </span>
        </button>
      </article>`;
  }

  function paintList(){
    const q = state.query;
    const pool = allItems();
    const list = pool.filter(x => (state.src === "all" || x.src === state.src) && (!q || x.hay.includes(q))).sort(cmp());
    state.shown = list.slice(0, state.limit);
    paintStatus(list.length);
    const grid = state.view === "grid";
    if(!list.length){
      if(!pool.length && state.granted && state.scanning && !q){
        const sk = grid
          ? `<div class="file-card is-skeleton"><span class="cover file-card-cover file-thumb"></span><i class="sk w70"></i><i class="sk w40"></i></div>`.repeat(6)
          : `<div class="file-row is-skeleton"><span class="cover is-mini file-thumb"></span><span class="file-info"><i class="sk w70"></i><i class="sk w40"></i><i class="sk w55"></i></span></div>`.repeat(4);
        listBox.innerHTML = `<div class="${grid ? "file-grid" : "file-list"}" aria-hidden="true">${sk}</div>`;
      }else if(pool.length){
        listBox.innerHTML = empty("search", T.noMatch);
      }else if(plugin && state.granted && !scanInfo().at && !state.scanning){
        listBox.innerHTML = empty("pdf", T.scanNever, `<a class="cta-btn" href="#more">${T.openScan}${icon("arrow")}</a>`);
      }else if(plugin && state.granted && scanInfo().at){
        listBox.innerHTML = empty("pdf", T.devEmpty);
      }else{
        listBox.innerHTML = empty("book", T.krEmpty, `<a class="cta-btn" href="#catalogue">${T.browse}${icon("arrow")}</a>`);
      }
      return;
    }
    listBox.innerHTML = `<div class="${grid ? "file-grid" : "file-list"}">${state.shown.map((x, i) => cardHTML(x, i, grid)).join("")}</div>
      ${list.length > state.shown.length ? `<div class="lb-more"><button class="lb-more-btn" id="lbMore" type="button">${T.more}<span>${list.length - state.shown.length}</span></button></div>` : ""}`;
    listBox.querySelectorAll(".file-thumb:not(.is-pdf)").forEach(wireCover);
    $("#lbMore")?.addEventListener("click", () => { state.limit += PAGE; remember(); paintList(); });
    if(observer) listBox.querySelectorAll(".is-pdf").forEach(el => observer.observe(el));
  }

  function paintAll(){ paintAccess(); paintChips(); paintList(); restoreScroll(); }

  // The scan itself lives in device-scan.js (shared with More); we only repaint when its state changes.
  const scan = () => runScan();
  const offScan = onScanChange(() => {
    if(state.destroyed) return;
    const info = scanInfo();
    state.scanning = info.scanning; state.scanError = info.failed;
    state.files = cachedFiles();
    paintAccess(); paintChips(); paintList(); restoreScroll();
  });

  async function refreshAccess(){
    if(!plugin) return;
    try{
      state.granted = await checkAccess();
      remember();
      if(state.destroyed) return;
      paintAccess(); paintChips(); paintList(); restoreScroll();
      if(state.granted && needsAutoScan()) scan();
    }catch{}
  }

  // Books downloaded here: does the file still exist? (and how many pages it has, once)
  if(plugin){
    getDownloads().forEach(async rec => {
      try{
        const key = `kr|${rec.bookId}|${rec.size}`;
        const info = await plugin.fileInfo({ id: rec.downloadId, pages: !pagesFor(key) });
        if(state.destroyed) return;
        if(info?.pages){ rememberPages(key, info.pages); applyPages(key, Number(info.pages)); }
        if(info?.exists) return;
        state.missing.add(rec.bookId);
        paintList();
      }catch{}
    });
  }

  listBox.addEventListener("click", async e => {
    const readBtn = e.target.closest("[data-read]");
    const delBtn = e.target.closest("[data-delete]");
    const openBtn = e.target.closest("[data-open]");
    if(openBtn){
      const f = state.shown[Number(openBtn.dataset.open)];
      if(f) navigate("local", { path: f.path, name: f.name });
    }else if(readBtn){
      const id = readBtn.dataset.read;
      if(state.missing.has(id)){
        const b = books().find(x => x.id === id);
        if(!b){ removeDownloadRecord(id); paintChips(); paintList(); return; }
        if(await confirmDialog(T.missing, T.againMsg, T.again, false)) downloadBookPdf(b);
        return;
      }
      navigate("local", { book: id });
    }else if(delBtn){
      const id = delBtn.dataset.delete;
      const rec = getDownloadRecord(id);
      if(!rec) return;
      if(!(await confirmDialog(T.delTitle, T.delMsg, T.del, true))) return;
      try{ await plugin?.deleteDownload({ id: rec.downloadId }); }catch{}
      removeDownloadRecord(id);
      showToast(T.deleted);
      paintChips(); paintList();
    }
  });

  let searchTimer = null;
  $("#lbSearch").addEventListener("input", e => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { state.query = e.target.value.trim().toLowerCase(); state.limit = PAGE; remember(); paintList(); }, 160);
  });
  $("#lbSearchForm").addEventListener("submit", e => { e.preventDefault(); $("#lbSearch").blur(); });

  chipsBox.addEventListener("click", e => {
    const btn = e.target.closest("[data-src]");
    if(!btn || btn.dataset.src === state.src) return;
    state.src = btn.dataset.src; state.limit = PAGE; remember();
    chipsBox.querySelectorAll("[data-src]").forEach(b => b.setAttribute("aria-checked", String(b === btn)));
    btn.scrollIntoView({ inline: "nearest", block: "nearest", behavior: "smooth" });
    paintList();
  });

  // Sort: a small dropdown under the "Newest" button
  const menu = $("#lbMenu"), sortBtn = $("#lbSortBtn");
  const closeMenu = () => { if(menu.hidden) return; menu.hidden = true; sortBtn.setAttribute("aria-expanded", "false"); };
  sortBtn.addEventListener("click", () => {
    const open = menu.hidden;
    menu.hidden = !open;
    sortBtn.setAttribute("aria-expanded", String(open));
  });
  menu.addEventListener("click", e => {
    const btn = e.target.closest("[data-sort]");
    if(!btn) return;
    closeMenu();
    if(btn.dataset.sort === state.sort) return;
    state.sort = btn.dataset.sort;
    menu.querySelectorAll("[data-sort]").forEach(b => b.setAttribute("aria-checked", String(b === btn)));
    $("#lbSortLabel").textContent = sortLabel[state.sort];
    remember(); paintList();
  });
  const onDocDown = e => { if(!e.target.closest(".lb-sortwrap")) closeMenu(); };
  const onKey = e => { if(e.key === "Escape") closeMenu(); };
  document.addEventListener("pointerdown", onDocDown, true);
  document.addEventListener("keydown", onKey);
  window.addEventListener("scroll", closeMenu, { passive: true });

  $("#lbView").addEventListener("click", e => {
    const btn = e.target.closest("[data-view]");
    if(!btn || btn.dataset.view === state.view) return;
    state.view = btn.dataset.view;
    saveView(state.view);
    $("#lbView").querySelectorAll("[data-view]").forEach(b => b.setAttribute("aria-checked", String(b === btn)));
    paintList();
  });
  const onVisible = () => { if(document.visibilityState === "visible") refreshAccess(); };
  document.addEventListener("visibilitychange", onVisible);
  activeCleanup = () => {
    state.destroyed = true;
    clearTimeout(searchTimer);
    document.removeEventListener("visibilitychange", onVisible);
    document.removeEventListener("pointerdown", onDocDown, true);
    document.removeEventListener("keydown", onKey);
    window.removeEventListener("scroll", closeMenu);
    offScan();
    observer?.disconnect();
  };

  paintAll();
  refreshAccess();
}
