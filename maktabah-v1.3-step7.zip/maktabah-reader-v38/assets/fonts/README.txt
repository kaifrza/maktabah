Put the Urdu note font here as urdu-note.ttf (e.g. Noto Naskh Arabic / Noto Nastaliq Urdu).
The reader uses it offline for Urdu text in sticky notes. If missing, it falls back to the phone Naskh font.
