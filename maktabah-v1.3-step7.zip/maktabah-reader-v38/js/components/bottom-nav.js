import { navigate } from "../router.js";

/* ------------------------------------------------------------------
   Bottom dock v3 — built once, never rebuilt.

   Why it feels instant:
   - The dock lives in <body>, outside #app. Screens come and go; the dock stays,
     so nothing is re-created, re-measured or re-blurred when a tab changes.
   - Switching tabs only changes two things: a CSS variable (--i, the position of the
     indicator) and aria-current. The indicator moves with a plain CSS transform
     transition, which runs on the GPU thread even while the next screen is being built.
   - No JS animation loop, no layout animation, no backdrop blur.
   - The next screen is built two frames after the tap, so the indicator is already
     painted and travelling before the main thread gets busy.
------------------------------------------------------------------ */

const TABS = ["home", "classes", "categories", "downloads", "more"];

const ICONS = {
  home: `<path class="f" d="M4 10.8 11.2 4.4a1.2 1.2 0 0 1 1.6 0L20 10.8V19a1.5 1.5 0 0 1-1.5 1.5H15v-5a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v5H5.5A1.5 1.5 0 0 1 4 19z"/>`,
  classes: `<path class="f" d="M12 4.4 2.9 9.1 12 13.8l9.1-4.7z"/><path d="M6.6 11.7v4.3c0 1.4 2.5 2.8 5.4 2.8s5.4-1.4 5.4-2.8v-4.3"/><path d="M21.1 9.1v5.4"/>`,
  categories: `<path class="f" d="M12 3.8 3.5 8.3 12 12.8l8.5-4.5z"/><path d="M3.5 12.1 12 16.6l8.5-4.5"/><path d="M3.5 15.9 12 20.4l8.5-4.5"/>`,
  downloads: `<rect class="f" x="4" y="4.5" width="4.6" height="15" rx="1.2"/><rect class="f" x="10" y="4.5" width="4.6" height="15" rx="1.2"/><rect class="f" x="15.6" y="5.2" width="4.6" height="14.6" rx="1.2" transform="rotate(-13 17.9 12.5)"/>`,
  more: `<circle class="d" cx="5.5" cy="12" r="1.75"/><circle class="d" cx="12" cy="12" r="1.75"/><circle class="d" cx="18.5" cy="12" r="1.75"/>`
};

const NAMES = {
  ur: { home: "گھر", classes: "جماعت", categories: "زمرہ", downloads: "لائبریری", more: "مزید" },
  en: { home: "Home", classes: "Class", categories: "Category", downloads: "Library", more: "More" }
};
const ARIA = { ur: "مرکزی نیویگیشن", en: "Main navigation" };

const reduceMotion = () => Boolean(window.matchMedia?.("(prefers-reduced-motion: reduce)").matches);

let nav = null;          // the one and only dock element
let items = [];          // its five buttons
let shownLang = "";
let activeIdx = -2;      // -1 = no tab highlighted (screen is not one of the five tabs)
let tapToken = 0;

function build() {
  nav = document.createElement("nav");
  nav.className = "bottom-nav is-idle";
  nav.hidden = true;

  const track = document.createElement("div");
  track.className = "nav-track";

  const ind = document.createElement("span");
  ind.className = "nav-ind";
  ind.setAttribute("aria-hidden", "true");
  track.appendChild(ind);

  items = TABS.map((route, i) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "nav-item";
    b.dataset.route = route;
    b.innerHTML = `<svg class="nav-ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${ICONS[route]}</svg><span class="nav-label"></span>`;
    b.addEventListener("click", () => onTap(route, i));
    track.appendChild(b);
    return b;
  });

  nav.appendChild(track);
  nav.addEventListener("animationend", () => nav.classList.remove("is-entering"));
  document.body.appendChild(nav);
}

function setLang(lang) {
  const l = lang === "ur" ? "ur" : "en";
  if (l === shownLang) return;
  shownLang = l;
  nav.setAttribute("aria-label", ARIA[l]);
  items.forEach((b, i) => {
    const name = NAMES[l][TABS[i]];
    b.setAttribute("aria-label", name);
    b.querySelector(".nav-label").textContent = name;
  });
}

/** Moves the highlight. `instant` = jump without travelling (first show, or coming back from "no tab"). */
function setActive(idx, instant) {
  if (idx === activeIdx) return;
  const wasIdle = activeIdx < 0;
  activeIdx = idx;
  if (instant || wasIdle) nav.classList.add("jump");
  nav.style.setProperty("--i", String(Math.max(0, idx)));
  nav.classList.toggle("is-idle", idx < 0);
  items.forEach((b, n) => {
    if (n === idx) b.setAttribute("aria-current", "page");
    else b.removeAttribute("aria-current");
  });
  if (nav.classList.contains("jump")) {
    void nav.offsetWidth;                 // apply the jump without a transition, then switch transitions back on
    nav.classList.remove("jump");
  }
}

function onTap(route, i) {
  if (i === activeIdx) {                   // already here: scroll to the top instead of stacking a duplicate history entry
    window.scrollTo({ top: 0, left: 0, behavior: reduceMotion() ? "auto" : "smooth" });
    return;
  }
  try { navigator.vibrate?.(8); } catch {}
  setActive(i, false);                     // the dock reacts on the very first frame
  const mine = ++tapToken;
  let done = false;
  const go = () => {
    if (done || mine !== tapToken) return; // a newer tap replaced this one
    done = true;
    navigate(route);
  };
  // Build the next screen after the indicator has been painted, not before.
  requestAnimationFrame(() => requestAnimationFrame(go));
  setTimeout(go, 120);                     // safety net when frames are throttled
}

/** Show the dock (creating it the first time) with `active` highlighted. Safe to call on every screen render. */
export function showBottomNav(active, lang) {
  if (!nav) build();
  setLang(lang);
  const wasHidden = nav.hidden;
  setActive(TABS.indexOf(active), wasHidden);
  if (wasHidden) {
    nav.hidden = false;
    if (!reduceMotion()) nav.classList.add("is-entering");
  }
}

/** Hide the dock (book page, reader, search ...). The element is kept, so showing it again costs nothing. */
export function hideBottomNav() {
  if (nav && !nav.hidden) {
    nav.hidden = true;
    nav.classList.remove("is-entering");
  }
}

export const BOTTOM_NAV_TABS = TABS;
