/* Pre-paint theme + language, so the splash (and first screen) never flash the wrong colours. */
(function () {
  try {
    var d = document.documentElement, p = "krul:v1:", t = localStorage.getItem(p + "theme"),
      dark = t === "dark" || (t !== "light" && window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches);
    d.dataset.theme = dark ? "dark" : "light";
    d.dataset.ksLang = localStorage.getItem(p + "language") === "en" ? "en" : "ur";
  } catch (e) { /* storage blocked: CSS defaults apply */ }
})();
