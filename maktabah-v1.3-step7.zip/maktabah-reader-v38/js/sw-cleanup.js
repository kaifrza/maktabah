/* No service worker any more: remove any old one plus its stale file cache. */
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.getRegistrations().then(async regs => {
    if (!regs.length) return;
    await Promise.all(regs.map(r => r.unregister()));
    if (window.caches) {
      const keys = await caches.keys();
      await Promise.all(keys.filter(k => k.indexOf("krl-final-") === 0).map(k => caches.delete(k)));
    }
    try {
      if (!sessionStorage.getItem("krl-sw-cleaned")) { sessionStorage.setItem("krl-sw-cleaned", "1"); location.reload(); }
    } catch { /* sessionStorage blocked */ }
  }).catch(() => {});
}
