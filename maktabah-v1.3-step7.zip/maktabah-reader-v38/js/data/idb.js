// Tiny IndexedDB key-value store for data too big or too frequently rewritten for localStorage
// (catalogue cache, highlights). Every call resolves; it never throws and never hangs.
// { ok:false } means "IndexedDB is unavailable", so callers can fall back to localStorage.

const DB_NAME = "krul-data";
const STORE = "kv";
const OPEN_TIMEOUT_MS = 4000;

let dbPromise = null;

function open() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise(resolve => {
    let settled = false;
    const done = db => { if (!settled) { settled = true; clearTimeout(timer); resolve(db); } };
    const timer = setTimeout(() => done(null), OPEN_TIMEOUT_MS);
    try {
      if (typeof indexedDB === "undefined") return done(null);
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
      };
      req.onsuccess = () => {
        const db = req.result;
        db.onversionchange = () => { db.close(); dbPromise = null; };
        db.onclose = () => { dbPromise = null; };
        done(db);
      };
      req.onerror = () => done(null);
      req.onblocked = () => done(null);
    } catch { done(null); }
  });
  return dbPromise;
}

function run(mode, work) {
  return open().then(db => {
    if (!db) return { ok: false, value: null };
    return new Promise(resolve => {
      try {
        const tx = db.transaction(STORE, mode);
        const request = work(tx.objectStore(STORE));
        tx.oncomplete = () => resolve({ ok: true, value: request ? request.result : null });
        tx.onerror = tx.onabort = () => resolve({ ok: false, value: null });
      } catch { resolve({ ok: false, value: null }); }
    });
  });
}

/** { ok, value }: ok=false when IndexedDB is unusable; value=null when the key is missing. */
export async function idbRead(key) {
  const r = await run("readonly", s => s.get(key));
  return { ok: r.ok, value: r.ok && r.value !== undefined ? r.value : null };
}

export async function idbSet(key, value) {
  return (await run("readwrite", s => { s.put(value, key); return null; })).ok;
}

export async function idbDel(key) {
  return (await run("readwrite", s => { s.delete(key); return null; })).ok;
}

export async function idbKeys(prefix = "") {
  const range = prefix ? IDBKeyRange.bound(prefix, prefix + "￿") : undefined;
  const r = await run("readonly", s => s.getAllKeys(range));
  return r.ok && Array.isArray(r.value) ? r.value : [];
}
