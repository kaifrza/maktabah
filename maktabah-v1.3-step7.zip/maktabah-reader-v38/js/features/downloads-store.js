// Small record of books downloaded through this app (title, size, Android download id).
// The PDF files themselves stay in the phone's Downloads folder; nothing is copied here.
import { notifyStorageFull } from "../utils/storage.js";
const KEY = "krl_downloads_v1";

export function getDownloads(){
  try{
    const list = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(list) ? list : [];
  }catch{
    return [];
  }
}

function save(list){
  try{ localStorage.setItem(KEY, JSON.stringify(list)); return true; }catch{ notifyStorageFull(); return false; }
}

export function getDownloadRecord(bookId){
  return getDownloads().find(item => item.bookId === bookId) || null;
}

/** Returns true when the record was stored (false: storage full / unavailable). */
export function addDownloadRecord(record){
  if(!record || record.downloadId === undefined || record.downloadId === null) return false;
  const list = getDownloads().filter(item => item.bookId !== record.bookId);
  list.unshift({ ...record, savedAt: record.savedAt || Date.now() });
  let ok = save(list.slice(0, 500));
  if(!ok) ok = save(list.slice(0, 100));   // storage nearly full: keep the newest records rather than lose this one
  return ok;
}

// Downloads that were started but not yet finished. If the app is closed or reloaded while the system is still
// downloading, this list lets the next launch add the finished book to the library.
const PENDING_KEY = "krl_pending_downloads_v1";
export function getPendingDownloads(){
  try{
    const list = JSON.parse(localStorage.getItem(PENDING_KEY) || "[]");
    return Array.isArray(list) ? list : [];
  }catch{ return []; }
}
function savePending(list){ try{ localStorage.setItem(PENDING_KEY, JSON.stringify(list.slice(0, 50))); }catch{} }
export function addPendingDownload(item){
  if(!item || item.downloadId === undefined || item.downloadId === null) return;
  savePending([item, ...getPendingDownloads().filter(x => x.bookId !== item.bookId)]);
}
export function removePendingDownload(bookId){
  const list = getPendingDownloads();
  const next = list.filter(x => x.bookId !== bookId);
  if(next.length !== list.length) savePending(next);
}

export function removeDownloadRecord(bookId){
  save(getDownloads().filter(item => item.bookId !== bookId));
}
