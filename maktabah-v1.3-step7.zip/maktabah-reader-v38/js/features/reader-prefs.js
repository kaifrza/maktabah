// Small local stores for the in-app reader: look & feel, bookmarks, exact reading position.
// Highlights and ink can be large, so they live in IndexedDB (one record per book); the rest stays in localStorage.
import { idbRead, idbSet, idbDel, idbKeys } from "../data/idb.js";
const PREFS_KEY = "krl_reader_prefs_v1";
const MARKS_KEY = "krl_reader_marks_v1";
const POS_KEY = "krl_reader_pos_v1";
const HL_KEY = "krl_reader_hl_v1";

const DEFAULTS = { theme: "paper", dim: 0, keepAwake: false, autoHide: true };
const THEMES = ["paper", "sepia", "night"];

function read(key, fallback){
  try{
    const v = JSON.parse(localStorage.getItem(key) || "null");
    return v && typeof v === "object" ? v : fallback;
  }catch{ return fallback; }
}
function write(key, value){
  try{ localStorage.setItem(key, JSON.stringify(value)); }catch{}
}

export function getReaderPrefs(){
  const p = { ...DEFAULTS, ...read(PREFS_KEY, {}) };
  if(!THEMES.includes(p.theme)) p.theme = DEFAULTS.theme;
  p.dim = Math.min(.7, Math.max(0, Number(p.dim) || 0));
  p.keepAwake = Boolean(p.keepAwake);
  p.autoHide = p.autoHide !== false;
  return p;
}
export function saveReaderPrefs(patch){
  const next = { ...getReaderPrefs(), ...patch };
  write(PREFS_KEY, next);
  return next;
}

export function getBookmarks(key){
  const all = read(MARKS_KEY, {});
  const list = Array.isArray(all[key]) ? all[key] : [];
  return list.filter(n => Number.isInteger(n) && n > 0).sort((a, b) => a - b);
}
export function toggleBookmark(key, page){
  const all = read(MARKS_KEY, {});
  const list = new Set(Array.isArray(all[key]) ? all[key] : []);
  let added;
  if(list.has(page)){ list.delete(page); added = false; }
  else{ list.add(page); added = true; }
  all[key] = Array.from(list).sort((a, b) => a - b);
  if(!all[key].length) delete all[key];
  write(MARKS_KEY, all);
  return added;
}

export function setBookmarks(key, pages){
  const all = read(MARKS_KEY, {});
  const list = Array.from(new Set((pages || []).map(Number).filter(n => Number.isInteger(n) && n > 0))).sort((a, b) => a - b);
  if(list.length) all[key] = list; else delete all[key];
  write(MARKS_KEY, all);
}

function cleanHighlights(list){
  if(!Array.isArray(list)) return [];
  const out = [];
  const nums = (v, max) => Array.isArray(v) ? v.slice(0, max).map(Number).filter(Number.isFinite) : [];
  for(const h of list){
    if(!h || typeof h !== "object") continue;
    const p = Number(h.p);
    if(!Number.isInteger(p) || p < 1) continue;
    const k = Math.min(2, Math.max(0, Number(h.k) | 0));
    const item = {
      id: String(h.id || "").slice(0, 40) || Math.random().toString(36).slice(2),
      k, p,
      t: String(h.t || "").slice(0, 4000),
      c: Math.min(7, Math.max(0, Number(h.c) | 0)),
      s: Math.min(2, Math.max(0, Number(h.s) | 0)),
      n: String(h.n || "").slice(0, 4000),
      d: Number(h.d) || 0
    };
    if(k === 0){
      const r = nums(h.r, 4000);
      if(r.length < 4) continue;
      item.r = r.slice(0, r.length - (r.length % 4));
    } else {
      const pt = nums(h.pt, 40000);
      if(pt.length < 2) continue;
      item.pt = pt.slice(0, pt.length - (pt.length % 2));
      item.w = Number(h.w) || 0.01;
      item.a = Math.min(100, Math.max(5, Number(h.a) | 0));
      item.m = h.m ? 1 : 0;
      item.f = h.f ? 1 : 0;
    }
    out.push(item);
    if(out.length >= 1500) break;
  }
  return out;
}
const HL_PREFIX = "hl:";

// Older builds kept every book's highlights in ONE localStorage value. Move them once; the old value is
// removed only after every book was stored, so nothing is lost if IndexedDB is unavailable or fails midway.
let hlMigration = null;
function migrateLegacyHighlights(){
  if(!hlMigration){
    hlMigration = (async () => {
      const legacy = read(HL_KEY, null);
      if(!legacy) return;
      for(const [k, list] of Object.entries(legacy)){
        const clean = cleanHighlights(list);
        if(!clean.length) continue;
        const existing = await idbRead(HL_PREFIX + k);
        if(!existing.ok) return;
        if(Array.isArray(existing.value) && existing.value.length) continue;
        if(!(await idbSet(HL_PREFIX + k, clean))) return;
      }
      try{ localStorage.removeItem(HL_KEY); }catch{}
    })().catch(() => {});
  }
  return hlMigration;
}

export async function getHighlights(key){
  await migrateLegacyHighlights();
  const r = await idbRead(HL_PREFIX + key);
  if(r.ok) return cleanHighlights(r.value);
  return cleanHighlights(read(HL_KEY, {})[key]);      // IndexedDB unavailable: legacy location
}
export async function setHighlights(key, list){
  await migrateLegacyHighlights();
  const clean = cleanHighlights(list);
  const ok = clean.length ? await idbSet(HL_PREFIX + key, clean) : await idbDel(HL_PREFIX + key);
  if(ok) return;
  const all = read(HL_KEY, {});
  if(clean.length) all[key] = clean; else delete all[key];
  write(HL_KEY, all);
}

export function getReadingPosition(key){
  const all = read(POS_KEY, {});
  const v = all[key];
  if(!v || !Number.isInteger(v.p) || v.p < 1) return null;
  return { page: v.p, frac: Math.min(1, Math.max(0, Number(v.f) || 0)) };
}
export function saveReadingPosition(key, page, frac){
  const all = read(POS_KEY, {});
  all[key] = { p: page, f: Math.round(frac * 1000) / 1000 };
  const keys = Object.keys(all);
  if(keys.length > 400) delete all[keys[0]];
  write(POS_KEY, all);
}

// Copy bookmarks + reading position from an old key to a new one (only if the new key has none yet).
export async function migrateReaderKey(from, to){
  if(!from || !to || from === to) return;
  const marks = read(MARKS_KEY, {});
  if(marks[from] && !marks[to]){ marks[to] = marks[from]; write(MARKS_KEY, marks); }
  const pos = read(POS_KEY, {});
  if(pos[from] && !pos[to]){ pos[to] = pos[from]; write(POS_KEY, pos); }
  const fromHl = await getHighlights(from);
  if(fromHl.length && !(await getHighlights(to)).length) await setHighlights(to, fromHl);
}

/* ---------------------------------------------------------------- backup / restore */

export async function exportReaderData(){
  await migrateLegacyHighlights();
  const highlights = {};
  for(const k of await idbKeys(HL_PREFIX)){
    const list = await getHighlights(String(k).slice(HL_PREFIX.length));
    if(list.length) highlights[String(k).slice(HL_PREFIX.length)] = list;
  }
  if(!Object.keys(highlights).length){
    const legacy = read(HL_KEY, {});
    for(const [k, v] of Object.entries(legacy)){ const l = cleanHighlights(v); if(l.length) highlights[k] = l; }
  }
  return { marks: read(MARKS_KEY, {}), positions: read(POS_KEY, {}), highlights };
}

/** Merges reader data from a backup: bookmarks are united, positions and highlights never replace what exists. */
export async function importReaderData(data = {}){
  const added = { marks: 0, positions: 0, highlights: 0 };
  const okKey = k => typeof k === "string" && k.length > 0 && k.length <= 300;

  const marksIn = data.marks && typeof data.marks === "object" ? data.marks : {};
  for(const [k, pages] of Object.entries(marksIn).slice(0, 2000)){
    if(!okKey(k) || !Array.isArray(pages)) continue;
    const have = getBookmarks(k);
    const merged = Array.from(new Set([...have, ...pages.map(Number).filter(n => Number.isInteger(n) && n > 0)])).sort((a, b) => a - b);
    if(merged.length > have.length){ setBookmarks(k, merged); added.marks += merged.length - have.length; }
  }

  const posIn = data.positions && typeof data.positions === "object" ? data.positions : {};
  const pos = read(POS_KEY, {});
  for(const [k, v] of Object.entries(posIn).slice(0, 2000)){
    if(!okKey(k) || pos[k] || !v || !Number.isInteger(v.p) || v.p < 1) continue;
    pos[k] = { p: v.p, f: Math.min(1, Math.max(0, Number(v.f) || 0)) };
    added.positions++;
  }
  if(added.positions) write(POS_KEY, pos);

  const hlIn = data.highlights && typeof data.highlights === "object" ? data.highlights : {};
  for(const [k, list] of Object.entries(hlIn).slice(0, 2000)){
    if(!okKey(k)) continue;
    const incoming = cleanHighlights(list);
    if(!incoming.length) continue;
    const have = await getHighlights(k);
    const ids = new Set(have.map(h => h.id));
    const fresh = incoming.filter(h => !ids.has(h.id));
    if(fresh.length){ await setHighlights(k, [...have, ...fresh]); added.highlights += fresh.length; }
  }
  return added;
}
