// Thin reading-progress line shown under a book cover.
// Progress is saved by the native reader when it closes (see native-reader.js) under the book's progress key.
import { getBookProgress } from "./storage.js";

/** 0..100 (not rounded); 0 when the book was never read. A started book shows at least a small stub. */
export function readPercent(key){
  if(!key) return 0;
  let p = null;
  try{ p = getBookProgress(key); }catch{ return 0; }
  if(!p) return 0;
  const page = Number(p.page) || 0, total = Number(p.totalPages) || 0;
  let pct = total > 0 && page > 0 ? page / total * 100 : Number(p.percent) || 0;
  if(!(pct > 0)) return 0;
  pct = Math.min(100, pct);
  return pct < 3 ? 3 : pct;
}

/**
 * @param key      progress key of the book
 * @param lang     "ur" | "en" (label only)
 * @param reserve  true: always output the line (invisible when unread) so cards in a row keep the same height
 */
export function readLine(key, lang, reserve = true){
  const pct = readPercent(key);
  if(!pct) return reserve ? `<span class="read-line is-empty" aria-hidden="true"><i></i></span>` : "";
  const shown = Math.round(pct);
  const label = lang === "ur" ? `${shown}% پڑھا گیا` : `${shown}% read`;
  return `<span class="read-line${pct >= 98 ? " is-done" : ""}" role="img" aria-label="${label}" title="${label}"><i style="width:${pct.toFixed(1)}%"></i></span>`;
}
