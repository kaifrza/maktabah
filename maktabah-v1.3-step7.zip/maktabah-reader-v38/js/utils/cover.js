// Shared cover-image markup + persistent cover cache.
//
// How a cover reaches the screen:
//   1. The typeset cover is always drawn underneath. The <img> fades in over it once it has loaded,
//      and is removed if it fails. So the typeset cover only ever shows while loading / when offline.
//   2. wireCover() waits until the cover is near the screen (IntersectionObserver), so a long list
//      does not download hundreds of covers at once.
//   3. getCover() looks in: memory -> IndexedDB (persistent, survives restarts and works offline)
//      -> the network (max 4 at a time, 10 s timeout). A fresh download is saved for next time.
//   4. Each visible <img> gets its OWN object URL, revoked only after the image leaves the DOM.
//
// The persistent cache is bounded (size + number of covers, least-recently-used removed first) and
// entries older than 30 days are refreshed (the old copy is still shown if the refresh fails).
//
// Hosts that do not allow cross-origin reads (no CORS) cannot be saved. They are remembered for a week
// and their covers are simply loaded directly by the browser (its own HTTP cache still applies).

const DB_NAME = 'kr-urdu-library-covers';
const DB_VERSION = 1;
const STORE = 'covers';
const LEGACY_CACHE_NAME = 'kr-urdu-library-covers-v1';   // older versions used Cache Storage

const MAX_BYTES = 60 * 1024 * 1024;
const MAX_ENTRIES = 500;
const MAX_FILE_BYTES = 2.5 * 1024 * 1024;
const TTL_MS = 30 * 24 * 60 * 60 * 1000;
const TOUCH_EVERY_MS = 6 * 60 * 60 * 1000;
const FETCH_TIMEOUT_MS = 10000;
const MAX_PARALLEL = 4;
const FAIL_COOLDOWN_MS = 3 * 60 * 1000;
const NOCORS_KEY = 'kr-cover-nocors-v1';
const NOCORS_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const MEMORY_LIMIT = 48;

const imageObjectUrls = new Map();
const coverInFlight = new Map();
const failedUntil = new Map();
const memory = new Map();          // url -> Blob (small LRU, makes re-renders instant)
let cleanupObserver = null;
let visibilityObserver = null;
const pendingStart = new WeakMap(); // container -> function that starts its load

/* ------------------------------------------------------------------ storage (IndexedDB) */

let dbPromise = null;
function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise(resolve => {
    try {
      if (typeof indexedDB === 'undefined') return resolve(null);
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const store = req.result.createObjectStore(STORE, { keyPath: 'url' });
        store.createIndex('lastUsed', 'lastUsed');
      };
      req.onsuccess = () => {
        const db = req.result;
        // Ask the WebView not to evict this data when the phone is low on space (it may simply say no).
        try { navigator.storage?.persist?.().catch(() => {}); } catch { /* not supported */ }
        db.onversionchange = () => { db.close(); dbPromise = null; };
        resolve(db);
      };
      req.onerror = req.onblocked = () => resolve(null);
    } catch { resolve(null); }
  });
  return dbPromise;
}

function run(db, mode, work) {
  return new Promise(resolve => {
    if (!db) return resolve(null);
    try {
      const tx = db.transaction(STORE, mode);
      const request = work(tx.objectStore(STORE));
      tx.oncomplete = () => resolve(request && 'result' in request ? request.result : true);
      tx.onerror = tx.onabort = () => resolve(null);
    } catch { resolve(null); }
  });
}

const dbGet = async url => run(await openDb(), 'readonly', s => s.get(url));
const dbPut = async record => run(await openDb(), 'readwrite', s => s.put(record));
const dbDelete = async url => run(await openDb(), 'readwrite', s => s.delete(url));
const dbAll = async () => (await run(await openDb(), 'readonly', s => s.getAll())) || [];

// Removes the least recently used covers until the cache is under its limits.
// `force` is used when the device refused a write (storage full): then it trims down to half.
async function prune({ force = false } = {}) {
  const all = await dbAll();
  let bytes = all.reduce((n, r) => n + (r.size || 0), 0);
  let count = all.length;
  if (!force && bytes <= MAX_BYTES && count <= MAX_ENTRIES) return;
  const factor = force ? 0.5 : 0.85;
  const targetBytes = Math.min(bytes, MAX_BYTES) * factor, targetCount = Math.min(count, MAX_ENTRIES) * factor;
  all.sort((a, b) => (a.lastUsed || 0) - (b.lastUsed || 0));          // least recently used first
  for (const rec of all) {
    if (bytes <= targetBytes && count <= targetCount) break;
    await dbDelete(rec.url);
    bytes -= rec.size || 0; count -= 1; memory.delete(rec.url);
  }
}

let pruneTimer = 0;
function schedulePrune() {
  clearTimeout(pruneTimer);
  pruneTimer = setTimeout(() => { prune().catch(() => {}); }, 2500);
}

function remember(url, blob) {
  memory.delete(url);
  memory.set(url, blob);
  while (memory.size > MEMORY_LIMIT) memory.delete(memory.keys().next().value);
}

/* ------------------------------------------------------------------ hosts without CORS */

const hostOf = url => { try { return new URL(url, location.href).host; } catch { return ''; } };
function readNoCors() { try { return JSON.parse(localStorage.getItem(NOCORS_KEY) || '{}') || {}; } catch { return {}; } }
const isNoCors = host => (readNoCors()[host] || 0) > Date.now();
function markNoCors(host) {
  try {
    const map = readNoCors();
    map[host] = Date.now() + NOCORS_TTL_MS;
    localStorage.setItem(NOCORS_KEY, JSON.stringify(map));
  } catch { /* best effort */ }
}

/* A CORS failure and a plain network failure look the same. Probe without CORS: if THAT works,
   the network is fine and the host just does not allow reading the image. */
async function probeNoCors(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 6000);
  try { await fetch(url, { mode: 'no-cors', credentials: 'omit', signal: controller.signal }); return true; }
  catch { return false; }
  finally { clearTimeout(timer); }
}

/* ------------------------------------------------------------------ network queue */

let active = 0;
const waiting = [];
function schedule(task) {
  return new Promise((resolve, reject) => {
    const go = () => {
      active += 1;
      task().then(resolve, reject).finally(() => {
        active -= 1;
        const next = waiting.shift();
        if (next) next();
      });
    };
    if (active < MAX_PARALLEL) go(); else waiting.push(go);
  });
}

async function download(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: controller.signal, credentials: 'omit' });
    if (!res.ok) { const e = new Error(`Cover request failed (${res.status})`); e.http = true; throw e; }
    const blob = await res.blob();
    if (!blob.size) { const e = new Error('Empty cover'); e.http = true; throw e; }
    if (blob.type && !/^image\//i.test(blob.type)) { const e = new Error('Not an image'); e.http = true; throw e; }
    return blob;
  } finally { clearTimeout(timer); }
}

/* Old builds kept covers in Cache Storage. Read through once, move the hit into IndexedDB. */
async function readLegacy(url) {
  try {
    if (typeof caches === 'undefined') return null;
    const cache = await caches.open(LEGACY_CACHE_NAME);
    const hit = await cache.match(url, { ignoreVary: true });
    if (!hit) return null;
    const blob = await hit.blob();
    if (!blob || !blob.size) return null;
    cache.delete(url).catch(() => {});
    return blob;
  } catch { return null; }
}

async function storeBlob(url, blob) {
  if (blob.size > MAX_FILE_BYTES) return;
  const now = Date.now();
  const record = { url, blob, size: blob.size, savedAt: now, lastUsed: now };
  if (await dbPut(record) === null) {
    // The write failed (usually: the phone is low on storage). Make room once and retry; if it still
    // fails the cover just isn't saved and keeps loading from the network.
    await prune({ force: true });
    await dbPut(record);
  }
  schedulePrune();
}

/**
 * Resolves to a Blob for the cover, or null when it can't be provided as a Blob
 * (the caller then lets the browser load the URL directly).
 */
export function getCover(url, { background = false } = {}) {
  if (!url || !/^https?:/i.test(url)) return Promise.resolve(null);
  if (coverInFlight.has(url)) return coverInFlight.get(url);

  const task = (async () => {
    const mem = memory.get(url);
    if (mem) { remember(url, mem); return mem; }

    const rec = await dbGet(url);
    const age = rec ? Date.now() - (rec.savedAt || 0) : Infinity;
    if (rec?.blob && age < TTL_MS) {
      remember(url, rec.blob);
      if (Date.now() - (rec.lastUsed || 0) > TOUCH_EVERY_MS) dbPut({ ...rec, lastUsed: Date.now() });
      return rec.blob;
    }
    const stale = rec?.blob || null;             // expired copy: used only if a refresh is impossible

    if (!rec) {
      const legacy = await readLegacy(url);
      if (legacy) { remember(url, legacy); storeBlob(url, legacy); return legacy; }
    }

    const offline = typeof navigator !== 'undefined' && navigator.onLine === false;
    const cooling = (failedUntil.get(url) || 0) > Date.now();
    if (offline || cooling || isNoCors(hostOf(url))) return stale;

    try {
      const blob = await schedule(() => download(url));
      remember(url, blob);
      storeBlob(url, blob);
      return blob;
    } catch (error) {
      failedUntil.set(url, Date.now() + FAIL_COOLDOWN_MS);
      const looksLikeCors = !error?.http && error?.name !== 'AbortError' && !offline;
      if (looksLikeCors && !background && await probeNoCors(url)) markNoCors(hostOf(url));
      return stale;
    }
  })();

  coverInFlight.set(url, task);
  task.finally(() => coverInFlight.delete(url));
  return task;
}

/** Quietly downloads covers (favourites, downloads...) so they also show offline. One at a time. */
let prefetching = false;
export async function prefetchCovers(urls = []) {
  if (prefetching) return;
  if (typeof navigator !== 'undefined' && (navigator.onLine === false || navigator.connection?.saveData)) return;
  prefetching = true;
  try {
    for (const url of [...new Set(urls)].filter(Boolean).slice(0, 60)) {
      if (typeof navigator !== 'undefined' && navigator.onLine === false) break;
      if (memory.has(url)) continue;
      await getCover(url, { background: true });
    }
  } finally { prefetching = false; }
}

export async function getCoverCacheInfo() {
  const all = await dbAll();
  return { count: all.length, bytes: all.reduce((n, r) => n + (r.size || 0), 0) };
}

export async function clearCoverCache() {
  memory.clear(); failedUntil.clear();
  const db = await openDb();
  await run(db, 'readwrite', s => s.clear());
  try { localStorage.removeItem(NOCORS_KEY); } catch { /* ignore */ }
  try { if (typeof caches !== 'undefined') await caches.delete(LEGACY_CACHE_NAME); } catch { /* ignore */ }
}

/* ------------------------------------------------------------------ DOM side */

function revokeImageObjectUrl(img) {
  const url = imageObjectUrls.get(img);
  if (!url) return;
  URL.revokeObjectURL(url);
  imageObjectUrls.delete(img);
}

const eachPending = (node, fn) => {
  if (node.nodeType !== 1) return;
  if (node.hasAttribute('data-cover-pending')) fn(node);
  node.querySelectorAll?.('[data-cover-pending]').forEach(fn);
};

function ensureObservers() {
  if (cleanupObserver || typeof MutationObserver === 'undefined' || !document.body) return;
  cleanupObserver = new MutationObserver(mutations => {
    // Revoke only images that are still detached after the whole batch;
    // nodes that were removed and re-added (replaceChildren) stay alive.
    const revokeIfDetached = img => { if (!img.isConnected) revokeImageObjectUrl(img); };
    for (const mutation of mutations) {
      for (const removed of mutation.removedNodes) {
        if (removed.nodeType !== 1) continue;
        if (removed.matches?.('img')) revokeIfDetached(removed);
        removed.querySelectorAll?.('img').forEach(revokeIfDetached);
        if (visibilityObserver) eachPending(removed, el => { if (!el.isConnected) visibilityObserver.unobserve(el); });
      }
      // A card built earlier but only attached now starts being watched from this moment.
      if (visibilityObserver) {
        for (const added of mutation.addedNodes) {
          eachPending(added, el => { if (el.isConnected && pendingStart.has(el)) visibilityObserver.observe(el); });
        }
      }
    }
  });
  cleanupObserver.observe(document.body, { childList: true, subtree: true });
}

// Starts `start` when the cover is within ~one screen of the viewport.
function whenNearScreen(container, start) {
  if (typeof IntersectionObserver === 'undefined') { start(); return; }
  if (!visibilityObserver) {
    visibilityObserver = new IntersectionObserver(entries => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        visibilityObserver.unobserve(entry.target);
        entry.target.removeAttribute('data-cover-pending');
        const fn = pendingStart.get(entry.target);
        pendingStart.delete(entry.target);
        fn?.();
      }
    }, { root: null, rootMargin: '600px 0px', threshold: 0 });
  }
  pendingStart.set(container, start);
  container.setAttribute('data-cover-pending', '');
  if (container.isConnected) visibilityObserver.observe(container);   // else: observed when attached
}

// Returns "" when there is no cover: callers draw their own typeset cover underneath.
const SAFE_COVER = /^(https?:\/\/|\/(?!\/)|\.{1,2}\/|blob:|data:image\/(png|jpe?g|webp|gif|avif);)/i;
export function coverMarkup(coverUrl, alt = "") {
  if (!coverUrl || !SAFE_COVER.test(String(coverUrl).trim())) return "";
  return `<div class="cover-spinner" aria-hidden="true"></div><img loading="lazy" decoding="async" data-cover-src="${coverUrl}" alt="${alt}">`;
}

// Call this once the markup above has been created (it may be attached to the page a moment later).
export function wireCover(container) {
  if (!container) return;
  ensureObservers();

  const img = container.querySelector("img");
  const spinner = container.querySelector(".cover-spinner");
  if (!img) { spinner?.remove(); return; }

  const sourceUrl = img.dataset.coverSrc;
  if (!sourceUrl) { spinner?.remove(); return; }

  let settled = false;
  const clearSpinner = () => spinner?.remove();
  // A failed image is simply removed: the typeset cover underneath stays visible.
  const dropImage = () => {
    if (settled) return;
    settled = true;
    revokeImageObjectUrl(img);
    clearSpinner();
    img.remove();
  };

  img.addEventListener("load", () => {
    settled = true;
    clearSpinner();
    img.classList.add("is-loaded");
  }, { once: true });
  img.addEventListener("error", dropImage, { once: true });

  const start = () => {
    getCover(sourceUrl).then(blob => {
      if (settled) return;
      if (!img.isConnected) { whenNearScreen(container, start); return; }   // screen changed meanwhile: retry when shown again
      if (blob && typeof URL?.createObjectURL === 'function') {
        try {
          const objectUrl = URL.createObjectURL(blob);
          imageObjectUrls.set(img, objectUrl);
          img.src = objectUrl;
          return;
        } catch { /* fall through to the canonical URL */ }
      }
      img.src = sourceUrl;     // not cacheable here: let the browser load (and HTTP-cache) it
    }).catch(() => {
      if (!settled && img.isConnected) img.src = sourceUrl;
    });
  };

  if (document.body) whenNearScreen(container, start); else start();
}

window.addEventListener('pagehide', () => {
  for (const img of imageObjectUrls.keys()) revokeImageObjectUrl(img);
});
