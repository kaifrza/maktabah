const PREFIX = "krul:v1:";
const LIMITS = { history: 50, progress: 300, ids: 5000 };

let lastFullNotice = 0;
/** Tells the UI (once per 30 s) that the browser refused a write, so the user is not left guessing. */
export function notifyStorageFull() {
  const now = Date.now();
  if (now - lastFullNotice < 30000) return;
  lastFullNotice = now;
  try { window.dispatchEvent(new CustomEvent("krul:storage-full")); } catch { /* no window */ }
}

function safeRead(key, fallback) {
  try {
    const value = localStorage.getItem(PREFIX + key);
    if (value === null) return fallback;
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function safeWrite(key, value) {
  try { localStorage.setItem(PREFIX + key, JSON.stringify(value)); return true; }
  catch { notifyStorageFull(); return false; }
}

export function getFavorites() {
  const value = safeRead("favorites", []);
  return Array.isArray(value) ? value.filter(x => typeof x === "string" && x) : [];
}

export function toggleFavorite(id) {
  if (!id) return getFavorites();
  const favorites = new Set(getFavorites());
  favorites.has(id) ? favorites.delete(id) : favorites.add(id);
  const result = [...favorites];
  safeWrite("favorites", result);
  return result;
}

export function isFavorite(id) { return getFavorites().includes(id); }

export function getHistory() {
  const value = safeRead("history", []);
  return Array.isArray(value) ? value.filter(x => typeof x === "string" && x) : [];
}

export function addHistory(id) {
  if (!id) return getHistory();
  const history = getHistory().filter(x => x !== id);
  history.unshift(id);
  safeWrite("history", history.slice(0, LIMITS.history));
}

export function clearHistory() { safeWrite("history", []); }

export function getProgress() {
  const value = safeRead("progress", {});
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

export function setProgress(id, progress) {
  if (!id || !progress || typeof progress !== "object") return null;
  const all = getProgress();
  all[id] = { ...all[id], ...progress, updatedAt: new Date().toISOString() };
  const ids = Object.keys(all);
  if (ids.length > LIMITS.progress) {
    ids.sort((a, b) => String(all[b]?.updatedAt || "").localeCompare(String(all[a]?.updatedAt || "")));
    ids.slice(LIMITS.progress).forEach(k => delete all[k]);
  }
  safeWrite("progress", all);
  return all[id];
}

export function getBookProgress(id) { return getProgress()[id] || null; }

export function clearProgress() { safeWrite("progress", {}); }

export function getTheme() {
  let value = null;
  try { value = localStorage.getItem(PREFIX + "theme"); } catch { /* storage blocked */ }
  return ["system","light","dark"].includes(value) ? value : "system";
}
export function setTheme(theme) {
  if (!["system","light","dark"].includes(theme)) return false;
  try { localStorage.setItem(PREFIX + "theme", theme); return true; } catch { return false; }
}
export function getLanguage() {
  let value = null;
  try { value = localStorage.getItem(PREFIX + "language"); } catch { /* storage blocked */ }
  return ["ur","en"].includes(value) ? value : "ur";
}
export function setLanguage(lang) {
  if (!["ur","en"].includes(lang)) return false;
  try { localStorage.setItem(PREFIX + "language", lang); return true; } catch { return false; }
}


/* ---------------------------------------------------------------- backup / restore */

const cleanId = v => (typeof v === "string" && v.length > 0 && v.length <= 200 ? v : null);

function cleanIds(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  const seen = new Set();
  for (const item of list.slice(0, LIMITS.ids)) {
    const id = cleanId(item);
    if (id && !seen.has(id)) { seen.add(id); out.push(id); }
  }
  return out;
}

function cleanProgressEntry(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const out = {};
  for (const [k, v] of Object.entries(value).slice(0, 12)) {
    if (typeof v === "number" && Number.isFinite(v)) out[k.slice(0, 40)] = v;
    else if (typeof v === "string" && v.length <= 200) out[k.slice(0, 40)] = v;
  }
  return Object.keys(out).length ? out : null;
}

export function exportUserData() {
  return { favorites: getFavorites(), history: getHistory(), progress: getProgress() };
}

/** Merges (never overwrites) data from a backup. Returns how many items were new. */
export function importUserData(data = {}) {
  const added = { favorites: 0, history: 0, progress: 0 };

  const favorites = getFavorites();
  const haveFav = new Set(favorites);
  for (const id of cleanIds(data.favorites)) if (!haveFav.has(id)) { favorites.push(id); added.favorites++; }
  if (added.favorites) safeWrite("favorites", favorites);

  const history = getHistory();
  const haveHist = new Set(history);
  const extra = cleanIds(data.history).filter(id => !haveHist.has(id));
  if (extra.length) {
    added.history = Math.min(extra.length, Math.max(0, LIMITS.history - history.length));
    safeWrite("history", [...history, ...extra].slice(0, LIMITS.history));
  }

  const progress = getProgress();
  const incoming = data.progress && typeof data.progress === "object" && !Array.isArray(data.progress) ? data.progress : {};
  for (const [rawId, rawEntry] of Object.entries(incoming).slice(0, LIMITS.progress * 2)) {
    const id = cleanId(rawId);
    const entry = cleanProgressEntry(rawEntry);
    if (!id || !entry) continue;
    const current = progress[id];
    // The more recently updated record wins; a record without a date never beats one that has it.
    if (!current || String(entry.updatedAt || "") > String(current.updatedAt || "")) {
      progress[id] = entry;
      added.progress++;
    }
  }
  if (added.progress) {
    const ids = Object.keys(progress);
    if (ids.length > LIMITS.progress) {
      ids.sort((a, b) => String(progress[b]?.updatedAt || "").localeCompare(String(progress[a]?.updatedAt || "")));
      ids.slice(LIMITS.progress).forEach(k => delete progress[k]);
    }
    safeWrite("progress", progress);
  }
  return added;
}
