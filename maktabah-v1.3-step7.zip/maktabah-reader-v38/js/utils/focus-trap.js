// Keeps Tab inside an open dialog and returns focus to the control that opened it.
const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

/** Returns a release() function: call it when the dialog closes. */
export function trapFocus(container) {
  const previous = document.activeElement;
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
    document.removeEventListener("keydown", onKey, true);
    try { if (previous && previous.isConnected && typeof previous.focus === "function") previous.focus({ preventScroll: true }); } catch { /* element gone */ }
  };
  function onKey(e) {
    if (!container.isConnected) { released = true; document.removeEventListener("keydown", onKey, true); return; }   // removed without release() (Android Back)
    if (e.key !== "Tab") return;
    const items = [...container.querySelectorAll(FOCUSABLE)].filter(el => el.getClientRects().length > 0);
    if (!items.length) { e.preventDefault(); return; }
    const first = items[0], last = items[items.length - 1], active = document.activeElement;
    if (!container.contains(active)) { e.preventDefault(); first.focus(); }
    else if (e.shiftKey && active === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && active === last) { e.preventDefault(); first.focus(); }
  }
  document.addEventListener("keydown", onKey, true);
  return release;
}
