#!/usr/bin/env python3
"""Bundle + minify the web app for the APK / hosting build.

Usage: python3 ci/optimize-web.py <web-root>      (web-root = the folder that holds index.html, e.g. www)

- All stylesheets linked in index.html (except splash.css, which must paint first) become ONE minified css/app.css.
- js/app.js and everything it imports become ONE minified js/app.js. The four classic boot scripts are minified in place.
- Nothing is written to the real folder until every step worked; on any error the folder is left untouched
  and the script exits with code 1, so the build can simply continue with the readable, unbundled files.
Needs esbuild (env ESBUILD, else `npx esbuild`).
"""
import os, re, shutil, subprocess, sys, tempfile

root = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else "www")
ESBUILD = os.environ.get("ESBUILD", "").split() or ["npx", "--no-install", "esbuild"]
CLASSIC = ["perf-boot.js", "theme-boot.js", "splash.js", "sw-cleanup.js"]
KEEP_CSS = {"splash.css"}


def run(args):
    r = subprocess.run(ESBUILD + args, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("esbuild failed: " + (r.stderr or r.stdout)[-1500:])
    return r


def size(p):
    return os.path.getsize(p) if os.path.exists(p) else 0


def main():
    if not os.path.isfile(os.path.join(root, "index.html")):
        raise RuntimeError("index.html not found in " + root)
    stage = tempfile.mkdtemp(prefix="krweb-")
    try:
        work = os.path.join(stage, "w")
        shutil.copytree(root, work)
        html_path = os.path.join(work, "index.html")
        html = open(html_path, encoding="utf-8").read()
        before = {"css": 0, "js": 0}

        # ---- CSS: one file, in the order index.html loads them
        link_re = re.compile(r'[ \t]*<link rel="stylesheet" href="\./css/([\w.-]+\.css)">[ \t]*\n?')
        merged = [m.group(1) for m in link_re.finditer(html) if m.group(1) not in KEEP_CSS]
        if not merged:
            raise RuntimeError("no local stylesheets found in index.html")
        parts = []
        for name in merged:
            p = os.path.join(work, "css", name)
            before["css"] += size(p)
            parts.append("/* ==== %s ==== */\n%s\n" % (name, open(p, encoding="utf-8").read()))
        combined = os.path.join(stage, "all.css")
        open(combined, "w", encoding="utf-8").write("".join(parts))
        run([combined, "--minify", "--loader:.css=css", "--outfile=" + os.path.join(work, "css", "app.css")])

        first = {"done": False}

        def swap(m):
            name = m.group(1)
            if name in KEEP_CSS:
                return m.group(0)
            if not first["done"]:
                first["done"] = True
                return '  <link rel="stylesheet" href="./css/app.css">\n'
            return ""

        html = link_re.sub(swap, html)
        for name in merged:
            os.remove(os.path.join(work, "css", name))

        # ---- JS: one module bundle + minified classic scripts
        js_dir = os.path.join(work, "js")
        for dirpath, _, files in os.walk(js_dir):
            for f in files:
                if f.endswith(".js"):
                    before["js"] += size(os.path.join(dirpath, f))
        bundle = os.path.join(stage, "app.bundle.js")
        run([os.path.join(js_dir, "app.js"), "--bundle", "--format=esm", "--target=chrome89", "--minify",
             "--legal-comments=none", "--external:/vendor/*", "--external:https://*", "--outfile=" + bundle])
        for dirpath, _, files in os.walk(js_dir, topdown=False):
            for f in files:
                if f.endswith(".js") and not (dirpath == js_dir and f in CLASSIC):
                    os.remove(os.path.join(dirpath, f))
            if dirpath != js_dir and not os.listdir(dirpath):
                os.rmdir(dirpath)
        shutil.copyfile(bundle, os.path.join(js_dir, "app.js"))
        for f in CLASSIC:
            p = os.path.join(js_dir, f)
            if os.path.exists(p):
                run([p, "--minify", "--legal-comments=none", "--allow-overwrite", "--outfile=" + p])

        open(html_path, "w", encoding="utf-8").write(html)

        for must in ("css/app.css", "js/app.js", "index.html"):
            if size(os.path.join(work, must)) < 100:
                raise RuntimeError("missing or empty output: " + must)

        # ---- everything worked: swap into place
        for sub in ("css", "js"):
            shutil.rmtree(os.path.join(root, sub))
            shutil.copytree(os.path.join(work, sub), os.path.join(root, sub))
        shutil.copyfile(html_path, os.path.join(root, "index.html"))
        print("optimize-web: css %d KB -> %d KB (%d files -> 1) | js %d KB -> %d KB" % (
            before["css"] // 1024, size(os.path.join(root, "css", "app.css")) // 1024, len(merged),
            before["js"] // 1024, sum(size(os.path.join(js_dir.replace(work, root), f)) for f in os.listdir(js_dir.replace(work, root))) // 1024))
    finally:
        shutil.rmtree(stage, ignore_errors=True)


try:
    main()
except Exception as e:
    print("optimize-web: SKIPPED, files left unbundled:", e)
    sys.exit(1)
