package com.maktabah.kaif;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Resumable HTTPS downloader. Partial data lives in app storage (.part); a finished, verified PDF is
 * published to the public Downloads folder. Ids are above OWN_BASE so they never clash with the ids of
 * Android's DownloadManager, which older records may still use. Status codes mirror DownloadManager:
 * 2 running, 4 paused, 8 successful, 16 failed.
 */
final class KRDownloadEngine {
    static final long OWN_BASE = 1_000_000_000_000L;
    static final int RUNNING = 2, PAUSED = 4, SUCCESS = 8, FAILED = 16;
    static final int R_NETWORK = 1, R_WRITE = 1001, R_NOT_PDF = 1002, R_BAD_FILE = 1003, R_SPACE = 1006;

    private static final String PREFS = "kr_downloads";
    private static final Map<Long, Job> JOBS = new ConcurrentHashMap<>();
    private static final AtomicLong LAST_ID = new AtomicLong(0);

    private KRDownloadEngine() { }

    static boolean isOwn(long id) { return id >= OWN_BASE; }

    private static SharedPreferences prefs(Context c) { return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    private static File partFile(Context c, long id) {
        File dir = new File(c.getApplicationContext().getFilesDir(), "dl");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        return new File(dir, id + ".part");
    }

    // ------------------------------------------------------------------ public API

    static long start(Context ctx, String url, String name) {
        long now = System.currentTimeMillis();
        long id;
        while (true) {
            long last = LAST_ID.get();
            id = Math.max(last + 1, Math.max(now, OWN_BASE));
            if (LAST_ID.compareAndSet(last, id)) break;
        }
        Job j = new Job(ctx.getApplicationContext(), id, url, name);
        JOBS.put(id, j);
        j.saveMeta();
        j.launch();
        return id;
    }

    /** Running/paused/finished job for this id, restored from disk after the app process was killed. */
    static Job get(Context ctx, long id) {
        Job j = JOBS.get(id);
        if (j != null) return j;
        Context app = ctx.getApplicationContext();
        SharedPreferences p = prefs(app);
        try {
            String fin = p.getString("f" + id, null);
            if (fin != null) {
                JSONObject o = new JSONObject(fin);
                Job d = new Job(app, id, "", o.optString("name", "book.pdf"));
                d.status = SUCCESS;
                d.downloaded = d.total = o.optLong("size", 0);
                d.mime = "application/pdf";
                d.uri = "file://" + o.optString("path", "/" + d.name);
                JOBS.put(id, d);
                return d;
            }
            String meta = p.getString("p" + id, null);
            if (meta != null) {
                JSONObject o = new JSONObject(meta);
                File part = partFile(app, id);
                if (!part.isFile()) { p.edit().remove("p" + id).apply(); return null; }
                Job r = new Job(app, id, o.optString("url"), o.optString("name", "book.pdf"));
                r.downloaded = part.length();
                r.total = o.optLong("total", -1);
                r.status = PAUSED;
                r.reason = R_NETWORK;
                JOBS.put(id, r);
                return r;
            }
        } catch (Exception ignored) { }
        return null;
    }

    static boolean pause(Context ctx, long id) {
        Job j = get(ctx, id);
        if (j == null || j.status != RUNNING) return false;
        j.stop(false);
        return true;
    }

    static boolean resume(Context ctx, long id) {
        Job j = get(ctx, id);
        if (j == null || j.status != PAUSED) return false;
        j.launch();
        return true;
    }

    static void cancel(Context ctx, long id) {
        Job j = get(ctx, id);
        if (j == null) return;
        j.stop(true);
        if (!j.alive()) j.cleanup();
    }

    /** Removes a finished download from the Downloads folder. */
    static void delete(Context ctx, long id) {
        Context app = ctx.getApplicationContext();
        SharedPreferences p = prefs(app);
        try {
            String fin = p.getString("f" + id, null);
            if (fin != null) {
                JSONObject o = new JSONObject(fin);
                String content = o.optString("content", "");
                String path = o.optString("path", "");
                boolean gone = false;
                if (!content.isEmpty()) {
                    try { gone = app.getContentResolver().delete(Uri.parse(content), null, null) > 0; } catch (Exception ignored) { }
                }
                if (!gone && !path.isEmpty()) {
                    //noinspection ResultOfMethodCallIgnored
                    new File(path).delete();
                }
            }
        } catch (Exception ignored) { }
        p.edit().remove("f" + id).remove("p" + id).apply();
        JOBS.remove(id);
    }

    /** Read-only descriptor of a finished download, or null. */
    static ParcelFileDescriptor open(Context ctx, long id) {
        Context app = ctx.getApplicationContext();
        try {
            String fin = prefs(app).getString("f" + id, null);
            if (fin == null) return null;
            JSONObject o = new JSONObject(fin);
            String content = o.optString("content", "");
            if (!content.isEmpty()) {
                try { return app.getContentResolver().openFileDescriptor(Uri.parse(content), "r"); } catch (Exception ignored) { }
            }
            String path = o.optString("path", "");
            if (!path.isEmpty()) {
                File f = new File(path);
                if (f.isFile()) return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** Public file path of a finished download when it is directly readable, else null. */
    static File publicFile(Context ctx, long id) {
        try {
            String fin = prefs(ctx).getString("f" + id, null);
            if (fin == null) return null;
            String path = new JSONObject(fin).optString("path", "");
            if (path.isEmpty()) return null;
            File f = new File(path);
            if (f.isFile() && f.length() > 0) {
                try (FileInputStream probe = new FileInputStream(f)) { if (probe.read() >= 0) return f; }
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** Writes a small text file (e.g. a backup) into the public Downloads folder; returns the final file name. */
    static String saveText(Context ctx, String rawName, String text, String mime) throws IOException {
        String name = rawName == null ? "" : rawName.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", " ").replaceAll("\\s+", " ").trim();
        if (name.isEmpty()) name = "maktabah-backup.json";
        if (name.length() > 120) name = name.substring(name.length() - 120);
        byte[] bytes = text.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        Context app = ctx.getApplicationContext();
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
            cv.put(MediaStore.Downloads.MIME_TYPE, mime);
            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            cv.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri target = app.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (target == null) throw new IOException("Could not create the file in Downloads");
            try (OutputStream os = app.getContentResolver().openOutputStream(target)) {
                if (os == null) throw new IOException("Could not write the file in Downloads");
                os.write(bytes);
                os.flush();
            } catch (IOException e) {
                try { app.getContentResolver().delete(target, null, null); } catch (Exception ignored) { }
                throw e;
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Downloads.IS_PENDING, 0);
            app.getContentResolver().update(target, done, null, null);
            Cursor q = null;
            try {
                q = app.getContentResolver().query(target, new String[]{MediaStore.Downloads.DISPLAY_NAME}, null, null, null);
                if (q != null && q.moveToFirst() && !q.isNull(0)) return q.getString(0);
            } catch (Exception ignored) {
            } finally { if (q != null) q.close(); }
            return name;
        }
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File dest = new File(dir, name);
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; dest.exists() && i < 1000; i++) dest = new File(dir, base + " (" + i + ")" + ext);
        try (FileOutputStream os = new FileOutputStream(dest)) { os.write(bytes); }
        return dest.getName();
    }

    // ------------------------------------------------------------------ job

    static final class Job implements Runnable {
        final Context ctx;
        final long id;
        final String url;
        final String name;
        final File part;
        volatile int status = PAUSED;
        volatile int reason = 0;
        volatile long downloaded = 0;
        volatile long total = -1;
        volatile String mime = "";
        volatile String uri = "";
        private volatile boolean stopRequested = false;
        private volatile boolean cancelRequested = false;
        private volatile HttpURLConnection conn;
        private volatile Thread thread;

        Job(Context ctx, long id, String url, String name) {
            this.ctx = ctx;
            this.id = id;
            this.url = url;
            this.name = name;
            this.part = partFile(ctx, id);
        }

        boolean alive() { Thread t = thread; return t != null && t.isAlive(); }

        synchronized void launch() {
            Thread old = thread;
            if (old != null && old.isAlive()) {
                try { old.join(1500); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
                if (old.isAlive()) return;
            }
            stopRequested = false;
            cancelRequested = false;
            status = RUNNING;
            reason = 0;
            Thread t = new Thread(this, "kr-download-" + id);
            t.setDaemon(true);
            thread = t;
            t.start();
        }

        void stop(boolean cancel) {
            if (cancel) cancelRequested = true;
            stopRequested = true;
            HttpURLConnection c = conn;
            if (c != null) { try { c.disconnect(); } catch (Exception ignored) { } }
        }

        void saveMeta() {
            try {
                JSONObject o = new JSONObject();
                o.put("url", url);
                o.put("name", name);
                o.put("total", total);
                prefs(ctx).edit().putString("p" + id, o.toString()).apply();
            } catch (Exception ignored) { }
        }

        void cleanup() {
            //noinspection ResultOfMethodCallIgnored
            part.delete();
            prefs(ctx).edit().remove("p" + id).apply();
            JOBS.remove(id);
        }

        private void fail(int why) {
            reason = why;
            status = FAILED;
            //noinspection ResultOfMethodCallIgnored
            part.delete();
            prefs(ctx).edit().remove("p" + id).apply();
        }

        private HttpURLConnection openConnection(long from) throws IOException {
            String cur = url;
            for (int i = 0; i < 6; i++) {
                URL u = new URL(cur);
                if (!"https".equalsIgnoreCase(u.getProtocol())) throw new IOException("Only https downloads are allowed");
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                conn = c;
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(20000);
                c.setReadTimeout(30000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) Maktabah");
                c.setRequestProperty("Accept-Encoding", "identity");
                if (from > 0) c.setRequestProperty("Range", "bytes=" + from + "-");
                int code = c.getResponseCode();
                if (code >= 300 && code < 400 && code != 304) {
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    if (loc == null || loc.isEmpty()) throw new IOException("Bad redirect");
                    cur = new URL(u, loc).toString();
                    continue;
                }
                return c;
            }
            throw new IOException("Too many redirects");
        }

        @Override
        public void run() {
            RandomAccessFile out = null;
            InputStream in = null;
            try {
                long have = part.isFile() ? part.length() : 0;
                HttpURLConnection c = openConnection(have);
                int code = c.getResponseCode();
                if (code == 416) {
                    c.disconnect();
                    //noinspection ResultOfMethodCallIgnored
                    part.delete();
                    have = 0;
                    c = openConnection(0);
                    code = c.getResponseCode();
                }
                if (stopRequested) { endStopped(); return; }
                if (code != 200 && code != 206) { fail(code); return; }
                String ct = c.getContentType();
                mime = ct == null ? "" : ct.split(";")[0].trim().toLowerCase(Locale.ROOT);
                if ("text/html".equals(mime)) { fail(R_NOT_PDF); return; }
                long len = c.getContentLengthLong();
                if (code == 206) {
                    long t = -1;
                    String cr = c.getHeaderField("Content-Range");
                    if (cr != null && cr.contains("/")) {
                        try { t = Long.parseLong(cr.substring(cr.lastIndexOf('/') + 1).trim()); } catch (Exception ignored) { }
                    }
                    total = t > 0 ? t : (len > 0 ? have + len : -1);
                } else {
                    have = 0;
                    total = len > 0 ? len : -1;
                }
                downloaded = have;
                saveMeta();

                out = new RandomAccessFile(part, "rw");
                if (code == 200) out.setLength(0);
                out.seek(have);
                in = c.getInputStream();
                byte[] buf = new byte[65536];
                int n;
                while (!stopRequested && (n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                    downloaded += n;
                }
                if (stopRequested) { endStopped(); return; }
                if (total > 0 && downloaded < total) { reason = R_NETWORK; status = PAUSED; return; }

                out.close();
                out = null;
                finish();
            } catch (IOException e) {
                if (stopRequested) { endStopped(); return; }
                String m = String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT);
                if (m.contains("enospc") || m.contains("no space")) fail(R_SPACE);
                else { reason = R_NETWORK; status = PAUSED; }
            } catch (SecurityException e) {
                fail(R_WRITE);
            } catch (Throwable e) {
                fail(R_WRITE);
            } finally {
                try { if (in != null) in.close(); } catch (Exception ignored) { }
                try { if (out != null) out.close(); } catch (Exception ignored) { }
                HttpURLConnection c = conn;
                if (c != null) { try { c.disconnect(); } catch (Exception ignored) { } }
                if (cancelRequested) cleanup();
            }
        }

        private void endStopped() {
            if (cancelRequested) return;
            reason = 0;
            status = PAUSED;
            saveMeta();
        }

        private boolean looksLikePdf() {
            try (FileInputStream f = new FileInputStream(part)) {
                byte[] head = new byte[1024];
                int n = f.read(head);
                for (int i = 0; i + 4 < n; i++) {
                    if (head[i] == '%' && head[i + 1] == 'P' && head[i + 2] == 'D' && head[i + 3] == 'F' && head[i + 4] == '-') return true;
                }
            } catch (Exception ignored) { }
            return false;
        }

        private void finish() {
            if (!looksLikePdf()) { fail(R_BAD_FILE); return; }
            try {
                String content = "";
                String path = "";
                String finalName = name;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    cv.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    cv.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri target = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (target == null) throw new IOException("Could not create the file in Downloads");
                    try (OutputStream os = ctx.getContentResolver().openOutputStream(target); FileInputStream src = new FileInputStream(part)) {
                        if (os == null) throw new IOException("Could not write the file in Downloads");
                        copy(src, os);
                    } catch (Exception e) {
                        try { ctx.getContentResolver().delete(target, null, null); } catch (Exception ignored) { }
                        throw e;
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Downloads.IS_PENDING, 0);
                    ctx.getContentResolver().update(target, done, null, null);
                    content = target.toString();
                    Cursor q = null;
                    try {
                        q = ctx.getContentResolver().query(target, new String[]{MediaStore.Downloads.DISPLAY_NAME}, null, null, null);
                        if (q != null && q.moveToFirst() && !q.isNull(0)) finalName = q.getString(0);
                    } catch (Exception ignored) {
                    } finally { if (q != null) q.close(); }
                    path = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), finalName).getAbsolutePath();
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    //noinspection ResultOfMethodCallIgnored
                    dir.mkdirs();
                    File dest = new File(dir, name);
                    String base = name.substring(0, name.length() - 4);
                    for (int i = 1; dest.exists() && i < 1000; i++) dest = new File(dir, base + " (" + i + ").pdf");
                    try (FileOutputStream os = new FileOutputStream(dest); FileInputStream src = new FileInputStream(part)) { copy(src, os); }
                    finalName = dest.getName();
                    path = dest.getAbsolutePath();
                }
                long size = part.length();
                JSONObject o = new JSONObject();
                o.put("content", content);
                o.put("path", path);
                o.put("name", finalName);
                o.put("size", size);
                SharedPreferences.Editor ed = prefs(ctx).edit();
                ed.putString("f" + id, o.toString()).remove("p" + id).apply();
                //noinspection ResultOfMethodCallIgnored
                part.delete();
                mime = "application/pdf";
                downloaded = total = size;
                uri = "file://" + path;
                status = SUCCESS;
            } catch (Exception e) {
                String m = String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT);
                fail(m.contains("enospc") || m.contains("no space") ? R_SPACE : R_WRITE);
            }
        }

        private static void copy(InputStream in, OutputStream out) throws IOException {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.flush();
        }
    }
}
