package com.kr.urdulibrary;

import java.util.ArrayList;
import java.util.List;

/**
 * Pen / marker / eraser settings and the stroke being drawn. Coordinates are page-width units (x / pageWidth, y / pageWidth).
 * The view feeds it touches; when a stroke ends the finished MuAnnot is handed back.
 */
final class MuInk {
    static final int OFF = 0, MARKER = 1, PEN = 2, ERASER = 3;
    static final int FREE = 0, LINE = 1, BOX = 2;

    static final float MIN_W = 0.003f, MAX_W = 0.07f;

    // ---- settings (the dock edits these; the activity saves them)
    int tool = OFF;
    int shape = FREE;
    boolean snap = true;                 // marker follows the text line under the finger
    int color = 0;
    float markerW = 0.024f, penW = 0.006f;
    int markerAlpha = 70, penAlpha = 100;
    boolean flat = true;                 // marker ends: flat (chisel) or round

    static float widthOf(int progress) {
        float t = Math.max(0, Math.min(100, progress)) / 100f;
        return MIN_W + t * t * (MAX_W - MIN_W);
    }

    static int progressOf(float w) {
        float t = (w - MIN_W) / (MAX_W - MIN_W);
        return Math.round((float) Math.sqrt(Math.max(0f, Math.min(1f, t))) * 100f);
    }

    boolean active() { return tool != OFF; }
    boolean isMarker() { return tool == MARKER; }
    float width() { return tool == PEN ? penW : markerW; }
    void setWidth(float w) {
        w = Math.max(MIN_W, Math.min(MAX_W, w));
        if (tool == PEN) penW = w; else markerW = w;
    }
    int alpha() { return tool == PEN ? penAlpha : markerAlpha; }
    void setAlpha(int a) {
        a = Math.max(15, Math.min(100, a));
        if (tool == PEN) penAlpha = a; else markerAlpha = a;
    }

    // ---- the stroke in progress
    MuAnnot cur;
    private float sx, sy;
    private boolean locked;              // snapped to a text line: y stays fixed
    private float lockY;
    private float[] buf = new float[256];
    private int n;                       // number of floats used in buf
    private float pageH;                 // page height in units, for clamping

    /** Begin a stroke. snapY/snapH (units) lock it to a text line when snapH > 0. */
    void begin(int page0, float x, float y, float pageHUnits, float snapY, float snapH) {
        pageH = pageHUnits;
        MuAnnot a = new MuAnnot();
        a.id = MuAnnot.newId();
        a.page0 = page0;
        a.created = System.currentTimeMillis();
        a.color = color;
        a.marker = tool == MARKER;
        a.alpha = alpha();
        a.flat = a.marker && flat;
        a.width = width();
        a.type = shape == BOX ? MuAnnot.BOX : MuAnnot.STROKE;
        locked = a.marker && snapH > 0f && shape != BOX;
        if (locked) { lockY = snapY; y = snapY; a.width = snapH; a.flat = true; }
        sx = clampX(x); sy = clampY(y);
        n = 0;
        put(sx, sy);
        cur = a;
        if (shape != FREE || locked) put(sx, sy);     // second point follows the finger
        publish(a);
    }

    boolean snapped() { return locked; }

    private float clampX(float x) { return Math.max(0f, Math.min(1f, x)); }
    private float clampY(float y) { return Math.max(0f, Math.min(pageH, y)); }

    private void put(float x, float y) {
        if (n + 2 > buf.length) buf = java.util.Arrays.copyOf(buf, buf.length * 2);
        buf[n++] = x; buf[n++] = y;
    }

    /** Returns true if the stroke changed. */
    boolean move(float x, float y) {
        if (cur == null) return false;
        x = clampX(x);
        y = locked ? lockY : clampY(y);
        if (shape == FREE && !locked) {
            float lx = buf[n - 2], ly = buf[n - 1];
            float min = Math.max(0.0012f, cur.width * 0.06f);
            if (Math.hypot(x - lx, y - ly) < min) return false;
            put(x, y);
            return true;
        }
        // straight line / box / snapped line: only the second point moves
        if (shape == LINE && !locked) {
            float dx = x - sx, dy = y - sy;
            // near-horizontal or near-vertical lines lock to the axis
            float ax = Math.abs(dx), ay = Math.abs(dy);
            if (ax > 0.02f && ay < ax * 0.09f) y = sy;
            else if (ay > 0.02f && ax < ay * 0.09f) x = sx;
        }
        if (n < 4) put(x, y);
        else { buf[2] = x; buf[3] = y; }
        return true;
    }

    /** Finishes the stroke; returns the annotation to store, or null if it is too small to keep. */
    MuAnnot end() {
        MuAnnot a = cur;
        cur = null;
        if (a == null) return null;
        publish(a);
        if (a.type == MuAnnot.BOX) {
            if (a.pts.length < 4 || Math.abs(a.pts[2] - a.pts[0]) < 0.01f || Math.abs(a.pts[3] - a.pts[1]) < 0.01f) return null;
        } else if (shape == LINE || locked) {
            if (a.pts.length < 4 || Math.hypot(a.pts[2] - a.pts[0], a.pts[3] - a.pts[1]) < 0.01f) return null;
        } else if (a.pts.length == 2 && a.marker) {
            return null;                                  // a tap with the marker draws nothing
        }
        if (shape == FREE && !locked && a.pts.length > 12) a.pts = simplify(a.pts, a.width * 0.12f);
        return a;
    }

    /** Copies the working buffer into the annotation (also used for the live preview). */
    void publish(MuAnnot a) {
        if (a.pts.length != n) a.pts = new float[n];
        System.arraycopy(buf, 0, a.pts, 0, n);
    }

    void cancel() { cur = null; }

    // ---- eraser
    final List<MuAnnot> erase = new ArrayList<>();

    // ---- path simplification (Douglas-Peucker), keeps the look but cuts the saved size
    private static float[] simplify(float[] p, float eps) {
        int cnt = p.length / 2;
        boolean[] keep = new boolean[cnt];
        keep[0] = true; keep[cnt - 1] = true;
        int[] stack = new int[cnt * 2];
        int sp = 0;
        stack[sp++] = 0; stack[sp++] = cnt - 1;
        while (sp > 0) {
            int b = stack[--sp], a = stack[--sp];
            float ax = p[2 * a], ay = p[2 * a + 1], bx = p[2 * b], by = p[2 * b + 1];
            float dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
            float md = -1f; int mi = -1;
            for (int i = a + 1; i < b; i++) {
                float px = p[2 * i], py = p[2 * i + 1];
                float t = l2 == 0f ? 0f : Math.max(0f, Math.min(1f, ((px - ax) * dx + (py - ay) * dy) / l2));
                float d = (float) Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
                if (d > md) { md = d; mi = i; }
            }
            if (mi >= 0 && md > eps) {
                keep[mi] = true;
                stack[sp++] = a; stack[sp++] = mi;
                stack[sp++] = mi; stack[sp++] = b;
            }
        }
        int k = 0;
        for (boolean b : keep) if (b) k++;
        float[] out = new float[k * 2];
        int o = 0;
        for (int i = 0; i < cnt; i++) if (keep[i]) { out[o++] = p[2 * i]; out[o++] = p[2 * i + 1]; }
        return out;
    }
}
