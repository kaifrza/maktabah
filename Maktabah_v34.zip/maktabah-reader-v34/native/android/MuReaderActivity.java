package com.kr.urdulibrary;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

/**
 * Native PDF reader (MuPDF). Launched from KRDownloaderPlugin.openMuReader().
 * All state (position, bookmarks, look) comes in through intent extras and goes back out through
 * the result intent, so the web layer stays the single place where it is stored.
 */
public class MuReaderActivity extends Activity implements MuPdfView.Host {

    // ------------------------------------------------------------ extras
    static final String X_PATH = "path", X_TITLE = "title", X_LANG = "lang", X_PAGE = "page", X_FRAC = "frac",
            X_THEME = "theme", X_DIM = "dim", X_AWAKE = "keepAwake", X_AUTOHIDE = "autoHide", X_MARKS = "marks",
            X_HL = "highlights", R_TOTAL = "total", R_ERROR = "error";

    private boolean ur;
    private String title, path;
    private int theme;                 // 0 paper 1 sepia 2 night
    private float dim;
    private boolean keepAwake, autoHide;
    private final TreeSet<Integer> marks = new TreeSet<>();   // 1-based
    private int startPage0;
    private float startFrac;
    private String hlJson = "[]";      // highlights as they came in; handed back untouched if the book never opened

    // ------------------------------------------------------------ ui
    private MuPdfView view;
    private FrameLayout root;
    private LinearLayout topBar, searchBar;
    private TextView titleView, searchCount;
    private ScrubHandle scrub;
    private IconView optBtn, markBtn;
    private MuDock dock;
    private View scrim;                       // invisible layer under the tray: a tap on empty screen closes the settings card
    private boolean trayShown = false, recovered = false, backupOff = false;
    private File backupFile;
    private final java.util.concurrent.ExecutorService io = java.util.concurrent.Executors.newSingleThreadExecutor();
    private final Runnable saveBackup = new Runnable() {
        @Override public void run() {
            if (view == null || !opened || backupOff || backupFile == null) return;
            final String j = MuAnnot.toJson(view.highlights());
            final File f = backupFile;
            try { io.execute(() -> { if (!backupOff) writeFile(f, j); }); } catch (Throwable ignored) { }
        }
    };
    private EditText searchInput;
    private ProgressBar spinner;
    private int topInset = 0, botInset = 0, insLeft = 0, insRight = 0;
    private int traySide = 0;               // 0 bottom, 1 left, 2 right
    private boolean barsShown = true, opened = false, searching = false;
    private int total = 0;
    private int curPage0 = 0;
    private List<MuPdfView.OutlineItem> outline = new ArrayList<>();
    private float density;
    private final List<Dialog> dialogs = new ArrayList<>();

    // highlights
    private SharedPreferences uiPrefs;
    private int hlColor = 0, hlStyle = 0;       // last used, remembered between books
    private LinearLayout menu;                  // floating menu next to a selection / a tapped highlight
    private MuAnnot menuHl;         // null = menu of a new selection
    private LinearLayout snackView;
    private final Runnable snackHide = new Runnable() { @Override public void run() { hideSnack(); } };

    // theme colours
    private int barBg, barFg, barSub, accent, sheetBg, sheetFg, chipBg;

    // ================================================================= lifecycle
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        density = getResources().getDisplayMetrics().density;
        Intent in = getIntent();
        path = in.getStringExtra(X_PATH);
        title = in.getStringExtra(X_TITLE);
        if (title == null) title = "PDF";
        ur = "ur".equals(in.getStringExtra(X_LANG));
        startPage0 = Math.max(0, in.getIntExtra(X_PAGE, 1) - 1);
        startFrac = in.getFloatExtra(X_FRAC, 0f);
        String th = in.getStringExtra(X_THEME);
        theme = "night".equals(th) ? 2 : "sepia".equals(th) ? 1 : 0;
        dim = in.getFloatExtra(X_DIM, 0f);
        keepAwake = in.getBooleanExtra(X_AWAKE, false);
        autoHide = in.getBooleanExtra(X_AUTOHIDE, true);
        int[] m = in.getIntArrayExtra(X_MARKS);
        if (m != null) for (int x : m) if (x > 0) marks.add(x);
        String hj = in.getStringExtra(X_HL);
        if (hj != null) hlJson = hj;
        String hf = in.getStringExtra("highlightsFile");
        if (hf != null) { String t = readFile(new File(hf)); if (t != null) hlJson = t; }
        backupFile = path == null ? null : new File(getFilesDir(), "mu_ink_" + md5(path) + ".json");
        uiPrefs = getSharedPreferences("mu_reader_ui", MODE_PRIVATE);
        hlColor = Math.max(0, Math.min(MuAnnot.FILL.length - 1, uiPrefs.getInt("hlColor", 0)));
        hlStyle = Math.max(0, Math.min(2, uiPrefs.getInt("hlStyle", 0)));
        if (b != null) {   // recreated (rotation, dark-mode switch...): resume where the reader was, not where it started
            startPage0 = Math.max(0, b.getInt("s_page", startPage0 + 1) - 1);
            startFrac = b.getFloat("s_frac", startFrac);
            theme = b.getInt("s_theme", theme);
            dim = b.getFloat("s_dim", dim);
            keepAwake = b.getBoolean("s_awake", keepAwake);
            int[] sm = b.getIntArray("s_marks");
            if (sm != null) { marks.clear(); for (int x : sm) if (x > 0) marks.add(x); }
            String sh = b.getString("s_hl");
            if (sh != null) hlJson = sh;
        }

        Window w = getWindow();
        WindowCompat.setDecorFitsSystemWindows(w, false);
        try { w.setStatusBarColor(Color.TRANSPARENT); w.setNavigationBarColor(Color.TRANSPARENT); } catch (Throwable ignored) { }
        if (keepAwake) w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        String bk = readFile(backupFile);
        if (bk != null && !bk.isEmpty()) {              // the last session never finished: its marks are newer than the saved ones
            recovered = b == null && MuAnnot.parse(bk).size() != MuAnnot.parse(hlJson).size();
            hlJson = bk;
        }

        buildUi();
        loadInkPrefs();
        applyTraySide();                 // traySide is read from prefs only now: rebuild the tray + settings card position
        dock.refresh();
        view.setHighlights(MuPdfView.parseHighlights(hlJson));
        applyLook();

        if (path == null || !new File(path).exists()) { finishWith("File not found"); return; }
        view.open(path, null, startPage0, startFrac);
    }

    @Override protected void onPause() {
        super.onPause();
        saveBackup.run();
        publishResult(null);
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (view != null && opened) {
            out.putInt("s_page", view.currentPage0() + 1);
            out.putFloat("s_frac", view.currentFrac());
        }
        out.putInt("s_theme", theme);
        out.putFloat("s_dim", dim);
        out.putBoolean("s_awake", keepAwake);
        int[] arr = new int[marks.size()]; int i = 0; for (int x : marks) arr[i++] = x;
        out.putIntArray("s_marks", arr);
        String hs = currentHighlightsJson();
        if (hs.length() < 200000) out.putString("s_hl", hs);   // stay far below the Binder limit
    }

    @Override protected void onDestroy() {
        for (Dialog d : new ArrayList<>(dialogs)) { try { if (d.isShowing()) d.dismiss(); } catch (Throwable ignored) { } }
        dialogs.clear();
        if (snackView != null) snackView.removeCallbacks(snackHide);
        if (view != null) view.destroy();
        io.shutdown();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (dock != null && dock.dismissOverlays()) return;
        if (view.ink().active()) { selectTool(MuInk.OFF); return; }
        if (menu != null || view.hasSelection()) { hideMenu(); view.clearSelection(); return; }
        if (searching) { closeSearch(); return; }
        finishWith(null);
    }

    private String currentHighlightsJson() {
        return view != null && opened ? MuPdfView.highlightsToJson(view.highlights()) : hlJson;
    }

    // Remembered so that onPause() (which also publishes the result) cannot overwrite the error with RESULT_OK.
    private String failure;

    private void finishWith(String error) {
        failure = error;
        publishResult(error);
        if (error == null && backupFile != null) {          // the result carries the marks now
            backupOff = true;
            final File bf = backupFile;
            try { io.execute(() -> bf.delete()); } catch (Throwable ignored) { }
        }
        finish();
    }

    private void publishResult(String error) {
        if (error == null) error = failure;
        Intent r = new Intent();
        if (view != null && opened) {
            r.putExtra(X_PAGE, view.currentPage0() + 1);
            r.putExtra(X_FRAC, view.currentFrac());
            r.putExtra(R_TOTAL, total);
        }
        r.putExtra(X_THEME, theme == 2 ? "night" : theme == 1 ? "sepia" : "paper");
        r.putExtra(X_DIM, dim);
        r.putExtra(X_AWAKE, keepAwake);
        int[] arr = new int[marks.size()]; int i = 0; for (int x : marks) arr[i++] = x;
        r.putExtra(X_MARKS, arr);
        String hjOut = currentHighlightsJson();
        if (hjOut.length() < 100000) r.putExtra(X_HL, hjOut);          // big lists go through a file (Binder limit)
        else {
            File of = new File(getCacheDir(), "mu_hl_out.json");
            if (writeFile(of, hjOut)) r.putExtra("highlightsFile", of.getAbsolutePath()); else r.putExtra(X_HL, hjOut);
        }
        if (error != null) r.putExtra(R_ERROR, error);
        setResult(error == null ? RESULT_OK : RESULT_CANCELED, r);
    }

    // ================================================================= strings
    private String s(String key) {
        if (ur) {
            switch (key) {
                case "search": return "تلاش کریں";
                case "contents": return "فہرست";
                case "marks": return "نشانیاں";
                case "look": return "ظاہری شکل";
                case "look_s": return "ظاہری";
                case "paper": return "کاغذ";
                case "sepia": return "سیپیا";
                case "night": return "رات";
                case "brightness": return "روشنی";
                case "awake": return "اسکرین جاگتی رکھیں";
                case "tray_pos": return "ٹول بار کی جگہ";
                case "tray_bottom": return "نیچے";
                case "tray_left": return "بائیں";
                case "tray_right": return "دائیں";
                case "fit": return "چوڑائی کے مطابق";
                case "jump": return "صفحے پر جائیں";
                case "go": return "جائیں";
                case "cancel": return "منسوخ";
                case "pick_new": return "نیا رنگ";
                case "pick_add": return "شامل کریں";
                case "ok": return "ٹھیک ہے";
                case "pw_title": return "یہ PDF محفوظ ہے";
                case "pw_hint": return "پاس ورڈ";
                case "pw_wrong": return "پاس ورڈ درست نہیں";
                case "nocontents": return "اس کتاب میں فہرست موجود نہیں";
                case "nomarks": return "ابھی کوئی نشانی نہیں لگائی گئی";
                case "added": return "نشانی لگا دی گئی";
                case "removed": return "نشانی ہٹا دی گئی";
                case "noresult": return "کچھ نہیں ملا";
                case "page": return "صفحہ";
                case "pages": return "صفحات";
                case "of": return "از";
                case "loading": return "کھل رہی ہے…";
                case "highlights": return "ہائی لائٹس";
                case "highlight": return "ہائی لائٹ";
                case "underline": return "انڈر لائن";
                case "strike": return "کٹی لکیر";
                case "copy": return "کاپی";
                case "note": return "نوٹ";
                case "share": return "شیئر";
                case "delete": return "حذف";
                case "done": return "مکمل";
                case "undo": return "واپس";
                case "copied": return "کاپی ہو گیا";
                case "hl_saved": return "ہائی لائٹ محفوظ ہو گئی";
                case "hl_deleted": return "ہائی لائٹ حذف ہو گئی";
                case "hl_limit": return "ہائی لائٹس کی حد پوری ہو گئی";
                case "no_text": return "اس صفحے پر منتخب ہونے والا متن نہیں ہے";
                case "no_text_here": return "یہاں متن نہیں ملا، لفظ کے قریب دبائیں";
                case "note_hint": return "اپنا نوٹ یہاں لکھیں…";
                case "no_hl": return "ابھی کوئی ہائی لائٹ نہیں";
                case "no_hl_sub": return "متن والے صفحے پر لفظ کو دبائے رکھیں، اور اسکین صفحات پر قلم کا بٹن استعمال کریں۔ آپ کے نشانات اور نوٹس یہاں جمع ہوں گے۔";
                case "start_hl": return "نشان لگانا شروع کریں";
                case "hl_hint": return "کسی لفظ کو دبائے رکھیں";
                case "all": return "سب";
                case "search_hl": return "ہائی لائٹس میں تلاش";
                case "share_all": return "سب شیئر کریں";
                case "clear_all": return "سب حذف کریں";
                case "clear_q": return "کیا اس کتاب کی تمام ہائی لائٹس حذف کر دی جائیں؟";
                case "goto": return "اس صفحے پر جائیں";
                case "bm_this": return "اس صفحے پر نشانی لگائیں";
                case "search_sel": return "تلاش";
                case "c0": return "پیلا";
                case "c1": return "سبز";
                case "c2": return "نیلا";
                case "c3": return "گلابی";
                case "c4": return "جامنی";
                case "c5": return "نارنجی";
                case "c6": return "سرخ";
                case "c7": return "سیاہ";
                case "tool_marker": return "مارکر";
                case "tool_pen": return "قلم";
                case "tool_eraser": return "مٹائیں";
                case "erase_whole": return "پورا نشان";
                case "erase_free": return "آزاد مٹائیں";
                case "thick": return "موٹائی";
                case "opacity": return "گہرائی";
                case "shape_free": return "آزاد";
                case "shape_line": return "سیدھی لکیر";
                case "shape_box": return "ڈبہ";
                case "snap": return "لائن پر چپکائیں";
                case "tip_flat": return "چپٹی نوک";
                case "tip_round": return "گول نوک";
                case "redo": return "دوبارہ";
                case "ink": return "نشان لگائیں";
                case "drawing": return "نشان";
                case "read": return "پڑھیں";
                case "search_book": return "کتاب میں تلاش کریں";
                case "options": return "آپشنز";
                case "ink_no_line": return "لائن نہیں ملی، آزاد لکیر لگ رہی ہے";
                case "ink_recovered": return "غیر محفوظ شدہ نشانات بحال کر دیے گئے";
                default: return key;
            }
        }
        switch (key) {
            case "search": return "Search";
            case "contents": return "Contents";
            case "marks": return "Bookmarks";
            case "look": return "Appearance";
            case "look_s": return "Look";
            case "paper": return "Paper";
            case "sepia": return "Sepia";
            case "night": return "Night";
            case "brightness": return "Brightness";
            case "awake": return "Keep screen on";
            case "tray_pos": return "Tray position";
            case "tray_bottom": return "Bottom";
            case "tray_left": return "Left";
            case "tray_right": return "Right";
            case "fit": return "Fit width";
            case "jump": return "Go to page";
            case "go": return "Go";
            case "cancel": return "Cancel";
            case "pick_new": return "New colour";
            case "pick_add": return "Add";
            case "ok": return "OK";
            case "pw_title": return "This PDF is protected";
            case "pw_hint": return "Password";
            case "pw_wrong": return "Wrong password";
            case "nocontents": return "This book has no table of contents";
            case "nomarks": return "No bookmarks yet";
            case "added": return "Bookmark added";
            case "removed": return "Bookmark removed";
            case "noresult": return "No results";
            case "page": return "Page";
            case "pages": return "pages";
            case "of": return "of";
            case "loading": return "Opening…";
            case "highlights": return "Highlights";
            case "highlight": return "Highlight";
            case "underline": return "Underline";
            case "strike": return "Strikethrough";
            case "copy": return "Copy";
            case "note": return "Note";
            case "share": return "Share";
            case "delete": return "Delete";
            case "done": return "Done";
            case "undo": return "Undo";
            case "copied": return "Copied";
            case "hl_saved": return "Highlight saved";
            case "hl_deleted": return "Highlight deleted";
            case "hl_limit": return "Highlight limit reached";
            case "no_text": return "No selectable text on this page";
            case "no_text_here": return "No text here — press closer to a word";
            case "note_hint": return "Write your note here…";
            case "no_hl": return "No highlights yet";
            case "no_hl_sub": return "On text pages press and hold a word; on scanned pages use the pen button. Your marks and notes will collect here.";
            case "start_hl": return "Start marking up";
            case "hl_hint": return "Press and hold a word";
            case "all": return "All";
            case "search_hl": return "Search highlights";
            case "share_all": return "Share all";
            case "clear_all": return "Delete all";
            case "clear_q": return "Delete all highlights in this book?";
            case "goto": return "Go to page";
            case "bm_this": return "Bookmark this page";
            case "search_sel": return "Search";
            case "c0": return "Yellow";
            case "c1": return "Green";
            case "c2": return "Blue";
            case "c3": return "Pink";
            case "c4": return "Purple";
            case "c5": return "Orange";
            case "c6": return "Red";
            case "c7": return "Black";
            case "tool_marker": return "Marker";
            case "tool_pen": return "Pen";
            case "tool_eraser": return "Eraser";
            case "erase_whole": return "Whole mark";
            case "erase_free": return "Freehand";
            case "thick": return "Thickness";
            case "opacity": return "Opacity";
            case "shape_free": return "Freehand";
            case "shape_line": return "Straight";
            case "shape_box": return "Box";
            case "snap": return "Snap to line";
            case "tip_flat": return "Flat tip";
            case "tip_round": return "Round tip";
            case "redo": return "Redo";
            case "ink": return "Mark up";
            case "drawing": return "Drawing";
            case "read": return "Read";
            case "search_book": return "Search in this book";
            case "options": return "Options";
            case "ink_no_line": return "No text line found — drawing freely";
            case "ink_recovered": return "Unsaved marks were restored";
            default: return key;
        }
    }

    // ================================================================= UI construction
    private int dp(float v) { return Math.round(v * density); }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setLayoutDirection(ur ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        view = new MuPdfView(this);
        view.setHost(this);
        view.setOnAnnotChanged(this::onAnnotsChanged);
        root.addView(view, new FrameLayout.LayoutParams(-1, -1));

        // ---- top bar
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        IconView back = new IconView(this, IconView.BACK);
        back.setOnClickListener(v -> finishWith(null));
        titleView = new TextView(this);
        titleView.setText(title);
        titleView.setSingleLine(true);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        titleView.setTextSize(16f);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        titleView.setPadding(dp(4), 0, dp(4), 0);
        optBtn = new IconView(this, IconView.LIST);
        optBtn.setContentDescription(s("contents"));
        optBtn.setOnClickListener(v -> showContents());
        topBar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        topBar.addView(titleView, new LinearLayout.LayoutParams(0, -2, 1f));
        IconView searchBtn = new IconView(this, IconView.SEARCH);
        searchBtn.setContentDescription(s("search"));
        searchBtn.setOnClickListener(v -> openSearch());
        topBar.addView(searchBtn, new LinearLayout.LayoutParams(dp(44), dp(48)));
        markBtn = new IconView(this, IconView.MARK);
        markBtn.setContentDescription(s("marks"));
        markBtn.setOnClickListener(v -> toggleMark());
        topBar.addView(markBtn, new LinearLayout.LayoutParams(dp(44), dp(48)));
        topBar.addView(optBtn, new LinearLayout.LayoutParams(dp(44), dp(48)));
        root.addView(topBar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // ---- search bar (replaces the top bar while searching)
        searchBar = new LinearLayout(this);
        searchBar.setOrientation(LinearLayout.HORIZONTAL);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setVisibility(View.GONE);
        IconView sClose = new IconView(this, IconView.BACK);
        sClose.setOnClickListener(v -> closeSearch());
        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setHint(s("search"));
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setInputType(InputType.TYPE_CLASS_TEXT);
        searchInput.setTextSize(16f);
        searchInput.setBackground(null);
        searchInput.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        searchInput.setOnEditorActionListener((tv, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_SEARCH || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) { runSearch(); return true; }
            return false;
        });
        searchCount = new TextView(this);
        searchCount.setTextSize(12f);
        searchCount.setPadding(dp(6), 0, dp(6), 0);
        searchCount.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        IconView up = new IconView(this, IconView.UP);
        up.setOnClickListener(v -> { view.nextHit(-1); updateSearchCount(); });
        IconView down = new IconView(this, IconView.DOWN);
        down.setOnClickListener(v -> { view.nextHit(1); updateSearchCount(); });
        searchBar.addView(sClose, new LinearLayout.LayoutParams(dp(48), dp(48)));
        searchBar.addView(searchInput, new LinearLayout.LayoutParams(0, dp(48), 1f));
        searchBar.addView(searchCount, new LinearLayout.LayoutParams(-2, -2));
        searchBar.addView(up, new LinearLayout.LayoutParams(dp(40), dp(48)));
        searchBar.addView(down, new LinearLayout.LayoutParams(dp(40), dp(48)));
        root.addView(searchBar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        spinner = new ProgressBar(this);
        root.addView(spinner, new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER));

        // ---- scrub handle: shows with the page number while the book scrolls; drag = fast scroll, tap = go to page
        scrub = new ScrubHandle(this);
        root.addView(scrub, new FrameLayout.LayoutParams(dp(190), -1, Gravity.RIGHT));
        view.setScrollListener(f -> scrub.onScroll(f));

        scrim = new View(this);
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(v -> { if (dock != null) dock.dismissOverlays(); });
        root.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        dock = new MuDock(this, view.ink(), new MuDock.Cb() {
            @Override public void onTool(int tool) { view.setInkTool(tool); saveInkPrefs(); }
            @Override public void onAction(int id) { onTrayAction(id); }
            @Override public void onChanged() { saveInkPrefs(); }
            @Override public void onUndo() { view.store().undo(); }
            @Override public void onRedo() { view.store().redo(); }
            @Override public void onDone() { }
            @Override public void onOverlay(boolean shown) { overlayChanged(shown); }
        }, key -> s(key));
        dock.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        dock.setVisibility(View.GONE);
        root.addView(dock, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        root.addView(dock.overlayView(), new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        dock.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, orr, ob) -> { if (b - t != ob - ot || r - l != orr - ol) layoutBottom(); });
        applyTraySide();

        setContentView(root);

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets sb = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            topInset = sb.top; botInset = sb.bottom; insLeft = sb.left; insRight = sb.right;
            topBar.setPadding(sb.left, topInset, sb.right, 0);
            searchBar.setPadding(sb.left, topInset, sb.right, 0);
            layoutBottom();
            applyDockPadding();
            return insets;
        });
    }

    private void applyLook() {
        if (theme == 2) { barBg = 0xF0151B17; barFg = 0xFFE6ECE8; barSub = 0xFF9AA8A0; accent = 0xFF55B88B; sheetBg = 0xFF171D19; sheetFg = 0xFFE6ECE8; chipBg = 0xFF232B26; }
        else if (theme == 1) { barBg = 0xF0EFE6D2; barFg = 0xFF2B2418; barSub = 0xFF7A6D55; accent = 0xFF176B4D; sheetBg = 0xFFF4ECD8; sheetFg = 0xFF2B2418; chipBg = 0xFFE7DCC2; }
        else { barBg = 0xF0F7F7F5; barFg = 0xFF1C2420; barSub = 0xFF6B7770; accent = 0xFF176B4D; sheetBg = 0xFFFFFFFF; sheetFg = 0xFF1C2420; chipBg = 0xFFEDEDE8; }
        topBar.setBackgroundColor(barBg);
        searchBar.setBackgroundColor(barBg);
        titleView.setTextColor(barFg);
        searchInput.setTextColor(barFg);
        searchInput.setHintTextColor(barSub);
        searchCount.setTextColor(barSub);
        recolor(topBar); recolor(searchBar);
        view.setLook(theme, dim);
        root.setBackgroundColor(view.backgroundColor());
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (c != null) { c.setAppearanceLightStatusBars(theme != 2); c.setAppearanceLightNavigationBars(theme != 2); }
        if (scrub != null) scrub.restyle();
        updateMarkIcon();
        if (dock != null) dock.restyle(sheetBg, sheetFg, barSub, chipBg, accent);
        if (dock != null) dock.setThemeIdx(theme);
    }

    private void recolor(ViewGroup g) {
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (c instanceof IconView) { ((IconView) c).setColor(barFg); }
        }
    }

    // ================================================================= bars
    private void setBars(boolean show) {
        if (barsShown == show) return;
        barsShown = show;
        updateTray();
        applyDockPadding();
        layoutBottom();
        if (show && scrub != null) scrub.show();   // tapping the page brings the handle too, so it is easy to find
        View top = searching ? searchBar : topBar;
        top.animate().alpha(show ? 1f : 0f).translationY(show ? 0 : -dp(24)).setDuration(160).withEndAction(() -> { if (!barsShown && !searching) top.setVisibility(View.INVISIBLE); }).start();
        if (show) top.setVisibility(View.VISIBLE);
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (c != null) {
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            if (show) c.show(WindowInsetsCompat.Type.systemBars()); else c.hide(WindowInsetsCompat.Type.systemBars());
        }
    }

    // ================================================================= MuPdfView.Host
    @Override public void onOpened(int pageCount, boolean hasOutline) {
        opened = true; total = pageCount;
        spinner.setVisibility(View.GONE);
        updateTray();
        setPageText(Math.max(0, Math.min(pageCount - 1, startPage0)));
        if (recovered) { recovered = false; snack(s("ink_recovered"), null, null); }
    }

    @Override public void onOutline(List<MuPdfView.OutlineItem> items) { outline = items == null ? new ArrayList<MuPdfView.OutlineItem>() : items; }

    @Override public void onOpenFailed(String message) { finishWith(message == null ? "open failed" : message); }

    @Override public void onNeedPassword(boolean wrongBefore) {
        spinner.setVisibility(View.GONE);
        showPasswordSheet(wrongBefore);
    }

    @Override public void onPageChanged(int page0, int pageTotal) {
        curPage0 = page0;
        total = pageTotal;
        setPageText(page0);
        updateMarkIcon();
    }

    @Override public void onTap() {
        if (menu != null) { hideMenu(); return; }
        if (!searching) setBars(!barsShown); else hideKeyboard();
    }

    @Override public void onUserScroll() {
        if (scrub != null) scrub.show();
        if (menuHl != null) hideMenu();
        if (autoHide && barsShown && !searching) setBars(false);
    }

    @Override public void onSelectionStart() {
        hideMenu();
        if (barsShown && !searching) setBars(false);
    }

    @Override public void onSelectionMenu(RectF anchor) {
        if (anchor == null) hideMenu(); else showMenu(anchor, null);
    }

    @Override public void onSelectionEnd() { hideMenu(); }

    @Override public void onHighlightTap(MuAnnot h, RectF anchor) {
        if (anchor == null) return;
        if (barsShown && !searching) setBars(false);
        showMenu(anchor, h);
    }

    @Override public void onNoteTap(MuAnnot h) { showHlEditor(h, false, null); }

    @Override public void onNotice(int code) {
        snack(s(code == MuPdfView.NOTICE_NO_TEXT ? "no_text" : code == MuPdfView.NOTICE_NO_LINE ? "ink_no_line" : "no_text_here"), null, null);
    }

    @Override public void onExternalLink(String uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(uri))); } catch (Throwable ignored) { }
    }

    private void setPageText(int page0) {
        if (scrub != null) scrub.setPage(page0 + 1, total);
    }

    // ================================================================= ink (marker / pen / eraser)
    private void loadInkPrefs() {
        MuInk k = view.ink();
        k.color = Math.max(0, Math.min(MuAnnot.FILL.length - 1, uiPrefs.getInt("inkColor", 0)));
        k.rgb = uiPrefs.getInt("inkRgb", 0);
        k.markerShape = Math.max(0, Math.min(2, uiPrefs.getInt("inkShape", 0)));
        k.penShape = Math.max(0, Math.min(2, uiPrefs.getInt("inkShapePen", 0)));
        k.snap = uiPrefs.getBoolean("inkSnap2", false);
        traySide = Math.max(0, Math.min(2, uiPrefs.getInt("traySide", 0)));
        k.eraseMode = uiPrefs.getInt("inkEraseMode", 0) == 1 ? MuInk.FREEHAND : MuInk.WHOLE;
        k.eraserW = Math.max(MuInk.MIN_W, Math.min(MuInk.ERASER_MAX_W, uiPrefs.getFloat("inkEW", 0.05f)));
        k.flat = uiPrefs.getBoolean("inkFlat", true);
        k.markerW = Math.max(MuInk.MIN_W, Math.min(MuInk.MAX_W, uiPrefs.getFloat("inkMW", 0.024f)));
        k.penW = Math.max(MuInk.MIN_W, Math.min(MuInk.MAX_W, uiPrefs.getFloat("inkPW", 0.006f)));
        k.markerAlpha = Math.max(15, Math.min(100, uiPrefs.getInt("inkMA", 70)));
        k.penAlpha = Math.max(15, Math.min(100, uiPrefs.getInt("inkPA", 100)));
    }

    private void saveInkPrefs() {
        MuInk k = view.ink();
        SharedPreferences.Editor e = uiPrefs.edit();
        e.putInt("inkColor", k.color).putInt("inkRgb", k.rgb).putInt("inkShape", k.markerShape).putInt("inkShapePen", k.penShape).putBoolean("inkSnap2", k.snap).putInt("traySide", traySide).putBoolean("inkFlat", k.flat)
                .putInt("inkEraseMode", k.eraseMode).putFloat("inkEW", k.eraserW).putFloat("inkMW", k.markerW).putFloat("inkPW", k.penW).putInt("inkMA", k.markerAlpha).putInt("inkPA", k.penAlpha);
        if (k.tool != MuInk.OFF) e.putInt("inkTool", k.tool);
        e.apply();
    }

    /** The tray follows the header (tap = show / hide), but stays while a drawing tool is active. */
    private void updateTray() {
        if (dock == null) return;
        boolean want = opened && ((barsShown && !searching) || view.ink().active());
        if (want == trayShown) return;
        trayShown = want;
        dock.animate().cancel();
        if (want) {
            dock.setThemeIdx(theme);
            dock.setUndoState(view.store().canUndo(), view.store().canRedo());
            dock.restyle(sheetBg, sheetFg, barSub, chipBg, accent);
            dock.setAlpha(0f);
            dock.setTranslationX(trayShiftX());
            dock.setTranslationY(trayShiftY());
            dock.setVisibility(View.VISIBLE);
            dock.animate().alpha(1f).translationX(0f).translationY(0f).setDuration(180).start();
        } else {
            dock.dismissOverlays();
            dock.animate().alpha(0f).translationX(trayShiftX()).translationY(trayShiftY()).setDuration(150).withEndAction(() -> { if (!trayShown) dock.setVisibility(View.GONE); }).start();
        }
        layoutBottom();
    }

    private float trayShiftX() { return traySide == 1 ? -dp(30) : traySide == 2 ? dp(30) : 0f; }
    private float trayShiftY() { return traySide == 0 ? dp(30) : 0f; }

    /** Header height (below the status bar): a side tray starts right under it. */
    private int headerH() { return topInset + dp(48); }

    /** The tray is a bar attached to the screen edge, like the header: no margin, the inset sits inside its background. */
    private void applyDockPadding() {
        if (dock == null) return;
        if (traySide == 0) dock.setPadding(insLeft, dp(2), insRight, botInset + dp(2));
        else if (traySide == 1) dock.setPadding(insLeft, dp(4), 0, botInset + dp(4));
        else dock.setPadding(0, dp(4), insRight, botInset + dp(4));
        if (traySide != 0 && dock.getLayoutParams() instanceof FrameLayout.LayoutParams) {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) dock.getLayoutParams();
            int tm = barsShown ? headerH() : 0;
            if (lp.topMargin != tm) { lp.topMargin = tm; dock.setLayoutParams(lp); }
        }
    }

    /** Puts the tray at the bottom, left or right edge (Appearance setting). */
    private void applyTraySide() {
        dock.setSide(traySide);
        FrameLayout.LayoutParams lp = traySide == 0 ? new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)
                : new FrameLayout.LayoutParams(-2, -1, traySide == 1 ? Gravity.LEFT : Gravity.RIGHT);
        dock.setLayoutParams(lp);
        applyDockPadding();
        dock.animate().cancel();
        dock.setTranslationX(0f);
        dock.setTranslationY(0f);
        if (trayShown) dock.setAlpha(1f);
        layoutBottom();
    }

    private void selectTool(int tool) {
        view.ink().tool = tool;
        view.setInkTool(tool);
        dock.refresh();
        saveInkPrefs();
        updateTray();
    }

    /** Space taken by the tray at the bottom (0 when hidden). */
    private int trayHeight() {
        return trayShown && traySide == 0 && dock.getVisibility() == View.VISIBLE ? dock.getHeight() : 0;
    }

    private void layoutBottom() {
        if (scrub != null) {
            // The handle always sits on the edge opposite to the tray: tray on the right -> handle on the left.
            boolean onLeft = traySide == 2;
            FrameLayout.LayoutParams sl = (FrameLayout.LayoutParams) scrub.getLayoutParams();
            int g = onLeft ? Gravity.LEFT : Gravity.RIGHT, lm = 0, rm = 0;   // flush with the screen edge
            if (sl.gravity != g || sl.leftMargin != lm || sl.rightMargin != rm) {
                sl.gravity = g; sl.leftMargin = lm; sl.rightMargin = rm;
                scrub.setLayoutParams(sl);
            }
            scrub.setOnLeft(onLeft);
            scrub.setInsets(topInset + dp(52), botInset + dp(12) + Math.max(0, trayHeight() - botInset));
        }
        layoutOverlay();
    }

    /** Puts the settings card right next to the tray (above it, or beside it) and keeps it inside the screen. */
    private void layoutOverlay() {
        if (dock == null) return;
        View card = dock.overlayView();
        FrameLayout.LayoutParams cl = (FrameLayout.LayoutParams) card.getLayoutParams();
        int gap = dp(8);
        int rootW = root.getWidth() > 0 ? root.getWidth() : getResources().getDisplayMetrics().widthPixels;
        int top = (barsShown ? headerH() : topInset) + gap;
        if (traySide == 0) {
            cl.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            cl.width = Math.min(dp(400), Math.max(dp(240), rootW - insLeft - insRight - 2 * gap));
            cl.leftMargin = 0; cl.rightMargin = 0;
            cl.topMargin = top;
            cl.bottomMargin = (dock.getHeight() > 0 ? dock.getHeight() : botInset + dp(56)) + gap;
        } else {
            int strip = dock.getWidth() > 0 ? dock.getWidth() : dock.stripWidth() + (traySide == 1 ? insLeft : insRight);
            int outer = traySide == 1 ? insRight : insLeft;
            cl.width = Math.max(dp(230), Math.min(dp(300), rootW - strip - outer - 2 * gap));
            cl.gravity = (traySide == 1 ? Gravity.LEFT : Gravity.RIGHT) | Gravity.CENTER_VERTICAL;
            cl.leftMargin = traySide == 1 ? strip + gap : 0;
            cl.rightMargin = traySide == 2 ? strip + gap : 0;
            cl.topMargin = top;
            cl.bottomMargin = botInset + gap;
        }
        card.setLayoutParams(cl);
    }

    /** The settings card opened or closed: a tap anywhere else on the screen now closes it. */
    private void overlayChanged(boolean shown) {
        if (scrim != null) scrim.setVisibility(shown ? View.VISIBLE : View.GONE);
        if (dock == null) return;
        View card = dock.overlayView();
        layoutOverlay();
        card.animate().cancel();
        if (shown) { card.bringToFront(); card.setElevation(dp(16)); card.requestLayout(); card.setAlpha(0f); card.animate().alpha(1f).setDuration(140).start(); }
        else card.setAlpha(1f);
    }

    private void cycleTheme() {
        theme = (theme + 1) % 3;
        applyLook();
        toast(s(theme == 2 ? "night" : theme == 1 ? "sepia" : "paper"));
    }

    private void onTrayAction(int id) {
        switch (id) {

            case MuDock.THEME: cycleTheme(); break;
            case MuDock.LOOK: toggleLook(); break;
            case MuDock.GOTO: showJump(); break;
            default: break;
        }
    }

    private void onAnnotsChanged() {
        if (dock != null) dock.setUndoState(view.store().canUndo(), view.store().canRedo());
        if (root != null) { root.removeCallbacks(saveBackup); root.postDelayed(saveBackup, 1200); }
    }

    private static String readFile(File f) {
        try {
            if (f == null || !f.exists() || f.length() > 8000000L) return null;
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            }
            return new String(bo.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (Throwable t) { return null; }
    }

    private static boolean writeFile(File f, String text) {
        try {
            File tmp = new File(f.getPath() + ".tmp");
            try (java.io.FileOutputStream o = new java.io.FileOutputStream(tmp)) { o.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8)); }
            return tmp.renameTo(f) || (f.delete() && tmp.renameTo(f));
        } catch (Throwable t) { return false; }
    }

    private static String md5(String s) {
        try {
            byte[] d = java.security.MessageDigest.getInstance("MD5").digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format(Locale.ROOT, "%02x", b));
            return sb.toString();
        } catch (Throwable t) { return Integer.toHexString(s.hashCode()); }
    }

    private String inkLabel(MuAnnot a) {
        return s(a.type == MuAnnot.BOX ? "shape_box" : a.marker ? "tool_marker" : "tool_pen");
    }

    private void tintSeek(SeekBar sb) {
        try {
            sb.getProgressDrawable().setColorFilter(accent, android.graphics.PorterDuff.Mode.SRC_IN);
            sb.getThumb().setColorFilter(accent, android.graphics.PorterDuff.Mode.SRC_IN);
        } catch (Throwable ignored) { }
    }

    /** Menu body for a tapped drawing: colour, thickness, opacity, note, delete. */
    private void buildInkMenu(LinearLayout card, final MuAnnot a) {
        int nc = a.marker ? MuAnnot.TEXT_COLORS : MuAnnot.FILL.length;
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        final Swatch[] sw = new Swatch[nc];
        for (int i = 0; i < nc; i++) {
            final int ci = i;
            sw[i] = new Swatch(this, MuAnnot.INK[i], a.rgb == 0 && i == a.color);
            sw[i].setContentDescription(s("c" + i));
            sw[i].setOnClickListener(v -> {
                a.color = ci; a.rgb = 0;
                for (int k = 0; k < sw.length; k++) sw[k].setOn(k == ci);
                view.refreshHighlights();
            });
            pressable(sw[i]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(32), dp(32));
            if (i > 0) lp.setMargins(dp(5), 0, 0, 0);
            r1.addView(sw[i], lp);
        }
        card.addView(r1);

        {
            LinearLayout r2 = new LinearLayout(this);
            r2.setOrientation(LinearLayout.HORIZONTAL);
            r2.setGravity(Gravity.CENTER_VERTICAL);
            TextView l2 = text(s("thick"), 12f, false, barSub);
            SeekBar sb = new SeekBar(this);
            sb.setMax(100);
            sb.setPadding(dp(12), 0, dp(12), 0);
            sb.setProgress(MuInk.progressOf(a.width));
            tintSeek(sb);
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar x, int p, boolean user) {
                    if (!user) return;
                    a.width = MuInk.widthOf(p);
                    view.refreshHighlights();
                }
                @Override public void onStartTrackingTouch(SeekBar x) { }
                @Override public void onStopTrackingTouch(SeekBar x) { }
            });
            r2.addView(l2, new LinearLayout.LayoutParams(dp(66), -2));
            r2.addView(sb, new LinearLayout.LayoutParams(0, dp(34), 1f));
            LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(-1, -2);
            p2.topMargin = dp(6);
            card.addView(r2, p2);
        }

        LinearLayout r3 = new LinearLayout(this);
        r3.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams p3 = new LinearLayout.LayoutParams(-1, -2);
        p3.topMargin = dp(6);
        card.addView(r3, p3);
        r3.addView(action(IconView.NOTE, s("note"), sheetFg, v -> showHlEditor(a, a.note == null || a.note.isEmpty(), null)), new LinearLayout.LayoutParams(0, -2, 1f));
        r3.addView(action(IconView.TRASH, s("delete"), 0xFFD64545, v -> deleteHighlight(a)), new LinearLayout.LayoutParams(0, -2, 1f));
    }

    // ================================================================= bookmarks
    private void toggleMark() {
        if (!opened) return;
        int p = view.currentPage0() + 1;
        if (marks.contains(p)) { marks.remove(p); toast(s("removed")); } else { marks.add(p); toast(s("added")); }
        updateMarkIcon();
    }

    private void updateMarkIcon() {
        if (markBtn == null) return;
        boolean m = marks.contains(curPage0 + 1);
        markBtn.setFilled(m);
        markBtn.setColor(m ? accent : barFg);
    }

    private void toast(String m) { snack(m, null, null); }

    // ================================================================= search
    private void openSearch() {
        if (!opened) return;
        searching = true;
        updateTray();
        topBar.setVisibility(View.GONE);
        searchBar.setAlpha(1f); searchBar.setTranslationY(0); searchBar.setVisibility(View.VISIBLE);
        if (!barsShown) setBars(true);
        searchInput.requestFocus();
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.showSoftInput(searchInput, 0);
    }

    private void closeSearch() {
        searching = false;
        updateTray();
        view.clearSearch();
        searchCount.setText("");
        searchBar.setVisibility(View.GONE);
        topBar.setAlpha(1f); topBar.setTranslationY(0); topBar.setVisibility(View.VISIBLE);
        hideKeyboard();
    }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
    }

    private void runSearch() {
        String q = searchInput.getText().toString();
        hideKeyboard();
        searchCount.setText("…");
        view.search(q, (hits, done) -> {
            if (done) {
                if (hits == 0) { searchCount.setText("0"); toast(s("noresult")); } else updateSearchCount();
            } else updateSearchCount();
        });
    }

    private void updateSearchCount() {
        int n = view.hitCount();
        searchCount.setText(n == 0 ? "…" : (view.currentHitIndex() + 1) + "/" + n);
    }

    // ================================================================= sheets
    private Dialog newSheet(View content, boolean bottom) { return newSheet(content, bottom, null); }

    private Dialog newSheet(View content, boolean bottom, final Runnable onDismiss) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(ur ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(sheetBg);
        float r = dp(22);
        if (bottom) bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0}); else bg.setCornerRadius(r);
        box.setBackground(bg);
        box.setPadding(dp(18), dp(14), dp(18), dp(18) + (bottom ? botInset : 0));
        box.addView(content, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            w.setLayout(bottom ? -1 : (int) (getResources().getDisplayMetrics().widthPixels * 0.9f), -2);
            w.setGravity(bottom ? Gravity.BOTTOM : Gravity.CENTER);
            w.setDimAmount(0.45f);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        dialogs.add(d);
        d.setOnDismissListener(x -> { dialogs.remove(d); if (onDismiss != null) onDismiss.run(); });
        d.show();
        return d;
    }

    private TextView text(String t, float sp, boolean bold, int color) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(sp); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        return v;
    }

    private TextView chip(String t, boolean on) {
        TextView v = text(t, 12.5f, true, on ? 0xFFFFFFFF : sheetFg);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        v.setEllipsize(TextUtils.TruncateAt.END);
        v.setPadding(dp(6), dp(9), dp(6), dp(9));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10)); g.setColor(on ? accent : chipBg);
        v.setBackground(g);
        return v;
    }

    // ---- contents + bookmarks + highlights
    private int contentsTab = 0;                // 0 contents, 1 bookmarks, 2 highlights
    private String hlQuery = "";
    private int hlFilter = -1;                  // -1 = every colour

    private void showContents() { if (opened) openContents(contentsTab); }

    private TextView tabChip(String t, boolean on) {
        TextView v = chip(t, on);
        v.setTextSize(13f);
        v.setPadding(dp(6), dp(10), dp(6), dp(10));
        v.setSingleLine(true);
        v.setEllipsize(TextUtils.TruncateAt.END);
        pressable(v);
        return v;
    }

    private void openContents(int startTab) {
        contentsTab = startTab;
        final LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        final LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);

        // highlight tools: built once so the search box keeps its focus while typing
        final LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        final EditText q = new EditText(this);
        q.setSingleLine(true);
        q.setHint(s("search_hl"));
        q.setTextSize(14f);
        q.setTextColor(sheetFg);
        q.setHintTextColor(barSub);
        q.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        q.setInputType(InputType.TYPE_CLASS_TEXT);
        q.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        q.setBackground(round(chipBg, 14));
        q.setPadding(dp(14), 0, dp(14), 0);
        q.setText(hlQuery);
        IconView shareAll = iconBtn(IconView.SHARE, sheetFg, .5f, s("share_all"));
        IconView clearAll = iconBtn(IconView.TRASH, 0xFFD64545, .5f, s("clear_all"));
        tools.addView(q, new LinearLayout.LayoutParams(0, dp(42), 1f));
        tools.addView(shareAll, new LinearLayout.LayoutParams(dp(44), dp(44)));
        tools.addView(clearAll, new LinearLayout.LayoutParams(dp(44), dp(44)));

        final HorizontalScrollView fscroll = new HorizontalScrollView(this);
        fscroll.setHorizontalScrollBarEnabled(false);
        final LinearLayout filters = new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        fscroll.addView(filters);

        final LinearLayout emptyBox = new LinearLayout(this);
        emptyBox.setOrientation(LinearLayout.VERTICAL);
        emptyBox.setGravity(Gravity.CENTER_HORIZONTAL);
        emptyBox.setPadding(dp(8), dp(24), dp(8), dp(24));
        final TextView eTitle = text("", 16f, true, sheetFg);
        eTitle.setGravity(Gravity.CENTER);
        final TextView eSub = text("", 13.5f, false, barSub);
        eSub.setGravity(Gravity.CENTER);
        eSub.setLineSpacing(0f, 1.15f);
        final TextView eBtn = chip("", true);
        pressable(eBtn);
        emptyBox.addView(eTitle, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams esp = new LinearLayout.LayoutParams(-1, -2); esp.topMargin = dp(6);
        emptyBox.addView(eSub, esp);
        LinearLayout.LayoutParams ebp = new LinearLayout.LayoutParams(-2, -2); ebp.topMargin = dp(16);
        ebp.gravity = Gravity.CENTER_HORIZONTAL;
        emptyBox.addView(eBtn, ebp);

        final ListView list = new ListView(this);
        list.setDivider(null);
        list.setVerticalScrollBarEnabled(false);
        list.setLayoutDirection(ur ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);

        LinearLayout.LayoutParams tabsLp = new LinearLayout.LayoutParams(-1, -2);
        tabsLp.bottomMargin = dp(10);
        LinearLayout.LayoutParams toolsLp = new LinearLayout.LayoutParams(-1, -2);
        toolsLp.bottomMargin = dp(8);
        LinearLayout.LayoutParams fLp = new LinearLayout.LayoutParams(-1, -2);
        fLp.bottomMargin = dp(8);
        col.addView(tabs, tabsLp);
        col.addView(tools, toolsLp);
        col.addView(fscroll, fLp);
        col.addView(emptyBox);
        col.addView(list, new LinearLayout.LayoutParams(-1, (int) (getResources().getDisplayMetrics().heightPixels * 0.5f)));

        final Dialog[] dr = new Dialog[1];
        final Runnable[] renderTabs = new Runnable[1];
        final Runnable[] renderBody = new Runnable[1];


        renderBody[0] = () -> {
            boolean hlTab = contentsTab == 2;
            tools.setVisibility(hlTab ? View.VISIBLE : View.GONE);
            ViewGroup.LayoutParams lpl = list.getLayoutParams();
            lpl.height = (int) (getResources().getDisplayMetrics().heightPixels * (hlTab ? 0.42f : 0.55f));
            list.setLayoutParams(lpl);
            if (!hlTab) {
                fscroll.setVisibility(View.GONE);
                final List<String> labels = new ArrayList<>();
                final List<Integer> pages = new ArrayList<>();
                final List<Integer> levels = new ArrayList<>();
                if (contentsTab == 1) {
                    for (int p : marks) { labels.add(s("page") + " " + p); pages.add(p - 1); levels.add(0); }
                    eTitle.setText(s("nomarks"));
                    eBtn.setText(s("bm_this"));
                    eBtn.setVisibility(View.VISIBLE);
                    eBtn.setOnClickListener(v -> { toggleMark(); renderTabs[0].run(); });
                } else {
                    for (MuPdfView.OutlineItem it : outline) { labels.add(it.title.isEmpty() ? "—" : it.title); pages.add(it.page0); levels.add(Math.min(it.level, 4)); }
                    eTitle.setText(s("nocontents"));
                    eBtn.setVisibility(View.GONE);
                }
                eSub.setVisibility(View.GONE);
                emptyBox.setVisibility(labels.isEmpty() ? View.VISIBLE : View.GONE);
                list.setVisibility(labels.isEmpty() ? View.GONE : View.VISIBLE);
                list.setAdapter(new BaseAdapter() {
                    @Override public int getCount() { return labels.size(); }
                    @Override public Object getItem(int i) { return labels.get(i); }
                    @Override public long getItemId(int i) { return i; }
                    @Override public View getView(int i, View cv, ViewGroup parent) {
                        LinearLayout row = new LinearLayout(MuReaderActivity.this);
                        row.setOrientation(LinearLayout.HORIZONTAL);
                        row.setGravity(Gravity.CENTER_VERTICAL);
                        row.setPadding(dp(4 + levels.get(i) * 16), dp(12), dp(4), dp(12));
                        TextView name = text(labels.get(i), 15f, levels.get(i) == 0, sheetFg);
                        name.setSingleLine(true); name.setEllipsize(TextUtils.TruncateAt.END);
                        TextView pg = text(pages.get(i) >= 0 ? String.valueOf(pages.get(i) + 1) : "", 13f, false, barSub);
                        pg.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
                        row.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
                        row.addView(pg, new LinearLayout.LayoutParams(-2, -2));
                        return row;
                    }
                });
                list.setOnItemClickListener((p, v, i, id) -> {
                    if (pages.get(i) >= 0) { view.goToPage(pages.get(i)); dr[0].dismiss(); setBars(false); }
                });
                list.setOnItemLongClickListener((p, v, i, id) -> {
                    if (contentsTab == 1) { marks.remove(pages.get(i) + 1); updateMarkIcon(); renderTabs[0].run(); return true; }
                    return false;
                });
                return;
            }

            // ---- highlights tab
            final List<MuAnnot> all = sortedHighlights();
            final int[] counts = new int[MuAnnot.FILL.length];
            for (MuAnnot h : all) counts[h.color]++;
            if (hlFilter >= 0 && counts[hlFilter] == 0) hlFilter = -1;
            filters.removeAllViews();
            fscroll.setVisibility(all.isEmpty() ? View.GONE : View.VISIBLE);
            filters.addView(filterChip(-1, all.size(), hlFilter == -1, () -> { hlFilter = -1; renderBody[0].run(); }));
            for (int ci = 0; ci < counts.length; ci++) {
                if (counts[ci] == 0) continue;
                final int cc = ci;
                filters.addView(filterChip(ci, counts[ci], hlFilter == ci, () -> { hlFilter = cc; renderBody[0].run(); }));
            }
            final String needle = hlQuery.trim().toLowerCase(Locale.ROOT);
            final List<MuAnnot> shown = new ArrayList<>();
            for (MuAnnot h : all) {
                if (hlFilter >= 0 && h.color != hlFilter) continue;
                if (!needle.isEmpty() && !h.text.toLowerCase(Locale.ROOT).contains(needle) && !h.note.toLowerCase(Locale.ROOT).contains(needle)) continue;
                shown.add(h);
            }
            if (all.isEmpty()) {
                eTitle.setText(s("no_hl"));
                eSub.setText(s("no_hl_sub"));
                eSub.setVisibility(View.VISIBLE);
                eBtn.setText(s("start_hl"));
                eBtn.setVisibility(View.VISIBLE);
                eBtn.setOnClickListener(v -> { dr[0].dismiss(); if (!barsShown) setBars(true); selectTool(MuInk.MARKER); });
            } else {
                eTitle.setText(s("noresult"));
                eSub.setVisibility(View.GONE);
                eBtn.setVisibility(View.GONE);
            }
            emptyBox.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
            list.setVisibility(shown.isEmpty() ? View.GONE : View.VISIBLE);
            list.setAdapter(new BaseAdapter() {
                @Override public int getCount() { return shown.size(); }
                @Override public Object getItem(int i) { return shown.get(i); }
                @Override public long getItemId(int i) { return i; }
                @Override public View getView(int i, View cv, ViewGroup parent) { return hlRow(shown.get(i), () -> renderTabs[0].run()); }
            });
            list.setOnItemClickListener((p, v, i, id) -> {
                dr[0].dismiss();
                setBars(false);
                view.goToHighlight(shown.get(i));
            });
            list.setOnItemLongClickListener(null);
        };

        renderTabs[0] = () -> {
            tabs.removeAllViews();
            int n = view.highlights().size();
            String[] names = {
                    s("contents"),
                    s("marks") + (marks.isEmpty() ? "" : " (" + marks.size() + ")"),
                    s("highlights") + (n == 0 ? "" : " (" + n + ")")
            };
            for (int i = 0; i < 3; i++) {
                final int idx = i;
                TextView t = tabChip(names[i], contentsTab == i);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                if (i > 0) lp.setMargins(dp(6), 0, 0, 0);
                t.setOnClickListener(v -> { contentsTab = idx; renderTabs[0].run(); });
                tabs.addView(t, lp);
            }
            renderBody[0].run();
        };

        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable e) {
                hlQuery = e.toString();
                if (contentsTab == 2) renderBody[0].run();
            }
        });
        q.setOnEditorActionListener((tv, id, ev) -> { hideKeyboard(q); return true; });
        shareAll.setOnClickListener(v -> {
            List<MuAnnot> all = sortedHighlights();
            if (!all.isEmpty()) shareText(exportText(all));
        });
        clearAll.setOnClickListener(v -> {
            if (!view.highlights().isEmpty()) confirmClearAll(() -> renderTabs[0].run());
        });

        dr[0] = newSheet(col, true);
        renderTabs[0].run();
    }

    private List<MuAnnot> sortedHighlights() {
        List<MuAnnot> l = new ArrayList<>(view.highlights());
        java.util.Collections.sort(l, (a, b) -> a.page0 != b.page0 ? Integer.compare(a.page0, b.page0) : Float.compare(sortY(a), sortY(b)));
        return l;
    }

    private static float sortY(MuAnnot a) {
        if (a.type == MuAnnot.TEXT) return a.rects.length > 1 ? a.rects[1] : 0f;
        return a.pts.length > 1 ? a.pts[1] * 595f : 0f;      // page-width units -> roughly points
    }

    private View filterChip(int color, int count, boolean on, final Runnable click) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(dp(12), dp(7), dp(12), dp(7));
        c.setBackground(round(on ? accent : chipBg, 16));
        int fg = on ? 0xFFFFFFFF : sheetFg;
        if (color >= 0) {
            View dot = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL); g.setColor(MuAnnot.INK[color]);
            if (on) g.setStroke(dp(2), 0xFFFFFFFF);
            dot.setBackground(g);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(12), dp(12));
            dl.setMarginEnd(dp(6));
            c.addView(dot, dl);
            c.setContentDescription(s("c" + color));
        }
        TextView t = text(color < 0 ? s("all") + " " + count : String.valueOf(count), 13f, true, fg);
        c.addView(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMarginEnd(dp(8));
        c.setLayoutParams(lp);
        c.setOnClickListener(v -> click.run());
        pressable(c);
        return c;
    }

    private View hlRow(final MuAnnot h, final Runnable onChanged) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(10), dp(0), dp(10));
        View bar = new View(this);
        bar.setBackground(round(h.inkC(), 2));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(4), -1);
        bl.setMargins(0, dp(2), dp(12), dp(2));
        LinearLayout colx = new LinearLayout(this);
        colx.setOrientation(LinearLayout.VERTICAL);
        Bitmap tb = h.isInk() ? view.thumb(h, dp(220), dp(70)) : null;
        TextView qt = text(h.isInk() ? inkLabel(h) : h.text.isEmpty() ? "—" : h.text, 14.5f, false, sheetFg);
        qt.setMaxLines(3);
        qt.setEllipsize(TextUtils.TruncateAt.END);
        qt.setLineSpacing(0f, 1.12f);
        if (tb != null) {
            android.widget.ImageView iv = new android.widget.ImageView(this);
            iv.setImageBitmap(tb);
            iv.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
            colx.addView(iv, new LinearLayout.LayoutParams(dp(220), dp(70)));
        } else colx.addView(qt);
        if (h.note != null && !h.note.isEmpty()) {
            TextView n = text(h.note, 12.5f, false, accent);
            n.setTypeface(Typeface.DEFAULT, Typeface.ITALIC);
            n.setMaxLines(2);
            n.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-2, -2); np.topMargin = dp(4);
            colx.addView(n, np);
        }
        String meta = s("page") + " " + (h.page0 + 1);
        if (h.created > 0) {
            try { meta += "  ·  " + java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM).format(new java.util.Date(h.created)); } catch (Throwable ignored) { }
        }
        TextView mt = text(meta, 11.5f, false, barSub);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-2, -2); mp.topMargin = dp(4);
        colx.addView(mt, mp);
        IconView more = iconBtn(IconView.MORE, barSub, .5f, s("note"));
        more.setOnClickListener(v -> showHlEditor(h, false, onChanged));
        row.addView(bar, bl);
        row.addView(colx, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(more, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return row;
    }

    private String exportText(List<MuAnnot> list) {
        StringBuilder sb = new StringBuilder();
        sb.append(title).append('\n').append(s("highlights")).append(" (").append(list.size()).append(")\n\n");
        for (MuAnnot h : list) {
            sb.append(s("page")).append(' ').append(h.page0 + 1).append('\n');
            if (h.isInk()) sb.append('[').append(inkLabel(h)).append("]\n");
            else sb.append('“').append(h.text).append("”\n");
            if (h.note != null && !h.note.isEmpty()) sb.append(s("note")).append(": ").append(h.note).append('\n');
            sb.append('\n');
        }
        return sb.toString().trim();
    }

    private void confirmClearAll(final Runnable after) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(s("clear_q"), 16f, true, sheetFg));
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        TextView cancel = chip(s("cancel"), false), del = chip(s("delete"), true);
        del.setBackground(round(0xFFD64545, 12));
        pressable(cancel); pressable(del);
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, -2, 1f); a.setMargins(0, dp(16), dp(8), 0);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, -2, 1f); b.setMargins(0, dp(16), 0, 0);
        btns.addView(cancel, a); btns.addView(del, b);
        col.addView(btns);
        final Dialog d = newSheet(col, false);
        cancel.setOnClickListener(v -> d.dismiss());
        del.setOnClickListener(v -> {
            final List<MuAnnot> backup = new ArrayList<>(view.highlights());
            view.setHighlights(new ArrayList<MuAnnot>());
            d.dismiss();
            snack(s("hl_deleted"), s("undo"), () -> { view.setHighlights(backup); });
            if (after != null) after.run();
        });
    }

    // ---- appearance
    private void toggleLook() {
        if (dock.isPanelShown()) { dock.hidePanel(); return; }
        showLook();
    }

    private void showLook() {
        if (!opened) return;
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(s("look"), 15f, true, sheetFg));
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2); rp.topMargin = dp(10);
        col.addView(row, rp);
        final String[] names = {s("paper"), s("sepia"), s("night")};
        final Runnable[] fill = new Runnable[1];
        fill[0] = () -> {
            row.removeAllViews();
            for (int i = 0; i < 3; i++) {
                final int idx = i;
                TextView c = chip(names[i], theme == i);
                c.setOnClickListener(v -> {
                    theme = idx; applyLook();
                    showLook();                      // rebuild in the new colours
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                lp.setMargins(i == 0 ? 0 : dp(6), 0, 0, 0);
                row.addView(c, lp);
            }
        };
        fill[0].run();

        TextView bl = text(s("brightness"), 12.5f, false, barSub);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2); bp.topMargin = dp(14);
        col.addView(bl, bp);
        SeekBar br = new SeekBar(this);
        br.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        br.setMax(70);
        br.setProgress(70 - Math.round(dim * 100));
        try { br.getProgressDrawable().setTint(accent); br.getThumb().setTint(accent); } catch (Throwable ignored) { }
        br.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) { dim = (70 - p) / 100f; view.setLook(theme, dim); }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        col.addView(br, new LinearLayout.LayoutParams(-1, dp(34)));

        LinearLayout awakeRow = new LinearLayout(this);
        awakeRow.setOrientation(LinearLayout.HORIZONTAL);
        awakeRow.setGravity(Gravity.CENTER_VERTICAL);
        awakeRow.addView(text(s("awake"), 13f, false, sheetFg), new LinearLayout.LayoutParams(0, -2, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(keepAwake);
        sw.setOnCheckedChangeListener((b, on) -> {
            keepAwake = on;
            if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
        awakeRow.addView(sw);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2); ap.topMargin = dp(6);
        col.addView(awakeRow, ap);

        TextView posLbl = text(s("tray_pos"), 12.5f, false, barSub);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-2, -2); plp.topMargin = dp(12);
        col.addView(posLbl, plp);
        LinearLayout posRow = new LinearLayout(this);
        posRow.setOrientation(LinearLayout.HORIZONTAL);
        final String[] posNames = {s("tray_bottom"), s("tray_left"), s("tray_right")};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView pc = chip(posNames[i], traySide == i);
            pc.setOnClickListener(v -> {
                if (traySide == idx) return;
                traySide = idx; saveInkPrefs(); applyTraySide();
                showLook();
            });
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(0, -2, 1f);
            pl.setMargins(i == 0 ? 0 : dp(6), 0, 0, 0);
            posRow.addView(pc, pl);
        }
        LinearLayout.LayoutParams prp = new LinearLayout.LayoutParams(-1, -2); prp.topMargin = dp(8);
        col.addView(posRow, prp);

        TextView fit = chip(s("fit") + "  ·  " + Math.round(view.zoom() * 100) + "%", false);
        fit.setOnClickListener(v -> { view.resetZoom(); dock.hidePanel(); });
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2); fp.topMargin = dp(12);
        col.addView(fit, fp);

        TextView info = text(total + " " + s("pages"), 11f, false, barSub);
        info.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        info.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin = dp(8);
        col.addView(info, ip);
        dock.showPanel(col);
    }

    // ---- jump
    private void showJump() {
        if (!opened) return;
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(s("jump") + "  (1 – " + total + ")", 16f, true, sheetFg));
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setSingleLine(true);
        et.setText(String.valueOf(curPage0 + 1));
        et.setSelectAllOnFocus(true);
        et.setTextColor(sheetFg);
        et.setTextSize(20f);
        et.setGravity(Gravity.CENTER);
        et.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(10);
        col.addView(et, lp);
        TextView go = chip(s("go"), true);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2); gp.topMargin = dp(12);
        col.addView(go, gp);
        final Dialog d = newSheet(col, true);
        final Runnable doGo = () -> {
            try {
                int n = Integer.parseInt(et.getText().toString().trim());
                if (n >= 1 && n <= total) { view.goToPage(n - 1); d.dismiss(); setBars(false); return; }
            } catch (Throwable ignored) { }
            et.setError(" ");
        };
        go.setOnClickListener(v -> doGo.run());
        et.setOnEditorActionListener((tv, id, ev) -> { doGo.run(); return true; });
        et.requestFocus();
    }

    // ---- password
    private void showPasswordSheet(boolean wrong) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(s("pw_title"), 17f, true, sheetFg));
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        et.setSingleLine(true);
        et.setHint(s("pw_hint"));
        et.setTextColor(sheetFg); et.setHintTextColor(barSub);
        et.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(10);
        col.addView(et, lp);
        if (wrong) {
            TextView err = text(s("pw_wrong"), 13f, false, 0xFFD64545);
            col.addView(err);
        }
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        TextView cancel = chip(s("cancel"), false), ok = chip(s("ok"), true);
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, -2, 1f); a.setMargins(0, dp(14), dp(8), 0);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, -2, 1f); b.setMargins(0, dp(14), 0, 0);
        btns.addView(cancel, a); btns.addView(ok, b);
        col.addView(btns);
        final Dialog d = newSheet(col, false);
        d.setCancelable(false);
        final Runnable submit = () -> {
            String pw = et.getText().toString();
            d.dismiss();
            spinner.setVisibility(View.VISIBLE);
            view.open(path, pw, startPage0, startFrac);
        };
        ok.setOnClickListener(v -> submit.run());
        cancel.setOnClickListener(v -> { d.dismiss(); finishWith(null); });
        et.setOnEditorActionListener((tv, id, ev) -> { submit.run(); return true; });
        et.requestFocus();
    }

    // ================================================================= highlight UI helpers
    private GradientDrawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    /** Small press animation for custom buttons; the click itself still goes through. */
    private void pressable(final View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(.94f).scaleY(.94f).setDuration(90).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) x.animate().scaleX(1f).scaleY(1f).setDuration(150).start();
            return false;
        });
    }

    private IconView iconBtn(int kind, int color, float scale, String desc) {
        IconView v = new IconView(this, kind);
        v.setScale(scale);
        v.setColor(color);
        v.setBackground(null);
        v.setContentDescription(desc);
        pressable(v);
        return v;
    }

    private void hideKeyboard(View v) {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    private void dismissDialogs() {
        for (Dialog d : new ArrayList<>(dialogs)) { try { d.dismiss(); } catch (Throwable ignored) { } }
    }

    private void copyText(String t) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(title, t));
        } catch (Throwable ignored) { }
    }

    private void shareText(String t) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, t);
            startActivity(Intent.createChooser(i, null));
        } catch (Throwable ignored) { }
    }

    private String quoteOf(String text, int page0, String note) {
        StringBuilder sb = new StringBuilder();
        sb.append('“').append(text).append('”').append("\n— ").append(title).append(", ").append(s("page")).append(' ').append(page0 + 1);
        if (note != null && !note.isEmpty()) sb.append('\n').append(s("note")).append(": ").append(note);
        return sb.toString();
    }

    // ---- snackbar: quick confirmations, with Undo where it makes sense
    private void hideSnack() {
        if (snackView == null) return;
        final View sv = snackView;
        snackView = null;
        sv.removeCallbacks(snackHide);
        sv.animate().alpha(0f).translationY(dp(10)).setDuration(160).withEndAction(() -> root.removeView(sv)).start();
    }

    private void snack(String msg, String action, final Runnable onAction) {
        if (snackView != null) {
            snackView.removeCallbacks(snackHide);
            snackView.animate().cancel();
            root.removeView(snackView);
            snackView = null;
        }
        final LinearLayout sv = new LinearLayout(this);
        sv.setOrientation(LinearLayout.HORIZONTAL);
        sv.setGravity(Gravity.CENTER_VERTICAL);
        sv.setLayoutDirection(ur ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
        sv.setMinimumHeight(dp(44));
        sv.setPadding(dp(18), 0, dp(action != null ? 6 : 18), 0);
        sv.setBackground(round(theme == 2 ? 0xF2262E29 : 0xF21C2420, 16));
        sv.setElevation(dp(8));
        sv.setClickable(true);
        TextView m = text(msg, 13.5f, false, 0xFFFFFFFF);
        m.setMaxWidth(dp(250));
        m.setPadding(0, dp(11), 0, dp(11));
        sv.addView(m);
        if (action != null) {
            TextView a = text(action, 13.5f, true, 0xFF7FE0B0);
            a.setPadding(dp(16), dp(11), dp(14), dp(11));
            a.setOnClickListener(v -> { hideSnack(); if (onAction != null) onAction.run(); });
            sv.addView(a);
        }
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lp.bottomMargin = trayHeight() > 0 ? trayHeight() + dp(16) : botInset + dp(58);
        lp.leftMargin = dp(16); lp.rightMargin = dp(16);
        sv.setAlpha(0f);
        sv.setTranslationY(dp(12));
        root.addView(sv, lp);
        sv.animate().alpha(1f).translationY(0f).setDuration(190).start();
        snackView = sv;
        sv.postDelayed(snackHide, action != null ? 4600 : 2600);
    }

    // ---- floating menu: next to a fresh selection, or next to a tapped highlight
    private void hideMenu() {
        if (menu == null) return;
        final View m = menu;
        menu = null;
        menuHl = null;
        m.animate().alpha(0f).scaleX(.96f).scaleY(.96f).setDuration(110).withEndAction(() -> root.removeView(m)).start();
    }

    private View action(int icon, String label, int color, View.OnClickListener l) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER_HORIZONTAL);
        b.setPadding(dp(2), dp(2), dp(2), dp(0));
        IconView ic = new IconView(this, icon);
        ic.setScale(.56f);
        ic.setColor(color);
        ic.setBackground(null);
        ic.setClickable(false);
        TextView t = text(label, 11f, true, color);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        b.addView(ic, new LinearLayout.LayoutParams(dp(44), dp(30)));
        b.addView(t, new LinearLayout.LayoutParams(-2, -2));
        b.setContentDescription(label);
        b.setOnClickListener(l);
        pressable(b);
        return b;
    }

    private void showMenu(RectF anchor, final MuAnnot existing) {
        if (!opened || root.getWidth() == 0) return;
        hideMenu();
        menuHl = existing;
        final int[] ink = MuAnnot.INK;
        final int curC = existing != null ? existing.color : hlColor;
        final int curS = existing != null ? existing.style : hlStyle;

        final LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        card.setClickable(true);
        card.setPadding(dp(12), dp(10), dp(12), dp(6));
        GradientDrawable bg = round((sheetBg & 0x00FFFFFF) | 0xF7000000, 22);
        bg.setStroke(dp(1), (barSub & 0x00FFFFFF) | 0x33000000);
        card.setBackground(bg);
        card.setElevation(dp(12));

        if (existing != null && existing.isInk()) buildInkMenu(card, existing);
        else {
        // row 1: colours | style
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        final Swatch[] sw = new Swatch[MuAnnot.TEXT_COLORS];
        for (int i = 0; i < MuAnnot.TEXT_COLORS; i++) {
            final int ci = i;
            sw[i] = new Swatch(this, ink[i], i == curC);
            sw[i].setContentDescription(s("c" + i));
            sw[i].setOnClickListener(v -> pickColor(ci, existing, sw));
            pressable(sw[i]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(32), dp(32));
            if (i > 0) lp.setMargins(dp(5), 0, 0, 0);
            r1.addView(sw[i], lp);
        }
        View div = new View(this);
        div.setBackgroundColor((barSub & 0x00FFFFFF) | 0x40000000);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(1), dp(22));
        dl.setMargins(dp(10), 0, dp(6), 0);
        r1.addView(div, dl);
        final IconView[] st = new IconView[3];
        final int[] kinds = {IconView.PEN, IconView.UNDERLINE, IconView.STRIKE};
        final String[] kn = {s("highlight"), s("underline"), s("strike")};
        final int[] curStyle = {curS};
        final Runnable paintStyles = () -> {
            for (int i = 0; i < 3; i++) {
                st[i].setBackground(round(i == curStyle[0] ? chipBg : 0x00000000, 11));
                st[i].setColor(i == curStyle[0] ? accent : sheetFg);
            }
        };
        for (int i = 0; i < 3; i++) {
            final int si = i;
            st[i] = new IconView(this, kinds[i]);
            st[i].setScale(.58f);
            st[i].setContentDescription(kn[i]);
            st[i].setOnClickListener(v -> {
                curStyle[0] = si;
                if (existing != null) { existing.style = si; view.refreshHighlights(); }
                else { hlStyle = si; uiPrefs.edit().putInt("hlStyle", si).apply(); }
                paintStyles.run();
            });
            pressable(st[i]);
            r1.addView(st[i], new LinearLayout.LayoutParams(dp(36), dp(36)));
        }
        paintStyles.run();
        card.addView(r1);

        // row 2: actions
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams r2p = new LinearLayout.LayoutParams(-1, -2);
        r2p.topMargin = dp(8);
        card.addView(r2, r2p);
        final String textNow = existing != null ? existing.text : view.selectionText();
        r2.addView(action(IconView.COPY, s("copy"), sheetFg, v -> {
            copyText(textNow);
            if (existing == null) view.clearSelection(); else hideMenu();
            snack(s("copied"), null, null);
        }), new LinearLayout.LayoutParams(0, -2, 1f));
        r2.addView(action(IconView.NOTE, s("note"), sheetFg, v -> {
            if (existing != null) { showHlEditor(existing, existing.note == null || existing.note.isEmpty(), null); return; }
            MuAnnot h = view.commitSelection(hlColor, hlStyle, new ArrayList<MuAnnot>());
            if (h == null) { snack(s("hl_limit"), null, null); return; }
            showHlEditor(h, true, null);
        }), new LinearLayout.LayoutParams(0, -2, 1f));
        r2.addView(action(IconView.SHARE, s("share"), sheetFg, v -> {
            if (existing != null) { shareText(quoteOf(existing.text, existing.page0, existing.note)); hideMenu(); }
            else { String t = textNow; int p = view.currentPage0(); view.clearSelection(); shareText(quoteOf(t, p, null)); }
        }), new LinearLayout.LayoutParams(0, -2, 1f));
        if (existing != null) {
            r2.addView(action(IconView.TRASH, s("delete"), 0xFFD64545, v -> deleteHighlight(existing)), new LinearLayout.LayoutParams(0, -2, 1f));
        } else {
            r2.addView(action(IconView.SEARCH, s("search_sel"), sheetFg, v -> {
                String t = textNow.replace('\n', ' ').trim();
                if (t.length() > 80) t = t.substring(0, 80);
                view.clearSelection();
                searchInput.setText(t);
                openSearch();
                runSearch();
            }), new LinearLayout.LayoutParams(0, -2, 1f));
        }

        }

        // position: above the text, else below it, else pinned to the top of the screen
        int sw0 = root.getWidth(), sh0 = root.getHeight();
        card.measure(View.MeasureSpec.makeMeasureSpec(Math.min(dp(330), sw0 - dp(24)), View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int mw = card.getMeasuredWidth(), mh = card.getMeasuredHeight();
        int x = Math.round((anchor.left + anchor.right) / 2f - mw / 2f);
        x = Math.max(dp(12), Math.min(sw0 - mw - dp(12), x));
        int minTop = topInset + dp(10), maxBottom = sh0 - botInset - dp(10);
        int pad = existing == null ? dp(30) : dp(10);
        int y = Math.round(anchor.top) - pad - mh;
        if (y < minTop) {
            y = Math.round(anchor.bottom) + pad;
            if (y + mh > maxBottom) y = minTop + dp(8);
        }
        y = Math.max(minTop, Math.min(maxBottom - mh, y));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(mw, mh, Gravity.TOP | Gravity.LEFT);
        lp.leftMargin = x;
        lp.topMargin = y;
        card.setAlpha(0f);
        card.setScaleX(.94f);
        card.setScaleY(.94f);
        card.setTranslationY(dp(6));
        root.addView(card, lp);
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(160).start();
        menu = card;
    }

    private void pickColor(int ci, final MuAnnot existing, Swatch[] sw) {
        if (existing != null) {
            existing.color = ci; existing.rgb = 0;
            view.refreshHighlights();
            for (int i = 0; i < sw.length; i++) sw[i].setOn(i == ci);
            return;
        }
        hlColor = ci;
        uiPrefs.edit().putInt("hlColor", ci).apply();
        final List<MuAnnot> removed = new ArrayList<>();
        final MuAnnot h = view.commitSelection(ci, hlStyle, removed);
        if (h == null) { snack(s("hl_limit"), null, null); return; }
        snack(s("hl_saved"), s("undo"), () -> {
            view.removeHighlight(h);
            for (MuAnnot o : removed) view.addHighlight(o);
        });
    }

    private void deleteHighlight(final MuAnnot h) {
        view.removeHighlight(h);
        hideMenu();
        snack(s("hl_deleted"), s("undo"), () -> view.addHighlight(h));
    }

    // ---- editor sheet: quote, colour, style, note, copy / share / go to page / delete
    private void showHlEditor(final MuAnnot h, final boolean focusNote, final Runnable onDone) {
        hideMenu();
        final LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text(h.isInk() ? s("drawing") : s("highlight"), 17f, true, sheetFg), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView pg = text(s("page") + " " + (h.page0 + 1), 12f, true, sheetFg);
        pg.setPadding(dp(12), dp(6), dp(12), dp(6));
        pg.setBackground(round(chipBg, 12));
        head.addView(pg);
        col.addView(head);

        LinearLayout quote = new LinearLayout(this);
        quote.setOrientation(LinearLayout.HORIZONTAL);
        quote.setPadding(dp(12), dp(12), dp(12), dp(12));
        quote.setBackground(round(chipBg, 14));
        final View bar = new View(this);
        bar.setBackground(round(h.inkC(), 2));
        quote.addView(bar, new LinearLayout.LayoutParams(dp(4), -1));
        Bitmap tb = h.isInk() ? view.thumb(h, dp(300), dp(120)) : null;
        TextView qt = text(h.isInk() ? inkLabel(h) : h.text.isEmpty() ? "—" : h.text, 15f, false, sheetFg);
        qt.setMaxLines(6);
        qt.setEllipsize(TextUtils.TruncateAt.END);
        qt.setLineSpacing(0f, 1.15f);
        qt.setPaddingRelative(dp(10), 0, 0, 0);
        if (tb != null) {
            android.widget.ImageView iv = new android.widget.ImageView(this);
            iv.setImageBitmap(tb);
            iv.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
            iv.setPaddingRelative(dp(10), 0, 0, 0);
            quote.addView(iv, new LinearLayout.LayoutParams(0, dp(110), 1f));
        } else quote.addView(qt, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams ql = new LinearLayout.LayoutParams(-1, -2);
        ql.topMargin = dp(12);
        col.addView(quote, ql);

        LinearLayout opts = new LinearLayout(this);
        opts.setOrientation(LinearLayout.HORIZONTAL);
        opts.setGravity(Gravity.CENTER_VERTICAL);
        opts.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        final Swatch[] sw = new Swatch[h.isInk() && !h.marker ? MuAnnot.INK.length : MuAnnot.TEXT_COLORS];
        for (int i = 0; i < sw.length; i++) {
            final int ci = i;
            sw[i] = new Swatch(this, MuAnnot.INK[i], h.rgb == 0 && i == h.color);
            sw[i].setContentDescription(s("c" + i));
            sw[i].setOnClickListener(v -> {
                h.color = ci; h.rgb = 0;
                bar.setBackground(round(MuAnnot.INK[ci], 2));
                for (int k = 0; k < sw.length; k++) sw[k].setOn(k == ci);
                view.refreshHighlights();
            });
            pressable(sw[i]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
            if (i > 0) lp.setMargins(dp(6), 0, 0, 0);
            opts.addView(sw[i], lp);
        }
        opts.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        final IconView[] st = new IconView[3];
        final int[] kinds = {IconView.PEN, IconView.UNDERLINE, IconView.STRIKE};
        final String[] kn = {s("highlight"), s("underline"), s("strike")};
        final Runnable paintStyles = () -> {
            for (int i = 0; i < 3; i++) {
                if (st[i] == null) continue;
                st[i].setBackground(round(i == h.style ? chipBg : 0x00000000, 11));
                st[i].setColor(i == h.style ? accent : sheetFg);
            }
        };
        for (int i = 0; i < 3; i++) {
            if (h.isInk()) continue;
            final int si = i;
            st[i] = new IconView(this, kinds[i]);
            st[i].setScale(.58f);
            st[i].setContentDescription(kn[i]);
            st[i].setOnClickListener(v -> { h.style = si; paintStyles.run(); view.refreshHighlights(); });
            pressable(st[i]);
            opts.addView(st[i], new LinearLayout.LayoutParams(dp(36), dp(36)));
        }
        paintStyles.run();
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, -2);
        op.topMargin = dp(14);
        col.addView(opts, op);

        final EditText et = new EditText(this);
        et.setHint(s("note_hint"));
        et.setHintTextColor(barSub);
        et.setTextColor(sheetFg);
        et.setTextSize(16f);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        et.setMinLines(3);
        et.setMaxLines(6);
        et.setGravity(Gravity.TOP | Gravity.START);
        et.setBackground(round(chipBg, 14));
        et.setPadding(dp(14), dp(12), dp(14), dp(12));
        et.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        et.setText(h.note);
        et.setSelection(et.length());
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.topMargin = dp(12);
        col.addView(et, ep);

        final Dialog[] dr = new Dialog[1];
        LinearLayout acts = new LinearLayout(this);
        acts.setOrientation(LinearLayout.HORIZONTAL);
        if (!h.isInk()) {
            acts.addView(action(IconView.COPY, s("copy"), sheetFg, v -> { copyText(h.text); snack(s("copied"), null, null); }), new LinearLayout.LayoutParams(0, -2, 1f));
            acts.addView(action(IconView.SHARE, s("share"), sheetFg, v -> shareText(quoteOf(h.text, h.page0, et.getText().toString().trim()))), new LinearLayout.LayoutParams(0, -2, 1f));
        }
        acts.addView(action(IconView.GOTO, s("goto"), sheetFg, v -> {
            dismissDialogs();
            setBars(false);
            view.goToHighlight(h);
        }), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = dp(10);
        col.addView(acts, ap);

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        TextView del = chip(s("delete"), false), done = chip(s("done"), true);
        del.setTextColor(0xFFD64545);
        pressable(del); pressable(done);
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, -2, 1f); a.setMargins(0, dp(12), dp(8), 0);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, -2, 1.4f); b.setMargins(0, dp(12), 0, 0);
        btns.addView(del, a); btns.addView(done, b);
        col.addView(btns);

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(col);
        dr[0] = newSheet(scroll, true, () -> {
            String n = et.getText().toString().trim();
            if (!n.equals(h.note == null ? "" : h.note)) { h.note = n; view.refreshHighlights(); }
            hideKeyboard(et);
            if (onDone != null) onDone.run();
        });
        done.setOnClickListener(v -> dr[0].dismiss());
        del.setOnClickListener(v -> { deleteHighlight(h); dr[0].dismiss(); });
        if (focusNote && dr[0].getWindow() != null) {
            dr[0].getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            et.requestFocus();
        }
    }

    /** Round colour dot; the selected one gets a ring and a tick. */
    static final class Swatch extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int color;
        private boolean on;

        Swatch(Context c, int color, boolean on) {
            super(c);
            this.color = color;
            this.on = on;
            setClickable(true);
        }

        void setOn(boolean o) { on = o; invalidate(); }

        @Override protected void onDraw(Canvas cv) {
            float d = getResources().getDisplayMetrics().density;
            float cx = getWidth() / 2f, cy = getHeight() / 2f, r = Math.min(getWidth(), getHeight()) / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(color);
            cv.drawCircle(cx, cy, r * (on ? 0.66f : 0.74f), p);
            if (on) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2f * d);
                p.setColor(color);
                cv.drawCircle(cx, cy, r - d, p);
                p.setColor(0xFFFFFFFF);
                p.setStrokeWidth(2f * d);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeJoin(Paint.Join.ROUND);
                Path t = new Path();
                t.moveTo(cx - r * 0.24f, cy + r * 0.02f);
                t.lineTo(cx - r * 0.06f, cy + r * 0.2f);
                t.lineTo(cx + r * 0.26f, cy - r * 0.16f);
                cv.drawPath(t, p);
            }
        }
    }

    // ================================================================= icons
    /**
     * Scroll handle, attached to the screen edge opposite to the tray (right by default; on the left it is the same
     * shape mirrored). It slides in while the book scrolls, with a "99/305" bubble beside it, and slides out when idle.
     * Drag it to scrub through the book; tap it (or the bubble) for "go to page".
     * Geometry comes from the design drawing: a tall tab with a dome at both ends whose neck flares into the edge.
     */
    private final class ScrubHandle extends View {
        // design units (px of the original drawing) -> dp
        private static final float BW = 388f, R = 118f, H = 1047f, RY = 155f, NECK = 224f, BH = 538f, GAP = 50f, PAD = 100f;
        private final float k;
        private final float hw, hh;                       // handle size in px
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path body = new Path();
        private final RectF rect = new RectF(), tmp = new RectF();
        private final int slop;
        private float frac = 0f, downY, grabDy, insetTop, insetBottom, slide = 0f, target = 0f;
        private int page = 1, pages = 1, bodyColor, tintColor, inkColor, lineColor, activeColor;
        private boolean dragging, pressed, moved, wasShown, shown, left;
        private android.animation.ValueAnimator anim;
        private final Runnable hideRun = new Runnable() {
            @Override public void run() {
                if (dragging || pressed) return;
                shown = false;
                slideTo(0f, 240);
            }
        };

        ScrubHandle(Context c) {
            super(c);
            setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            k = c.getResources().getDisplayMetrics().density * 0.0725f;
            hw = (BW + R) * k; hh = H * k;
            slop = android.view.ViewConfiguration.get(c).getScaledTouchSlop();
            txt.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            txt.setTextAlign(Paint.Align.LEFT);
            txt.setTextSize(dp(21));
            buildPath();
            setAlpha(0f);
        }

        /** The tab, drawn for the right edge: x = 0 is its outer end, x = hw is the screen edge. Open at the edge. */
        private void buildPath() {
            float bw = BW * k, r = R * k, h = H * k, ry = RY * k, fy = (H / 2f - NECK - R) * k;
            body.reset();
            body.moveTo(bw + r, h - fy - r);
            body.arcTo(new RectF(bw, h - fy - r, bw + 2 * r, h - fy + r), 270f, -90f);   // lower flare
            body.lineTo(bw, h - ry);
            body.arcTo(new RectF(0, h - 2 * ry, bw, h), 0f, 180f);                       // lower dome
            body.lineTo(0, ry);
            body.arcTo(new RectF(0, 0, bw, 2 * ry), 180f, 180f);                         // upper dome
            body.lineTo(bw, fy);
            body.arcTo(new RectF(bw, fy - r, bw + 2 * r, fy + r), 180f, -90f);           // upper flare
        }

        void restyle() {
            bodyColor = sheetBg;
            inkColor = theme == 2 ? 0xFFE7E5F0 : theme == 1 ? 0xFF4A3B2B : 0xFF433A54;
            tintColor = mix(bodyColor, inkColor, 0.05f);
            lineColor = (inkColor & 0x00FFFFFF) | 0x99000000;
            activeColor = accent;
            invalidate();
        }

        private int mix(int a, int b, float t) {
            int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
            int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
            int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
            return 0xFF000000 | (r << 16) | (g << 8) | bl;
        }

        /** True when the handle lives on the left edge (tray on the right): the same shape, mirrored. */
        void setOnLeft(boolean l) { if (left != l) { left = l; invalidate(); } }

        void setInsets(int top, int bottom) { insetTop = top; insetBottom = bottom; invalidate(); }

        void setPage(int p, int n) {
            page = p; pages = Math.max(1, n);
            if (shown || dragging) invalidate();
        }

        /** Scroll position of the book (0..1): moves the handle and brings it into view. */
        void onScroll(float f) {
            if (dragging) return;
            frac = f < 0f ? 0f : (f > 1f ? 1f : f);
            if (opened && total > 1) show(); else if (shown) invalidate();
        }

        void show() {
            if (total <= 1) return;
            shown = true;
            if (target != 1f) slideTo(1f, 170);
            keepAlive();
            invalidate();
        }

        private void slideTo(float to, long ms) {
            if (anim != null) anim.cancel();
            target = to;
            anim = android.animation.ValueAnimator.ofFloat(slide, to);
            anim.setDuration(ms);
            anim.setInterpolator(to > slide ? new android.view.animation.DecelerateInterpolator() : new android.view.animation.AccelerateInterpolator());
            anim.addUpdateListener(a -> { slide = (float) a.getAnimatedValue(); setAlpha(Math.min(1f, slide * 1.6f)); invalidate(); });
            anim.start();
        }

        private void keepAlive() {
            removeCallbacks(hideRun);
            if (!dragging && !pressed) postDelayed(hideRun, 1500);
        }

        private float trackH() { return Math.max(1f, getHeight() - insetTop - insetBottom); }

        private float thumbCy() { return insetTop + hh / 2f + frac * Math.max(0f, trackH() - hh); }

        private String label() { return page + "/" + pages; }

        private void bubbleRect(RectF r) {
            float bh = BH * k, bw = txt.measureText(label()) + 2 * PAD * k, cy = thumbCy(), g = GAP * k;
            if (left) r.set(hw + g, cy - bh / 2f, hw + g + bw, cy + bh / 2f);
            else r.set(getWidth() - hw - g - bw, cy - bh / 2f, getWidth() - hw - g, cy + bh / 2f);
        }

        private boolean hit(float x, float y) {
            float cy = thumbCy();
            if (shown) {
                boolean onHandle = (left ? x <= hw + dp(10) : x >= getWidth() - hw - dp(10)) && Math.abs(y - cy) <= hh / 2f + dp(10);
                bubbleRect(tmp);
                return onHandle || (tmp.contains(x, y));
            }
            // hidden: only a short stretch of the screen edge, at the handle's height, brings it back
            boolean edge = left ? x <= dp(24) : x >= getWidth() - dp(24);
            return edge && Math.abs(y - cy) <= dp(44);
        }

        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            if (w == 0 || h == 0 || total <= 1 || slide <= 0.01f) return;
            float cy = thumbCy();
            float off = (left ? -1f : 1f) * (1f - slide) * (hw + dp(24));
            // while dragging: small ticks at the edge show where the highlights are
            if (dragging) {
                List<MuAnnot> hs = view.highlights();
                if (!hs.isEmpty()) {
                    fill.setStyle(Paint.Style.FILL);
                    fill.setColor(0xE6F2B705);
                    for (int i = 0; i < hs.size(); i++) {
                        float y = insetTop + hh / 2f + view.pageFraction(hs.get(i).page0) * Math.max(0f, trackH() - hh);
                        if (left) tmp.set(0, y - dp(1.25f), dp(3), y + dp(1.25f));
                        else tmp.set(w - dp(3), y - dp(1.25f), w, y + dp(1.25f));
                        c.drawRoundRect(tmp, dp(1.25f), dp(1.25f), fill);
                    }
                }
            }
            c.save();
            c.translate(off, 0);
            // ---- bubble: "99/305"
            bubbleRect(rect);
            float bh = rect.height(), rad = bh / 2f;
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(bodyColor);
            c.drawRoundRect(rect, rad, rad, fill);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(3f)); line.setColor((inkColor & 0x00FFFFFF) | 0x12000000);   // faint halo instead of a shadow
            c.drawRoundRect(rect, rad, rad, line);
            line.setStrokeWidth(Math.max(1f, dp(0.9f))); line.setColor(lineColor);
            c.drawRoundRect(rect, rad, rad, line);
            txt.setColor(inkColor);
            c.drawText(label(), rect.left + PAD * k, rect.centerY() - (txt.ascent() + txt.descent()) / 2f, txt);
            // ---- handle (mirrored when it sits on the left edge)
            c.save();
            if (left) { c.translate(hw, cy - hh / 2f); c.scale(-1f, 1f); }
            else c.translate(w - hw, cy - hh / 2f);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(bodyColor);
            c.drawPath(body, fill);
            c.save();
            c.clipRect(BW * k, 0, hw + dp(2), hh);              // the flare into the edge is a touch darker
            fill.setColor(tintColor);
            c.drawPath(body, fill);
            c.restore();
            line.setStrokeWidth(dp(3f)); line.setColor((inkColor & 0x00FFFFFF) | 0x12000000);
            c.drawPath(body, line);
            line.setStrokeWidth(Math.max(1f, dp(0.9f))); line.setColor(lineColor);
            c.drawPath(body, line);
            // grip: three pairs of bars
            fill.setColor(dragging ? activeColor : inkColor);
            float bx0 = 48f * k, bx1 = 349f * k, bt = 37f * k, gp = 26f * k, mid = hh / 2f;
            for (int g = -1; g <= 1; g++) {
                float gy = mid + g * 237f * k;
                c.drawRect(bx0, gy - gp / 2f - bt, bx1, gy - gp / 2f, fill);
                c.drawRect(bx0, gy + gp / 2f, bx1, gy + gp / 2f + bt, fill);
            }
            c.restore();
            c.restore();
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    if (total <= 1 || !hit(e.getX(), e.getY())) return false;   // not on the handle: the page gets the touch
                    wasShown = shown && slide > 0.6f; pressed = true; moved = false;
                    downY = e.getY(); grabDy = e.getY() - thumbCy();
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    show();
                    return true;
                }
                case MotionEvent.ACTION_MOVE: {
                    if (!pressed) return false;
                    if (!moved && Math.abs(e.getY() - downY) > slop) {
                        moved = true; dragging = true;
                        view.setScrubbing(true);
                        performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
                    }
                    if (moved) {
                        float f = (e.getY() - grabDy - insetTop - hh / 2f) / Math.max(1f, trackH() - hh);
                        frac = f < 0f ? 0f : (f > 1f ? 1f : f);
                        view.scrollToFraction(frac);
                        invalidate();
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    if (!pressed) return false;
                    boolean wasDrag = dragging;
                    boolean tap = !moved && e.getActionMasked() == MotionEvent.ACTION_UP;
                    pressed = false; dragging = false;
                    if (wasDrag) view.setScrubbing(false);
                    keepAlive();
                    invalidate();
                    if (tap && wasShown) showJump();   // a tap on the handle / page number: go to page
                    return true;
                }
                default:
                    return false;
            }
        }
    }

    static final class IconView extends View {
        static final int BACK = 0, SEARCH = 1, MARK = 2, LIST = 3, SLIDERS = 4, UP = 5, DOWN = 6,
                PEN = 7, UNDERLINE = 8, STRIKE = 9, COPY = 10, NOTE = 11, SHARE = 12, TRASH = 13, MORE = 14, GOTO = 15,
                MARKER = 16, ERASER = 17, UNDO = 18, REDO = 19, CHECK = 20, POINTER = 21, THEME = 22, OPTIONS = 23;
        private final int kind;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF tmpRect = new RectF();
        private boolean filled = false;
        private float scale = 0.5f;

        IconView(Context c, int kind) {
            super(c);
            this.kind = kind;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(2f * c.getResources().getDisplayMetrics().density);
            p.setColor(Color.BLACK);
            setClickable(true);
            setBackgroundResource(android.R.drawable.list_selector_background);
        }

        void setColor(int c) { p.setColor(c); invalidate(); }
        void setFilled(boolean f) { filled = f; invalidate(); }
        void setScale(float s) { scale = s; invalidate(); }

        @Override protected void onDraw(Canvas cv) {
            float s = Math.min(getWidth(), getHeight()) * scale;       // icon box (24 units)
            float u = s / 24f;
            float ox = (getWidth() - s) / 2f, oy = (getHeight() - s) / 2f;
            cv.save();
            cv.translate(ox, oy);
            cv.scale(u, u);
            float sw = p.getStrokeWidth();
            p.setStrokeWidth(2f * getResources().getDisplayMetrics().density / u);
            Path path = new Path();
            switch (kind) {
                case BACK: {
                    boolean rtl = getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
                    if (rtl) { path.moveTo(9, 5); path.lineTo(16, 12); path.lineTo(9, 19); }
                    else { path.moveTo(15, 5); path.lineTo(8, 12); path.lineTo(15, 19); }
                    cv.drawPath(path, p); break;
                }
                case SEARCH:
                    cv.drawCircle(10.5f, 10.5f, 6.5f, p);
                    cv.drawLine(15.3f, 15.3f, 21f, 21f, p); break;
                case MARK: {
                    path.moveTo(6, 3.5f); path.lineTo(18, 3.5f); path.lineTo(18, 21); path.lineTo(12, 16.5f); path.lineTo(6, 21); path.close();
                    Paint.Style st = p.getStyle();
                    if (filled) p.setStyle(Paint.Style.FILL_AND_STROKE);
                    cv.drawPath(path, p);
                    p.setStyle(st); break;
                }
                case LIST:
                    cv.drawLine(8, 6, 21, 6, p); cv.drawLine(8, 12, 21, 12, p); cv.drawLine(8, 18, 21, 18, p);
                    cv.drawPoint(3.5f, 6, p); cv.drawPoint(3.5f, 12, p); cv.drawPoint(3.5f, 18, p); break;
                case SLIDERS:
                    cv.drawLine(4, 7, 20, 7, p); cv.drawLine(4, 17, 20, 17, p);
                    cv.drawCircle(9, 7, 2.4f, p); cv.drawCircle(15, 17, 2.4f, p); break;
                case UP:
                    path.moveTo(6, 15); path.lineTo(12, 9); path.lineTo(18, 15); cv.drawPath(path, p); break;
                case DOWN:
                    path.moveTo(6, 9); path.lineTo(12, 15); path.lineTo(18, 9); cv.drawPath(path, p); break;
                case PEN:
                    path.moveTo(15f, 4f); path.lineTo(20f, 9f); path.lineTo(11f, 18f); path.lineTo(6f, 13f); path.close();
                    cv.drawPath(path, p); cv.drawLine(4f, 21f, 20f, 21f, p); break;
                case UNDERLINE:
                    path.moveTo(7f, 4f); path.lineTo(7f, 11f); path.arcTo(new RectF(7f, 6f, 17f, 16f), 180f, -180f); path.lineTo(17f, 4f);
                    cv.drawPath(path, p); cv.drawLine(5f, 20.5f, 19f, 20.5f, p); break;
                case STRIKE:
                    path.moveTo(16f, 7.5f); path.cubicTo(15f, 5f, 9.5f, 4.5f, 8.5f, 8f); path.cubicTo(7.5f, 12f, 16.5f, 11f, 15.5f, 16f);
                    path.cubicTo(14.5f, 19.5f, 8.5f, 19.5f, 7.5f, 16.5f);
                    cv.drawPath(path, p); cv.drawLine(4f, 12f, 20f, 12f, p); break;
                case COPY:
                    tmpRect.set(9f, 9f, 20f, 20f); cv.drawRoundRect(tmpRect, 2.5f, 2.5f, p);
                    path.moveTo(6f, 15f); path.lineTo(6f, 7f); path.quadTo(6f, 5f, 8f, 5f); path.lineTo(15f, 5f); cv.drawPath(path, p); break;
                case NOTE:
                    tmpRect.set(4f, 4f, 20f, 17f); cv.drawRoundRect(tmpRect, 3f, 3f, p);
                    path.moveTo(9f, 17f); path.lineTo(9f, 21f); path.lineTo(13f, 17f); cv.drawPath(path, p);
                    cv.drawLine(8f, 9f, 16f, 9f, p); cv.drawLine(8f, 12.5f, 13f, 12.5f, p); break;
                case SHARE:
                    cv.drawCircle(18f, 5.5f, 2.6f, p); cv.drawCircle(6f, 12f, 2.6f, p); cv.drawCircle(18f, 18.5f, 2.6f, p);
                    cv.drawLine(8.3f, 10.8f, 15.7f, 6.7f, p); cv.drawLine(8.3f, 13.2f, 15.7f, 17.3f, p); break;
                case TRASH:
                    cv.drawLine(4f, 7f, 20f, 7f, p);
                    path.moveTo(9f, 7f); path.lineTo(9f, 4.5f); path.lineTo(15f, 4.5f); path.lineTo(15f, 7f);
                    path.moveTo(6.5f, 7f); path.lineTo(7.5f, 20f); path.lineTo(16.5f, 20f); path.lineTo(17.5f, 7f);
                    cv.drawPath(path, p); cv.drawLine(10f, 10.5f, 10f, 16.5f, p); cv.drawLine(14f, 10.5f, 14f, 16.5f, p); break;
                case MORE:
                    cv.drawCircle(5f, 12f, 1.3f, p); cv.drawCircle(12f, 12f, 1.3f, p); cv.drawCircle(19f, 12f, 1.3f, p); break;
                case GOTO:
                    cv.drawLine(4f, 12f, 19f, 12f, p);
                    path.moveTo(13f, 6f); path.lineTo(19f, 12f); path.lineTo(13f, 18f); cv.drawPath(path, p); break;
                case MARKER:
                    path.moveTo(14.5f, 3.5f); path.lineTo(20.5f, 9.5f); path.lineTo(11f, 19f); path.lineTo(5f, 13f); path.close();
                    cv.drawPath(path, p);
                    cv.drawLine(5f, 13f, 3.5f, 18.5f, p); cv.drawLine(3.5f, 18.5f, 9f, 17.5f, p);
                    cv.drawLine(12f, 21f, 21f, 21f, p); break;
                case ERASER:
                    path.moveTo(13.5f, 4f); path.lineTo(20.5f, 11f); path.lineTo(12f, 19.5f); path.lineTo(5f, 12.5f); path.close();
                    cv.drawPath(path, p);
                    cv.drawLine(8.8f, 8.8f, 16.6f, 16.6f, p); cv.drawLine(11f, 20.5f, 21f, 20.5f, p); break;
                case UNDO:
                    path.moveTo(9f, 6f); path.lineTo(4f, 11f); path.lineTo(9f, 16f);
                    cv.drawPath(path, p);
                    path.reset();
                    path.moveTo(4.5f, 11f); path.lineTo(14f, 11f); path.quadTo(20f, 11f, 20f, 16f); path.quadTo(20f, 19.5f, 16.5f, 19.5f);
                    cv.drawPath(path, p); break;
                case REDO:
                    path.moveTo(15f, 6f); path.lineTo(20f, 11f); path.lineTo(15f, 16f);
                    cv.drawPath(path, p);
                    path.reset();
                    path.moveTo(19.5f, 11f); path.lineTo(10f, 11f); path.quadTo(4f, 11f, 4f, 16f); path.quadTo(4f, 19.5f, 7.5f, 19.5f);
                    cv.drawPath(path, p); break;
                case POINTER:
                    path.moveTo(6f, 3.5f); path.lineTo(6f, 18.5f); path.lineTo(10f, 14.8f); path.lineTo(13f, 21f);
                    path.lineTo(15.8f, 19.7f); path.lineTo(12.9f, 13.6f); path.lineTo(18.5f, 13.4f); path.close();
                    cv.drawPath(path, p); break;
                case THEME: {
                    cv.drawCircle(12f, 12f, 8f, p);
                    Paint.Style st2 = p.getStyle();
                    p.setStyle(Paint.Style.FILL);
                    path.moveTo(12f, 4f); path.arcTo(new RectF(4f, 4f, 20f, 20f), -90f, 180f); path.close();
                    cv.drawPath(path, p);
                    p.setStyle(st2); break;
                }
                case OPTIONS:
                    tmpRect.set(4f, 4f, 10.5f, 10.5f); cv.drawRoundRect(tmpRect, 2f, 2f, p);
                    tmpRect.set(13.5f, 4f, 20f, 10.5f); cv.drawRoundRect(tmpRect, 2f, 2f, p);
                    tmpRect.set(4f, 13.5f, 10.5f, 20f); cv.drawRoundRect(tmpRect, 2f, 2f, p);
                    tmpRect.set(13.5f, 13.5f, 20f, 20f); cv.drawRoundRect(tmpRect, 2f, 2f, p); break;
                case CHECK:
                    path.moveTo(5f, 12.5f); path.lineTo(10f, 17.5f); path.lineTo(19f, 7f);
                    cv.drawPath(path, p); break;
                default: break;
            }
            p.setStrokeWidth(sw);
            cv.restore();
        }
    }

    @Override public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (view != null) view.trimMemory(level);
    }
}
